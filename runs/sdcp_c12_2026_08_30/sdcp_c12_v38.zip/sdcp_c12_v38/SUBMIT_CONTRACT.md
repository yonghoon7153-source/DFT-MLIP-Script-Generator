# 제출 계약 (SUBMIT_CONTRACT)

## 상 의존성
```
static  (같은 단계 안에서는 병렬 가능)   ← 이 묶음은 static 만 (dense 없음 · δ_k 설계 제외)
```
⛔ **잡 사이에 의존성이 있습니다** (이 묶음은 staged 구성입니다).
- canary(`*__nzmag`)는 `PARENT_GEOM` 이 가리키는 **부모 기체 기준의 최종 기하**를
  받습니다 — 부모가 먼저 완주해야 합니다.
- 2단계는 1단계 게이트 **8축**을 전부 통과해야 열립니다 (진공 수렴 · 분자 스핀 ·
  canary 기하 · POTCAR 신원 · 기체 상자 수렴 δ_gas · pm1 자기 topology ·
  잔여 차단 0 · 봉인이 계획 전체를 포괄).
순서는 `run_staged.sh` 가 강제합니다.

## 규모
| | |
|---|---:|
| 잡 | 19 |
| static 실행 | 19 |
| dense 실행 | 0 |
| 총 VASP 실행 | **19** |
| 상별 | static 19 |

⚠ **잡 수의 정본은 `find . -name run_job.sh | wc -l`** 입니다 (디스크에서 센 값).
`MANIFEST.planned` 도 같은 수를 냅니다 — 아래 census 가 두 수를 나란히 보여 줍니다.
⛔ 종전 문구는 *"planned 에는 D3-off 쌍둥이가 없으므로 적게 나온다"* 라고 적었는데
**거짓이었습니다** (회신 AY P1): 이 묶음은 D3-off 쌍둥이를 **0개** 만들고
(C3 는 D3-on OUTCAR 의 Edisp 로 냅니다 — 회신 AV P0-3), 실물·planned 둘 다 같습니다.

### census

- references 8 (끝점 8 + 쌍둥이 0)
- calibration complexes 8 (pose×seed 8 + 쌍둥이 0)
- audit pose 0
- pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 실행 (이 경로 하나뿐입니다)
```bash
cd <이 묶음을 푼 디렉터리>              # 묶음 **루트**

# ── POTCAR 원본 트리와 allowlist (조립기가 쓴다) ──
export PP=/path/to/potpaw_PBE.54
# allowlist 는 그 트리의 변형별 POTCAR 해시 목록입니다. 없으면 이렇게 만드십시오:
#   for v in $(ls "$PP"); do sha256sum "$PP/$v/POTCAR"; done > /abs/site_allow.txt
#   (형식: `<sha256>  <PP>/<variant>/POTCAR` — sha256sum 기본 출력 그대로)
export POTCAR_ALLOWLIST=/abs/site_allow.txt

# ── 배포본 결박 (ZIP 밖의 값이 유일한 앵커입니다) ──
export BUNDLE_ZIP_SHA256=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)
export EXPECT_MANIFEST_SHA256=<메일 본문의 MANIFEST SHA256>
export EXPECT_ZIP_SHA256=<메일 본문의 ZIP SHA256>

# ── 실행 방식 ──
# ⛔ 자유형 launcher 문자열(VASP_CMD·VASP_LAUNCHER)은 **폐지됐습니다** (회신 AV P0-2) —
#    문자열 검사는 우회가 가능해, 종류와 수만 받고 실행 명령은 러너가 조립합니다.
export VASP_LAUNCHER_KIND=mpirun            # mpirun|mpiexec|srun|none|wrapper
export LAUNCHER_BIN=/abs/path/to/mpirun     # **필수** — PATH 에서 찾지 않습니다. 없으면 exit 2
export VASP_NPROC=192                        # 랭크 수 (잡 하나당) — **KPAR × NCORE = 16 의 배수**여야 합니다
#    이 묶음의 INCAR 은 KPAR=4 · NCORE=4 로 고정했습니다. 쓸 수 있는 랭크: 48·64·96·128·192·256·384·512.
#    ⛔ KPAR 배수만으로는 부족합니다 — k-그룹당 랭크가 NCORE 로 안 나뉘면 VASP 가 조용히
#      NCORE 를 되돌립니다 (예: 랭크 20 은 KPAR 4 로 나뉘지만 그룹당 5 가 NCORE 4 로 안 나뉩니다).
#    배수가 아니면 러너가 **첫 VASP 실행 전에** 멈춥니다. INCAR 은 해시로 동결돼 고칠 수 없습니다.
#    ⚠ KPAR 은 k-그룹마다 배열 사본을 들어 **노드당 메모리가 늘어납니다.** 모자라면 랭크를
#      줄이지 마시고(배수 조건이 깨집니다) 노드를 늘려 주십시오.
export VASP_EXE=/abs/path/to/vasp_std       # 실행파일 절대경로 (봉인 대상)

# ── 메모리 배치 (**2026-09-04 OOM 재발 방지 · 필수**) ──
export NODE_MEM_GB=188          # 노드 하나의 메모리 [GB]
export VASP_NODES=4                        # 잡 하나를 **이만큼의 노드에 펼쳐** 주십시오
#    잡 하나가 노드 하나에 몰리면 최악 잡이 노드당 292.2 GB 를 요구해 OOM 납니다.
#    노드 4 개에 펼치면 노드당 73.1 GB (가용 159.8 GB 의 46 퍼센트) 로 내려갑니다.
#    필요한 총 노드 = 4 (노드/잡) x 4 (동시잡) = **16 노드**.
#    러너가 **첫 VASP 실행 전에** 이 값으로 계산해 보고, 넘치면 멈춥니다.
#    ⚠ 위 두 값은 **선언**입니다. 러너는 선언을 믿지 않고 관측과 대조합니다:
#      · 노드 메모리 — SLURM_MEM_PER_NODE · 이 작업에 적용된 cgroup 제한(계층 전부) · /proc/meminfo
#        중 **가장 작은 값**. 선언이 그보다 크면 멈춥니다 (선언으로 메모리를 늘릴 수 없습니다).
#      · 노드 수 — SLURM_JOB_NUM_NODES 또는 아래 VASP_HOSTFILE 의 고유 호스트 수와 대조.
#        잡당 노드 × 동시 잡이 할당을 넘으면 멈춥니다.
# export VASP_HOSTFILE=/abs/hosts.txt   # SLURM 밖에서 돌리실 때만: 할당 호스트를 한 줄에 하나씩
#    (SLURM 안에서는 SLURM_JOB_NODELIST 를 scontrol 로 풀어 자동으로 얻습니다.)
#    러너는 그 호스트들을 **동시 잡 수만큼 서로소 조각**으로 나눠 잡마다 hostfile 로 넘기고,
#    **첫 VASP 실행 전에** 같은 launcher·같은 플래그로 `hostname` 을 동시에 띄워 랭크가 실제로
#    어느 노드에 놓이는지 읽습니다 (노드 수 · 노드당 랭크 · 조각 안 · 잡 사이 겹침 없음).
#    어긋나면 멈추고, 결과는 PLACEMENT_PROBE.json 에 남습니다 — 반송 목록에 포함해 주십시오.
#    ⚠ MPI 구현은 `<launcher> --version` 으로 판별합니다 (Open MPI → -N · MPICH/Intel → -ppn).
#      판별이 안 되면 멈춥니다. Intel MPI 는 I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0 을 러너가 켭니다.

# ⚠ 러너는 기본으로 잡 4개를 **동시에** 띄웁니다 (= 4 × VASP_NPROC 랭크).
#    할당이 그보다 적으면:  export JOBS_PARALLEL=<동시에 돌릴 잡 수>

# (선택) PAW release 기록 — 첫 VASP 실행 **전에만** 가능 · 안 하셔도 러너·판정에 영향 없음.
#   위 export 들이 같은 셸에 있어야 합니다. 결함이면 러너가 생산 **전에** 멈춥니다 (지우면 다시 돌아갑니다).
#   RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" bash MAKE_POTCAR_ATTESTATION.sh

bash run_staged.sh 1     # census → POTCAR 조립+봉인 → 봉인 census → 1단계 → 판정
bash run_staged.sh 2     # 1단계 통과(STAGE1_PASS.json) 뒤에만
```
⛔ **전체를 배열로 한꺼번에 던지지 마십시오.** 위 의존성 때문에 결과가 무의미해집니다.
`run_all.sh` 는 이 묶음에 **넣지 않았습니다**.
⛔ `BUNDLE_ZIP_SHA256` 이 없으면 봉인 스크립트가 거부합니다 (번들 안에는 자기 해시를
넣을 수 없어 받으신 파일에서 직접 구해 주셔야 합니다).

## 수치 게이트 (이 값들이 결과 판정을 정합니다)

| 게이트 | 문턱 | 뜻 |
|---|---:|---|
| 진공 두께 수렴 Δ_vac | 5 meV | 셀 두 높이의 대비 차 |
| 기체 상자 수렴 δ_gas | 5 meV | box20↔box24 **두 조각의 차** |
| k 격자 수렴 δ_k | **이 번들 설계에 없음** | dense 를 돌리지 않습니다 — 0.01 eV 안정성은 **주장하지 않습니다**. 재개 조건: 재개하지 않는다. |D_raw| < 0.05 eV 는 프로토콜 §7 미해결 · §8 '계산을 확장하지 않는다'. |D_raw| ≥ 0.05 eV 면 k 가드밴드(0.01 eV)가 부호·판정을 못 바꾼다. 경계 구간 0.05 ≤ |D_raw| < 0.06 eV 에서는 분석기가 KCONV_UNTESTED_AXIS_AT_THRESHOLD 자문을 내고 원고는 '미시험 축에 판정이 민감하다' 를 적는다 — 계산은 추가하지 않는다. |
| 자기 basin 일치 | 정확 일치 | 비교하는 두 복합체의 Ni 부호 배열 (전역 반전은 동치) |

⚠ 수치 게이트는 **조각별이 아니라 두 조각의 차**에 겁니다. 조각별로 각각 작아도
부호가 반대면 차에서 두 배가 되기 때문입니다.

## 반송 목록

**정본은 `MANIFEST.json` 의 `return_contract`** 이며 이 목록은 그 렌더입니다
(README 와 SUBMIT_CONTRACT 어디를 보셔도 같습니다 — 회신 AV P0-4).

**보내는 방법**: 가장 쉬운 방법 — 푼 디렉터리를 **통째로** 다시 압축해 보내 주십시오 (배포 입력·MANIFEST 포함 · 위 목록이 자동으로 충족됩니다). 예: `tar --exclude=CHGCAR --exclude=WAVECAR --exclude=POTCAR -czf 반송.tgz <푼 디렉터리>`  ⛔ **POTCAR 는 반드시 빼 주십시오** (라이선스 — 2026-09-07 Codex v37 P1-2). 종전 명령은 CHGCAR·WAVECAR 만 빼서 조립된 POTCAR 가 딸려 왔습니다. 증빙인 `POTCAR_PROVENANCE.json` · `POTCAR_ROOT_SEAL.json` · `EXECUTABLE_RECEIPT.tsv` 는 **그대로 두십시오** — 그게 판정에 쓰이는 것이고, POTCAR 원문은 저희가 받으면 안 되는 것입니다.

각 잡 폴더에서:
- static/OUTCAR (또는 .gz)
- static/OSZICAR
- static/POSCAR — **실행된 기하** (부모↔canary 기하 대조·기하 감사. 없으면 CANARY_GEOM_UNCHECKED 로 막힙니다)
- POTCAR_PROVENANCE.json (조립기가 자동 생성)
- job.json (받으신 그대로 — 분석기가 잡의 정체·상 목록을 이것으로 읽습니다 · 없으면 그 잡은 차단)
- EXECUTABLE_RECEIPT.tsv — 상별 실행파일 해시 (run_staged 경로가 자동 생성 · 분석기가 root seal 과 대조합니다)

묶음 루트에서:
- MANIFEST.json (받으신 그대로 — 분석기가 가장 먼저 읽습니다)
- POTCAR_ROOT_SEAL.json (첫 실행 전 봉인)
- ZIP_SHA256.txt
- RESULTS.json (run_staged 가 판정 때 만듦 — 있으면 그대로)
- PLACEMENT_PROBE.json — 첫 VASP 전 배치 프로브 기록 (2026-09-08 · 랭크가 실제로 어느 노드에 놓였는지 · 잡 사이 겹침 없음의 증거)
- STAGE1_PASS.json (1단계 통과 receipt)
- POTCAR_ATTESTATION.json — **선택** (탐색용 정책). 없어도 러너는 돌아갑니다. ⚠ 다만 그 결과는 **원고 인용 자격이 없습니다** — 사후 provenance 는 무엇을 썼는지만 기록하고 그것이 승인된 PAW dataset 인지 판정하지 못합니다 (회신 AZ P0-7·Q4). 만들려면 `MAKE_POTCAR_ATTESTATION.sh` 를 **첫 VASP 실행 전에만** 돌릴 수 있습니다 (회신 AR P0-6)

보내지 않으셔도 되는 것: CHGCAR·WAVECAR (용량 — 압축에서 빼셔도 됩니다 · ⚠ 서버에서는 지우지 말고 두십시오) · vasprun.xml (선택)
⚠ 발산·미수렴 잡도 지우지 말고 그대로 보내 주십시오 — 실패도 판정의 일부입니다

⚠ **공통 POTCAR 를 전 잡에 복사하면 안 됩니다** (직접 조립할 일도 없습니다 — 러너가 합니다).
조각마다 POSCAR 종 순서가 달라 (`C F` · `Li Ni O` · `Li Ni O C F` · `Li Ni O S C H` · `O S C H`) 하나를 돌려 쓰면 그 잡은 조용히 **다른 계**를
계산합니다. `SEAL_POTCAR_ROOT.sh` 가 첫 실행 전에 전 잡을 조립하고 TITEL 순서까지 검증합니다.
⚠ **walltime — 요청은 단계 기준 하나입니다.** `run_staged.sh` 는 계산노드 할당 **안에서**(로그인 노드 아님) 그 단계의 잡 전부를 동시 4잡 × VASP_NPROC 랭크로 돌리므로, 할당은 **그 단계가 끝날 때까지** 유지돼야 합니다. 잡 하나하나가 짧아도 단계 합이 넘으면 **할당이 먼저 잘립니다.**
   · 단계 할당 (러너의 실제 순서로 계산 — 경로 사전순 FIFO + 물결 장벽): 중앙 추정 1단계 55.6 h · 2단계 51.5 h / NELM 시나리오 1단계 148.2 h · 2단계 137.4 h
   ⇒ **단계당 156 h** 를 요청해 주십시오 (NELM 시나리오 최대를 12 h 단위로 올림). ⚠ 이 수도 보장이 아닌 **계획값**입니다 — 여유를 더 둘지는 귀측 큐 정책의 선택이고, NELM 으로 입증되는 것이 아닙니다.
   ⛔ 알려 주신 잡당 큐 상한 **91 h 로는 충족되지 않습니다.** 더 긴 할당이 가능한지, 아니면 완료된 잡 사이에서 단계를 이어갈 운영 방식이 있는지 **제출 전에** 알려 주십시오. VASP 를 중간에 끊거나 잡을 쪼개는 방식은 안 됩니다 — static 단일점은 나눌 수 없고 재개도 없습니다.
   참고 (요청값 아님): 가장 긴 잡의 중앙 추정 **29 h** (192코어/잡 · 모형 ±2배 → 외피 58 h). 가정한 스텝수 대신 `NELM=200` 번을 다 돌면 가장 긴 잡이 **77 h** 입니다 (잡당 큐 상한 91 h 아래입니다 (여유 14 h)). ⛔ 다만 NELM 이 묶는 것은 **횟수**이지 시간이 아닙니다 — 스텝당 시간이 바로 ±2배인 그 양이라 이 수도 같은 폭을 안고 있고, **보장이 아닙니다**. 종전 문서의 *'결정론적 상한'* 표현은 **철회합니다**. 봉인 프로브도 같은 노드에서 VASP 를 인자 없이 한 번 잠깐 기동합니다.
⚠ **전체 일정** — 동시 4잡 기준 약 **4.14일**입니다 (1단계 최장 28.9 h → 게이트 → 2단계 최장 26.0 h · 두 단계는 **직렬**이라 동시 실행을 늘려도 이 아래로는 내려가지 않습니다). 여기에 1단계 반송 뒤 저희 판정 왕복 시간은 포함돼 있지 않습니다.
💡 **먼저 한 잡만 재 보시길 권합니다.** 위 추정은 모형이라 ±2배입니다. 큐 상한이 빠듯하시면 `refs/` 의 기체 잡 하나(가장 짧습니다)나 복합체 한 잡을 먼저 돌려 실제 벽시계를 알려 주시면, 나머지 walltime 을 그 값으로 다시 잡아 드립니다. 1단계 전체를 던진 뒤 큐에서 잘리는 것보다 쌉니다 — 잘린 잡은 재개할 수 없어 통째로 다시 돌려야 합니다.

## 비용 추정의 출처
- 모델: `tools/sdcp/vasp_cost_estimate.py` — 2026-08-08 납품 `slab/OUTCAR.gz`
  (192원자 · NKPTS 4 · 48코어 · 30,438 s / 58 전자스텝 = **525 s/스텝**)
- **±2배 불확실성**을 인정하는 모델입니다. 계약값이 아니라 계획용 수치입니다.
- `python3 tools/sdcp/vasp_cost_estimate.py --manifest MANIFEST.json --concurrent 4`
  로 이 번들의 실제 계획에서 다시 계산하세요.
- ⚠ **aggregate 시간 ÷ 동시 실행 수**는 산술 하한입니다. 이 묶음은 static 만이라 가장 긴 잡 하나가 임계경로입니다 — 동시 4잡이면 약 4.14일.

## 코어 수
이 번들은 **192 코어/잡 · 동시 4잡**으로 계획했습니다
(MANIFEST.json 의 `submission`). 실제와 다르면 추정이 그만큼 어긋납니다 —
알려 주시면 `--manifest` 로 다시 계산합니다.
