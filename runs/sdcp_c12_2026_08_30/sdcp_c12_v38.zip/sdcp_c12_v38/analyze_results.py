#!/usr/bin/env python3
"""analyze_results.py v3 — VASP 완주 후 이거 **하나**로 회수 (stdlib only).

  python3 analyze_results.py <bundle_dir> [--delta 0.030]

판정 에너지 = **static/OUTCAR 만**. 전 검사는 fail-closed 다 — 확인 못 한 것은
통과가 아니라 게이트다 (2026-08-11 Codex 재검토 P0-C/D/E/G/H).

  잡: MANIFEST 해시(입력 무결성) / 상별 정상종료 / 전자수렴 / relax 이온수렴 /
     POTCAR TITEL(반도체준위 변형은 치명) / 힘 블록 존재·원자수 / 등록(표면 양이온만)
     / 결합 그래프 / 탈착 / 고정원자 drift / **Ni 국소 모멘트·부호 패턴**
  쌍: PAIR_MIGRATED · PAIR_COLLAPSED(주기 RMSD + 접촉 지문) ·
     seed-매칭 |ΔE_pm1−ΔE_net4| ≤ 10 meV
  수치(**게이트다 — 실패하면 E_ads/판정을 만들지 않는다**):
     상자 20↔24 Å ≤ 10 meV (정본은 box24) · dense-k ΔE·E_ads ≤ 10 meV
exit 0 = 필수(tier1+refs) 완결 · exit 2 = 필수 산출 누락/무결성 실패 (fail-closed).

이 도구가 **못 하는 것**
  · 자기바닥상태를 찾아 주지 않는다. 두 seed 가 같은 basin 으로 무너졌는지
    모멘트 부호 패턴으로 **알려만** 준다.
  · POTCAR 파일 자체를 검증하지 못한다 (라이선스로 미포함) — OUTCAR 의 TITEL 만 본다.
  · 유한셀 보정(전하·쌍극자 상호작용)을 하지 않는다. 상 사이 비교용이다.
"""
import gzip, hashlib, json, math, os, pathlib, re, sys

# ── GOV_CORE (생성기 `GOV_CORE_SRC` 와 바이트 동일 — 사본이 아니라 같은 소스다) ──────
def dec_digest(x):
    """decision 한 건의 내용 digest — `ratification` 칸을 뺀 나머지의 sha256."""
    _c = {k: v for k, v in (x or {}).items() if k != "ratification"}
    return hashlib.sha256(json.dumps(_c, sort_keys=True, ensure_ascii=False)
                          .encode("utf-8")).hexdigest()


def ratification_record_problems(rt, digest_field="content_digest"):
    """비준 기록(`ratification`)의 **형식** 위반 목록. → list[str] (빈 리스트 = 통과)

    🔴 회신 BG P1-1 — 이 검사가 참조 문서(`ref_doc_state`)에만 있고 `decisions.json`
      원문 검사에는 없었다. 거기서는 사실상 `state=="ratified"` 만 봐서 actor·시각·role
      이 전부 없는 기록도 비준으로 통과했다 (리뷰어 재현: `{state, decision_digest}` 두
      칸만 남겨도 strict·bytes 둘 다 ok). 규약을 두 벌 두면 반드시 갈라지므로 한 함수다.
    ⛔ 못 하는 것: actor 가 **실재하는 사람인지**, 시각이 참인지는 모른다 — 형식만 본다.
      그 앵커는 사람 확인 몫이다.
    """
    bad = []
    if not isinstance(rt, dict):
        return ["비준 기록이 객체가 아니다 (%s)" % type(rt).__name__]
    _actor = rt.get("by") or rt.get("actor_id")
    _when = rt.get("at") or rt.get("timestamp")
    if not (isinstance(_actor, str) and _actor.strip()):
        bad.append("actor(by/actor_id) 없음")
    if not (isinstance(_when, str) and _when.strip()):
        bad.append("timestamp(at/timestamp) 없음")
    if not (isinstance(rt.get("state"), str) and isinstance(rt.get("role"), str)):
        bad.append("state/role 이 문자열이 아니다")
    if rt and not isinstance(rt.get(digest_field), str):
        bad.append("%s 가 문자열이 아니다" % digest_field)
    return bad


def ref_doc_state(path):
    """참조 문서의 비준 상태 → dict. **`content_digest` 를 재계산해 대조한다.**

    ⛔ 못 하는 것: 그 문서의 *내용*이 옳은지는 안 본다 — 비준 결박만 본다.
    """
    _p = os.fspath(path)
    if not os.path.isfile(_p):
        return {"status": None, "ratified": False, "why": "파일 없음"}
    try:
        with open(_p, encoding="utf-8") as _fh:
            _j = json.load(_fh)
    except Exception:                                        # noqa: BLE001
        return {"status": None, "ratified": False, "why": "JSON 파싱 실패"}
    if not isinstance(_j, dict):
        return {"status": None, "ratified": False, "why": "JSON 최상위가 객체가 아니다"}
    # ⚠ 상태 칸 이름이 문서마다 다르다 — protocol 은 `지위` 에만 적혀 있다.
    _st = _j.get("status") or _j.get("지위")
    _rt = _j.get("ratification")
    # 🔴 회신 BF P0-4·P1 — 비준 기록은 **dict 이고 필수 필드·타입**을 갖춰야 한다.
    #   종전엔 사실상 state=="ratified" 만 봤고, 기록이 list/문자열이면 예외로 죽었다.
    if _rt is None:
        _rt = {}
    if not isinstance(_rt, dict):
        return {"status": _st, "ratified": False, "superseded": False,
                "has_ratification_record": False, "digest_recomputed": dec_digest(_j),
                "digest_recorded": None, "digest_matches": False,
                "why": "비준 기록이 객체가 아니다 (%s) — 형식 위반 (BF P0-4)" % type(_rt).__name__}
    _rt_bad = ratification_record_problems(_rt)
    # ⛔ 회신 BB P0-4 — 폐기 표시가 `지위` 같은 다른 칸에 있을 수 있다.
    _sup = any(isinstance(v, str) and
               ("SUPERSEDED" in v.upper() or "철회" in v or "폐기" in v)
               for k, v in _j.items() if k in ("지위", "status", "state", "성격"))
    # ⛔⛔ 회신 BC P0-2 — **digest 를 재계산한다.** 종전엔 상태 문자열과 role 만
    #   보고 `ratified` 를 냈다. 비준을 받아 놓고 내용을 고친 문서가 그대로
    #   통과했고, 그러면 digest 를 적어 둔 의미가 없다.
    _dg = dec_digest(_j)
    _rec = str(_rt.get("content_digest") or "").split(":")[-1]
    _dg_ok = bool(_rec) and _rec == _dg
    _ok = (_st in ("ratified", "active")
           and _rt.get("state") == "ratified"
           and _rt.get("role") == "scientific_owner"
           and _dg_ok and not _sup and not _rt_bad)
    return {"status": _st, "ratified": bool(_ok), "superseded": bool(_sup),
            "has_ratification_record": bool(_rt) and not _rt_bad,
            "record_problems": _rt_bad,
            "digest_recomputed": _dg, "digest_recorded": _rec or None,
            "digest_matches": _dg_ok,
            "why": (None if _ok else
                    ("⛔ SUPERSEDED/철회 문서다" if _sup else
                     "비준 기록 형식 위반: %s (BF P0-4)" % "; ".join(_rt_bad) if (_rt and _rt_bad) else
                     "비준 기록에 `content_digest` 가 없다" if not _rec else
                     "**비준 이후 내용이 바뀌었다** (기록 %s… ≠ 재계산 %s…)"
                     % (_rec[:12], _dg[:12]) if not _dg_ok else
                     "status=%r · 사람 비준 기록 %s — 이 문서가 정의하는 주장은 "
                     "아직 닫히지 않았다" % (_st, "있음" if _rt else "**없음**")))}


# ── KCONV_CORE (2026-09-03 · 렌즈2 P0-1/P1-2/P1-3 · 렌즈4 P0-2 · 렌즈5 P1-1) ──────────────
#   δ_k 축 **설계 제외**의 법적 근거는 비준 사전등록 `3_오차예산` 의 `축_설계_제외_*` 항이다.
#   그 항이 없으면 50행("축이 하나라도 없으면 INCOMPLETE")이 그대로 적용된다 — 코드가 비준
#   문서보다 관대해질 수 없다. 생성기(--no_kconv)는 그 항의 재개 조건을 MANIFEST 로 **복사**하고,
#   분석기는 번들에 실린 사전등록 사본에서 같은 항을 읽어 **같은지** 본다. 재개 조건은 문장이
#   아니라 기계 평가 가능한 구조여야 한다 (판정량 D_raw_eV · 문턱 · 비교 · 충족시).
C12_PREREG_REL = "db/properties/sdcp_c12_claim_prereg_2026_08_31.json"
KCONV_REOPEN_CMP = ("abs_lt", "boundary", "none")


def _prereg_axis_exclusion(man, axis="δ_k"):
    """비준 사전등록에서 `3_오차예산.축_설계_제외_*` (해당 축) 항 → (entry|None, key|None, 사유|None).

    ⚠ 원문은 ① `man["_prereg_doc"]` (dict — 생성기·픽스처가 직접 준다) ② 번들에 실린 사본
      (`_bundled_ref_path`, 분석기) 순서로 찾는다. 둘 다 없으면 '없음' 이고 그것은 통과가 아니다.
    """
    pj = (man or {}).get("_prereg_doc")
    if not isinstance(pj, dict):
        try:
            f, why = _bundled_ref_path(man, C12_PREREG_REL)      # noqa: F821 (분석기 안에 있다)
        except NameError:
            return None, None, "사전등록 원문을 읽을 경로가 없다 (_prereg_doc 도 번들 사본도 없다)"
        if f is None:
            return None, None, why
        try:
            with open(f, encoding="utf-8") as _fh:
                pj = json.load(_fh)
        except Exception as e:                                   # noqa: BLE001
            return None, None, "사전등록 원문 파싱 실패 (%r)" % (e,)
    sec = pj.get("3_오차예산") or {}
    for k in sorted(sec):
        v = sec.get(k)
        if (str(k).startswith("축_설계_제외") and isinstance(v, dict)
                and str(v.get("축") or "") == axis):
            return v, k, None
    return None, None, ("사전등록 3_오차예산 에 %s 의 '축_설계_제외_*' 항이 없다 — 50행(축이 하나라도 "
                        "없으면 INCOMPLETE)이 그대로 적용된다" % axis)


def _kconv_reopen_rule_problems(rule):
    """재개 조건 dict 의 **형식** 위반 목록 — 기계 평가 가능해야 한다 (렌즈2 P1-2). 빈 리스트 = 통과."""
    bad = []
    if not isinstance(rule, dict):
        return ["재개 조건이 dict 가 아니다 (%s)" % type(rule).__name__]
    if not str(rule.get("규칙") or "").strip():
        bad.append("규칙 문장이 비었다")
    if str(rule.get("판정량") or "") != "D_raw_eV":
        bad.append("판정량은 'D_raw_eV'(pm1 primary 조건부 D · 반올림 전) 여야 한다 (지금 %r)"
                   % (rule.get("판정량"),))
    _c = str(rule.get("비교") or "")
    if _c not in KCONV_REOPEN_CMP:
        bad.append("비교 는 %s 중 하나여야 한다 (지금 %r)" % (KCONV_REOPEN_CMP, rule.get("비교")))
    if _c and _c != "none":
        try:
            if not (float(rule.get("문턱_eV")) > 0):
                bad.append("문턱_eV 는 양수여야 한다")
        except (TypeError, ValueError):
            bad.append("문턱_eV 가 수가 아니다 (%r)" % (rule.get("문턱_eV"),))
        if not str(rule.get("충족시") or "").strip():
            bad.append("충족시 행동이 비었다")
    if _c == "boundary":
        try:
            if not (float(rule.get("가드밴드_eV")) > 0):
                bad.append("가드밴드_eV 는 양수여야 한다")
        except (TypeError, ValueError):
            bad.append("boundary 비교는 가드밴드_eV 가 필요하다 (%r)" % (rule.get("가드밴드_eV"),))
    return bad


def _kconv_reopen_eval(rule, d_raw):
    """선언된 재개 조건을 D_raw 에 **기계로** 댄다 → {판정량·값·비교·문턱·충족·행동}."""
    out = {"판정량": "D_raw_eV", "값_eV": (None if d_raw is None else round(float(d_raw), 6)),
           "비교": rule.get("비교"), "문턱_eV": rule.get("문턱_eV"),
           "가드밴드_eV": rule.get("가드밴드_eV"), "충족": None, "행동": None}
    if d_raw is None:
        out["행동"] = "D_raw 가 없어 평가 불가"
        return out
    a = abs(float(d_raw))
    _c = str(rule.get("비교") or "")
    if _c == "none":
        out["충족"] = False
        out["행동"] = "재개 조건 없음(선언) — %s" % (rule.get("규칙") or "")
    elif _c == "abs_lt":
        out["충족"] = bool(a < float(rule["문턱_eV"]))
        out["행동"] = (str(rule.get("충족시")) if out["충족"] else "조건 불충족 — 추가 계산 없음")
    elif _c == "boundary":
        # ⚠ 렌즈6′ P2 — eV 부동소수로 하면 0.05+0.01 = 0.060000000000000005 라 |D|=0.06 이
        #   "< 0.06" 인데도 충족이 된다. **meV 정수 근방**에서 비교한다 (선언과 같은 뜻).
        t, g = float(rule["문턱_eV"]), float(rule["가드밴드_eV"])
        _am, _tm, _gm = round(a * 1000, 3), round(t * 1000, 3), round(g * 1000, 3)
        out["충족"] = bool(_tm <= _am < _tm + _gm)
        if out["충족"]:
            out["행동"] = str(rule.get("충족시"))
        elif a < t:
            out["행동"] = "|D_raw| < 문턱 — 프로토콜 §7 미해결 영역 · §8 확장 금지 (재개 대상 아님)"
        else:
            out["행동"] = "|D_raw| ≥ 문턱+가드밴드 — 미시험 축이 판정을 못 바꾼다 · 추가 계산 없음"
    return out
# ── /KCONV_CORE ────────────────────────────────────────────────────────────────
# ── /GOV_CORE ─────────────────────────────────────────────────────────────────
from glob import glob

# ⛔⛔ 회신 AR P1-12 / 2026-08-31 실측 — **표준출력 인코딩**도 실패 지점이다.
#   파일 IO 를 전부 utf-8 로 박았는데도 gabia 에서 `LC_ALL=C` 로 돌리자
#   `UnicodeEncodeError: 'ascii' codec can't encode character '\u2713'` 로 죽었다.
#   ✓/⛔/한글이 **print 될 때** 죽는 것이고, Windows cp949 기본값이 같은 모양이다.
#   ⚠ 내 selftest 가 이걸 놓친 이유: 환경에 `PYTHONIOENCODING=utf-8` 을 같이
#     넣어서 stdout 만 살려 놓고 통과시켰다 — 양성만 있는 시험의 전형이다.
for _std in (sys.stdout, sys.stderr):
    try:
        _std.reconfigure(encoding="utf-8", errors="replace")
    except Exception:                                    # noqa: BLE001
        pass                                             # 3.6 이하 · 리다이렉트된 스트림

DELTA = 0.030
SEED_TOL = 0.010          # eV — seed-매칭 ΔE 게이트
BOX_TOL = 0.010           # eV — 기체상 **조각별** 상자 수렴 (진단용)
#: ⛔ 회신 AP #11 — 판정은 조각별이 아니라 **두 기체의 차**에 건다. D 에 남는 것이
#:   그 차이기 때문이다. 0.01 eV 보고를 유지하려면 5 meV 다 (AP 가 지정한 사전 문턱).
GAS_BOX_DELTA_TOL = 0.005
K_TOL = 0.010             # eV — dense-k 민감도
GUARD_EV = 0.010          # ±10 meV — k 전이 불확실성. **30 meV 판정바닥과 별개다**
                          #   (Codex 5차: 두 숫자를 하나로 합치면 경계 결과를 오판한다)
RMSD_TOL = 0.75           # Å — 두 끝점이 같은 basin 인가 (0.50/1.00 민감도도 같이 뽑는다)
CONTACT_A = 3.0           # Å — 접촉 지문 반경
FP_JACCARD = 0.80         # 접촉 지문 겹침 — 경계 원자 하나로 뒤집히지 않게 완전일치 대신
#: 실행 INCAR echo 로 대조할 키. 생성부의 AUDIT_KEYS 와 **같은 목록이어야 한다** —
#:  둘이 따로 적혀 있어 한쪽만 늘리면 조용히 갈린다 (Codex 5차 P1-3).
#:  물리 규약 키(LASPH/ADDGRID/ISYM/NUPDOWN/LDAUU)도 넣어 외주처의 우발적 수정을 잡는다.
AUDIT_KEYS_RUNTIME = ("ENCUT", "ISMEAR", "IVDW", "LREAL", "ISTART", "ICHARG", "LDIPOL",
                      "LASPH", "ADDGRID", "ISYM", "NUPDOWN", "LDAUU", "LDAUTYPE", "IDIPOL",
                      "ISPIN", "LDAUL", "LDAUJ", "MAGMOM", "LDAU", "LMAXMIX",
                      # 🔴 회신 AB P0-5 — `_spin_setup_ok()` 가 이 넷을 검사하는데
                      #   여기 없어서 `read_outcar()` 가 **아예 안 읽었다**. 손으로 만든
                      #   dict 를 넣는 단위시험은 통과하고 실제 OUTCAR 경로에서는
                      #   검사가 통째로 꺼져 있었다 (전형적인 가짜 초록).
                      #   ⚠ 넷 다 **미출력이 기본값**이다: VASP 는 기본값이면 안 찍는
                      #     경우가 있어 None 이 곧 "안전한 기본" 이다. 그래서
                      #     _spin_setup_ok 은 None 을 통과로 본다 — 그 해석을 여기 적어
                      #     둔다(안 적으면 다음 사람이 fail-closed 로 바꿔 전 잡을 막는다).
                      "LNONCOLLINEAR", "LSORBIT", "I_CONSTRAINED_M", "BEXT")

# ── 되울림 형식 3종 (2026-08-25 실측, wave1 43개 OUTCAR) ─────────────────────
#   ① 행두형: `   ENCUT  =  520.0 eV …` · `   NUPDOWN=      -1.0000` (= 앞 공백 0개 허용)
#   ② 산문형: LDA+U 계열은 행 **중간**에 있다 —
#        ` LDA+U is selected, type is set to LDAUTYPE =  2`
#        `   U (eV)           for each species LDAUU =   0.0  6.2  0.0  0.0  0.0`
#      행두 앵커로는 한 줄도 안 잡힌다. 고정 산문을 앵커로 쓴다.
#   ③ 미되울림: MAGMOM · ADDGRID 는 OUTCAR 어디에도 없다(grep 0건) —
#      **원리적으로 검증 불가**이므로 영원히 unverified 로 보고한다 (조용한 통과 금지).
_ECHO_PROSE = {
    "LDAUTYPE": r"type is set to LDAUTYPE\s*=\s*(\S+)",
    "LDAUL": r"for each species LDAUL\s*=\s*([^\n]+)",
    "LDAUU": r"for each species LDAUU\s*=\s*([^\n]+)",
    "LDAUJ": r"for each species LDAUJ\s*=\s*([^\n]+)",
}
_ECHO_ABSENT = ("MAGMOM", "ADDGRID")

# ── OUTCAR 되울림 ↔ INCAR 선언 대조 (2026-08-25) ─────────────────────────────
#   VASP 는 INCAR 표기를 그대로 되울리지 않는다: 520 → `520.0`, `.TRUE.` → `T`,
#   `Auto` → `T`. 문자열 비교로는 전부 불일치로 잡혀 게이트가 30/30 오탐을 냈다.
_TRUE = {"T", "TRUE", ".TRUE."}
_FALSE = {"F", "FALSE", ".FALSE."}
#   LREAL 은 Auto·On·A·O 가 전부 "실공간" 이고 되울림은 `T` 하나뿐이다.
_LREAL_REAL = {"AUTO", "A", "ON", "O"} | _TRUE
_LREAL_RECIP = set(_FALSE)


def _echo_val(text, key):
    """OUTCAR 의 **파라미터 줄**에서 key 의 값을 읽는다 (산문·경고문 제외).

    행두형은 행두 공백 앵커로(권고 상자는 `|` 시작이라 걸러진다), LDA+U 계열은
    고정 산문 앵커로 읽는다(행 중간이라 행두 앵커가 못 잡는다 — 2026-08-25 실측).
    목록 키는 **줄 끝까지** 캡처해 공백 정규화한다 — 한 토큰만 읽으면
    `LDAUU = 0.0 6.2 0.0` 이 `0.0` 으로 잘려 실제 U 차이를 못 잡는다 (codex E-1).

    이 함수가 못 하는 것: MAGMOM·ADDGRID 는 OUTCAR 가 되울리지 않아 **원리적으로
    None** 이다 — 호출부가 unverified 로 보고한다 (통과도 실패도 아니다).
    """
    if key in _ECHO_ABSENT:
        return None
    if key == "LDAU":
        # 직접 되울림 줄이 없다 — "LDA+U is selected" 산문의 존재가 곧 T 다 (실측).
        # ⚠ 켜져 있을 때만 판별 가능: .FALSE. 는 산문이 없어 None(unverified)로 남는다.
        return "T" if "LDA+U is selected" in text else None
    pat = _ECHO_PROSE.get(key)
    if pat:
        m = re.search(pat, text)
        return " ".join(m.group(1).split()) if m else None
    m = re.search(r"^[ \t]{0,8}" + key + r"\s*=\s*([-\w.]+)", text, re.M)
    return m.group(1) if m else None


def _incar_match(key, got, want):
    """되울림 got 과 선언 want 대조 → (일치 여부, 종류).

    종류 (codex E-2 분류):
      "exact"             — 같은 값 (표기 차이만: 520.0↔520, T↔.TRUE., 목록 원소별)
      "equivalence_class" — **같은 값임을 보증 못 하고 같은 계열임만 보증**.
                            LREAL 의 Auto/On/.TRUE. 는 알고리즘이 서로 다른데
                            VASP 가 전부 `T` 로만 되울려 계열까지만 갈라진다.
      "mismatch"          — 다르다.

    수치는 **Decimal** 로 비교한다 (codex E-1) — float 는 `1e309` 가 inf 로 붙어
    서로 다른 두 값이 같아질 수 있고, 큰 정수에서 정밀도를 잃는다.
    비유한값(inf/nan 표기)은 일치로 치지 않는다.
    """
    from decimal import Decimal, InvalidOperation

    def _nonfinite(s):
        for tok in s.split():
            try:
                if not Decimal(tok).is_finite():
                    return True
            except (InvalidOperation, ValueError):
                pass
        return False

    g, w = str(got).strip(), str(want).strip()
    # ⚠ 비유한값 검사가 문자열 지름길보다 **먼저**다 — "inf"=="inf" 가 문자열로
    #   같아서 통과해 버리면 이 가드는 죽은 코드가 된다 (selftest 가 실제로 잡았다).
    if _nonfinite(g) or _nonfinite(w):
        return False, "mismatch"
    gu, wu = g.upper(), w.upper()
    if gu.strip(".") == wu.strip("."):          # .TRUE. ↔ TRUE 도 여기서 걸린다
        return True, "exact"
    if key == "LREAL":
        known = _LREAL_REAL | _LREAL_RECIP
        if gu in known and wu in known:
            same = (gu in _LREAL_REAL) == (wu in _LREAL_REAL)
            return (True, "equivalence_class") if same else (False, "mismatch")
        return False, "mismatch"
    if gu in _TRUE | _FALSE and wu in _TRUE | _FALSE:
        return ((gu in _TRUE) == (wu in _TRUE)), "exact"
    try:                                         # 520.0 ↔ 520 · LDAUU 목록도 원소별
        gd = [Decimal(x) for x in g.split()]
        wd = [Decimal(x) for x in w.split()]
    except (InvalidOperation, ValueError):
        return False, "mismatch"
    if any(not x.is_finite() for x in gd + wd):
        return False, "mismatch"
    ok = len(gd) == len(wd) and all(a == b for a, b in zip(gd, wd))
    return ok, ("exact" if ok else "mismatch")


def _incar_equal(key, got, want):
    """(하위호환 래퍼) — 일치 여부만. 종류가 필요하면 _incar_match 를 쓸 것."""
    return _incar_match(key, got, want)[0]

RCOV = {"H": 0.31, "B": 0.84, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
        "Na": 1.66, "P": 1.07, "S": 1.05, "Cl": 1.02, "Li": 1.28, "Ni": 1.24}
BOND_F = 1.25             # 결합 = d < BOND_F × (r_i + r_j)
DETACH_A = 4.0            # 분자-슬랩 최소거리가 이보다 크면 탈착
FIX_DRIFT_A = 0.10        # 고정(F F F) 원자가 이보다 움직이면 파일 불일치
FORCE_TOL = 0.05          # eV/Å — 자유원자 잔여 힘 경고
RECON_A = 0.60            # Å — 자유 상부 양이온이 이만큼 움직이면 재구성
LI_OUT_A = 0.80           # Å — Li 가 바깥(+z)으로 이만큼 나오면 추출 의심
LI_O_A = 2.60             # Å — Li–O 배위 반경
LI_COORD_LOSS = 2         # O 배위가 이만큼 줄면 추출로 본다
MOM_MIN = 0.30            # μB — **개별 검토 trigger** (판정 문턱 아님, Codex Q7)
Q_RATIO_MIN = 0.50        # clean 대비 Q 가 이 아래면 집단 붕괴 (초기 민감도)
F_SMALL_MAX = 0.25        # |m|<MOM_MIN 비율이 이 위면 집단 붕괴 (초기 민감도)
#: 준중심(semicore) 변형이 다르면 원자가 전자 수가 달라진다 — 일관돼도 치명이다.
SEMICORE = ("_pv", "_sv", "_h", "_s", "_d")


def _read_text(path):
    try:
        if os.path.isfile(path):
            # ⛔ 2026-08-25 — `.gz` 경로를 그대로 주면 gzip 바이너리를 errors="ignore"
            #   로 읽어 **깨진 문자열을 조용히 돌려줬다**. 그러면 모든 정규식이 안
            #   맞아 E0·NIONS·되울림이 전부 None 이 되는데, None 은 "없음" 으로만
            #   보여 원인이 안 드러난다. 매직바이트로 판별한다 (확장자 말고).
            with open(path, "rb") as fh:
                if fh.read(2) == b"\x1f\x8b":
                    return gzip.open(path, "rt", errors="ignore",
                                 encoding="utf-8").read()
            return open(path, errors="ignore", encoding="utf-8").read()
        if os.path.isfile(path + ".gz"):
            return gzip.open(path + ".gz", "rt", errors="ignore",
                             encoding="utf-8").read()
    except OSError:
        pass
    return None


def global_sign(moments, want):
    """시드 부호 want 에 대해 관측 모멘트의 **전역 부호**를 정한다.

    ⚠ 전역 반전은 시간반전이라 **같은 상태**다. 그래서 부호를 정규화한 뒤
      *부분* 반전만 문제 삼아야 한다. static 과 dense 가 이 규칙을 따로 구현하면
      갈린다 — 실제로 dense 가 static 의 부호를 재사용해, dense 가 완전한
      시간반전으로 수렴했을 때 전부 불일치로 잡는 **거짓 차단**이 났다
      (Codex 5차 P1-2). 한 함수로 둔다.

    반환 (sg, 불일치 인덱스). want/moments 는 {인덱스: 값} 이다.
    """
    ag = {s: sum(1 for i, v in want.items() if moments.get(i, 0.0) * s * v > 0)
          for s in (1.0, -1.0)}
    sg = 1.0 if ag[1.0] >= ag[-1.0] else -1.0
    bad = [i for i, v in want.items() if moments.get(i, 0.0) * sg * v <= 0]
    return sg, bad


#: 회신 AA Q5 — **단일 문턱 금지.** 확실한 붕괴 / 회색 / 확실한 자성으로 나누고
#: 회색은 unresolved 로 뺀다. 값은 wave1 clean slab 분포(|m| ~1.2 μB)와 반복
#: 산포에서 잡았다: 0.25 아래는 어떤 basin 에서도 안 나오고, 0.55 위는 정상
#: Ni 모멘트다. 그 사이는 **우리가 못 가르는 구간**이다.
MOM_COLLAPSE = 0.25      # 이 아래 = 확실한 붕괴
MOM_MAGNETIC = 0.55      # 이 위   = 확실한 자성
#: 같은 부호벡터라도 크기가 이보다 더 벌어지면 자동 동일 판정하지 않는다 (Q5)
MOM_RMS_TOL = 0.30       # μB


def _spin_setup_ok(incar_echo):
    """전역 시간반전을 접어도 되는 계인가 (회신 AA Q5).

    collinear · SOC 없음 · 외부장 없음 · signed spin constraint 없음일 때만
    `+++−` 와 `−−−+` 가 같은 상태다. **INCAR 되울림에서 기계적으로 확인한다** —
    전제를 사람이 기억하는 것에 맡기지 않는다.
    """
    # 🔴 회신 AB P0-5 — `str(None)` 이 **"NONE"** 이 된다. 종전 정규화는 None 을
    #   그 문자열로 만들었고, 그러면 `not in (None, "", "0")` 이 참이라 **미출력이
    #   곧 "스핀 제약 있음"** 이 됐다. 이 키들이 AUDIT_KEYS_RUNTIME 에 없어서
    #   실제 OUTCAR 경로로는 한 번도 안 들어왔기 때문에 드러나지 않았다 —
    #   손으로 만든 dict 를 넣는 단위시험만 통과하던 자리다.
    #   ⚠ VASP 는 이 넷이 기본값이면 **되울리지 않는다**. 그러므로 미출력(None)은
    #     "확인 불가" 가 아니라 **기본값(꺼짐)** 으로 읽는 것이 맞다. 반대로
    #     fail-closed 로 두면 전 잡이 BASIN_UNRESOLVED 가 된다(실측).
    e = {str(k).upper(): (None if v is None else str(v).strip().upper().strip("."))
         for k, v in (incar_echo or {}).items()}
    bad = []
    if e.get("LNONCOLLINEAR") in ("T", "TRUE"):
        bad.append("LNONCOLLINEAR=T (비공선)")
    if e.get("LSORBIT") in ("T", "TRUE"):
        bad.append("LSORBIT=T (SOC)")
    if e.get("I_CONSTRAINED_M") not in (None, "", "0"):
        bad.append(f"I_CONSTRAINED_M={e.get('I_CONSTRAINED_M')} (스핀 제약)")
    if e.get("BEXT") not in (None, "", "0", "0.0", "0.00"):
        bad.append(f"BEXT={e.get('BEXT')} (외부장)")
    return (not bad), bad


def realized_basin_id(mom, ni_sign, mol_sign, mom_min=None, incar_echo=None):
    """OUTCAR 국소모멘트 표 → **실제로 수렴한** 자기 basin 의 지문 (회신 Z P0-4).

    `pm1` · `net4` 는 **초기 MAGMOM seed 이름**이지 최종 상태가 아니다. wave1.5 에서
    raw `net4` 가 의도한 topology 가 아니라 Ni 하나 뒤집힌 basin 으로 반복 수렴한
    전례가 있다. seed 이름으로 짝지어 빼면 상태를 가로질러 뺀 것이 된다.

    v2 (회신 AA Q5 반영):
      · 전역 시간반전을 접기 전에 **collinear·무SOC·무외부장·무제약**을 INCAR
        되울림에서 확인한다. 아니면 접지 않고 unresolved 를 낸다.
      · 붕괴 판정을 **두 문턱**으로 (확실한 붕괴 / 회색 / 확실한 자성).
        회색이 하나라도 있으면 지문을 만들지 않는다 — 그 자리가 basin 을 가른다.
      · 지문 해시는 **정규화 canonical JSON 의 full SHA256**. 12자는 표시용이다.
      · raw 모멘트 벡터와 Ni 인덱스 매핑을 그대로 보존한다 (사후 재판독용).

    반환 (id, detail) — id 가 None 이면 사유가 detail["why"] 에 있다.

    ⛔ 이 함수가 **못 하는 것**
      · 어느 basin 이 **바닥**인지 말하지 못한다. 같은가 다른가만 가른다.
      · OUTCAR 의 site moment 는 PAW 구 안으로 투영한 **관측량**이지 basin 그
        자체가 아니다. 같은 설정 안에서만 쓰는 지문이다.
      · 모멘트 표가 없거나 불완전하면 **추측하지 않는다** — None 을 낸다.
      · Ni 인덱스 집합이 다른 두 계(다른 슬랩)를 비교할 수 없다.
    """
    if not mom:
        return None, {"why": "모멘트 표 없음 (LORBIT)"}
    ni = {int(k): float(v) for k, v in (ni_sign or {}).items()}
    if not ni:
        return None, {"why": "ni_sign_poscar_idx 없음"}
    if max(ni) >= len(mom):
        return None, {"why": f"Ni 인덱스가 모멘트 표 {len(mom)}행 밖"}
    if incar_echo is not None:
        ok_setup, why = _spin_setup_ok(incar_echo)
        if not ok_setup:
            return None, {"why": "전역 시간반전을 접을 수 없는 설정: " + " · ".join(why)}
    got = {i: mom[i] for i in ni}
    sg, _flip = global_sign(got, ni)
    idx = sorted(ni)
    gray = [k for k, i in enumerate(idx) if MOM_COLLAPSE <= abs(got[i]) < MOM_MAGNETIC]
    if gray:
        return None, {"why": (f"회색구간 모멘트 {len(gray)}자리 "
                              f"({MOM_COLLAPSE}–{MOM_MAGNETIC} μB) — 붕괴인지 자성인지 "
                              f"못 가른다. 이 잡으로는 뺄셈하지 않는다"),
                      "gray_positions": gray,
                      "gray_moments_muB": [round(got[idx[k]], 3) for k in gray]}
    vec = "".join("+" if got[i] * sg > 0 else "-" for i in idx)
    collapsed = [k for k, i in enumerate(idx) if abs(got[i]) < MOM_COLLAPSE]
    ms = {int(k): float(v) for k, v in (mol_sign or {}).items() if int(k) < len(mom)}
    org = "".join("+" if mom[i] * sg > 0 else "-" for i in sorted(ms)) if ms else ""
    # 정규화 canonical JSON → full SHA256 (12자는 표시용)
    canon = json.dumps({"ni_sign_vector": vec, "collapsed": collapsed,
                        "organic_relative_spin": org},
                       sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    full = hashlib.sha256(canon.encode()).hexdigest()
    return full, {
        "id_short": full[:12], "canonical": canon,
        "ni_sign_vector": vec, "n_ni": len(idx), "global_sign": sg,
        "collapsed_ni_positions": collapsed, "organic_relative_spin": org or None,
        "ni_index_poscar": idx,
        "ni_moments_muB": [round(got[i], 4) for i in idx],
        "abs_mean_muB": round(sum(abs(got[i]) for i in idx) / len(idx), 4),
        "thresholds": {"collapse": MOM_COLLAPSE, "magnetic": MOM_MAGNETIC},
        "⚠": "seed 이름이 아니라 **수렴 결과**의 지문이다. site moment 는 PAW 투영 관측량이다"}


def basin_distance(da, db):
    """두 realized basin 사이의 **거리** (회신 AA Q5-c).

    지문이 다르다는 것만으로는 "얼마나 다른가" 를 못 말한다. Ni 하나가 뒤집힌
    것과 20개가 뒤집힌 것은 다른 사건이다.

    반환: {hamming, collapse_symdiff, moment_rms_muB, moment_max_muB,
           flipped_index_poscar, same}
    `same` 은 부호·붕괴가 같고 **크기 RMS 도 MOM_RMS_TOL 안**일 때만 참이다 —
    같은 부호라도 크기가 크게 다르면 자동 동일 판정하지 않는다.
    """
    if not da or not db:
        return None
    va, vb = da.get("ni_sign_vector"), db.get("ni_sign_vector")
    ia, ib = da.get("ni_index_poscar"), db.get("ni_index_poscar")
    if not (va and vb) or len(va) != len(vb) or ia != ib:
        return {"same": False, "why": "Ni 인덱스 집합이 다르다 — 비교 불가"}
    ham = [k for k in range(len(va)) if va[k] != vb[k]]
    ca, cb = set(da.get("collapsed_ni_positions") or []), set(db.get("collapsed_ni_positions") or [])
    ma = da.get("ni_moments_muB") or []
    mb = db.get("ni_moments_muB") or []
    sa, sb = da.get("global_sign", 1.0), db.get("global_sign", 1.0)
    diff = [abs(ma[k] * sa - mb[k] * sb) for k in range(min(len(ma), len(mb)))]
    rms = (sum(x * x for x in diff) / len(diff)) ** 0.5 if diff else float("inf")
    mx = max(diff) if diff else float("inf")
    return {"hamming": len(ham), "flipped_index_poscar": [ia[k] for k in ham],
            "collapse_symdiff": sorted(ca ^ cb),
            "moment_rms_muB": round(rms, 4), "moment_max_muB": round(mx, 4),
            "same": (not ham and not (ca ^ cb) and rms <= MOM_RMS_TOL),
            "rms_tol_muB": MOM_RMS_TOL}


def read_moments(t):
    """LORBIT=11 의 마지막 'magnetization (x)' 표 → 이온별 tot 모멘트 [μB]."""
    k = t.rfind("magnetization (x)")
    if k < 0:
        return None
    out = []
    for ln in t[k:].splitlines()[1:]:
        v = ln.split()
        if len(v) == 5 and v[0].isdigit():
            try:
                out.append(float(v[4]))
            except ValueError:
                break
        elif out:
            break
    return out or None


def read_ldau(t):
    """LDAUPRINT=2 의 onsite density matrix → {원자: [n_up, n_dn]}. 없으면 None.

    ⚠ 모멘트 projector 하나에 자기상태 판정을 맡기지 않으려고 둔다 (Codex P0-2).
      **판정용이 아니라 기록용**이다 — 절대값은 PAW sphere 규약에 의존한다.
    """
    out = {}
    for m in re.finditer(r"atom\s*=\s*(\d+)\s+type\s*=\s*\d+\s+l\s*=\s*(\d+)", t):
        a, l = int(m.group(1)), int(m.group(2))
        n = 2 * l + 1
        seg = t[m.end():m.end() + 6000]
        traces = []
        for sm in re.finditer(r"spin component\s+\d+", seg):
            rows = []
            for ln in seg[sm.end():].splitlines()[1:]:
                v = ln.split()
                if len(v) == n:
                    try:
                        rows.append([float(x) for x in v])
                    except ValueError:
                        break
                elif rows:
                    break
                if len(rows) == n:
                    break
            if len(rows) == n:
                traces.append(round(sum(rows[i][i] for i in range(n)), 4))
            if len(traces) == 2:
                break
        if len(traces) == 2:
            out[a] = traces          # 뒤에 나온 이온스텝이 앞을 덮는다 = 최종값
    return out or None


def _pk(path, root):
    """잡 키를 **POSIX 구분자**로 정규화한다.

    ⚠ os.path.relpath 는 Windows 에서 `tier1\\job` 을 낸다. MANIFEST 의 prefix 는
      `tier1/job` 이라, 개별 잡이 멀쩡해도 pair 조회가 전부 실패해 "필수 산출 누락"
      으로 보였다 (2026-08-12 Codex 재감사 P0-6). 키는 한 표기법이어야 한다.
    """
    return os.path.relpath(path, root).replace(os.sep, "/").replace("\\", "/").strip("/")


# ══ OUTCAR 엄격 판독 (2026-08-25 codex E-3) ══════════════════════════════════
#   errors="ignore" 금지 — 깨진 바이트가 낀 `ENC\xffUT` 이 `ENCUT` 으로 붙어
#   **거짓 정상**을 만들고, 잘린 gzip 은 예외로 분석기 전체를 죽이며, UTF-16 은
#   NUL 이 낀 채 조용히 오독된다. 전부 판독 실패(OUTCAR_READ_ERROR)로 승격한다.
def _read_outcar_raw(p):
    """→ (text|None, meta). meta = {read_error, format, suffix_magic_mismatch}.

    이 함수가 못 하는 것: 내용의 물리적 타당성. **읽기 신뢰성**까지만 책임진다.
    """
    meta = {"read_error": None, "format": None, "suffix_magic_mismatch": False}
    base = p[:-3] if p.endswith(".gz") else p
    plain, gz = os.path.isfile(base), os.path.isfile(base + ".gz")
    if plain and gz:
        meta["read_error"] = "OUTCAR 와 OUTCAR.gz 가 둘 다 있다 — 어느 쪽이 정본인지 판정 불가"
        return None, meta
    path = base if plain else (base + ".gz" if gz else None)
    if path is None:
        return None, meta                      # 파일 없음 = NOT_RUN (read_error 아님)
    try:
        raw = open(path, "rb").read()
    except OSError as e:
        meta["read_error"] = f"open 실패: {e}"
        return None, meta
    is_gz_magic = raw[:2] == b"\x1f\x8b"
    meta["suffix_magic_mismatch"] = (path.endswith(".gz") != is_gz_magic)
    if is_gz_magic:
        try:
            raw = gzip.decompress(raw)         # CRC·절단이 여기서 예외로 드러난다
        # ⚠ py3.6 호환 — gzip.BadGzipFile 은 3.8+ 이고 OSError 의 하위클래스다.
        #   wave1.5 회신(2026-08-28)이 실측으로 알려줬다: 클러스터 파이썬이 3.6.8 이라
        #   손상 .gz 를 만나면 깔끔한 오류 대신 AttributeError 로 죽는다.
        except (OSError, EOFError) as e:
            meta["read_error"] = f"gzip 손상/절단: {type(e).__name__} {e}"
            return None, meta
    if b"\x00" in raw[:4096]:
        meta["read_error"] = "NUL 바이트 검출 — UTF-16/바이너리 오염 의심"
        return None, meta
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as e:
        meta["read_error"] = f"디코드 실패(비ASCII 오염): offset {e.start}"
        return None, meta
    meta["format"] = "gzip" if is_gz_magic else "plain"
    return text, meta


def _last_run_segment(text):
    """이어붙은 OUTCAR 를 실행 단위로 갈라 **마지막 완결 실행**을 고른다.

    (2026-08-25 codex E) 여러 실행이 한 파일에 이어지면 옛 코드는 파라미터를 첫
    실행에서, 에너지를 마지막에서, 정상종료를 아무 데서나 읽어 **서로 다른 실행을
    섞었다.** 실행 경계는 버전 배너(행두 ` vasp.`)다.

    → (segment_text, {"n": 배너수, "used": "only|last_complete|last_incomplete",
                       "used_index": i})
    """
    starts = [m.start() for m in re.finditer(r"(?m)^ vasp\.[\w.]+", text)]
    if len(starts) <= 1:
        return text, {"n": max(len(starts), 1) if text.strip() else 0,
                      "used": "only", "used_index": 0}
    segs = [text[s:e] for s, e in zip(starts, starts[1:] + [len(text)])]
    for i in range(len(segs) - 1, -1, -1):
        if "General timing and accounting" in segs[i]:
            return segs[i], {"n": len(segs), "used": "last_complete", "used_index": i}
    return segs[-1], {"n": len(segs), "used": "last_incomplete",
                      "used_index": len(segs) - 1}


def read_outcar(p):
    t, rmeta = _read_outcar_raw(p)
    if rmeta["read_error"]:
        return {"read_error": rmeta["read_error"], "normal_end": False, "E0": None,
                "edisp_eV": None, "edisp_n": 0,
                "nelm_hit": False, "ionic_conv": False, "nions": None, "nkpts": None,
                "titels": [], "incar_echo": {}, "moments": None, "mag_total": None,
                "run_segments": None}
    if t is None:
        return None
    t, seg = _last_run_segment(t)
    e = re.findall(r"energy\(sigma->0\)\s*=\s*(-?[\d.]+)", t)
    # ── D3 분산항. **VASP 가 IVDW=11 에서 직접 찍는다** (repo 실물 확인:
    #   runs/sdcp_phaseB_vasp_v1_2026_08_08/{slab,mol_neutral,complex_neutral}/OUTCAR.gz
    #   → " Edisp (eV)  -27.49493 / -0.71798 / -28.58614").
    #   D3 는 SCF 에 안 들어가고 핵좌표만 보고 총에너지에 **더해지는** 항이라
    #   고정기하 static 에서 `E_on − E_off = Edisp` 가 **항등식**이다 ⇒ C3 의 세 괄호가
    #   각각 Edisp 로 접힌다. 그래서 D3-off 쌍둥이 잡이 **필요 없다**.
    #   ⚠ NSW>0 이면 이온스텝마다 갱신될 수 있으므로 **마지막 것**을 쓴다. 이 캠페인은
    #     전 잡 NSW=0 이라 하나뿐이고, 개수도 같이 돌려준다(검사용).
    _ed = re.findall(r"Edisp\s*\(eV\)\s*:?\s*(-?[\d.]+)", t)
    nions = re.search(r"NIONS\s*=\s*(\d+)", t)
    nk = re.search(r"NKPTS\s*=\s*(\d+)", t)
    # 🔴 회신 AT P0-2 — VASP 는 KPOINTS 첫 줄(제목)을 ` KPOINTS: <제목>` 으로
    #   되울린다. 그 제목에 상·격자·시프트를 실어 두면 **정확한** 대조가 된다.
    _kt = re.search(r"^\s*KPOINTS:\s*(.+?)\s*$", t, re.M)
    nelm = re.search(r"NELM\s*=\s*(\d+)", t)
    iters = re.findall(r"Iteration\s+\d+\(\s*(\d+)\)", t)
    ver = re.search(r"vasp\.([\w.]+)", t)
    # 파일 존재가 아니라 **읽었다는 로그**로 승계를 증명한다 (Codex Q4)
    read_wav = bool(re.search(r"reading WAVECAR|WAVECAR.*read|initial charge.*wavefunc", t, re.I))
    fell_back = bool(re.search(r"ISTART.*=.*0.*job.*fresh|WAVECAR not read|"
                               r"wave function.*not.*found|reading from scratch", t, re.I))
    titels = re.findall(r"TITEL\s*=\s*(.+)", t)
    mag = re.findall(r"number of electron\s+[\d.]+\s+magnetization\s+(-?[\d.]+)", t)
    forces = None
    # ★ 실행 기하 감사용 — OUTCAR 안의 **실제 좌표**. phase POSCAR 를 반송받지 않아도
    #   VASP 가 무엇을 읽었는지 여기서 확인할 수 있다 (Codex zip 감사 P0-6).
    positions = None
    k0 = t.rfind("POSITION")
    if k0 > 0:
        positions = []
        for ln in t[k0:].splitlines()[2:]:
            v = ln.split()
            if len(v) >= 6:
                try:
                    positions.append([float(v[0]), float(v[1]), float(v[2])])
                except ValueError:
                    break
            elif positions:
                break
    k = t.rfind("TOTAL-FORCE")
    if k > 0:
        forces = []
        for ln in t[k:].splitlines()[2:]:
            v = ln.split()
            if len(v) >= 6:
                try:
                    forces.append([float(v[3]), float(v[4]), float(v[5])])
                except ValueError:
                    break
            else:
                break
    # CHGCAR 를 **실제로 읽었는가** — vasp.log 가 아니라 OUTCAR 자체의 마커 (실측):
    #   ICHARG=1: `initial charge density was supplied:` 만 있고
    #   ICHARG=2: 그 밑에 `charge density of overlapping atoms calculated`
    #             (원자에서 새로 만듦) 가 따라온다. 후자가 있으면 파일을 안 읽은 것.
    _sup = "initial charge density was supplied" in t
    _atoms = "charge density of overlapping atoms calculated" in t
    chg_from_file = (True if (_sup and not _atoms) else
                     False if _atoms else None)
    return {"E0": float(e[-1]) if e else None,
            "edisp_eV": float(_ed[-1]) if _ed else None,
            "edisp_n": len(_ed),
            "chgcar_from_file": chg_from_file,
            "ionic_conv": "reached required accuracy" in t,
            # ⚠ 정상종료를 안 보면 **잘린 OUTCAR 도 에너지만 있으면 통과**한다
            "normal_end": "General timing and accounting" in t,
            "nelm_hit": bool(nelm and iters
                             and any(int(x) >= int(nelm.group(1)) for x in iters)),
            "nions": int(nions.group(1)) if nions else None,
            "nkpts": int(nk.group(1)) if nk else None,
            "kpoints_title": _kt.group(1) if _kt else None,
            "read_wavecar": read_wav, "restart_fell_back": fell_back,
            "titels": [x.strip() for x in titels],
            "vasp_version": ver.group(1) if ver else None,
            "mag_total": float(mag[-1]) if mag else None,
            "moments": read_moments(t), "forces": forces,
            "positions": positions,
            "ldau": read_ldau(t),
            "run_segments": seg, "read_format": rmeta["format"],
            "suffix_magic_mismatch": rmeta["suffix_magic_mismatch"],
            # ⛔ 2026-08-25 (sdcp_wave1 회신) — 이 검색은 **앵커가 없어서 산문도 물었다.**
            #   분자 박스 OUTCAR 129행의 VASP 권고문
            #     `|      So try LREAL= Auto  in the INCAR   file.  |`
            #   이 첫 매치라, 실제 파라미터 줄이 `LREAL = F` 인데도 got="Auto" 가 나와
            #   `LREAL: Auto!=.FALSE.` 오탐이 났다. 파라미터 줄만 보도록 행두 고정.
            "incar_echo": {k2: _echo_val(t, k2) for k2 in AUDIT_KEYS_RUNTIME}}


def read_poscar(p):
    """POSCAR/CONTCAR (Direct/Cartesian · Selective 지원). 실패 시 None."""
    t = _read_text(p)
    if t is None:
        return None
    try:
        L = t.splitlines()
        scale = float(L[1].split()[0])
        cell = [[float(x) * scale for x in L[i].split()[:3]] for i in (2, 3, 4)]
        i = 5
        species = None
        if not L[i].split()[0].isdigit():
            species = L[i].split(); i += 1
        counts = [int(x) for x in L[i].split()]; i += 1
        seldyn = False
        if L[i].strip() and L[i].strip()[0] in "Ss":
            seldyn = True; i += 1
        direct = bool(L[i].strip()) and L[i].strip()[0] in "Dd"
        i += 1
        n = sum(counts)
        pos, fixed, sd_flags = [], [], []
        for k in range(n):
            v = L[i + k].split()
            xyz = [float(x) for x in v[:3]]
            if direct:
                xyz = [sum(xyz[j] * cell[j][ax] for j in range(3)) for ax in range(3)]
            else:
                xyz = [x * scale for x in xyz]
            pos.append(xyz)
            fixed.append(seldyn and len(v) >= 6 and
                         all(f.upper().startswith("F") for f in v[3:6]))
            # 🔴 회신 BF P0-2 — 원자별 **3축** selective-dynamics 플래그를 그대로 보존한다.
            #   `fixed` 는 "셋 다 F" 로 접은 값이라 T T F 같은 축 차이를 못 본다.
            sd_flags.append(tuple(f.upper()[:1] for f in v[3:6]) if (seldyn and len(v) >= 6)
                            else None)
        syms = []
        if species:
            for s, c in zip(species, counts):
                syms += [s] * c
        return {"cell": cell, "pos": pos, "fixed": fixed, "sd_flags": sd_flags, "syms": syms,
                "species": species, "counts": counts, "selective": seldyn}
    except Exception:
        return None


def mic_dist(a, b, cell):
    best = None
    for u in (-1, 0, 1):
        for v in (-1, 0, 1):
            for w in (-1, 0, 1):
                d = [a[x] - b[x] - u * cell[0][x] - v * cell[1][x] - w * cell[2][x]
                     for x in range(3)]
                r = math.sqrt(sum(x * x for x in d))
                best = r if best is None or r < best else best
    return best


def mol_bond_graph(struct, mol_idx):
    """분자 내부 결합 집합 {(i,j)} — 공유반경 기준."""
    bonds = set()
    syms = struct["syms"]
    for a in range(len(mol_idx)):
        for b in range(a + 1, len(mol_idx)):
            i, j = mol_idx[a], mol_idx[b]
            cut = BOND_F * (RCOV.get(syms[i], 1.0) + RCOV.get(syms[j], 1.0))
            if mic_dist(struct["pos"][i], struct["pos"][j], struct["cell"]) < cut:
                bonds.add((i, j))
    return bonds


def contact_fp(struct, mol_idx, slab_idx):
    """접촉 지문 — 분자에서 CONTACT_A 안에 있는 슬랩 원자 인덱스 집합."""
    fp = set()
    for i in slab_idx:
        for m in mol_idx:
            if mic_dist(struct["pos"][i], struct["pos"][m], struct["cell"]) < CONTACT_A:
                fp.add(i)
                break
    return fp


def geometry_audit(jd, meta):
    """relax/CONTCAR vs POSCAR — 등록·결합그래프·탈착·고정 drift. (게이트, 정보) 반환."""
    gates, info = [], {}
    init = read_poscar(os.path.join(jd, "POSCAR"))
    sp_only = "relax" not in (meta.get("phases") or ["relax"])
    # ⚠ 단일점 모드는 CONTCAR 가 없다 — 기하가 안 변하므로 POSCAR 가 곧 최종이다.
    #   그렇다고 검사를 끄지 않는다: 등록·결합 감사는 그대로 돌아 자세가 의도대로인지 본다.
    fin = init if sp_only else read_poscar(os.path.join(jd, "relax", "CONTCAR"))
    info["single_point"] = sp_only
    if init is None or fin is None or len(fin["pos"]) != len(init["pos"]):
        gates.append("REGISTRY_UNVERIFIED(CONTCAR 없음/파싱 실패/원자수 불일치)")
        return gates, info
    # ⚠ 원자수만 같고 종/셀이 다르면 다른 계다 (Codex P0-G)
    if fin.get("species") and init.get("species") and fin["species"] != init["species"]:
        gates.append(f"SPECIES_MISMATCH({fin['species']}!={init['species']})")
    if fin.get("counts") and init.get("counts") and fin["counts"] != init["counts"]:
        gates.append("COUNTS_MISMATCH(POSCAR vs CONTCAR)")
    dcell = max(abs(fin["cell"][i][j] - init["cell"][i][j])
                for i in range(3) for j in range(3))
    info["cell_drift_A"] = round(dcell, 4)
    if dcell > 1e-3:
        gates.append(f"CELL_CHANGED({dcell:.3f} Å — ISIF=2 인데 셀이 바뀌었다)")
    if not fin["syms"]:
        fin["syms"] = init["syms"]
    mol = meta.get("mol_poscar_idx") or []
    # ★ 등록은 **표면 양이온**으로만 판정한다 — 먼 H/C 나 표면 아래 양이온이
    #   라벨을 정하면 안 된다 (Codex P0-G). 표면 목록이 없으면 전체로 후퇴하되 표시한다.
    top_li = meta.get("top_li_poscar_idx") or meta.get("slab_li_poscar_idx") or []
    top_ni = meta.get("top_ni_poscar_idx") or meta.get("slab_ni_poscar_idx") or []
    if mol and (top_li or top_ni):
        def dmin(idxs):
            return min((mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                        for m in mol for i in idxs), default=1e9)
        dli, dni = dmin(top_li), dmin(top_ni)
        info["registry"] = {"d_Li": round(dli, 3), "d_Ni": round(dni, 3),
                            "nearest": "Li" if dli < dni else "Ni",
                            "top_only": bool(meta.get("top_li_poscar_idx"))}
        # 🔴 회신 AB P0-1 — `role` 이 **두 가지 뜻**으로 쓰이고 있었다.
        #   champion/cross 경로는 `role = "Li"|"Ni"`(등록 역할)를 쓰는데,
        #   from_basins 경로는 `role = "calibration"|"holdout"`(분석 역할)을 쓴다.
        #   그래서 동결본 번들의 복합체 전 잡이 `calibration -> Ni` 로 **항상**
        #   불일치했다 — OUTCAR 가 와도 그대로 막힌다.
        #   ⇒ 등록 기대는 `registry_role` 에서만 읽고, 옛 번들 호환으로
        #     `role` 은 그 값이 실제 Li/Ni 일 때만 받는다.
        want = meta.get("registry_role")
        if want is None and meta.get("role") in ("Li", "Ni"):
            want = meta["role"]
        info["registry"]["expected"] = want
        if want is None:
            # ⚠ **조용한 통과가 아니다.** 기대가 없다는 사실을 기록한다 —
            #   안 적으면 나중에 "검사했는데 통과" 로 읽힌다.
            info["registry"]["checked"] = False
        if want and info["registry"]["nearest"] != want:
            # ⚠ 단일점에서 이건 "이완 중 옮겨갔다" 가 아니라 **애초에 그 자리가 아니다**
            #   이다 (Codex 6차 §4). 이름이 원인을 오도하면 진단이 엉뚱한 데로 간다.
            gates.append(("SOURCE_ROLE_MISMATCH" if sp_only else "PAIR_MIGRATED")
                         + f":{want}->{info['registry']['nearest']}")
        slab_idx = (meta.get("slab_li_poscar_idx") or []) + \
                   (meta.get("slab_ni_poscar_idx") or [])
        dsl = min((mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                   for m in mol for i in slab_idx), default=1e9)
        info["mol_slab_min_A"] = round(dsl, 3)
        if dsl > DETACH_A:
            gates.append(f"DETACHED(분자-슬랩 {dsl:.2f} Å > {DETACH_A})")
        # ⚠ 지문에 **O 도 넣는다** — Li/Ni 만 보면 O 쪽 접촉 재구성을 못 본다 (Codex Q3)
        o_idx = [i for i, sy in enumerate(fin["syms"]) if sy == "O" and i not in mol]
        info["_contact_fp"] = sorted(contact_fp(fin, mol, slab_idx + o_idx))
    if mol:
        b1 = mol_bond_graph(fin, mol)
        if sp_only:
            # ⚠⚠ 단일점에서는 fin 이 곧 init 이다 — init↔fin 을 비교하면 변화가
            #   **구조적으로 항상 0** 이라 절대 발화하지 못하는 검사가 된다
            #   (통과해도 아무것도 보증하지 못한다 · Codex 6차 §4).
            #   정본은 빌드 때 저장한 **조각 정본 그래프**다. 없으면 통과시키지 않는다.
            b0 = {tuple(e) for e in (meta.get("mol_graph_canonical") or [])}
            if not meta.get("mol_graph_canonical"):
                gates.append("SOURCE_TOPOLOGY_UNVERIFIED(정본 분자 그래프가 job.json 에 "
                             "없다 — 옛 번들이다. 재생성할 것)")
                info["bonds"] = {"final": len(b1), "canonical": None}
            else:
                broke, formed = b0 - b1, b1 - b0
                info["bonds"] = {"canonical": len(b0), "broken": len(broke),
                                 "formed": len(formed),
                                 "compared_against": "빌드 시 조각 정본 그래프"}
                if broke or formed:
                    gates.append(f"SOURCE_TOPOLOGY_CHANGED(정본 대비 끊김 {len(broke)} · "
                                 f"생성 {len(formed)} — 계산에 넣은 분자가 조각이 아니다)")
        else:
            # 기체 기준계도 여기 온다 (슬랩이 없어 위 블록은 건너뛴다)
            b0 = mol_bond_graph(init, mol)
            broke, formed = b0 - b1, b1 - b0
            info["bonds"] = {"initial": len(b0), "broken": len(broke),
                             "formed": len(formed)}
            if broke or formed:
                gates.append(f"BOND_CHANGE(끊김 {len(broke)} · 생성 {len(formed)})")
    # ── 계면 정체성 (Codex P0-7) — 자리 선호를 묻던 계가 다른 계가 됐는가 ──
    #   ⚠ 이 검사들은 "버리라" 가 아니라 **격리하라** 는 뜻이다. 재구성·전이가 일어난
    #     끝점은 흡착 에너지의 질문 자체가 달라져 같은 표에 못 올린다.
    if mol and (top_li or top_ni) and not sp_only:
        top_all = sorted(set(top_li) | set(top_ni))
        # ① 자유 상부 양이온의 재구성 변위
        rec_d = max((mic_dist(init["pos"][i], fin["pos"][i], fin["cell"])
                     for i in top_all if not init["fixed"][i]), default=0.0)
        info["top_reconstruction_A"] = round(rec_d, 3)
        if rec_d > RECON_A:
            gates.append(f"SURFACE_RECONSTRUCTION(상부 양이온 {rec_d:.2f} Å > {RECON_A})")
        # ② Li 바깥쪽 이탈 + O 배위 손실 (표면에서 뽑혀 나왔나)
        o_slab = [i for i, sy in enumerate(fin["syms"]) if sy == "O" and i not in mol]
        worst_li = (0.0, 0, 0)
        for i in top_li:
            dz = fin["pos"][i][2] - init["pos"][i][2]
            n0 = sum(1 for j in o_slab
                     if mic_dist(init["pos"][i], init["pos"][j], init["cell"]) < LI_O_A)
            n1 = sum(1 for j in o_slab
                     if mic_dist(fin["pos"][i], fin["pos"][j], fin["cell"]) < LI_O_A)
            if dz - 0.0 > worst_li[0] or (n0 - n1) > worst_li[1]:
                worst_li = (max(dz, worst_li[0]), max(n0 - n1, worst_li[1]), i)
        info["li_outward_A"] = round(worst_li[0], 3)
        info["li_O_coord_loss"] = worst_li[1]
        if worst_li[0] > LI_OUT_A or worst_li[1] >= LI_COORD_LOSS:
            gates.append(f"LI_EXTRACTION(바깥 이동 {worst_li[0]:.2f} Å · "
                         f"O 배위 −{worst_li[1]})")
        # ③ 새 계면 결합 (분자 원자 ↔ 슬랩 원자가 공유반경 안으로)
        newb = []
        for m in mol:
            for i in slab_idx + o_slab:
                cut = BOND_F * (RCOV.get(fin["syms"][m], 1.0) + RCOV.get(fin["syms"][i], 1.0))
                d0 = mic_dist(init["pos"][m], init["pos"][i], init["cell"])
                d1 = mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                if d1 < cut <= d0:
                    newb.append((fin["syms"][m], fin["syms"][i], round(d1, 2)))
        info["new_interface_bonds"] = newb[:8]
        if newb:
            gates.append(f"INTERFACE_REACTION_OR_RECONSTRUCTION(새 계면 결합 {len(newb)}: "
                         + ", ".join(f"{a}–{b} {d}Å" for a, b, d in newb[:3]) + ")")

    # ⚠ 이완이 없으면 drift·재구성·Li 추출·새 계면결합은 **정의되지 않는다**.
    #   여기에 0 을 적으면 "검사했고 통과" 로 읽힌다 (Codex 6차 §4). 이름을 붙인다.
    if sp_only:
        info["fixed_drift_A"] = "NOT_APPLICABLE_SINGLE_POINT"
        info["relaxation_gates"] = "NOT_APPLICABLE_SINGLE_POINT"
        info["relaxation_gates_list"] = [
            "ionic convergence", "fixed-atom drift", "surface reconstruction",
            "Li extraction", "new interface bonds", "DFT CONTCAR migration"]
    else:
        dmax = 0.0
        for i, fx in enumerate(init["fixed"]):
            if fx:
                dmax = max(dmax, mic_dist(init["pos"][i], fin["pos"][i], fin["cell"]))
        info["fixed_drift_A"] = round(dmax, 4)
        if dmax > FIX_DRIFT_A:
            gates.append(f"FIXED_DRIFT({dmax:.3f} Å — 파일 불일치 의심)")
    info["_init_fixed"] = init["fixed"]
    info["_fin"] = fin
    return gates, info


BRANCH_TIE_EV = 0.020     # 두 branch 차가 이 아래면 k 보정(각 ±10)으로 순서가 뒤집힌다
MAX_OPTIONAL_DENSE = 2    # 예산 상한 — 넘으면 전이를 주장하지 않는다


def plan_dense(root, man, jobs, E, E_dense):
    """coarse static 을 보고 **어느 branch 에 dense 를 걸어야 하는지** 정한다.

    설계 (Codex 6차 §3 을 예산에 맞게 조정)
      · 기본 dense 는 pm1 에 **이미 사슬로 붙어 있다** — 아무것도 발동 안 하면 추가 0
      · 발동 조건은 두 가지뿐이다
          ① pm1 이 무효 (게이트/미완)          → net4 후보를 승격
          ② net4 가 pm1 보다 {BRANCH_TIE_EV*1000:.0f} meV 넘게 낮다 → net4 승격
        (둘 다 아니면 우리가 보고하는 branch 를 이미 dense 한 것이다)
      · 승격은 최대 {MAX_OPTIONAL_DENSE} 건. 넘으면 **한 조각만 완결**하고 나머지는
        MAX_OPTIONAL_DENSE 를 넘겼다고 적는다 — 임의의 둘로 전체를 주장하지 않는다.

    이 함수가 **못 하는 것**: 어느 branch 가 진짜 바닥인지 보장하지 못한다.
      두 seed 는 시도한 초기값 두 개일 뿐이고, 더 낮은 자기배치가 있을 수 있다.
    """
    seeds = man.get("seeds_full") or ["afm2424_pm1", "afm2424_net4"]
    main, alt = seeds[0], (seeds[1] if len(seeds) > 1 else seeds[0])
    cal = list(man.get("dense_calibrators") or [])
    plan = {"parent_manifest_sha256": hashlib.sha256(
                open(os.path.join(root, "MANIFEST.json"), "rb").read()).hexdigest(),
            "rule": {"branch_tie_eV": BRANCH_TIE_EV,
                     "max_optional": MAX_OPTIONAL_DENSE,
                     "why": (f"두 branch 의 k 보정이 각각 최대 ±10 meV 면 차가 "
                             f"{BRANCH_TIE_EV * 1000:.0f} meV 안일 때 순서가 뒤집힐 수 "
                             f"있다. 30 meV 판정바닥과는 다른 축이다.")},
            "calibrators": cal, "endpoints": {}, "promote": [], "notes": []}
    if not cal:
        plan["notes"].append("dense 보정자가 지정되지 않았다 — 계획할 대상이 없다")
    cand = []
    for pid, pm in man.get("pairs", {}).items():
        if pm["fragment"] not in cal:
            continue
        for role in ("li", "ni"):
            pre = pm[f"{role}_prefix"]
            ent = {"fragment": pm["fragment"], "role": role.capitalize(),
                   "E_by_seed": {}, "valid": {}, "static_sha256": {}}
            for sd in seeds:
                j = f"{pre}__{sd}"
                r = jobs.get(j)
                ent["valid"][sd] = bool(r and r.get("ok"))
                ent["E_by_seed"][sd] = E(j)
                for ext in ("", ".gz"):
                    p = os.path.join(root, j, "static", "OUTCAR" + ext)
                    if os.path.isfile(p):
                        ent["static_sha256"][sd] = hashlib.sha256(
                            open(p, "rb").read()).hexdigest()
                        break
                if r and not r.get("ok"):
                    ent.setdefault("gates", {})[sd] = r.get("gates", [])[:3]
            em, ea = ent["E_by_seed"].get(main), ent["E_by_seed"].get(alt)
            have_dense = E_dense(f"{pre}__{main}") is not None
            ent["dense_done_on"] = main if have_dense else None
            if em is None and ea is None:
                ent["decision"] = "NO_VALID_BRANCH — 이 끝점은 k 검증 불가"
            elif em is None:
                ent["decision"] = f"PROMOTE_{alt}(주 branch 무효)"
                cand.append((0, pid, role, alt, ent))          # 우선순위 0 = 최상
            elif ea is not None and ea < em - BRANCH_TIE_EV:
                ent["decision"] = (f"PROMOTE_{alt}(coarse 에서 "
                                   f"{(em - ea) * 1000:.0f} meV 더 낮다)")
                cand.append((1, pid, role, alt, ent))
            elif ea is not None and abs(em - ea) <= BRANCH_TIE_EV:
                # ⚠ tie 는 "괜찮다" 가 아니라 **재순위 위험 구간**이다. adaptive 가
                #   꺼져 있으면 추가 계산이 불가능하므로 그 사실을 판정으로 남긴다.
                ent["decision"] = (f"MAGNETIC_K_UNRESOLVED(두 branch 차 "
                                   f"{abs(em - ea) * 1000:.0f} meV ≤ "
                                   f"{BRANCH_TIE_EV * 1000:.0f} — k 보정 ±10 으로 순서가 "
                                   f"뒤집힐 수 있는데 adaptive dense 가 꺼져 있다)")
            else:
                ent["decision"] = (f"OK({main} 이 {(ea - em) * 1000:.0f} meV 낮다 — "
                                   f"보고 branch = dense 한 branch)")
            if not have_dense:
                ent["decision"] += " ⚠ 주 branch dense 산출이 없다(미완/게이트)"
            plan["endpoints"][f"{pid}/{role}"] = ent
    cand.sort(key=lambda t: (t[0], t[1], t[2]))
    for pr, pid, role, sd, ent in cand[:MAX_OPTIONAL_DENSE]:
        rel = f"{man['pairs'][pid][role + '_prefix']}__{sd}"
        plan["promote"].append({"job": rel, "seed": sd, "priority": pr,
                                "reason": ent["decision"],
                                "candidate_dir": "dense_cand"})
    if len(cand) > MAX_OPTIONAL_DENSE:
        drop = [f"{p}/{r}" for _x, p, r, _s, _e in cand[MAX_OPTIONAL_DENSE:]]
        plan["notes"].append(
            f"⛔ 승격 후보 {len(cand)}건 > 상한 {MAX_OPTIONAL_DENSE} — "
            f"{drop} 는 MAGNETIC_K_UNRESOLVED 다. 임의의 둘로 전체 전이를 "
            f"주장하지 않는다 (예산을 늘리든지 주장 범위를 줄이든지 골라야 한다)")
    plan["estimated_extra_dense_runs"] = len(plan["promote"])
    op = os.path.join(root, "DENSE_PLAN.json")
    with open(op, "w", encoding="utf-8") as fh:
        json.dump(plan, fh, indent=1, ensure_ascii=False)
    print(f"=== dense 계획 ===  보정자 {cal} · 끝점 {len(plan['endpoints'])}")
    for k, v in plan["endpoints"].items():
        print(f"  {k:44s} {v['decision']}")
    print(f"\n승격 {len(plan['promote'])}건"
          + ("  (추가 계산 없음 — 보고 branch 를 이미 dense 했다)"
             if not plan["promote"] else ""))
    for p in plan["promote"]:
        print(f"   ▶ {p['job']}  ({p['reason']})")
    for n in plan["notes"]:
        print(f"  ⚠ {n}")
    print(f"\n→ {op}")
    print("   ⚠ 이 모드는 --adaptive_dense 로 만든 번들에서만 의미가 있다. "
          "기본 번들에는 dense_cand/ 도 run_dense_selected.sh 도 없다.")
    return 0


def k_transfer_gate(cal, kap_all, frags):
    """k 전이 게이트 — (판정, 조각별 라벨, 통과한 보정자) 를 낸다.

    ★ κ 는 **부호 있는** 양이다. 크기만 보면 +9 와 −9 를 둘 다 통과시켜 실제
      18 meV 의 계 의존성을 놓친다. 그래서 max|κ| 와 range 를 **둘 다** 본다.
    ★ n=2 다 — 평균·표준편차·CI 를 쓰지 않는다. deterministic max/range 규칙이다.

    이 함수가 **못 하는 것**: 보정자가 대표성이 있는지는 판단하지 못한다.
      큰 계 하나 + open-shell 하나로 고른 것은 **공학적 선택**이지 통계가 아니다.
    """
    # ★ 라벨은 **선언이 아니라 데이터**를 따른다 (2026-08-12). κ 를 실제로 잰 조각은
    #   dense_calibrators 에 안 적혀 있어도 직접 검증된 것이다 — 선언만 보면 dense 를
    #   돌리고도 K_UNVERIFIED 가 되어 headline 이 막힌다.
    have = {f: kap_all[f] for f in (cal or list(kap_all)) if f in kap_all}
    if not cal and not have:
        kt = {"pass": False, "why": "dense 를 돌린 조각이 없다 — 전이 불가"}
    elif cal and len(have) < len(cal):
        kt = {"pass": False, "kappa_eV": have,
              "why": f"보정자 {len(have)}/{len(cal)} 만 회수 — 전이 근거 부족"}
    else:
        vals = list(have.values())
        mx = max(abs(v) for v in vals)
        rng = max(vals) - min(vals)
        kt = {"pass": bool(mx <= GUARD_EV and rng <= GUARD_EV), "kappa_eV": have,
              "max_abs_meV": round(mx * 1000, 1), "range_meV": round(rng * 1000, 1),
              "rule": (f"|κ_f| ≤ {GUARD_EV * 1000:.0f} meV **및** "
                       f"|κ_i−κ_j| ≤ {GUARD_EV * 1000:.0f} meV. n=2 라 max/range 로 "
                       f"본다 (평균·표준편차·CI 금지)")}
    labels = {f: ("K_DIRECTLY_CHECKED" if f in have else
                  "K_TRANSFER_SCREENED" if kt["pass"] else "K_UNVERIFIED")
              for f in frags}
    return kt, labels, have


def apply_k_guard(cls, med, lbl, delta):
    """guard band 를 **실제 release gate 로** 적용한다 (Codex 6차 §6).

    옛 판은 k_guard 에 문자열만 붙이고 최종 class 를 막지 않았다 — 직접 dense 하지
    않은 조각의 25 meV 대비가 그대로 판정으로 나갔다.
    ±10 meV(k 불확실성)는 30 meV(판정바닥)와 **별개 축**이다:
      · |ΔE| ≤ 10 meV      → 부호 자체가 안 정해진다 (라벨 무관)
      · 20 ≤ |ΔE| ≤ 40 meV → k 오차 하나로 바닥을 넘나든다. 직접 dense 아니면 보류
      · 그 밖                → 원래 판정 유지
    """
    a = abs(med)
    if a <= GUARD_EV:
        return f"UNRESOLVED_SIGN(|ΔE|={a * 1000:.0f} ≤ {GUARD_EV * 1000:.0f} meV)"
    # ★★ K_UNVERIFIED 는 **유한한 k 오차 경계가 없다** (Codex zip 감사).
    #   전이 게이트가 실패했다는 건 "10 meV 안" 이라고 말할 근거가 사라졌다는 뜻이다.
    #   그런데 옛 판은 |ΔE| 가 크면 그냥 통과시켰다 — 경계 없는 값에 판정을 붙인 셈이다.
    if lbl == "K_UNVERIFIED":
        return (f"UNRESOLVED_K(|ΔE|={a * 1000:.0f} meV 이지만 k 오차에 **유한한 경계가 "
                f"없다** — 전이 게이트 실패. 직접 dense 없이는 판정 불가)")
    if lbl != "K_DIRECTLY_CHECKED" and delta - GUARD_EV <= a <= delta + GUARD_EV:
        return (f"UNRESOLVED_K_GUARD(|ΔE|={a * 1000:.0f} meV 가 "
                f"{(delta - GUARD_EV) * 1000:.0f}–{(delta + GUARD_EV) * 1000:.0f} meV "
                f"띠 안 · {lbl} — 직접 dense 없이는 판정 불가)")
    return cls


def _stage1_prereqs(_cl, _vc, results):
    """1단계 선결조건 — **전부 통과해야** 2단계가 열린다.

    → {이름: {"pass": bool, "why": ...}}

    ⛔⛔ 회신 AP #5 → AR 해제조건 5 (2026-08-31). 종전 네 조건
      (vacuum/molecular_state/canary_geometry/potcar_identity)만으로는
      **이미 primary estimand 가 실패한 뒤에도** STAGE1_PASS.json 을 쓰고
      2단계를 열 수 있었다 — δ_gas 도 pm1 topology 도 잔여 exact/global
      block 도 보지 않았기 때문이다. 여덟으로 늘렸다.

    ⛔ 이 함수가 **못 하는 것**: 2단계 잡의 미실행을 요구하지 않는다
      (단계별 실행에서 2단계가 비어 있는 것은 정상이다). 여기서 보는 것은
      **1단계 산출만으로 판정 가능한 것들**뿐이다.
    """
    _pi = (_cl.get("potcar_identity") or {})
    _cg_all = (results.get("gas_canary_geom") or {})
    _mol_blk = [b for b in (_cl.get("blocks") or [])
                if b.startswith(("MOLECULAR_STATE_UNRESOLVED",
                                 "MOLECULAR_SPIN_CONTROL"))]
    _cg_bad = {f: v for f, v in _cg_all.items() if (v or {}).get("same") is not True}
    _pre = {
        "vacuum": {"pass": bool(_vc.get("pass")),
                   "why": _vc.get("verdict")},
        "molecular_state": {"pass": not _mol_blk,
                            "why": (_mol_blk[:2] if _mol_blk else
                                    "비영 시작이 부모보다 낮지 않다")},
        "canary_geometry": {"pass": bool(_cg_all) and not _cg_bad,
                            "why": (_cg_bad if _cg_bad else
                                    "부모/canary static 기하 동일 (%d조각)"
                                    % len(_cg_all))},
        "potcar_identity": {"pass": not (_pi.get("blocking") or []),
                            "why": (_pi.get("blocking") or [])[:2]
                                   or _pi.get("identity_scope")},
    }
    # ⛔⛔ 회신 AR 해제조건 5 (2026-08-31) — 위 네 조건만으로는
    #   **이미 primary estimand 가 실패한 뒤에도** STAGE1_PASS 를 쓰고 2단계를
    #   열 수 있었다. δ_gas 도 pm1 topology 도 잔여 exact/global block 도
    #   보지 않았기 때문이다. 네 개를 더 결박한다.
    #   ⚠ 이 네 조건은 **1단계 산출만으로 판정 가능한 것들**이다 —
    #     2단계(대안자세·net4)의 미실행을 요구하지 않는다.
    _gbd = (_cl.get("gas_box_delta") or {})
    _gpc = (_cl.get("gas_pair_contract") or {})
    _gas_why = ([b for b in (_cl.get("blocks") or [])
                 if b.startswith(("GAS_BOX", "GAS_PAIR"))][:2]
                or {"delta_gas_meV": _gbd.get("delta_gas_meV"),
                    "tol_meV": _gbd.get("tol_meV")})
    _pre["gas_box_delta"] = {
        "pass": bool(_gbd.get("pass") is True and _gpc.get("ok") is True),
        "why": _gas_why}
    _tp1 = ((_cl.get("estimand_topology") or {}).get("pm1") or {})
    _pre["estimand_topology_pm1"] = {
        "pass": bool(_tp1 and _tp1.get("same") is True and not _tp1.get("blocks")),
        "why": (_tp1.get("blocks") or [])[:2]
               or ("두 complex 가 같은 자기 branch (%s)" % _tp1.get("why")
                   if _tp1 else "pm1 topology 판정이 없다")}
    # 잔여 exact-estimand / 전역 차단 — pooled_diagnostic 만 제외한다
    #   (그 강등은 회신 AP #3 에서 근거를 남기고 한 것이고, 정본 blocks 는
    #    회신 AR Q1 이후 그대로 남아 있으므로 여기서 scope 로 걸러야 한다)
    _recs = (_cl.get("block_records") or [])
    _res_blk = [r["msg"] for r in _recs
                if r.get("scope") in ("estimand", "global")
                and r.get("affects_estimand") is not False]
    # 구조화되지 않은 옛 문자열 block 도 남아 있으면 통과가 아니다
    _unstruct = [b for b in (_cl.get("blocks") or [])
                 if b not in {r["msg"] for r in _recs}]
    _pre["closure_blocks_clear"] = {
        "pass": not _res_blk and not _unstruct,
        "why": ([b[:70] for b in (_res_blk + _unstruct)][:3]
                or "exact/global closure block 0건")}
    # 생산 전 root seal 이 **이 manifest 와 예정 잡 전체**를 포괄하는가
    _sealcov = (_cl.get("root_seal_coverage") or _pi.get("root_seal_coverage") or {})
    _pre["root_seal_covers_plan"] = {
        "pass": bool(_sealcov.get("ok") is True),
        "why": (_sealcov.get("why") or "root seal 포괄 검사 결과가 없다")}
    return _pre


#: ⛔ 회신 BD P0-3 · GO 해제조건 3 — **필수 문서 집합과 path→role 을 코드에 고정**한다.
#:   목록을 산출물에서 읽으면, 목록을 바꾼 번들이 자기 기준으로 통과한다.
C12_REQUIRED_DECISIONS = ("D-2026-08-30-sdcp-c12-path",
                          "D-2026-08-28-closure-criteria-first")
C12_REQUIRED_REFS = {
    "db/properties/sdcp_c12_claim_prereg_2026_08_31.json": "claim",
    "db/properties/sdcp_c12_protocol_2026_08_30.json": "claim",
    "db/properties/c12_poses_2026_08_30.json": "frozen_input",
}
_HEX64 = re.compile(r"^[0-9a-f]{64}$")

# 🔴🔴 회신 BG P0-1 (2026-09-03) — **반송 계약이 정본이다.**
#:  BF P1 로 "상 폴더 POTCAR 실물을 다시 해시한다" 를 넣었는데, 반송 계약은 그 파일을
#:  **주고받지 않는다** (README:"POTCAR 파일 자체는 주고받지 않습니다" · SUBMIT 반송목록에
#:  없음 · verify_bundle 은 POTCAR 를 FORBIDDEN_NAMES 로 취급 — VASP 라이선스). 그래서
#:  계약대로 회수하면 16/16 잡이 RECEIPT_POTCAR_FILE_MISSING 으로 막히고, 외주 기계에서
#:  도는 분석(상 폴더에 사본이 남아 있다)과 우리 재분석이 **서로 다른 판정**을 냈다.
#:  ⇒ 결과를 본 뒤 게이트를 고치게 되는 구조 — 이 캠페인이 여덟 번 물린 바로 그 모양이다.
#:  판정: 파일은 계약상 오지 않는다. POTCAR 결박은 **receipt 9열 + POTCAR_PROVENANCE +
#:  root seal** 이 이미 하고 있고 실물 재해시는 그 위의 **덤**이다. 없음은 계약 이행이지
#:  무결성 구멍이 아니므로 게이트에서 내린다. 있으면(외주처가 굳이 보냈으면) 반드시
#:  맞아야 한다 — MISMATCH 는 게이트로 남는다.
#:  ⚠ 이 상수와 `_return_contract` 의 per_job 목록은 selftest 가 **서로 결박**한다 —
#:    한쪽만 바꾸면 시험이 깨진다. 계약을 바꾸려면 둘 다 바꿔야 한다.
C12_POTCAR_RETURNED = False


def _strict_true(v):
    """**불리언 True 만** 참으로 본다 — 문자열 "false" 는 파이썬에서 참이다."""
    return v is True


def reported_quantity_matches_prereg(man):
    """MANIFEST 의 보고량이 **비준 사전등록의 §1_보고량과 같은가**. → 위반 목록

    🔴🔴 2026-09-04 신설. 이 캠페인의 존재 이유가 *"맞는 양을 재고 있나"* 인데,
      정작 **그 양이 바뀌는 것을 보는 기계가 없었다.** clean slab 을 넣고 보고량을
      "E_ads 절대값" 으로 바꿨더니 preflight 가 dirty tree 만 걸고 통과시켰다.

    무엇을 보나
      · 이름이 같은가 (공백 정규화 후 정확 일치)
      · 사전등록이 **금지한 이름**(`⛔_부르면_안_되는_이름`)을 MANIFEST 가 쓰고 있지 않은가

    ⛔ 이 검사가 **못 하는 것**
      · 식이 물리적으로 옳은지 모른다. 두 문서가 **같은 말을 하는지**만 본다.
      · 사전등록 자체가 틀렸으면 둘 다 틀린 채로 통과한다. 사람이 볼 몫이다.
      · 번들에 사전등록 사본이 없으면(구판) 조용히 건너뛴다 — 없는 것을 위반으로 세지 않는다.
    """
    import re as _re
    bad = []
    _bs = (man.get("governance_binding") or {}).get("bundled_sources") or {}
    _pre = next((v for k, v in _bs.items() if "claim_prereg" in k), None)
    if not _pre or not os.path.isfile(_pre):
        return bad                      # 사본이 없으면 판정하지 않는다
    try:
        with open(_pre, encoding="utf-8") as _f:
            _p = json.load(_f)
    except (OSError, ValueError) as _e:
        return ["사전등록 사본을 읽지 못했다 (%s)" % type(_e).__name__]
    _q = _p.get("1_보고량") or {}
    _rq = man.get("reported_quantity") or {}
    _n = lambda s: _re.sub(r"\s+", " ", str(s or "")).strip()
    if _n(_q.get("이름")) and _n(_rq.get("name")) != _n(_q.get("이름")):
        bad.append("보고량 이름이 비준 사전등록과 다르다 —\n"
                   "        사전등록: %s\n"
                   "        MANIFEST: %s\n"
                   "        ⇒ 새 보고량이면 §1_보고량 을 개정하고 **다시 비준**해야 한다 "
                   "(보고량 카드 → decisions.json)." % (_q.get("이름"), _rq.get("name")))
    # ⚠ 금지는 **부르는 이름**에 대한 것이지 언급이 아니다. 주의문에 "문헌 binding
    #   energy 와 같은 표에 놓지 않는다" 라고 **금지하려고** 쓴 것까지 잡으면 안 된다
    #   (실측 2026-09-04 — 초판이 자기 경고문을 물었다). ⇒ 이름 칸만 본다.
    _named = " | ".join(str(_rq.get(_k) or "") for _k in ("name", "korean", "formula", "기호"))
    for _f in (_q.get("⛔_부르면_안_되는_이름") or []):
        _w = str(_f).split("·")[0].split("—")[0].strip()
        if _w and len(_w) >= 4 and _w.lower() in _named.lower():
            bad.append("사전등록이 금지한 이름 '%s' 을 MANIFEST 가 **보고량의 이름/식으로** "
                       "쓰고 있다 (주의문에서 언급하는 것은 걸리지 않는다)" % _w)
    return bad


def _governance_strict(gb):
    """거버넌스 결박을 엄격하게 본다 → 차단 사유 목록 (회신 BD P0-3).

    ⛔ 못 하는 것: 그 문서의 *내용*이 옳은지는 안 본다 — 결박과 상태만 본다.
    """
    b = []
    _dec = gb.get("decisions")
    if not isinstance(_dec, dict):
        return ["governance_binding.decisions 가 dict 가 아니다 (%r)" % type(_dec).__name__]
    # ── ① 필수 decision **집합**이 정확히 있는가 (목록을 산출물이 정하지 않는다)
    _miss = [i for i in C12_REQUIRED_DECISIONS if i not in _dec]
    if _miss:
        b.append("필수 decision 이 없다 %s — 목록은 코드가 정한다 (BD P0-3)" % _miss)
    for _i in C12_REQUIRED_DECISIONS:
        _v = _dec.get(_i)
        if not isinstance(_v, dict):
            continue
        if not _strict_true(_v.get("ratified")):
            b.append("%s: ratified 가 **불리언 True 가 아니다** (%r)"
                     % (_i, _v.get("ratified")))
        if _v.get("state") not in ("active", "ratified"):
            b.append("%s: state=%r" % (_i, _v.get("state")))
        _dg = str(_v.get("digest") or "")
        if not _HEX64.match(_dg):
            b.append("%s: digest 가 64-hex 가 아니다 (%r)" % (_i, _v.get("digest")))
        if not _strict_true(_v.get("digest_matches")):
            b.append("%s: 기록 digest 와 재계산이 일치하지 않는다 (%r)"
                     % (_i, _v.get("digest_matches")))
    # ── ② 참조 문서 — 경로별 **역할이 코드에 고정**돼 있다
    _rs = gb.get("reference_files_state")
    _rf = gb.get("reference_files_sha256")
    if not isinstance(_rs, dict) or not isinstance(_rf, dict):
        return b + ["reference_files_state/sha256 가 dict 가 아니다"]
    for _p, _role in sorted(C12_REQUIRED_REFS.items()):
        if _p not in _rs or _p not in _rf:
            b.append("필수 참조 문서가 없다: %s — 목록은 코드가 정한다" % _p)
            continue
        _sha = str(_rf.get(_p) or "")
        if not _HEX64.match(_sha):
            b.append("%s: SHA 가 64-hex 가 아니다 (%r)" % (_p, _rf.get(_p)))
        _v = _rs.get(_p) or {}
        if _v.get("role") != _role:
            b.append("%s: role 이 %r 이어야 하는데 %r 다 — 역할을 바꿔 비준 요구를 "
                     "우회할 수 없다" % (_p, _role, _v.get("role")))
            continue
        # 🔴 회신 BF P1 — 불리언 필드는 **정확히 불리언**이어야 한다 (문자열 "false" 는 참이다)
        if _v.get("superseded") is not False:
            b.append("%s: superseded 가 불리언 False 가 아니다 (%r) — SUPERSEDED 문서이거나 형식 위반"
                     % (_p, _v.get("superseded")))
        if _role == "claim":
            # ⛔ GO 해제조건 4 — claim 만 ratification digest 로 본다
            if not _strict_true(_v.get("ratified")):
                b.append("%s: ratified 가 불리언 True 가 아니다 (%r)"
                         % (_p, _v.get("ratified")))
            if not _strict_true(_v.get("has_ratification_record")):
                b.append("%s: 사람 비준 기록이 없다 (또는 불리언 True 가 아니다)" % _p)
            if not _strict_true(_v.get("digest_matches")):
                b.append("%s: 비준 이후 내용이 바뀌었다 (digest 불일치)" % _p)
        else:
            # ⛔ GO 해제조건 4 — frozen_input 은 **raw SHA** 로만 본다.
            #   합법적으로 digest_matches=false 이므로 그것으로 막지 않는다.
            if _v.get("ratified") is True:
                b.append("%s: frozen_input 인데 ratified=True 다 — 데이터에 비준을 "
                         "붙이면 고무도장이 된다" % _p)
    # ⛔ 회신 BD P1 — 요약 **네 칸**을 전부 교차검사한다. 종전엔 `all_ratified` 만
    #   봤고 나머지 셋은 지우거나 false 로 바꿔도 통과했다.
    _dec_ok = all(_strict_true((_dec.get(i) or {}).get("ratified"))
                  for i in C12_REQUIRED_DECISIONS)
    _ref_ok = all(_strict_true((_rs.get(p_) or {}).get("ratified"))
                  for p_, r_ in C12_REQUIRED_REFS.items() if r_ == "claim")
    _in_ok = all(bool(_rf.get(p_)) for p_, r_ in C12_REQUIRED_REFS.items()
                 if r_ == "frozen_input")
    for _k, _want in (("decisions_all_ratified", _dec_ok),
                      ("reference_files_all_ratified", _ref_ok),
                      ("frozen_inputs_all_bound", _in_ok),
                      ("all_ratified", _dec_ok and _ref_ok and _in_ok)):
        if _k not in gb:
            b.append("요약 `%s` 가 없다 — 네 칸을 전부 교차검사한다 (BD P1)" % _k)
        elif bool(gb.get(_k)) != _want:
            b.append("요약 `%s`=%r 가 개별 항목(%r)과 **어긋난다** (BD P1)"
                     % (_k, gb.get(_k), _want))
    # 목록 밖 문서가 섞여 있으면 그 자체가 신호다 (evil.json 재현)
    _extra = sorted(set(_rs) - set(C12_REQUIRED_REFS))
    if _extra:
        b.append("코드가 모르는 참조 문서가 섞여 있다 %s — 목록을 바꾼 번들이 자기 "
                 "기준으로 통과할 수 없다" % _extra[:3])
    return b


def provenance_strict(man):
    """생성 계보(provenance)의 **완전성**을 본다 → 차단 목록 (회신 BF P0-4).

    🔴 종전엔 `{"clean": true, "dirty": [], "unknown_git_state": []}` 만 남겨도 통과했다 —
      필수 입력 집합·개별 SHA·개수·schema 를 검사하지 않았기 때문이다.
      ⇒ ① schema · files(dict, 비어 있지 않음) · n_files 일치 ② 항목마다 sha 64-hex · kind ·
        git · scope ③ generator 항목 ≥1 ④ dirty/unknown/clean 이 항목의 git 상태와 **재계산**
        일치 ⑤ 필수 입력 집합(비준 참조 문서 3 + decisions.json)이 있고 참조 문서 SHA 는
        governance_binding.reference_files_sha256 과 같다.
    ⛔ 못 하는 것: 등록되지 않은 입력·위조는 못 본다 (이 검사는 "목록을 줄여 놓은 번들" 을 닫는다).
    """
    b = []
    pv = (man or {}).get("provenance")
    if not isinstance(pv, dict):
        return b                        # 부재는 호출부가 따로 막는다
    if not str(pv.get("schema") or "").startswith("bundle_provenance/"):
        b.append("PROVENANCE_INCOMPLETE(schema=%r — bundle_provenance/* 가 아니다)" % (pv.get("schema"),))
    files = pv.get("files")
    if not isinstance(files, dict) or not files:
        return b + ["PROVENANCE_INCOMPLETE(files 목록이 없다 — clean 요약만 있는 계보는 계보가 아니다 · BF P0-4)"]
    if pv.get("n_files") != len(files):
        b.append("PROVENANCE_INCOMPLETE(n_files=%r ≠ files %d)" % (pv.get("n_files"), len(files)))
    _kinds_ok = {"generator", "imported_module", "input"}
    _dirty, _unk, _ngen = [], [], 0
    for k, v in sorted(files.items()):
        if not isinstance(v, dict):
            b.append("PROVENANCE_INCOMPLETE(%s: 항목이 객체가 아니다)" % k); continue
        if not _HEX64.match(str(v.get("sha256") or "")):
            b.append("PROVENANCE_INCOMPLETE(%s: sha256 이 64-hex 가 아니다)" % k)
        if v.get("kind") not in _kinds_ok:
            b.append("PROVENANCE_INCOMPLETE(%s: kind=%r)" % (k, v.get("kind")))
        if v.get("scope") not in ("repo", "external_content_bound"):
            b.append("PROVENANCE_INCOMPLETE(%s: scope=%r)" % (k, v.get("scope")))
        g = str(v.get("git") or "")
        if not g:
            b.append("PROVENANCE_INCOMPLETE(%s: git 상태가 없다)" % k)
        if g in ("modified", "untracked"):
            _dirty.append(k)
        if g == "unknown":
            _unk.append(k)
        if v.get("kind") == "generator":
            _ngen += 1
    if _ngen < 1:
        b.append("PROVENANCE_INCOMPLETE(generator 항목이 없다)")
    if sorted(pv.get("dirty") or []) != sorted(_dirty):
        b.append("PROVENANCE_INCOMPLETE(dirty 목록 %s ≠ 항목의 git 상태에서 재계산 %s)"
                 % ((pv.get("dirty") or [])[:3], _dirty[:3]))
    if sorted(pv.get("unknown_git_state") or []) != sorted(_unk):
        b.append("PROVENANCE_INCOMPLETE(unknown_git_state 목록 ≠ 재계산)")
    if pv.get("clean") is not ((not _dirty) and (not _unk)):
        b.append("PROVENANCE_INCOMPLETE(clean=%r 가 항목 재계산(%s)과 다르다)"
                 % (pv.get("clean"), (not _dirty) and (not _unk)))
    _rf = ((man or {}).get("governance_binding") or {}).get("reference_files_sha256") or {}
    for p in list(C12_REQUIRED_REFS) + ["db/governance/decisions.json"]:
        if p not in files:
            b.append("PROVENANCE_INCOMPLETE(필수 입력 %s 이 계보에 없다 — 목록을 줄인 번들 · BF P0-4)" % p)
            continue
        if p in _rf and _rf.get(p) and str(files[p].get("sha256")) != str(_rf.get(p)):
            b.append("PROVENANCE_INCOMPLETE(%s: 계보 sha %s… ≠ governance 기록 %s…)"
                     % (p, str(files[p].get("sha256"))[:12], str(_rf.get(p))[:12]))
    return b


def governance_bytes_check(man):
    """governance_binding 을 **번들에 실린 원문 byte** 에서 다시 계산해 대조한다 → 차단 목록.

    🔴🔴 회신 BE P0-4 (2026-09-03) — 종전 분석기는 manifest 의 `ratified`·
      `digest_matches` 불리언과 기록된 digest 를 **믿었다**. 리뷰어 재현: 문자열
      "false" · 틀린 digest · 불완전 provenance 가 통과. 생성기가 옳게 적었더라도
      분석기는 그것을 증명하지 못했다 — "v28 이 맞다는 사실을 게이트가 보증하지
      못한다" 는 것이 BE 의 요지다.
      ⇒ 번들이 `governance/` 에 원문 사본을 싣고(files_sha256 에 결박), 분석기는
        **같은 판독기(GOV_CORE)** 로 다시 계산해 manifest 의 주장과 **항목마다** 대조한다.
        하나라도 어긋나면 차단. 원문이 없으면 확인 못 한 것이고 그것은 통과가 아니다.

    ⛔ 못 하는 것: 원문 사본 자체가 위조됐는지는 못 본다 — 그건 files_sha256 ·
      ZIP 해시 · 우리 repo 의 원본 대조(리뷰어 몫)가 진다. 이 검사는 "manifest 만
      고쳐 놓는 경로" 와 "생성기가 잘못 적은 경로" 를 닫는다.
    """
    b = []
    gb = (man or {}).get("governance_binding") or {}
    root = (man or {}).get("_root")
    srcs = gb.get("bundled_sources")
    if not isinstance(srcs, dict) or not srcs:
        return ["governance_binding.bundled_sources 가 없다 — 원문 byte 를 번들 안에서 "
                "다시 계산할 수 없다 (BE P0-4 · 구판 번들이면 재생성)"]
    if not root:
        return ["번들 루트를 모른다 — governance 원문을 읽을 수 없다 (BE P0-4)"]

    def _bundled(rel):
        # 🔴 회신 BF P0-4 — 번들 **안**으로만 해석되는 경로 (`..`·절대경로 이탈 금지)
        return _bundled_ref_path(man, rel)

    _rs = gb.get("reference_files_state") or {}
    _rf = gb.get("reference_files_sha256") or {}
    for _p, _role in sorted(C12_REQUIRED_REFS.items()):
        _f, _why = _bundled(_p)
        if _f is None:
            b.append(_why); continue
        _sha = hashlib.sha256(open(_f, "rb").read()).hexdigest()
        if _sha != str(_rf.get(_p) or ""):
            b.append("%s: 원문 사본 sha %s… ≠ manifest 기록 %s… — 사본과 주장이 다르다"
                     % (_p, _sha[:12], str(_rf.get(_p) or "")[:12]))
        _st = ref_doc_state(_f)
        _cl = _rs.get(_p) or {}
        if _st.get("superseded"):
            b.append("%s: 원문이 **SUPERSEDED/철회** 문서다" % _p)
        if _role != "claim":
            continue                      # frozen_input 은 raw SHA 결박만 (BD P0-3)
        if _st.get("ratified") is not True:
            b.append("%s: 원문에서 다시 계산하면 비준이 **서지 않는다** (%s)"
                     % (_p, _st.get("why")))
        for _k in ("ratified", "digest_matches", "superseded", "has_ratification_record"):
            if bool(_st.get(_k)) != bool(_cl.get(_k)) or (_cl.get(_k) is not None
                                                          and not isinstance(_cl.get(_k), bool)):
                b.append("%s: manifest 의 %s=%r 가 원문 재계산 %r 와 다르다"
                         % (_p, _k, _cl.get(_k), _st.get(_k)))
        if _cl.get("status") != _st.get("status"):
            b.append("%s: manifest status=%r ≠ 원문 %r" % (_p, _cl.get("status"), _st.get("status")))

    _df, _why = _bundled("db/governance/decisions.json")
    if _df is None:
        return b + [_why]
    try:
        with open(_df, encoding="utf-8") as _fh:
            _dall = {x.get("id"): x for x in (json.load(_fh).get("decisions") or [])}
    except Exception as _e:                                  # noqa: BLE001
        return b + ["decisions.json 원문 사본을 읽을 수 없다 (%r)" % (_e,)]
    _md = gb.get("decisions") or {}
    for _i in C12_REQUIRED_DECISIONS:
        x = _dall.get(_i)
        if x is None:
            b.append("%s: 원문 decisions.json 에 없다" % _i); continue
        _dg = dec_digest(x)
        _rt = x.get("ratification") or {}
        _rec = str(_rt.get("decision_digest") or "").split(":")[-1]
        if _rec != _dg:
            b.append("%s: 원문의 기록 digest %s… ≠ 재계산 %s… (비준 뒤 내용이 바뀌었다)"
                     % (_i, _rec[:12], _dg[:12]))
        if _rt.get("state") != "ratified":
            b.append("%s: 원문 ratification.state=%r — 비준이 아니다" % (_i, _rt.get("state")))
        # 🔴 회신 BG P1-1 — 참조 문서와 **같은 형식 검사**를 결정 원문에도 건다.
        _rt_bad = ratification_record_problems(_rt, digest_field="decision_digest")
        if _rt_bad:
            b.append("%s: 원문 비준 기록 형식 위반 — %s (BG P1-1)" % (_i, "; ".join(_rt_bad)))
        if x.get("decision_state") not in ("active", "ratified"):
            b.append("%s: 원문 decision_state=%r" % (_i, x.get("decision_state")))
        m = _md.get(_i) or {}
        if m.get("digest") != _dg:
            b.append("%s: manifest digest %s… ≠ 원문 재계산 %s…"
                     % (_i, str(m.get("digest") or "")[:12], _dg[:12]))
        if str(m.get("recorded_digest") or "").split(":")[-1] != _rec:
            b.append("%s: manifest recorded_digest ≠ 원문 기록" % _i)
        if m.get("state") != x.get("decision_state"):
            b.append("%s: manifest state=%r ≠ 원문 %r" % (_i, m.get("state"), x.get("decision_state")))
        if m.get("ratified") is not (_rt.get("state") == "ratified"):
            b.append("%s: manifest ratified=%r 가 원문(%s)과 다르다"
                     % (_i, m.get("ratified"), _rt.get("state")))
    return b


def citation_status(man, cl):
    """계산 성공과 **원고 인용 자격**을 분리해 낸다 (회신 BA P0-3 · 해제조건 4).

    → {"manuscript_citable", "why", "blockers"}

    ⛔⛔ 왜 분리하나 (2026-09-02)
      종전엔 분석기가 `potcar_identity_policy.manuscript_citable` 를 **읽지 않았고**,
      `_final_verdict()` 가 post-hoc·overall=None 이어도 성공을 반환했다. 즉
      "계산이 잘 돌았다" 와 "원고에 쓸 수 있다" 가 한 값에 뭉개져 있었다.
      ⇒ 성공은 성공대로 내고, 인용 자격은 **별도 상태**로 기계가 집행한다.

    ⛔ 못 하는 것: 원고 문장이 실제로 그 조건을 지키는지 보지 않는다 (사람 몫).
    """
    b = []
    pol = (man or {}).get("potcar_identity_policy") or {}
    if pol.get("manuscript_citable") is not True:
        b.append("potcar_identity_policy.manuscript_citable != true (mode=%r) — "
                 "승인된 PAW dataset 인지 확인되지 않았다" % pol.get("mode"))
    if (cl or {}).get("overall_citable_at_0.01eV") is not True:
        b.append("overall_citable_at_0.01eV != true — ENCUT·축간 상호작용을 안 쟀다")
    _pi = (cl or {}).get("potcar_identity") or {}
    if _pi and _pi.get("allowed_claim") not in ("paw_release_attested",):
        b.append("potcar_identity.allowed_claim=%r — 외부 앵커가 없다"
                 % _pi.get("allowed_claim"))
    # ⛔ 회신 BA 해제조건 3 — 거버넌스 비준이 없으면 인용 자격이 서지 않는다.
    # ⛔⛔ 회신 BB P0-3 (2026-09-02) — **요약 불리언을 믿으면 fail-open 이다.**
    #   종전엔 `all_ratified` 하나만 봤다. 그 값이 true 이면 내부 decision 이
    #   proposed/false/digest BROKEN 이어도 `manuscript_citable=true` 가 재현됐다.
    #   ⇒ 항목마다 직접 본다. 요약은 **정보**이고, 개별 항목과 어긋나면 그 자체가
    #     차단 사유다 (누가 요약만 고쳐 놓는 경로를 닫는다).
    # ⛔⛔ 회신 BD P0-3 (2026-09-02) — **판독기가 fail-open 과 fail-closed 를 동시에
    #   냈다.** 필수 문서 집합과 path→role 을 고정하지 않아 다음이 전부
    #   `manuscript_citable=true` 로 통과했다(리뷰어 재현): 필수 문서 삭제 · 전체
    #   reference 를 evil.json 하나로 교체 · SHA 를 "x" 로 · has_ratification_record
    #   =false · clean=true 인데 dirty 가 비어 있지 않음 · 불리언 대신 문자열 "false".
    #   반대로 **정상 frozen pose** 는 비준 대상이 아니라 합법적으로
    #   digest_matches=false 인데 role 을 안 봐서 "비준 후 변경" 으로 거짓 차단했다.
    #   ⇒ 필수 key 집합과 role 을 **코드에 고정**하고, 엄격 타입으로 본다.
    _gb = (man or {}).get("governance_binding") or {}
    if _gb:
        _bad_g = _governance_strict(_gb)
        b.extend(_bad_g)
        # 🔴 회신 BE P0-4 — manifest 주장을 **원문 byte 에서 다시 계산**해 대조한다.
        b.extend(governance_bytes_check(man))
    else:
        b.append("governance_binding 이 없다 — 구판 번들이다 (BA 해제조건 3)")
    # ⛔⛔ 회신 BB P0-5 (2026-09-02) — **생성 계보가 dirty 면 인용 자격이 없다.**
    #   리뷰어 판정(Q5): 생성기든 dependency 든 input 이든 커밋본과 다르면 그 번들은
    #   폐기다. 범위를 사후에 확정할 수 없으면 clean tree 재생성이 안전하다.
    _pv = (man or {}).get("provenance")
    if _pv is None:
        b.append("provenance 가 없다 — 구판 번들이다 (BB P0-5). 어떤 코드·입력으로 "
                 "만들어졌는지 번들 안에서 말하지 못한다")
    elif (_pv.get("dirty") or _pv.get("unknown_git_state")) and _pv.get("clean"):
        # ⛔ 회신 BD P0-3 재현 — `clean=true` 인데 dirty 가 비어 있지 않은 번들이
        #   통과했다. 요약과 목록이 어긋나면 그 자체가 차단 사유다.
        b.append("provenance.clean=true 인데 dirty/미상 목록이 **비어 있지 않다** "
                 "(%s) — 요약과 목록이 어긋난다 (BD P0-3)"
                 % ((_pv.get("dirty") or _pv.get("unknown_git_state"))[:3]))
    elif not _strict_true(_pv.get("clean")):
        b.append("생성 계보가 **dirty** 다 (수정 %d · git상태 미상 %d) %s — "
                 "커밋본과 다른 코드·입력으로 만든 번들이다 (BB P0-5 · Q5)"
                 % (len(_pv.get("dirty") or []),
                    len(_pv.get("unknown_git_state") or []),
                    (_pv.get("dirty") or _pv.get("unknown_git_state") or [])[:3]))
    # 🔴 회신 BF P0-4 — 요약 세 칸만으로는 계보가 아니다: 목록·SHA·개수·필수 집합을 본다
    b.extend(provenance_strict(man))
    return {"manuscript_citable": not b,
            "blockers": b,
            "why": ("원고 인용 가능" if not b else
                    "⛔ **탐색용**이다. 이 결과로 원고 문장을 쓰지 않는다 — " +
                    " · ".join(b)),
            "⛔_계산_성공과_다른_상태다": (
                "계산이 정상 종료하고 게이트를 통과해도 이 값이 false 면 인용 불가다. "
                "둘을 한 값으로 뭉개지 않는다 (회신 BA P0-3)")}


def _final_verdict(_cl, _vc):
    """최종 종료 판정 — 비인용 상태면 사유 목록을 낸다 (빈 목록 = exit 0).

    ⛔⛔ 회신 AS 해제조건 1 (2026-08-31) — 종전엔 정본 `blocks` 를 읽었다.
      회신 AR Q1 이후 정본은 **강등하지 않으므로** `BASIN_HETEROGENEOUS` 가 남고,
      pm1 과 net4 는 **의도적으로 다른 magnetic topology** 라 둘 다 정상 수렴해도
      그것이 뜬다. 즉 이 번들은 **성공할 수 없었다** — 외주가 16잡을 다 돌린 뒤에야
      알았을 결함이다. 성공/실패 판정의 정본을 `primary_estimand_blocks` 하나로
      통일한다 (정본 blocks 는 기록으로 남고, 강등분은 nonprimary_notes 에 있다).

    ⛔ 이 함수가 못 하는 것: 왜 막혔는지 진단하지 않는다. 사유 문자열만 모은다.
    """
    bad = []
    if _vc and _vc.get("applicable") and not _vc.get("pass"):
        bad.append("closure_vacconv.pass != true")
    if str((_cl or {}).get("verdict", "")).startswith("NO_VALUE"):
        bad.append("prereg_closure = NO_VALUE")
    fin = (_cl or {}).get("primary_estimand_blocks")
    if fin is None:                              # 구판 결과 — 강등 뷰가 없다
        fin = (_cl or {}).get("blocks")
    if fin:
        bad.append("prereg_closure.primary_estimand_blocks %s" % fin[:2])
    return bad


def _selftest_closure(chk):
    """사전등록 estimand 의 ⛔음성 묶음 — **배포본 안에서** 돌아야 한다.

    ⛔⛔ 회신 AR P1-12 · 해제조건 10 (2026-08-31) — 이 시험들이 종전엔
      **생성기 selftest 에만** 있었다. 배포된 번들에서
      `python3 analyze_results.py --selftest` 를 돌리면 179건만 나오고
      production `_closure_estimand` 는 하나도 안 탔다. 외주처·리뷰어가
      재현할 수 없는 검사는 "있다" 고 말할 수 없다 ⇒ 여기로 옮긴다.
      생성기 selftest 는 이 함수를 **그대로 호출**한다 (출처는 하나다).

    이 함수가 **못 하는 것**: 실제 VASP·POTCAR·스케줄러를 대신하지 않는다.
      합성 job 레코드로 판정 논리만 친다.
    """
    # ── 🔴 회신 AT P0-2 — dense 상의 INCAR·k 감사 fail-open (배포본에서 돈다) ──
    #   ⚠ 이 시험은 **여기 있어야** 한다. `phase_gates` 는 배포본 분석기의 함수라
    #     생성기 selftest 스코프에는 없다 (2026-08-31 NameError 로 확인).
    def _at_pg(ph, meta_over=None, oc_over=None):
        _oc = {"nions": 4, "nkpts": 12, "normal_end": True, "nelm_hit": False,
               "ionic_conv": True, "titels": [], "E0": -1.0, "toten": -1.0,
               "mag_tot": None, "nelect": None, "n_iter": 5,
               "kpoints_title": "phase=dense k=4 6 1 shift=0 0 0",
               "incar_echo": {}, "run_segments": {"n": 1}}
        _oc.update(oc_over or {})
        _mt = {"species_order": [], "kmesh": {"dense": "4 6 1"},
               "incar_expected": {"dense": {"ENCUT": "520"}},
               "kpoints_expected": {"dense": {
                   "title": "phase=dense k=4 6 1 shift=0 0 0", "mode": "Gamma",
                   "mesh": "4 6 1", "shift": "0 0 0"}}}
        _mt.update(meta_over or {})
        return {x.split("(")[0] for x in phase_gates(_oc, ph, _mt, {})}

    chk("KPOINTS_MISMATCH" not in _at_pg("dense")
        and "INCAR_EXPECTED_MISSING" not in _at_pg("dense"),
        "AT P0-2 양성: 제목·기대 INCAR 이 맞으면 k/INCAR 게이트가 안 뜬다")
    chk("KPOINTS_MISMATCH" in _at_pg(
            "dense", oc_over={"kpoints_title": "phase=static k=3 4 1 shift=0 0 0"}),
        "⛔음성 AT P0-2: **coarse(3 4 1) OUTCAR 를 dense 폴더에** 넣으면 잡힌다 "
        "— 종전엔 NKPTS 12 ≤ 24 라 통과했다")
    chk("KPOINTS_TITLE_UNVERIFIED" in _at_pg("dense", oc_over={"kpoints_title": None}),
        "⛔음성 AT P0-2: ` KPOINTS:` 되울림이 없으면 **확인 못 함**이지 통과가 아니다")
    chk("KPOINTS_EXPECTED_MISSING" in _at_pg("dense", meta_over={"kpoints_expected": {}}),
        "⛔음성 AT P0-2: 구판 번들(kpoints_expected 없음)의 dense 는 막는다")
    chk("INCAR_EXPECTED_MISSING" in _at_pg("dense", meta_over={"incar_expected": {}}),
        "⛔음성 AT P0-2: dense 의 기대 INCAR 이 없으면 막는다 — 없으면 그 상의 "
        "감사가 통째로 비어 ENCUT 400·IVDW 0·ISPIN 1 도 통과한다")
    chk("KPOINTS_EXPECTED_MISSING" not in _at_pg(
            "static", meta_over={"kpoints_expected": {}, "kmesh": {}}),
        "AT P0-2 경계: static 은 기대값이 없어도 **이 게이트로는** 막지 않는다 "
        "(δ_k 에 직접 들어가는 상만 강제)")

    # ⛔ 회신 AS 해제조건 3 — pool 완전성 검사가 `planned` 를 읽는다. 실물 manifest
    #   에는 항상 있으므로 픽스처도 실물 모양이어야 한다 (회신 AP #8 과 같은 교훈).
    def _PL(jn, role="primary", frag=None, seed="afm2424_pm1"):
        return {"phases": ["static"], "required": True,
                "meta": {"kind": "prospective_pose", "d3": "on",
                         "fragment": frag or jn.split("/")[-1].split("__")[0],
                         "basin_id": jn.split("__")[1], "role": role, "seed": seed}}
    _PLANNED = {k: _PL(k) for k in
                ("prospective/sdcp_neutral__b00__afm2424_pm1",
                 "prospective/sdcp_neutral__b01__afm2424_pm1",
                 "prospective/ptfe_c10__b00__afm2424_pm1")}
    # 🔴 회신 BE P0-1 — 기체 기준계도 **planned 에 있는 잡**이다 (실물 manifest 그대로).
    #   estimand 의미 검사가 네 키 전부를 planned 선언과 대조하므로 픽스처도 싣는다.
    for _f0 in ("sdcp_neutral", "ptfe_c10"):
        for _b0 in ("20", "24"):
            _PLANNED["refs/mol__%s__box%s" % (_f0, _b0)] = {
                "phases": ["static"], "required": True,
                "meta": {"kind": "mol_ref", "fragment": _f0, "box_margin_A": float(_b0)}}
    # 🔴 회신 BE P0-1 — 사전 고정 네 잡 (실물 생성기가 박는 모양: primary b00 두 잡 +
    #   refs/mol__<frag>__box24 부모 + branch). 픽스처 전체가 이 봉인을 공유한다.
    _EJK_PM1 = {"E_C_sdcp": "prospective/sdcp_neutral__b00__afm2424_pm1",
                "E_C_control": "prospective/ptfe_c10__b00__afm2424_pm1",
                "E_G_sdcp": "refs/mol__sdcp_neutral__box24",
                "E_G_control": "refs/mol__ptfe_c10__box24",
                "branch": "afm2424_pm1",
                "formula": "D = (E_C_sdcp - E_G_sdcp) - (E_C_control - E_G_control)"}
    # 🔴 회신 BE P0-1 — 실물처럼 **대안 자세(stress_sensitivity) 잡이 planned·jobs 에 원래
    #   있다**. 리뷰어 공격은 그 잡을 가리키게 manifest 키만 바꾸는 것이었다 — 다른
    #   게이트는 아무것도 안 바뀌므로 의미 검사만이 그것을 잡는다.
    _KSS = "prospective/sdcp_neutral__b12__afm2424_pm1"
    _PLANNED[_KSS] = _PL(_KSS, role="stress_sensitivity")
    # 🔴 회신 BE P0-2 — 기체 쌍은 이제 POSCAR **실물**도 본다. 픽스처 루트에 실물을 쓴다:
    #   box20 = 30 Å 상자 · box24 = 34 Å 상자, 좌표는 +2.0 Å 강체 평행이동 (COM 중심 정의).
    _GROOT_EST = pathlib.Path(__import__("tempfile").mkdtemp()) / "est"

    def _write_gas_poscars(root, frag, same_cell=False, shift=2.0, center_shift=0.0,
                           box_extra=0.0):
        """🔴 회신 BF P0-3 — 픽스처를 **생성기 계약 그대로** 만든다: 질량중심을 셀 중앙에,
        상자 = 내부 span + margin(20/24). 종전 픽스처(30/34 Å 상자 · 모서리 근처 배치)는 상대
        관계만 맞아서 절대 검사를 시험할 수 없었다. `center_shift`·`box_extra` 가 음성 손잡이다."""
        _geo = ((0.0, 0.0, 0.0), (0.9, 0.0, 0.0), (0.0, 0.9, 0.0))          # O, H, H
        _ms = (15.999, 1.008, 1.008)
        _com = [sum(m * g[ax] for m, g in zip(_ms, _geo)) / sum(_ms) for ax in range(3)]
        _span = [max(g[ax] for g in _geo) - min(g[ax] for g in _geo) for ax in range(3)]
        for _b, _mg in (("20", 20.0), ("24", 20.0 if same_cell else 24.0)):
            _d = root / "refs" / ("mol__%s__box%s" % (frag, _b))
            _d.mkdir(parents=True, exist_ok=True)
            _box = [_span[ax] + _mg + box_extra for ax in range(3)]
            # `shift` ≠ 2.0 (음성): 셀은 그대로 +4 Å 두고 **좌표만** 2.0 대신 shift 만큼 밀어
            #   "+2.0 Å 강체 평행이동" 검사가 걸리게 한다 (셀 차 검사에서 먼저 끊기지 않게)
            _extra = (shift - 2.0) if (_b == "24" and not same_cell) else 0.0
            _lines = ["gas %s box%s" % (frag, _b), "1.0",
                      "  %.6f 0.0 0.0" % _box[0], "  0.0 %.6f 0.0" % _box[1],
                      "  0.0 0.0 %.6f" % _box[2], "  O H", "  1 2", "Cartesian"]
            for g in _geo:
                _lines.append("  %.6f %.6f %.6f" % tuple(
                    g[ax] - _com[ax] + _box[ax] / 2.0 + center_shift + _extra for ax in range(3)))
            (_d / "POSCAR").write_text("\n".join(_lines) + "\n", encoding="utf-8")
    for _f0 in ("sdcp_neutral", "ptfe_c10"):
        _write_gas_poscars(_GROOT_EST, _f0)
    # 🔴 회신 BF P0-1·P0-2 — 실물 번들처럼 **비준 protocol 원문 사본**을 번들 안에 싣는다.
    #   분석기는 estimand 네 키를 protocol 의 exact map 과, 진공 시험 셀을 protocol 의
    #   c1_A/c2_A 와 대조한다. 사본이 없으면 확인 못 함 = 통과 아님 (아래 음성시험).
    _GB_EST = _write_proto_fixture(_GROOT_EST)          # 모듈 수준 헬퍼 (selftest_k 도 쓴다)
    # ⛔ 회신 AS 9 — 실물 manifest 는 kconv_pair 를 담는다. 픽스처도 실물 모양으로.
    _KJ = ("prospective/sdcp_neutral__b00__afm2424_pm1",
           "prospective/ptfe_c10__b00__afm2424_pm1")
    _KCONV = {"jobs": list(_KJ), "coarse_kmesh": "3 4 1", "dense_kmesh": "4 6 1",
              "formula": "δ_k = (E_sdcp,dense−coarse) − (E_ctl,dense−coarse)",
              "tol_eV": 0.005}
    _man = {"fragments": ["sdcp_neutral", "ptfe_c10"],
            "planned": _PLANNED, "kconv_pair": _KCONV,
            # 🔴 회신 BE P0-1·P0-2 — 실물 manifest 는 언제나 네 키를 봉인하고, 분석기는
            #   번들 루트(_root)에서 POSCAR 실물을 읽는다. 픽스처도 그 모양이어야 한다.
            "estimand_job_keys": dict(_EJK_PM1), "_root": str(_GROOT_EST),
            # 🔴 회신 BF P0-1 — 비준 protocol 사본 (exact map 의 정본)
            "governance_binding": dict(_GB_EST),
            # ⛔ 회신 AR 해제조건 3 — 실물 생성기가 박는 기체 쌍 정책
            "gas_geometry_policy": {"fixed_geometry_static": True},
            "molecular_spin_controls": {
                "mol__sdcp_neutral__box24": "refs/mol__sdcp_neutral__box24__nzmag",
                "mol__ptfe_c10__box24": "refs/mol__ptfe_c10__box24__nzmag"}}
    _emol = {"sdcp_neutral": -200.0, "ptfe_c10": -100.0}
    # 🔴 키를 **실물 모양**으로 쓴다 (2026-08-29 자체 적대검토). 생성기는
    #   `prospective/<frag>__<basin>__<seed>` 로 낸다(_pk 가 상대경로 그대로).
    #   접두어 없는 옛 fixture 때문에 `startswith(f+"__")` 버그가 안 보였고,
    #   실물에서는 조각 매칭이 **하나도 안 걸려** J_f 가 조용히 비었다.
    # ⛔ 회신 AP #11 — δ_gas 게이트가 box20/box24 를 요구한다. 픽스처를 실물화한다.
    #   sdcp: 24−20 = +0.3 meV · ptfe: 24−20 = +0.2 meV ⇒ δ_gas = +0.1 meV (통과)
    #   ⚠ 회신 BE P0-1 이후 box24 부모가 **D 의 기체 기준**이다 (canary 가 아니다).
    #     옛 emol(−200/−100)과 같은 값을 두어 D 픽스처 값이 바뀌지 않게 한다.
    _GASE = {"refs/mol__sdcp_neutral__box24": -200.0,
             "refs/mol__sdcp_neutral__box20": -200.0003,
             "refs/mol__ptfe_c10__box24": -100.0,
             "refs/mol__ptfe_c10__box20": -100.0002}
    _en = {"mol__sdcp_neutral__box24__nzmag": -200.0,
           "mol__ptfe_c10__box24__nzmag": -100.0,
           **_GASE,
           "prospective/sdcp_neutral__b00__afm2424_pm1": -201.0,
           "prospective/sdcp_neutral__b01__afm2424_pm1": -200.9,
           "prospective/ptfe_c10__b00__afm2424_pm1": -100.5,
           _KSS: -201.9}                              # 대안 자세 (ALT 역할 · 풀 밖)
    # ★ 회신 Z P0-4 — 모든 잡이 realized basin 을 달고 있어야 뺄셈이 허용된다.
    #   합성 레코드였던 옛 fixture 는 basin 이 없어 새 게이트에 걸렸다 —
    #   **게이트가 맞고 fixture 가 낡았다** (실물은 LORBIT 로 항상 표가 있다).
    def _BAS(b, jn="prospective/sdcp_neutral__b00__afm2424_pm1", **kw):
        """실물 스키마의 job 레코드. **meta 없이 만들면 cohort 조립이 막힌다** —
        회신 AA P0-3 이후 조각·seed·d3 판정이 전부 구조화 필드에서 나온다."""
        base = jn.rsplit("/", 1)[-1]
        # ⚠ 회신 BE P0-1 이후 기본 역할은 **primary** 다 — estimand 의미 검사가 planned
        #   선언(role=primary)과 job.json 실물을 대조하므로 픽스처도 실물 모양이어야 한다.
        m = {"kind": "prospective_pose", "role": "primary",
             "fragment": base.split("__")[0], "basin_id": base.split("__")[1],
             "seed": "afm2424_" + base.split("afm2424_")[1].replace("__d3off", ""),
             "d3": "off" if base.endswith("__d3off") else "on"}
        m.update(kw)
        # ⛔ 회신 AP #2 — estimand 검사가 **Ni 모멘트 표**를 요구한다. basin id 만
        #   있는 픽스처는 실물이 아니다 (실물은 LORBIT 로 항상 표가 있다).
        mg = {"realized_basin_id": b}
        if b is not None:
            mg["realized_basin"] = {"ni_moments_muB":
                                    list(kw.pop("_mom", [1.2] * 24 + [-1.2] * 24))}
        else:
            kw.pop("_mom", None)
        r = {"ok": True, "gates": [], "meta": m, "geom": {"magnetic": mg}}
        # ⛔ 회신 AS 9 — dense 상. `_en` 에 coarse 가 있고 dense 는 그 + 오프셋이다.
        #   기본 오프셋은 두 조각이 같아 δ_k = 0 (통과). 시험이 덮어쓴다.
        if kw.get("_dense") is not None:
            r["dense"] = {"normal_end": True, "E0": kw["_dense"]}
        return r

    # ⛔ 회신 AR 해제조건 3 — 기체 쌍 cross-job gate 는 **잡 메타**를 읽는다.
    #   실물 `_emit_mol_job` 이 내는 필드 그대로 픽스처를 만든다.
    #   (energies 만 주던 옛 픽스처는 계약을 검증할 수 없다 = 통과가 아니다.)
    def _GASJ(frag, tag, geo="g-%s" % "x", **kw):
        # 🔴 회신 BF P0-3 — 내부기하 지문은 **픽스처 POSCAR 에서 재계산**한 값이어야 한다
        #   (분석기가 좌표에서 다시 만들어 대조한다 — "geo-<frag>" 장난감은 이제 걸린다)
        _pfx = read_poscar(str(_GROOT_EST / "refs" / ("mol__%s__%s" % (frag, tag)) / "POSCAR"))
        m = {"kind": "mol_ref", "fragment": frag, "box_margin_A": 20.0 if tag == "box20" else 24.0,
             "species_order": ["O", "S", "C", "F", "H"], "counts": [3, 1, 10, 20, 4],
             "gas_placement": "com_at_cell_center",
             "internal_geometry_sha": (_gas_internal_sha(_pfx) if _pfx else "geo-" + frag),
             "electronic_state_sha": "st-" + frag,
             # 생성기가 모든 job.json 에 사후로 박는 필드 (없으면 COHORT_INCOHERENT)
             "d3": "on", "ivdw_expected": 11,
             "fixed_geometry_static": True, "phases": ["static"]}
        m.update(kw)
        return {"ok": True, "gates": [], "meta": m, "geom": {}}

    _GASJOBS = {"refs/mol__%s__%s" % (f, t): _GASJ(f, t)
                for f in ("sdcp_neutral", "ptfe_c10") for t in ("box20", "box24")}
    _jobs = {k: _BAS("aaaa1111", k,
                     **dict(({"_dense": _en[k] + 0.010} if k in _KJ else {}),
                            **({"role": "stress_sensitivity"} if k == _KSS else {})))
             for k in _en if k.startswith("prospective/")}
    _jobs.update(_GASJOBS)
    _E = lambda j: _en.get(j)
    # ⛔ 회신 AO P0-4 — canary/부모 static 기하 대조 결과. 실물에서는 main() 이
    #   두 static/POSCAR 를 읽어 채운다. 없으면 fail-closed 로 막히므로 픽스처에도
    #   **명시적으로** 넣는다 (없는 것을 통과로 읽지 않는 것이 이 게이트의 요점이다).
    def _RES(same=True, **kw):
        g = {f: ({"same": True, "max_cart_diff_A": 0.0, "max_cell_diff_A": 0.0}
                 if same else
                 {"same": False, "max_cart_diff_A": 0.031, "max_cell_diff_A": 0.0})
             for f in ("sdcp_neutral", "ptfe_c10")}
        g.update(kw)
        return {"pairs": {}, "gas_canary_geom": g}

    r = _closure_estimand(_man, _RES(), _E, _emol, _jobs)
    chk(not r["blocks"], f"[V P0-4] 정상 입력에 blocks 없음 · {r.get('blocks')}")
    chk((r.get("gas_pair_contract") or {}).get("ok") is True
        and (r.get("gas_box_delta") or {}).get("pair_contract_ok") is True,
        "회신 AR 3 양성: 고정기하·동일 내부기하 쌍은 계약을 통과한다")

    # ══ 🔴 회신 AT Q2 — 합산 오차예산 B_num (양성 + ⛔음성) ═════════════════
    _nb = r.get("numeric_budget") or {}
    chk(_nb.get("정의", "").startswith("B_num"),
        "AT Q2: 결과에 **합산 오차예산**이 나온다 (%s)" % _nb.get("B_num_meV"))
    chk("RSS" in str(_nb.get("⛔_RSS_금지", "")),
        "AT Q2: 왜 RSS 를 안 쓰는지 산출물에 적힌다 (독립 확률오차가 아니다)")

    chk(_nb.get("tol_meV") == 5.0 and "미달이면" in _nb,
        "AT Q2: 문턱과 **미달 시 처방**이 결과에 같이 봉인된다 (값을 버리지 않고 "
        "보고 해상도를 낮춘다)")
    chk("sensitivity envelope" in str(_nb.get("성격"))
        and "총 오차 상한이" in str(_nb.get("성격")),
        "AV P1-5: B_num 을 '총 오차 상한' 이 아니라 **시험한 축의 envelope** 로 "
        "명명한다 (ENCUT·교차축 미포함)")
    chk(_nb.get("axes_not_designed") is not None,
        "AV P1-5: 설계에 없는 축이 침묵하지 않고 axes_not_designed 에 명시된다 "
        "(%s)" % _nb.get("axes_not_designed"))

    # ── 🔴 회신 AV P1-5 — **행동 시험**: envelope 초과가 D 를 죽이지 않는다 ──
    #   δ_k 를 10 meV 로 심는다 (dense 를 sdcp 쪽만 +10 meV): B_num > 5.
    _jb_ex = {k: (dict(v, dense={"normal_end": True,
                                 "E0": _en[k] + (0.010 if "sdcp" in k else 0.0)})
                  if k in _KJ else v) for k, v in _jobs.items()}
    _rex = _closure_estimand(_man, _RES(), _E, _emol, _jb_ex)
    chk(not any("NUMERIC_BUDGET_EXCEEDED" in b for b in _rex["blocks"])
        and any("NUMERIC_BUDGET_EXCEEDED" in a for a in (_rex.get("advisories") or [])),
        "🔴 AV P1-5: envelope 초과는 **estimand block 이 아니다** — advisory 로 "
        "남는다 (종전엔 D 계산 전에 NO_VALUE 였다)")
    chk(_rex.get("D_raw_eV") is not None
        and abs(_rex["D_raw_eV"] - (-0.5)) < 1e-6,
        "🔴 AV P1-5: 초과여도 **D_raw 는 보존**된다 (%s)" % _rex.get("D_raw_eV"))
    chk(_rex.get("rounded_value_under_tested_axes_eV") is None
        and _rex.get("tested_axes_stable_at_0.01eV") is False
        and "0.01 eV 인용 자격 없음" in str(_rex.get("rounded_value_under_tested_axes_⚠")),
        "🔴 AV P1-5: 초과 시 **0.01 eV 반올림 보고만** 철회된다 "
        "(tested_axes_stable_at_0.01eV=false)")
    # ⛔음성 회신 AZ P0-5 — `reported_X_eV` 는 overall 자격이 설 때만 존재한다
    # ⚠ 렌즈2 P1-4 (2026-09-03) — overall 은 이제 사전등록 축이 빠지면 False, 다 있으면
    #   None 이다. 이 검사의 뜻은 "True 로 올라가지 않는다" 이므로 `is not True` 로 본다.
    chk("reported_X_eV" not in _rex and _rex.get("overall_citable_at_0.01eV") is not True
        and "primary_ddE_lowE_eV" not in _rex,
        "⛔음성 AZ P0-5 · BA P0-2·Q4: 최상위에 **범위 없는 숫자 필드가 없다** — "
        "죽은 `reported_X_eV` 와 맨숫자 `primary_ddE_lowE_eV` 를 둘 다 걷었다 "
        "(남은 키 %s)" % sorted(k for k in _rex if k.endswith("_eV"))[:4])
    chk((_rex.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None
        and "인용 대상이 아니다" in str((_rex.get("diagnostic_only") or {}).get("⛔")),
        "회신 BA P0-2: 값 자체는 **진단 절 안에** 보존한다 (지우면 왜 못 쓰는지도 "
        "사라져 재논증이 반복된다 — 회신 AT Q5 a)")
    # ⚠ 렌즈2 P1-4 (2026-09-03) — 이 픽스처는 Δ_vac·δ_k 가 설계에 없어 verdict 뒤에
    #   "사전등록 축 없음 …" 꼬리가 붙는다. 앞머리(방향 결론)만 본다.
    chk(str(_rex.get("verdict", "")).startswith("보고 가능 (시험한 축 조건부)")
        and (_rex.get("D_interval_eV") or {}).get("hi", 0) <= -0.10,
        "AV P1-5 + AZ P0-5: 구간 [D−B, D+B] 전체가 guard 이하면 방향 결론은 유지되되 "
        "**시험한 축 조건부**로 적는다 · %s" % _rex.get("D_interval_eV"))
    # 구간이 guard 를 **가로지르면** 방향 결론이 NO_CLAIM 으로 내려간다
    _en_g = dict(_en)
    _en_g["prospective/sdcp_neutral__b00__afm2424_pm1"] = -200.605
    _en_g["prospective/sdcp_neutral__b01__afm2424_pm1"] = -200.604
    _jb_g = {k: (dict(v, dense={"normal_end": True,
                                "E0": _en_g[k] + (0.010 if "sdcp" in k else 0.0)})
                 if k in _KJ else v) for k, v in _jobs.items()}
    _rg2 = _closure_estimand(_man, _RES(), lambda j: _en_g.get(j), _emol, _jb_g)
    chk(str(_rg2.get("verdict", "")).startswith("NO_CLAIM")
        and _rg2.get("D_raw_eV") is not None,
        "⛔음성 AV P1-5: 구간이 guard(−0.10)를 가로지르면 **NO_CLAIM** — 점추정이 "
        "guard 아래여도 방향을 말하지 않는다 (D_raw 는 남는다) · D=%s 구간=%s"
        % (_rg2.get("D_raw_eV"), _rg2.get("D_interval_eV")))
    # 결과 객체가 없는 축은 **miss 로** 들어간다 (종전엔 조용히 빠졌다)
    _man_k0 = {k: v for k, v in _man.items() if k != "kconv_pair"}
    _man_k0["estimand_job_keys"] = None
    _rk0 = _closure_estimand(dict(_man_k0), _RES(), _E, _emol,
                             {k: {kk: vv for kk, vv in v.items() if kk != "dense"}
                              if k in _KJ else v for k, v in _jobs.items()})
    _nb0 = _rk0.get("numeric_budget") or {}
    chk("δ_k(k 수렴 쌍이 이 번들 설계에 없음)" in (_nb0.get("axes_not_designed") or []),
        "⛔음성 AV P1-5: 결과 객체가 없는 축이 **침묵하지 않는다** — 설계에 없으면 "
        "axes_not_designed 로 명시된다 (%s). 인용 자격은 실측 축으로 계산하되 "
        "빠진 축이 산출물에 남아 독자가 envelope 범위를 안다"
        % _nb0.get("axes_not_designed"))

    # ══ 🔴🔴 회신 BE P0-1 (2026-09-03) — fallback 삭제 + 네 키 **의미** 검사 ═══════════
    #   리뷰어 공격을 그대로 재현한다 (같은 합성 에너지에서 키만 바꿔 D 가 나오던 경로).
    chk(str(_rk0.get("verdict", "")).startswith("NO_VALUE")
        and any(b.startswith("ESTIMAND_KEYS_ABSENT") for b in _rk0["blocks"]),
        "⛔음성 BE P0-1: estimand_job_keys 가 없으면 **조각별 최솟값으로 전환하지 않고** "
        "NO_VALUE 다 (종전엔 map 을 지우면 다른 estimand 로 자동 전환됐다)")
    _r_ok = _closure_estimand(_man, _RES(), _E, _emol, _jobs)
    chk(not any("ESTIMAND_SEMANTICS" in b for b in _r_ok["blocks"])
        and (_r_ok.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None
        and abs((_r_ok.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") - (-0.5)) < 1e-9,
        "BE P0-1 양성: 봉인대로 가리키는 네 키는 의미 검사를 통과하고 D=−0.5 가 나온다 (%s)"
        % (_r_ok.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV"))

    def _sem_attack(keys_patch, why, man_over=None, jobs_over=None):
        _mk = dict(man_over or _man, estimand_job_keys=dict(_EJK_PM1, **keys_patch))
        _rr = _closure_estimand(_mk, _RES(), _E, _emol, jobs_over or _jobs)
        chk(str(_rr.get("verdict", "")).startswith("NO_VALUE")
            and any(b.startswith("ESTIMAND_SEMANTICS") for b in _rr["blocks"])
            and (_rr.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is None,
            "⛔음성 BE P0-1 (리뷰어 재현): %s → ESTIMAND_SEMANTICS · NO_VALUE · D 없음 "
            "(실제 %s · blocks %s)"
            % (why, (_rr.get("verdict") or "")[:48], [b[:80] for b in _rr["blocks"]][:2]))

    def _attack_any(keys_patch, why, jobs_over=None):
        """어느 게이트가 막든 **값이 안 나오는지**만 본다 (앞선 구조 게이트가 먼저 잡아도 된다)."""
        _mk = dict(_man, estimand_job_keys=dict(_EJK_PM1, **keys_patch))
        _rr = _closure_estimand(_mk, _RES(), _E, _emol, jobs_over or _jobs)
        chk(str(_rr.get("verdict", "")).startswith("NO_VALUE")
            and _rr.get("rounded_value_under_tested_axes_eV") is None,
            "⛔음성 BE P0-1: %s → NO_VALUE · 보고값 없음 (막은 게이트 %s)"
            % (why, [b.split("(")[0] for b in _rr["blocks"]][:3]))
    # 🔴 1저자 결정 2026-09-03 — **dense 를 설계에서 빼는 것**과 **반송에서만 빠지는 것**은
    #   분석기에서 다른 경로다. 그 둘을 시험이 못박는다 (--no_kconv 의 근거).
    # 🔴 2026-09-03 (렌즈2 P0-1 · P1-2) — 재개 조건은 **기계 평가 가능한 구조**이고, 같은 구조가
    #   비준 사전등록 `3_오차예산.축_설계_제외_*` 에 있어야 하며, MANIFEST 의 것과 같아야 한다.
    _RULE_NK = {"규칙": "재개하지 않는다 — 경계(0.05≤|D_raw|<0.06)면 자문만", "판정량": "D_raw_eV",
                "문턱_eV": 0.05, "가드밴드_eV": 0.01, "비교": "boundary",
                "충족시": "자문만 (KCONV_UNTESTED_AXIS_AT_THRESHOLD) — dense 추가 없음"}
    _PRE_NK = {"3_오차예산": {"축_설계_제외_2026_09_03": {
        "축": "δ_k", "재개_조건_결과_보기_전에_선언": dict(_RULE_NK)}}}
    _KP_NK = {"status": "not_designed", "🔁_재개_조건_결과_보기_전에_선언": dict(_RULE_NK)}
    _r_nk = _closure_estimand(dict(_man, kconv_pair=_KP_NK, _prereg_doc=_PRE_NK),
                              _RES(), _E, _emol, _jobs)
    _nb_nk = (_r_nk.get("numeric_budget") or {})
    # ⛔음성 — 비준 항이 없으면 종전대로 차단 (코드가 비준 문서보다 관대할 수 없다)
    _r_unr = _closure_estimand(dict(_man, kconv_pair=_KP_NK), _RES(), _E, _emol, _jobs)
    chk(any(str(b).startswith("KCONV_OMISSION_UNRATIFIED") for b in _r_unr["blocks"])
        and "δ_k" in ((_r_unr.get("numeric_budget") or {}).get("missing_axes") or [])
        and _r_unr.get("rounded_value_under_tested_axes_eV") is None,
        "⛔음성 렌즈2 P0-1: 사전등록에 '축_설계_제외' 항이 없으면 not_designed 경로가 **열리지 "
        "않는다** (KCONV_OMISSION_UNRATIFIED · δ_k missing) · %s"
        % [str(b)[:40] for b in _r_unr["blocks"] if "KCONV" in str(b)][:2])
    # ⛔음성 — MANIFEST 의 재개 조건이 사전등록 항과 다르면 드리프트 차단
    _r_drf = _closure_estimand(dict(_man, kconv_pair={
        "status": "not_designed",
        "🔁_재개_조건_결과_보기_전에_선언": dict(_RULE_NK, 문턱_eV=0.03)}, _prereg_doc=_PRE_NK),
        _RES(), _E, _emol, _jobs)
    chk(any(str(b).startswith("KCONV_OMISSION_DRIFT") for b in _r_drf["blocks"]),
        "⛔음성 렌즈2 P0-1: MANIFEST 재개 조건 ≠ 사전등록 항 → KCONV_OMISSION_DRIFT")
    # ⛔음성 — 문장만 있고 구조 필드가 없으면 기계 평가 불가 → UNDECLARED
    _r_und = _closure_estimand(dict(_man, kconv_pair={
        "status": "not_designed",
        "🔁_재개_조건_결과_보기_전에_선언": {"규칙": "|ΔE_ads| < 50 meV 이면 dense 2잡"}},
        _prereg_doc=_PRE_NK), _RES(), _E, _emol, _jobs)
    chk(any(str(b).startswith("KCONV_OMISSION_UNDECLARED") for b in _r_und["blocks"]),
        "⛔음성 렌즈2 P1-2: 재개 조건이 문장뿐(판정량·문턱·비교 없음)이면 KCONV_OMISSION_UNDECLARED")
    # 양성 — 재개 조건이 D_raw 에 기계로 대어지고 결과에 남는다 (D=−0.5 → 경계 밖 · 불충족)
    _ev_nk = ((_r_nk.get("kconv_omission") or {}).get("reopen_eval") or {})
    chk(_ev_nk.get("판정량") == "D_raw_eV" and _ev_nk.get("충족") is False
        and abs((_ev_nk.get("값_eV") or 0) - (-0.5)) < 1e-6
        and any("KCONV_REOPEN_NOT_TRIGGERED" in str(x) for x in (_r_nk.get("advisories") or [])),
        "렌즈2 P1-2 양성: 재개 조건을 D_raw_eV=%s 에 기계로 대어 reopen_eval 에 남긴다 (충족 %s · %s)"
        % (_ev_nk.get("값_eV"), _ev_nk.get("충족"), str(_ev_nk.get("행동"))[:40]))
    # 단위 — 세 비교 연산자의 경계 (결과를 보기 전에 정한 규칙이 어느 값에 어떻게 대어지는가)
    _rb = dict(_RULE_NK)
    chk(_kconv_reopen_eval(_rb, -0.055)["충족"] is True
        and _kconv_reopen_eval(_rb, -0.049)["충족"] is False
        and "§8" in _kconv_reopen_eval(_rb, -0.049)["행동"]
        and _kconv_reopen_eval(_rb, -0.061)["충족"] is False
        and _kconv_reopen_eval(dict(_rb, 비교="abs_lt", 충족시="dense 추가"), -0.049)["충족"] is True
        and _kconv_reopen_eval(dict(_rb, 비교="abs_lt", 충족시="dense 추가"), -0.05)["충족"] is False
        and _kconv_reopen_eval(dict(_rb, 비교="none"), -0.01)["충족"] is False,
        "렌즈2 P1-2 단위: boundary [0.05,0.06) · abs_lt <0.05 · none 의 경계가 선언대로다")
    chk(not _kconv_reopen_rule_problems(_RULE_NK)
        and _kconv_reopen_rule_problems({"규칙": "x"})
        and _kconv_reopen_rule_problems(dict(_RULE_NK, 판정량="rounded_value_under_tested_axes_eV"))
        and _kconv_reopen_rule_problems(dict(_RULE_NK, 비교="boundary", 가드밴드_eV=None)),
        "렌즈2 P1-2 단위: 재개 조건 형식 검사 — 판정량은 D_raw_eV 만, boundary 는 가드밴드 필수")
    # 🔴 렌즈2 P1-3 — preflight(--check_governance) 가 같은 정적 조건을 결과 없이 판정한다
    _pf_ok = preflight_static_physics(dict(_man, kconv_pair=_KP_NK, _prereg_doc=_PRE_NK))
    _pf_unr = preflight_static_physics(dict(_man, kconv_pair=_KP_NK))
    _pf_na = preflight_static_physics(dict(_man, kconv_pair={"status": "not_applicable"}))
    chk(any("kconv 설계 제외 (비준 사전등록" in x for x in _pf_ok[1])
        and not any("kconv" in x for x in _pf_ok[0])
        and any("KCONV_OMISSION_UNRATIFIED" in x for x in _pf_unr[0])
        and any("KCONV_STATUS_INVALID" in x for x in _pf_na[0]),
        "🔴 렌즈2 P1-3: preflight 가 kconv 생략의 비준·형식·상태를 **결과 전에** 판정한다 "
        "(양성 done · 비준 없음 bad · not_applicable bad)")
    chk("δ_k" not in (_nb_nk.get("missing_axes") or [])
        and any("δ_k" in str(x) for x in (_nb_nk.get("axes_not_designed") or []))
        and _r_nk.get("rounded_value_under_tested_axes_eV") is not None,
        "🔴 --no_kconv: kconv_pair 에 **jobs 가 없으면** δ_k 는 차단이 아니라 "
        "`axes_not_designed` 다 — ΔE_ads 는 나온다 (사전등록 3_오차예산 '넘으면' 절) · "
        "missing %s · 값 %s" % (_nb_nk.get("missing_axes"),
                                 _r_nk.get("rounded_value_under_tested_axes_eV")))
    # ⚠ `tested_axes_stable_at_0.01eV` 는 **시험한 축**만 말하므로 True 가 맞다.
    #   막아야 하는 것은 그것이 아니라 **전체 인용 자격**이다 — 그 필드가 True 로
    #   올라가면 안 되고, 빠진 축이 화면에 남아야 한다.
    chk(_nb_nk.get("overall_citable_at_0.01eV") is not True
        and any("δ_k" in str(x) for x in (_nb_nk.get("axes_not_designed") or []))
        and any("KCONV_NOT_DESIGNED" in str(x) for x in (_r_nk.get("advisories") or [])),
        "🔴 --no_kconv: 시험한 축만 안정으로 표시되고 **전체 인용 자격은 안 올라간다** "
        "· overall=%s · 빠진 축 %s · 주의 %s"
        % (_nb_nk.get("overall_citable_at_0.01eV"),
           [x for x in (_nb_nk.get("axes_not_designed") or []) if "δ_k" in str(x)],
           [x[:40] for x in (_r_nk.get("advisories") or []) if "KCONV" in str(x)]))
    _r_nk2 = _closure_estimand(dict(_man, kconv_pair=dict(_KCONV)), _RES(), _E, _emol,
                               {k: dict(v, dense=None) for k, v in _jobs.items()})
    chk("δ_k" in ((_r_nk2.get("numeric_budget") or {}).get("missing_axes") or []),
        "⛔음성 대조: kconv_pair 에 jobs 가 **있는데** dense 결과가 없으면 δ_k 가 "
        "missing 으로 차단된다 — 반송에서만 빼면 300 h 뒤에 막힌다")
    # 🔴 렌즈2 P1-1 (2026-09-03) — 조각이 둘인데 `not_applicable` 은 거짓 상태다 → 차단.
    #   리뷰어 재현: v34 분석기는 이 상태를 어느 분기도 타지 않아 재개 조건 없이 rc 3 통과.
    _r_na = _closure_estimand(dict(_man, kconv_pair={"status": "not_applicable",
                                                    "why": "(거짓) 조각이 둘이 아니다"}),
                              _RES(), _E, _emol, _jobs)
    chk(any(str(b).startswith("KCONV_STATUS_INVALID") for b in _r_na["blocks"])
        and "δ_k" in ((_r_na.get("numeric_budget") or {}).get("missing_axes") or [])
        and _r_na.get("rounded_value_under_tested_axes_eV") is None,
        "⛔음성 렌즈2 P1-1: 조각이 둘인데 kconv_pair.status=not_applicable 이면 **차단**한다 "
        "(종전엔 재개 조건 없이도 조용히 통과) · blocks %s"
        % [str(b)[:40] for b in _r_na["blocks"] if "KCONV" in str(b)][:2])
    # 🔴 렌즈2 P1-4/P1-5 · 렌즈5 P1-1 — 설계 제외면 overall 은 None 이 아니라 **False** 고,
    #   정의 문자열은 실제 합산 축(2축)을 말하며 verdict 에도 빠진 축이 남는다.
    _def_nk = str(_nb_nk.get("정의", ""))
    _vd_nk = str(_r_nk.get("verdict", ""))
    chk(_nb_nk.get("overall_citable_at_0.01eV") is False
        and _nb_nk.get("tested_axes_n") == len(_nb_nk.get("by_axis_meV") or {}) >= 1
        and "δ_k" not in _def_nk.split("—")[0] and "δ_k" in _def_nk
        and (not _vd_nk.startswith("보고 가능") or "δ_k" in _vd_nk),
        "🔴 렌즈2 P1-4·P1-5: δ_k 설계 제외 → overall=False(None 아님) · 정의 '%s' · "
        "verdict '%s'" % (_def_nk[:60], _vd_nk[:70]))
    _sem_attack({"E_C_sdcp": _EJK_PM1["E_C_control"], "E_C_control": _EJK_PM1["E_C_sdcp"]},
                "두 complex 키 교환 (종전 D=+200.5 차단 없음)")
    _sem_attack({"E_G_sdcp": _EJK_PM1["E_G_control"], "E_G_control": _EJK_PM1["E_G_sdcp"]},
                "gas reference 교환 (종전 D=−200.5 차단 없음)")
    _sem_attack({"E_G_sdcp": "mol__sdcp_neutral__box24__nzmag"},
                "gas 자리에 nzmag canary (box24 부모가 아니다)")
    _sem_attack({"E_G_sdcp": "refs/mol__sdcp_neutral__box20"},
                "gas 자리에 box20 (봉인은 box24 다)")
    _sem_attack({"branch": None}, "봉인에 branch(seed) 가 없다")
    _sem_attack({"branch": "afm2424_net4"}, "pm1 봉인의 branch 가 net4 다")
    # SDCP complex 를 **stress_sensitivity 잡**으로 교체 (종전 D=−1.5 차단 없음) —
    #   리뷰어 재현 그대로: 대안 자세 잡(b12)은 planned·jobs 에 **원래 있고**, manifest 의
    #   키만 그쪽을 가리키게 바꾼다. 다른 게이트는 아무것도 안 바뀌므로 의미 검사만이 잡는다.
    _rr_ss = _closure_estimand(dict(_man, estimand_job_keys=dict(_EJK_PM1, E_C_sdcp=_KSS)),
                               _RES(), _E, _emol, _jobs)
    chk(str(_rr_ss.get("verdict", "")).startswith("NO_VALUE")
        and any(b.startswith("ESTIMAND_SEMANTICS") and "role=" in b and "stress_sensitivity" in b
                for b in _rr_ss["blocks"])
        and (_rr_ss.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is None,
        "⛔음성 BE P0-1 (리뷰어 재현): SDCP complex 를 stress_sensitivity 잡(b12)으로 교체 → "
        "role 불일치로 NO_VALUE · D 없음 (종전 D=−1.5 차단 없음) · blocks %s"
        % [b[:80] for b in _rr_ss["blocks"]][:2])
    # 선언(planned)과 실물(job.json)이 갈리거나 planned 밖 잡을 가리키면 — 앞선 구조
    #   게이트(cohort 정합·topology)가 먼저 잡아도 된다. **값이 안 나오는 것**이 요점이다.
    _jobs_lie = dict(_jobs, **{_EJK_PM1["E_C_sdcp"]: _BAS("aaaa1111", _EJK_PM1["E_C_sdcp"],
                                                        fragment="ptfe_c10")})
    _attack_any({}, "job.json 의 fragment 가 planned·키와 다르다 (실물 거짓)", jobs_over=_jobs_lie)
    _attack_any({"E_C_sdcp": "prospective/sdcp_neutral__b77__afm2424_pm1"},
                "planned 에 없는 잡을 가리킨다")
    # 의미 검사 단독으로도 위 둘을 잡는다 (앞 게이트가 없다고 가정한 직접 호출)
    _sem_lie = _estimand_semantics_check(dict(_EJK_PM1), _jobs_lie, _man, "pm1", "primary")
    _sem_b77 = _estimand_semantics_check(dict(_EJK_PM1, E_C_sdcp="prospective/sdcp_neutral__b77__afm2424_pm1"),
                                         _jobs, _man, "pm1", "primary")
    chk(any("fragment=" in b for b in _sem_lie["blocks"])
        and any("planned 에 없는 잡" in b for b in _sem_b77["blocks"]),
        "BE P0-1: 의미 검사 단독으로도 실물 거짓(fragment)·planned 밖 잡을 잡는다")

    # ══ 🔴 회신 BE P0-2 — k 수렴 쌍을 primary complex 두 키에 결박 ═══════════════
    _mk_k = dict(_man, kconv_pair=dict(_KCONV, jobs=[
        "prospective/sdcp_neutral__b01__afm2424_pm1", "prospective/ptfe_c10__b00__afm2424_pm1"]))
    _rk_k = _closure_estimand(_mk_k, _RES(), _E, _emol, _jobs)
    chk(any(b.startswith("KCONV_PAIR_NOT_PRIMARY") for b in _rk_k["blocks"])
        and _rk_k.get("kconv_delta") is None
        and str(_rk_k.get("verdict", "")).startswith("NO_VALUE"),
        "⛔음성 BE P0-2 (리뷰어 재현): kconv_pair 를 대안 자세로 돌리면 KCONV_PAIR_NOT_PRIMARY "
        "— 다른 자세의 δ_k=0 으로 primary 를 '안정' 이라 하지 않는다")

    # ══ 회신 AR 해제조건 3 — 기체 쌍 cross-job gate (⛔음성 셋) ═════════════
    #   AR 이 실물 v15 에서 잡은 것: 네 기체 부모가 전부 relax→static 이라
    #   각 상자가 **독립으로 이완**했다. 그러면 δ_gas 는 셀 효과가 아니다.
    def _gasneg(mut, why):
        _jg = dict(_jobs)
        _mm = dict(_GASJOBS)
        for k, patch in mut.items():
            _mm[k] = {"ok": True, "gates": [],
                      "meta": dict(_GASJOBS[k]["meta"], **patch), "geom": {}}
        _jg.update(_mm)
        _rg = _closure_estimand(_man, _RES(), _E, _emol, _jg)
        chk(any(b.startswith("GAS_PAIR_CONTRACT") for b in _rg["blocks"])
            and (_rg.get("gas_box_delta") or {}).get("pass") is not True,
            "⛔음성 AR 3: %s → GAS_PAIR_CONTRACT 로 막고 δ_gas 를 통과로 세지 않는다 "
            "· blocks %s" % (why, [b[:60] for b in _rg["blocks"]][:2]))

    _gasneg({"refs/mol__sdcp_neutral__box20":
             {"fixed_geometry_static": False, "phases": ["relax", "static"]}},
            "한 상자가 relax→static (AR 이 v15 에서 실제로 잡은 결함)")
    _gasneg({"refs/mol__ptfe_c10__box20": {"internal_geometry_sha": "geo-DIFFERENT"}},
            "두 상자의 내부기하가 다르다")
    _gasneg({"refs/mol__sdcp_neutral__box24": {"electronic_state_sha": "st-OTHER"}},
            "두 상자의 전자상태 정책이 다르다")
    _gasneg({"refs/mol__ptfe_c10__box24": {"counts": [3, 1, 10, 20, 5]}},
            "두 상자의 원자 수가 다르다")
    # manifest 정책이 false 면 잡 메타가 다 맞아도 막는다 (선언과 실물 둘 다 봐야 한다)
    _rgp = _closure_estimand(dict(_man, gas_geometry_policy={"fixed_geometry_static": False}),
                             _RES(), _E, _emol, _jobs)
    chk(any(b.startswith("GAS_PAIR_CONTRACT") for b in _rgp["blocks"]),
        "⛔음성 AR 3: manifest 가 고정기하를 선언하지 않으면 막는다")
    # 구판 번들(메타에 새 필드가 없다) — 확인 못 한 것은 통과가 아니다
    _jold = dict(_jobs)
    for _k in _GASJOBS:
        _jold[_k] = {"ok": True, "gates": [],
                     "meta": {"kind": "mol_ref", "fragment": _GASJOBS[_k]["meta"]["fragment"],
                              "species_order": ["O"], "counts": [3]}, "geom": {}}
    chk(any(b.startswith("GAS_PAIR_CONTRACT")
            for b in _closure_estimand(_man, _RES(), _E, _emol, _jold)["blocks"]),
        "⛔음성 AR 3: 구판 번들(지문 필드 없음)은 **통과가 아니라 차단**이다")

    # ⛔음성 (회신 Z P0-4) — seed 이름이 같아도 **수렴 결과**가 갈리면 막는다
    _jb_het = dict(_jobs)
    _jb_het["prospective/sdcp_neutral__b01__afm2424_pm1"] = _BAS(
        "bbbb2222", "prospective/sdcp_neutral__b01__afm2424_pm1")
    _rh = _closure_estimand(_man, _RES(), _E, _emol, _jb_het)
    # ⚠ 회신 BE P0-1 이후 조각별 min 은 **없다** (fallback 폐지). 그래서 "min 을 안 뽑는다"
    #   는 더 이상 시험 대상이 아니다. 지금 계약(AO P0-7 · AR Q1): 풀의 이질성은 정본
    #   blocks 에 **그대로 남고**, D 에 들어가는 네 잡이 온전하면 primary 뷰에서만
    #   민감도 주석으로 내려간다 — pm1 조건부 D 는 살아 있어야 한다.
    chk(any("BASIN_HETEROGENEOUS" in b for b in _rh["blocks"])
        and not any("BASIN_HETEROGENEOUS" in b
                    for b in _rh.get("primary_estimand_blocks", _rh["blocks"]))
        and (_rh.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "⛔음성 Z P0-4 → AO P0-7: 풀 안 이질 basin 은 정본 blocks 에 남고, 네 잡이 온전하면 "
        "primary 뷰에서 강등되며 exact-key D 는 유지된다 (fragment_min 은 폐지 · BE P0-1)")
    _jb_none = dict(_jobs)
    _jb_none["prospective/ptfe_c10__b00__afm2424_pm1"] = _BAS(
        None, "prospective/ptfe_c10__b00__afm2424_pm1")
    _rn = _closure_estimand(_man, _RES(), _E, _emol, _jb_none)
    chk(any("BASIN_UNRESOLVED_IN_SET" in b for b in _rn["blocks"]),
        "⛔음성: realized basin 을 못 만든 잡이 있으면 그 집합으로 뺄셈하지 않는다")
    # ⛔음성 (회신 AA P0-3) — 경로와 구조화 필드가 어긋나면 값을 만들지 않는다
    _jb_x1 = dict(_jobs)
    _k1 = "prospective/sdcp_neutral__b00__afm2424_pm1"
    _jb_x1[_k1] = {**_BAS("aaaa1111", _k1)}
    _jb_x1[_k1]["meta"] = {**_jb_x1[_k1]["meta"], "fragment": "ptfe_c10"}
    _rx1 = _closure_estimand(_man, _RES(), _E, _emol, _jb_x1)
    chk(any("COHORT_INCOHERENT" in b for b in _rx1["blocks"]),
        "⛔음성: job.json 의 fragment 가 경로와 다르면 차단 (어느 쪽이 맞는지 우리가 못 정한다)")

    # ⛔음성 ★ v7 실측 — d3 가 **하나라도** 비면 막는다. 종전엔 "경로가 d3off 가
    #   아니면 정합" 으로 봐줬는데, 그 관용 때문에 net4 복합체 8잡이 필드 없이
    #   나갔다. 우연히 동작하는 것과 보증되는 것은 다르다.
    _jb_x2 = dict(_jobs)
    _jb_x2[_k1] = {**_BAS("aaaa1111", _k1)}
    _jb_x2[_k1]["meta"] = {k: v for k, v in _jb_x2[_k1]["meta"].items() if k != "d3"}
    _rx2 = _closure_estimand(_man, _RES(), _E, _emol, _jb_x2)
    chk(any("COHORT_INCOHERENT" in b for b in _rx2["blocks"]),
        "⛔음성: d3 필드가 비면 경로가 정상이어도 차단 (v7 의 net4 8잡이 그 모양이었다)")

    _jb_x3 = dict(_jobs)
    _k3 = "prospective/sdcp_neutral__b00__afm2424_pm1__d3off"
    _jb_x3[_k3] = {**_BAS("aaaa1111", _k1)}          # 경로는 d3off, 필드는 on
    _rx3 = _closure_estimand(_man, _RES(), _E, _emol, _jb_x3)
    chk(any("COHORT_INCOHERENT" in b for b in _rx3["blocks"]),
        "⛔음성: 경로는 __d3off 인데 job.json 이 d3=on 이면 차단 "
        "(D3 분해가 통째로 뒤집힌다)")

    _jb_x4 = dict(_jobs)
    _jb_x4[_k1] = {"ok": True, "gates": [], "geom": {"magnetic": {"realized_basin_id": "a"}}}
    _rx4 = _closure_estimand(_man, _RES(), _E, _emol, _jb_x4)
    chk(any("COHORT_INCOHERENT" in b for b in _rx4["blocks"]),
        "⛔음성: job.json(meta) 이 아예 없으면 차단 — 이름으로 추측하지 않는다")

    # ⛔음성 AO P0-4 — canary 와 부모 static 기하가 다르면 막는다 (스핀 검사 오염)
    chk(any("CANARY_GEOM_MISMATCH" in b for b in
            _closure_estimand(_man, _RES(same=False), _E, _emol, _jobs)["blocks"]),
        "⛔음성 AO P0-4: canary 가 부모와 **다른 기하**면 막는다 "
        "(두 에너지 차에 구조 이완 에너지가 섞인다)")
    # ⛔음성 AO P0-4 — 기하 대조를 **못 했으면** 그것도 차단이다 (확인 못 한 것 ≠ 통과)
    chk(any("CANARY_GEOM_UNCHECKED" in b for b in
            _closure_estimand(_man, {"pairs": {}}, _E, _emol, _jobs)["blocks"]),
        "⛔음성 AO P0-4: 기하 대조 결과가 **없으면** 통과가 아니라 차단이다")

    # ── 회신 AO P0-7 — pm1 조건부 D 를 net4 의 basin 차이가 지우지 않는다 ──
    _man7 = dict(_man, planned=dict(
        _PLANNED,
        **{k: _PL(k, seed="afm2424_net4")
           for k in ("prospective/sdcp_neutral__b09__afm2424_net4",
                     "prospective/ptfe_c10__b09__afm2424_net4")}),
        estimand_job_keys=dict(_EJK_PM1))
    _en7 = dict(_en, **{"prospective/sdcp_neutral__b09__afm2424_net4": -201.2,
                        "prospective/ptfe_c10__b09__afm2424_net4": -100.6})
    _jb7 = {k: _BAS("aaaa1111", k,
                    **({"_dense": _en7[k] + 0.010} if k in _KJ else {}))
            for k in _en7 if k.startswith("prospective/")}
    _jb7.update(_GASJOBS)          # 기체 쌍 계약은 이 시나리오의 시험 대상이 아니다
    # net4 두 잡만 **다른 basin** 으로 수렴 → 종전엔 BASIN_HETEROGENEOUS 로 D 가 죽었다
    for _k in ("prospective/sdcp_neutral__b09__afm2424_net4",
               "prospective/ptfe_c10__b09__afm2424_net4"):
        _jb7[_k] = _BAS("bbbb2222", _k)
    _r7 = _closure_estimand(_man7, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    # ⛔ 회신 AR Q1 이후: 정본 blocks 는 **다시 쓰지 않는다** (BASIN_HETEROGENEOUS 가 남는다).
    #   강등은 primary_estimand_blocks 뷰에서만 일어난다 — 그래서 둘 다 확인한다.
    chk(any(b.startswith("BASIN_HETEROGENEOUS") for b in _r7["blocks"]),
        "⛔음성 AR Q1: 정본 blocks 에는 BASIN_HETEROGENEOUS 가 **그대로 남는다** "
        f"(강등이 정본을 지우지 않는다) · blocks {_r7.get('blocks')}")
    chk(not any(b.startswith("BASIN_HETEROGENEOUS")
                for b in _r7.get("primary_estimand_blocks", _r7["blocks"]))
        and any("BASIN_HETEROGENEOUS" in n for n in (_r7.get("nonprimary_notes") or [])),
        "⛔음성 AO P0-7: net4 가 다른 basin 이어도 **pm1 조건부 D 를 지우지 않는다** "
        "(primary 뷰에서만 민감도 주석으로 내린다) · primary "
        f"{_r7.get('primary_estimand_blocks')}")
    chk((_r7.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        f"AO P0-7: 그 상태에서도 D_pm1 이 나온다 (실제 {_r7.get('primary_ddE_lowE_eV')})")
    # ⛔음성 — 그런데 **네 잡 자신**의 basin 이 없으면 여전히 막는다
    _jb7b = dict(_jb7)
    _jb7b["prospective/sdcp_neutral__b00__afm2424_pm1"] = _BAS(
        None, "prospective/sdcp_neutral__b00__afm2424_pm1")
    # ⛔ 회신 AP #2 이후 코드명이 바뀌었다: ESTIMAND_BASIN_UNRESOLVED(존재 확인) →
    #   ESTIMAND_TOPOLOGY_UNRESOLVED(모멘트 표를 읽어 topology 를 판정). pooled
    #   BASIN_UNRESOLVED_IN_SET 은 exact-key 경로에서 강등되므로 여기에 기대지 않는다.
    chk(any("ESTIMAND_TOPOLOGY_UNRESOLVED" in b
            for b in _closure_estimand(_man7, _RES(), lambda j: _en7.get(j),
                                       _emol, _jb7b)["blocks"]),
        "⛔음성 AO P0-7 / AP #2: **D 에 들어가는 네 잡** 의 자기 상태를 못 읽으면 "
        "여전히 막는다 (pooled 강등이 이걸 덮지 않는다)")
    # ── 회신 AP #2 — exact complex 쌍의 자기 topology 를 **직접 비교** ──
    def _J8(fp, jn, **kw):
        r = _BAS("aaaa1111", jn,
                 **dict(kw, **({"_dense": _en8.get(jn, 0.0) + 0.010} if jn in _KJ else {})))
        r["geom"]["magnetic"] = {"realized_basin_id": "aaaa1111",
                                 "realized_basin": {"ni_moments_muB": list(fp)}}
        return r
    _up8 = [1.2] * 24 + [-1.2] * 24
    _dn8 = [-1.2] * 24 + [1.2] * 24                    # 전역 반전 — 같은 상태
    _mix8 = [1.2] * 23 + [-1.2] + [-1.2] * 23 + [1.2]  # 배열이 다르다 — 다른 상태
    _KA = "prospective/sdcp_neutral__b00__afm2424_pm1"
    _KB = "prospective/ptfe_c10__b00__afm2424_pm1"
    _man8 = dict(_man, estimand_job_keys=dict(_EJK_PM1, E_C_sdcp=_KA, E_C_control=_KB))
    _en8 = {_KA: -201.0, _KB: -100.5,
            "mol__sdcp_neutral__box24__nzmag": -200.0,
            "mol__ptfe_c10__box24__nzmag": -100.0, **_GASE}
    _ok8 = dict(_GASJOBS, **{_KA: _J8(_up8, _KA), _KB: _J8(_dn8, _KB)})
    _r8 = _closure_estimand(_man8, _RES(), lambda j: _en8.get(j), _emol, _ok8)
    chk(not any("TOPOLOGY" in b for b in _r8["blocks"])
        and (_r8.get("estimand_topology") or {}).get("pm1", {}).get("same") is True,
        f"AP #2 양성: 전역 스핀 반전은 **같은 상태**로 본다 · blocks {_r8['blocks'][:1]}")
    _bad8 = dict(_GASJOBS, **{_KA: _J8(_up8, _KA), _KB: _J8(_mix8, _KB)})
    _r8b = _closure_estimand(_man8, _RES(), lambda j: _en8.get(j), _emol, _bad8)
    chk(any("ESTIMAND_TOPOLOGY_MISMATCH" in b for b in _r8b["blocks"]),
        "⛔음성 AP #2: 두 complex 가 **다른 자기 basin** 이면 막는다 "
        "(종전엔 각각 basin id 가 있는지만 보고 서로 같은지는 안 봤다)")
    _nofp = dict(_GASJOBS)
    for _k in (_KA, _KB):                       # 모멘트 표를 **명시적으로** 없앤다
        _j = _BAS("aaaa1111", _k)
        _j["geom"]["magnetic"] = {"realized_basin_id": "aaaa1111"}
        _nofp[_k] = _j
    chk(any("ESTIMAND_TOPOLOGY_UNRESOLVED" in b for b in
            _closure_estimand(_man8, _RES(), lambda j: _en8.get(j),
                              _emol, _nofp)["blocks"]),
        "⛔음성 AP #2: 모멘트 표가 없어 topology 를 못 읽으면 **막는다**")

    # ── 회신 AP #3 — 강등은 문자열이 아니라 job_keys 로 ──────────────────
    _r3 = _closure_estimand(_man7, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    _recs = (_r3.get("nonprimary_note_records") or [])
    chk(all(r.get("job_keys") for r in _recs) and _recs,
        f"AP #3: 강등된 record 가 **구조화**돼 있고 job_keys 를 갖는다 ({len(_recs)}건)")
    chk(all(r["scope"] == "pooled_diagnostic" for r in _recs),
        "AP #3: 강등 판정은 **scope 필드**로 한다 (문자열 매칭 아님)")
    chk((_r3.get("pooled_demote_policy") or {}).get("estimand_safety"),
        "AP #3: pooled 를 강등한 대신 **네 잡의 안전 근거**를 결과에 명시한다")
    # ⛔음성 — pooled 를 강등해도 **네 잡 자신**의 결함은 여전히 막는다
    _jb3c = dict(_jb7)
    _jb3c["prospective/sdcp_neutral__b00__afm2424_pm1"] = dict(
        _jb3c["prospective/sdcp_neutral__b00__afm2424_pm1"],
        gates=["MAGNETIC_COLLAPSE(합성)"])
    chk(any("ESTIMAND_KEY_UNUSABLE" in b for b in
            _closure_estimand(_man7, _RES(), lambda j: _en7.get(j),
                              _emol, _jb3c)["blocks"]),
        "⛔음성 AP #3: pooled 강등이 **네 잡의 게이트를 덮지 않는다** "
        "(exact key 가 게이트되면 여전히 NO_VALUE)")

    # net4 직접식이 봉인돼 있으면 D_net4 − D_pm1 을 **실제로 계산한다**
    _man7n = dict(_man7, estimand_job_keys_net4={
        "E_C_sdcp": "prospective/sdcp_neutral__b09__afm2424_net4",
        "E_C_control": "prospective/ptfe_c10__b09__afm2424_net4",
        "E_G_sdcp": "refs/mol__sdcp_neutral__box24",
        "E_G_control": "refs/mol__ptfe_c10__box24",
        "branch": "afm2424_net4"})
    _r7n = _closure_estimand(_man7n, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    chk((_r7n.get("branch_sensitivity") or {}).get("status") == "computed"
        and "D_net4_minus_D_pm1_eV" in (_r7n.get("branch_sensitivity") or {})
        and _r7n.get("sensitivity_complete") is True,
        "AO P0-7: net4 가 봉인돼 있으면 **D_net4 − D_pm1 을 계산한다** "
        f"(종전엔 요구해 놓고 안 냈다) · {_r7n.get('branch_sensitivity')}")

    # ══ 회신 AS 해제조건 1 — **정상 pm1/net4 가 exit 0 인가** ═════════════════
    #   AR Q1 이후 정본 blocks 는 BASIN_HETEROGENEOUS 를 그대로 갖는다. pm1 과 net4 는
    #   **의도적으로 다른 topology** 라 정상 수렴해도 그것이 뜬다. 최종 종료 판정이
    #   정본을 읽으면 이 번들은 **성공할 수 없다** — 외주가 16잡 다 돌린 뒤에야 안다.
    _r_ok = _closure_estimand(_man7, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    chk(any(b.startswith("BASIN_HETEROGENEOUS") for b in _r_ok["blocks"])
        and not _r_ok.get("primary_estimand_blocks")
        and (_r_ok.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "회신 AS 1: 정상 pm1/net4 는 정본에 BASIN_HETEROGENEOUS 가 있어도 "
        "**primary 뷰가 비어 있고 D 가 나온다** · primary %s"
        % _r_ok.get("primary_estimand_blocks"))
    # 그리고 **최종 종료 판정이 실제로 exit 0 을 내는지** 직접 친다
    _VCOK = {"applicable": True, "pass": True}
    # ⛔음성 회신 BA P0-3 · 해제조건 4 — 인용 자격은 계산 성공과 **다른 상태**다
    _cs_post = citation_status({"potcar_identity_policy": {"mode": "post_hoc",
                                                          "manuscript_citable": False}},
                               {"overall_citable_at_0.01eV": None})
    chk(_cs_post["manuscript_citable"] is False and len(_cs_post["blockers"]) >= 2
        and "탐색용" in _cs_post["why"],
        "⛔음성 BA P0-3: post_hoc + overall=None 이면 `manuscript_citable=false` 를 "
        "**기계가 집행**한다 (종전엔 분석기가 그 필드를 읽지도 않았다)")
    # ⛔ 회신 BA 해제조건 3 — 거버넌스 결박·비준이 있어야 인용 자격이 선다
    # ⚠ 회신 BB P0-2·P0-3 — 픽스처가 **실물과 같은 모양**이어야 한다. 종전 픽스처는
    #   `{"ratified": True}` 하나뿐이라 state·digest·참조문서 상태가 전부 빠져 있었고,
    #   그래서 요약 불리언만 보는 fail-open 을 시험이 잡아내지 못했다.
    # ⛔⛔ 회신 BD P0-3 · GO 해제조건 7 (2026-09-02) — 픽스처를 **production 형태**로
    #   바꾼다. 종전엔 `D-x`·`a.json` 같은 장난감이라, 필수 key 집합과 path→role 을
    #   고정하지 않은 fail-open 을 시험이 잡아낼 수 없었다 (리뷰어가 evil.json 하나로
    #   전체 reference 를 교체해 통과시켰다).
    # 🔴🔴 회신 BE P0-4 (2026-09-03) — 픽스처를 **원문 byte 에서** 만든다. 종전엔 digest
    #   "a"*64 같은 장난감이라, 분석기가 불리언·digest 를 **믿는** fail-open 을 시험이
    #   잡을 수 없었다. 이제 임시 번들 루트에 governance/ 원문 사본을 쓰고, **같은
    #   판독기(GOV_CORE)** 로 계산한 상태를 manifest 주장으로 삼는다 — 정합은 구성상
    #   보장되고, 어긋남은 아래 음성시험이 만든다.
    _GROOT = pathlib.Path(__import__("tempfile").mkdtemp()) / "govbundle"
    (_GROOT / "governance").mkdir(parents=True)

    def _ratified_doc(body, **rt_over):
        d = dict(body)
        # 🔴 회신 BF P0-4 — 실물 비준 기록 모양(at·by·state·role·content_digest). 필드가 빠지면
        #   ref_doc_state 가 ratified=False 를 낸다 (아래 음성시험).
        d["ratification"] = dict({"state": "ratified", "role": "scientific_owner",
                                  "at": "2026-09-02", "by": "fixture-owner",
                                  "content_digest": "sha256:" + dec_digest(d)}, **rt_over)
        return d
    _gdocs = {}
    for _p, _role in C12_REQUIRED_REFS.items():
        _nm = _p.rsplit("/", 1)[-1]
        if _role == "claim":
            _gdocs[_p] = _ratified_doc({"status": "ratified", "schema": "fixture/" + _nm,
                                        "claim": "fixture claim"})
        else:
            # ⛔ 정상 frozen pose 는 비준 기록이 없다 — **합법적으로** ratified=false 다.
            _gdocs[_p] = {"schema": "fixture/" + _nm, "poses": [1, 2, 3]}
        (_GROOT / "governance" / _nm).write_text(
            json.dumps(_gdocs[_p], indent=1, ensure_ascii=False), encoding="utf-8")
    _gdec = []
    for _i in C12_REQUIRED_DECISIONS:
        _x = {"id": _i, "decision_state": "active", "title": "fixture " + _i}
        # 🔴 회신 BG P1-1 — 실물 decisions.json 은 actor_id·timestamp·role 을 갖는다.
        #   픽스처가 그걸 빼고 있어서 "state 만 봐도 통과" 를 시험이 굳히고 있었다.
        _x["ratification"] = {"state": "ratified", "role": "scientific_owner",
                              "actor_id": "fixture@selftest", "timestamp": "2026-09-01T00:00:00Z",
                              "commit": "b" * 40,
                              "decision_digest": "sha256:" + dec_digest(_x)}
        _gdec.append(_x)
    (_GROOT / "governance" / "decisions.json").write_text(
        json.dumps({"decisions": _gdec}, indent=1, ensure_ascii=False), encoding="utf-8")
    _GSRC = {p: "governance/" + p.rsplit("/", 1)[-1]
             for p in list(C12_REQUIRED_REFS) + ["db/governance/decisions.json"]}
    _MROOT = {"_root": str(_GROOT)}

    def _gb_ok():
        _d = {}
        for _x in _gdec:
            _dg = dec_digest(_x)
            _d[_x["id"]] = {"state": _x["decision_state"], "ratified": True, "digest": _dg,
                            "digest_matches": True, "recorded_digest": "sha256:" + _dg,
                            "ratification_base_commit": "b" * 40}
        _rs, _rf = {}, {}
        for _p, _role in C12_REQUIRED_REFS.items():
            _f = _GROOT / _GSRC[_p]
            _rf[_p] = hashlib.sha256(_f.read_bytes()).hexdigest()
            _st = ref_doc_state(_f)
            _rs[_p] = {"status": _st.get("status"), "ratified": _st.get("ratified"),
                       "role": _role,
                       "has_ratification_record": _st.get("has_ratification_record"),
                       "digest_matches": _st.get("digest_matches"),
                       "superseded": _st.get("superseded")}
        return {"all_ratified": True, "decisions_all_ratified": True,
                "reference_files_all_ratified": True, "frozen_inputs_all_bound": True,
                "decisions": _d,
                "reference_files_sha256": _rf, "reference_files_state": _rs,
                "bundled_sources": dict(_GSRC)}

    _GBOK = _gb_ok()
    _DEC0 = C12_REQUIRED_DECISIONS[0]
    _CLAIM0 = [k for k, v in C12_REQUIRED_REFS.items() if v == "claim"][0]
    _FROZ0 = [k for k, v in C12_REQUIRED_REFS.items() if v == "frozen_input"][0]
    # 🔴 회신 BF P0-4 — 계보 픽스처를 **완전한 registry** 로 만든다 (요약 세 칸만인 옛 픽스처가
    #   바로 리뷰어가 통과시킨 fail-open 모양이었다 — 그것은 아래 음성시험으로 남긴다).
    _PVFILES = {}
    for _p in list(C12_REQUIRED_REFS) + ["db/governance/decisions.json"]:
        _PVFILES[_p] = {"kind": "input", "scope": "repo", "git": "clean",
                        "sha256": hashlib.sha256((_GROOT / _GSRC[_p]).read_bytes()).hexdigest()}
    _PVFILES["tools/sdcp/vasp_handoff_bundle.py"] = {"kind": "generator", "scope": "repo",
                                                      "git": "clean", "sha256": "7" * 64}
    _PVOK = {"schema": "bundle_provenance/v1", "files": _PVFILES, "n_files": len(_PVFILES),
             "clean": True, "dirty": [], "unknown_git_state": []}
    _PVOK_MINIMAL = {"clean": True, "dirty": [], "unknown_git_state": [], "n_files": 12}
    _cs_ok = citation_status(
        {"potcar_identity_policy": {"mode": "require_attestation",
                                    "manuscript_citable": True},
         "governance_binding": _GBOK, "provenance": _PVOK, **_MROOT},
        {"overall_citable_at_0.01eV": True,
         "potcar_identity": {"allowed_claim": "paw_release_attested"}})
    chk(_cs_ok["manuscript_citable"] is True and not _cs_ok["blockers"],
        "회신 BA P0-3 양성: 네 조건(정책·overall·외부앵커·거버넌스 비준)이 다 서면 "
        "인용 가능이다 (실제 %s)" % _cs_ok["blockers"][:2])
    # ⛔음성 BA 해제조건 3 — 비준 없이는 인용 불가
    _cs_gov = citation_status(
        {"potcar_identity_policy": {"mode": "require_attestation",
                                    "manuscript_citable": True},
         "governance_binding": dict(_GBOK, all_ratified=False,
                                    decisions=dict(_GBOK["decisions"], **{
                                        _DEC0: dict(_GBOK["decisions"][_DEC0],
                                                    ratified=False)})),
         "provenance": _PVOK, **_MROOT},
        {"overall_citable_at_0.01eV": True,
         "potcar_identity": {"allowed_claim": "paw_release_attested"}})
    chk(_cs_gov["manuscript_citable"] is False
        and any("불리언 True 가 아니다" in b or "미비준" in b
                for b in _cs_gov["blockers"]),
        "⛔음성 BA 해제조건 3: 거버넌스가 **미비준**이면 인용 불가다 — 비용 발생 전에 "
        "닫아야 한다")
    _cs_noref = citation_status(
        {"potcar_identity_policy": {"mode": "require_attestation",
                                    "manuscript_citable": True},
         "governance_binding": dict(_GBOK, reference_files_sha256={"a.json": None}),
         "provenance": _PVOK, **_MROOT},
        {"overall_citable_at_0.01eV": True,
         "potcar_identity": {"allowed_claim": "paw_release_attested"}})
    chk(_cs_noref["manuscript_citable"] is False,
        "⛔음성 BA 해제조건 3: 참조 문서 SHA 가 결박되지 않으면 인용 불가다")

    # ══ 회신 BB P0-2·P0-3 — **요약 불리언 fail-open** (리뷰어 재현 그대로) ══
    def _cs(gb, root=None):
        return citation_status(
            {"potcar_identity_policy": {"mode": "require_attestation",
                                        "manuscript_citable": True},
             "governance_binding": gb, "provenance": _PVOK,
             "_root": (root if root is not None else str(_GROOT))},
            {"overall_citable_at_0.01eV": True,
             "potcar_identity": {"allowed_claim": "paw_release_attested"}})

    def _mut_dec(**kw):
        return dict(_GBOK, decisions=dict(
            _GBOK["decisions"], **{_DEC0: dict(_GBOK["decisions"][_DEC0], **kw)}))

    for _nm, _gb, _need in (
        ("state=proposed", _mut_dec(state="proposed"), "state="),
        ("ratified=false", _mut_dec(ratified=False), "불리언 True 가 아니다"),
        ("digest=BROKEN", _mut_dec(digest="BROKEN"), "64-hex"),
        ("비준 후 내용 변경", _mut_dec(digest_matches=False), "일치하지 않는다"),
        # ⛔ 회신 BD P0-3 재현 — 불리언 대신 **문자열**
        ("ratified='false' (문자열)", _mut_dec(ratified="false"),
         "불리언 True 가 아니다"),
        ("digest_matches='true' (문자열)", _mut_dec(digest_matches="true"),
         "일치하지 않는다"),
        ("SHA 가 'x'", _mut_dec(digest="x"), "64-hex"),
    ):
        _r = _cs(_gb)
        chk(_r["manuscript_citable"] is False
            and any(_need in x for x in _r["blockers"]),
            "⛔음성 BB P0-3: `all_ratified=true` 인데 내부가 **%s** 면 인용 불가다 — "
            "종전엔 요약 불리언만 봐서 `manuscript_citable=true` 가 재현됐다" % _nm)
    # ⚠ 회신 BD P0-3 이후 판정은 **개별 항목**만으로 선다 — 요약은 참고값이다.
    #   요약을 false 로 바꿔도 개별이 다 서면 통과하는 것이 옳다 (요약이 판정을
    #   좌우하면 그것이 곧 fail-open 이다). 대신 요약 네 칸을 교차검사한다(아래).
    _r = _cs(dict(_GBOK, all_ratified=False))
    chk(_r["manuscript_citable"] is False
        and any("요약" in x for x in _r["blockers"]),
        "⛔음성 BD P1: 요약 `all_ratified` 가 개별 항목과 어긋나면 차단한다 "
        "(요약만 고쳐 놓는 경로)")
    _r = _cs(dict(_GBOK, decisions={}))
    chk(_r["manuscript_citable"] is False
        and any("필수 decision 이 없다" in x for x in _r["blockers"]),
        "⛔음성 BD P0-3: decisions 를 **비우면** 막는다 — 필수 목록은 **코드가** "
        "정한다 (종전엔 산출물이 정해 `all(빈 것)=True` 로 통과했다)")
    _r = _cs({k: v for k, v in _GBOK.items() if k != "reference_files_state"})
    chk(_r["manuscript_citable"] is False
        and any("dict 가 아니다" in x or "구판" in x for x in _r["blockers"]),
        "⛔음성 BB P0-2: 참조 문서의 **비준 상태**가 없는 구판 번들은 인용 불가다 "
        "(SHA 만으로는 그 내용이 비준됐는지 알 수 없다)")
    _r = _cs(dict(_GBOK, reference_files_state=dict(
        _GBOK["reference_files_state"], **{
            _CLAIM0: dict(_GBOK["reference_files_state"][_CLAIM0],
                          status="proposed", ratified=False,
                          has_ratification_record=False)})))
    chk(_r["manuscript_citable"] is False
        and any("불리언 True 가 아니다" in x for x in _r["blockers"]),
        "⛔음성 BB P0-2 (실물 재현): decision 은 active 인데 **claim prereg 가 "
        "proposed** 면 인용 불가다 — 실제 C-12 정본이 이 상태였다")
    # ══ 🔴🔴 회신 BE P0-4 — **원문 byte 재계산** (manifest 만 고쳐 놓는 경로를 닫는다) ══
    _shx = __import__("shutil")

    def _tampered_root(tag, rel_name, fn):
        """governance/ 사본 하나를 fn 으로 고친 임시 루트를 만든다."""
        _d = pathlib.Path(__import__("tempfile").mkdtemp()) / tag
        _shx.copytree(_GROOT, _d)
        _f = _d / "governance" / rel_name
        _j = json.loads(_f.read_text(encoding="utf-8"))
        fn(_j)
        _f.write_text(json.dumps(_j, indent=1, ensure_ascii=False), encoding="utf-8")
        return str(_d)
    chk(governance_bytes_check(dict(_MROOT, governance_binding=_GBOK)) == [],
        "BE P0-4 양성: 원문 사본과 manifest 주장이 같으면 재계산 차단 0건")
    # ⓐ manifest 는 그대로(ratified=True) 두고 **원문 사본**만 proposed 로 — 종전엔 통과
    _r = _cs(_GBOK, root=_tampered_root("gov_proposed", _CLAIM0.rsplit("/", 1)[-1],
                                        lambda j: j.__setitem__("status", "proposed")))
    chk(_r["manuscript_citable"] is False
        and any("원문" in x for x in _r["blockers"]),
        "⛔음성 BE P0-4 (리뷰어 재현): manifest 는 ratified=True 인데 **원문은 proposed** 면 "
        "인용 불가 — 불리언을 믿지 않고 byte 에서 다시 계산한다")
    # ⓑ decisions 원문의 내용을 고치면 기록 digest 와 재계산이 갈린다
    _r = _cs(_GBOK, root=_tampered_root("gov_dec_edit", "decisions.json",
                                        lambda j: j["decisions"][0].__setitem__("title", "edited")))
    chk(_r["manuscript_citable"] is False
        and any("digest" in x and "원문" in x for x in _r["blockers"]),
        "⛔음성 BE P0-4: decision 원문 내용이 비준 뒤 바뀌면(기록 digest ≠ 재계산) 인용 불가")
    # ⓑ-2 🔴 회신 BG P1-1 (리뷰어 재현) — decision 원문의 비준 기록을 {state, digest} 로 깎는다.
    #     종전엔 strict·bytes 둘 다 통과했다 (actor·시각·role 이 없어도 비준으로 셌다).
    def _strip_rt(j):
        for _d in j["decisions"]:
            _d["ratification"] = {"state": _d["ratification"]["state"],
                                  "decision_digest": _d["ratification"]["decision_digest"]}
    _r = _cs(_GBOK, root=_tampered_root("gov_rt_strip", "decisions.json", _strip_rt))
    chk(_r["manuscript_citable"] is False
        and any("비준 기록 형식 위반" in x for x in _r["blockers"]),
        "⛔음성 BG P1-1 (리뷰어 재현): decision 원문의 비준 기록을 {state, digest} 로 깎으면 "
        "막힌다 — actor·시각·role 없는 비준은 비준이 아니다 (참조 문서와 **같은** 검사)")
    # ⓒ 원문 사본이 없는 번들(bundled_sources 없음) 은 확인 못 한 것 = 통과 아님
    _r = _cs({k: v for k, v in _GBOK.items() if k != "bundled_sources"})
    chk(_r["manuscript_citable"] is False
        and any("bundled_sources" in x for x in _r["blockers"]),
        "⛔음성 BE P0-4: governance 원문 사본이 없는 번들은 인용 불가 (구판 번들 재생성)")
    # ⓓ manifest 의 sha 는 맞는데 상태 불리언만 거짓 — 원문 재계산과 어긋난다
    _r = _cs(dict(_GBOK, reference_files_state=dict(
        _GBOK["reference_files_state"], **{
            _FROZ0: dict(_GBOK["reference_files_state"][_FROZ0], superseded=True)})))
    chk(_r["manuscript_citable"] is False
        and any("SUPERSEDED" in x or "superseded" in x for x in _r["blockers"]),
        "⛔음성 BE P0-4: manifest 주장(superseded)이 원문 재계산과 어긋나면 그 자체가 차단")
    # ⓔ 원문 사본 byte 가 manifest sha 와 다르면(사본 바꿔치기) 차단
    _r = _cs(_GBOK, root=_tampered_root("gov_swap", _FROZ0.rsplit("/", 1)[-1],
                                        lambda j: j.__setitem__("poses", [9, 9, 9])))
    chk(_r["manuscript_citable"] is False
        and any("사본 sha" in x for x in _r["blockers"]),
        "⛔음성 BE P0-4: 원문 사본이 manifest 기록 sha 와 다르면 차단 (frozen_input 도)")

    # ══ 회신 BB P0-5 — 생성 계보 (dirty 면 폐기) ═══════════════════════════
    def _csp(pv):
        return citation_status(
            {"potcar_identity_policy": {"mode": "require_attestation",
                                        "manuscript_citable": True},
             "governance_binding": _GBOK, "provenance": pv, **_MROOT},
            {"overall_citable_at_0.01eV": True,
             "potcar_identity": {"allowed_claim": "paw_release_attested"}})
    chk(_csp(_PVOK)["manuscript_citable"] is True,
        "BB P0-5 양성: 계보가 clean 이면 인용 자격을 막지 않는다")
    _r = _csp(dict(_PVOK, clean=False, dirty=["tools/sdcp/site_screen.py"]))
    chk(_r["manuscript_citable"] is False
        and any("dirty" in x for x in _r["blockers"]),
        "⛔음성 BB P0-5: **import 한 모듈**이 dirty 면 인용 불가다 — 생성기만 "
        "커밋본과 같아도 dependency 가 다르면 다른 코드로 만든 번들이다")
    _r = _csp(dict(_PVOK, clean=False, unknown_git_state=["db/structures/x.vasp"]))
    chk(_r["manuscript_citable"] is False,
        "⛔음성 BB P0-5: git 상태를 **모르는** 파일이 있어도 불가다 — 모르는 것을 "
        "clean 으로 세면 그게 fail-open 이다")
    _r = _csp(None)
    chk(_r["manuscript_citable"] is False
        and any("provenance 가 없다" in x for x in _r["blockers"]),
        "⛔음성 BB P0-5: provenance 없는 구판 번들은 인용 불가다 (v22 가 이 상태였다)")
    # ⛔음성 BB P0-2 — frozen_input 은 **비준을 요구하지 않지만 SHA 는 요구한다**
    # ⛔ 정상 frozen pose 는 `digest_matches=False` 여도 통과해야 한다
    #   (회신 BD P0-3 이 잡은 **거짓 차단**)
    _r = _cs(_GBOK)
    chk(_r["manuscript_citable"] is True,
        "BB P0-2 양성: **동결 입력**(자세 집합 같은 데이터)은 비준 대상이 아니다 — "
        "SHA 결박이 있으면 통과한다 (데이터에 비준을 요구하면 고무도장이 된다)")
    _r = _cs(dict(_GBOK, reference_files_sha256=dict(
        _GBOK["reference_files_sha256"], **{_FROZ0: None})))
    chk(_r["manuscript_citable"] is False
        and any("64-hex" in x for x in _r["blockers"]),
        "⛔음성 BB P0-2: 동결 입력의 **SHA 가 없으면** 불가다 — 비준 대신 요구하는 "
        "것이 그것이다")
    # ══ 회신 BC P0-2 — 리뷰어가 재현한 네 가지 fail-open ═══════════════════
    for _nm, _rsx, _need in (
        ("빈 참조 집합", {}, "필수 참조 문서가 없다"),
        ("claim → frozen_input 역할 변경",
         dict(_GBOK["reference_files_state"], **{
             _CLAIM0: dict(_GBOK["reference_files_state"][_CLAIM0],
                           role="frozen_input")}), "role 이"),
        ("digest_matches 누락",
         dict(_GBOK["reference_files_state"], **{
             _CLAIM0: {k: v for k, v in
                       _GBOK["reference_files_state"][_CLAIM0].items()
                       if k != "digest_matches"}}), "비준 이후 내용이 바뀌었다"),
        ("비준 후 내용 변경",
         dict(_GBOK["reference_files_state"], **{
             _CLAIM0: dict(_GBOK["reference_files_state"][_CLAIM0],
                           digest_matches=False)}), "비준 이후 내용이 바뀌었다"),
        # ⛔ 회신 BD P0-3 재현 — 전체 reference 를 evil.json 하나로 교체
        ("evil.json 하나로 교체",
         {"db/properties/evil.json": {"status": "ratified", "ratified": True,
                                      "role": "claim", "digest_matches": True,
                                      "has_ratification_record": True}},
         "필수 참조 문서가 없다"),
        # ⛔ 정상 frozen pose 를 **거짓 차단**하던 것 (role 을 안 봤다)
        ("frozen pose 를 claim 으로 오분류",
         dict(_GBOK["reference_files_state"], **{
             _FROZ0: dict(_GBOK["reference_files_state"][_FROZ0],
                          role="claim")}), "role 이"),
    ):
        _r = _cs(dict(_GBOK, reference_files_state=_rsx))
        chk(_r["manuscript_citable"] is False
            and any(_need in x for x in _r["blockers"]),
            "⛔음성 BC P0-2: **%s** 으로 인용 가능을 통과하던 경로를 닫았다" % _nm)

    # ══ 회신 BC P1 — C-12 rescue **봉투** (300 h 잡 전에 고정) ═══════════════
    _RGOOD = {"rescue": {
        "parent_bundle_zip_sha256": "a" * 64, "parent_manifest_sha256": "b" * 64,
        "parent_job_key": "tier1/x__fib00__Litop__pm1",
        "parent_input_sha256": {"INCAR": "c" * 64},
        "attempt_id": "20260902T120000Z_scf_algo_all",
        "supersedes": "tier1/x__fib00__Litop__pm1",
        "reason": "SCF 미수렴 (NELM 소진)"}}
    _ok_r, _why_r = c12_rescue_envelope_ok(_RGOOD)
    chk(_ok_r and not _why_r,
        "BC P1 양성: 갖춘 rescue 봉투는 통과한다 (부모 ZIP·MANIFEST·잡·입력 SHA · "
        "attempt_id · supersedes · 사유)")
    for _nm, _mut, _need in (
        ("봉투 자체가 없음", {"rescue": {}}, "봉투가 없다"),
        ("부모 ZIP SHA 누락", {"parent_bundle_zip_sha256": None},
         "parent_bundle_zip_sha256"),
        ("부모 입력 SHA 누락", {"parent_input_sha256": None}, "parent_input_sha256"),
        ("attempt_id 누락", {"attempt_id": None}, "attempt_id"),
        ("attempt_id 형식 오류", {"attempt_id": "retry1"}, "형식이 아니다"),
        ("supersedes 가 다른 잡", {"supersedes": "tier1/other"}, "다르다"),
        ("supersedes 가 목록", {"supersedes": ["a", "b"]}, "목록이다"),
        ("부모 자동 대체", {"auto_replace_parent": True}, "자동으로 덮지 않는다"),
        ("원본 덮어씀", {"overwrote_parent": True}, "원본은 보존"),
        # ⛔ 회신 BD P1 재현 — 값의 **모양**을 안 봤다
        ("부모 ZIP SHA 가 'x'", {"parent_bundle_zip_sha256": "x"}, "64-hex"),
        ("부모 MANIFEST SHA 가 'x'", {"parent_manifest_sha256": "x"}, "64-hex"),
        ("입력 SHA 가 'x'", {"parent_input_sha256": {"INCAR": "x"}}, "64-hex"),
        ("입력 SHA 가 dict 가 아님", {"parent_input_sha256": "x" * 64},
         "dict 여야 한다"),
        ("job 키 모양이 아님", {"parent_job_key": "not-a-key",
                                "supersedes": "not-a-key"}, "모양이 아니다"),
    ):
        _m = ({"rescue": {}} if _nm == "봉투 자체가 없음"
              else {"rescue": dict(_RGOOD["rescue"], **_mut)})
        _o, _w = c12_rescue_envelope_ok(_m)
        chk(_o is False and any(_need in x for x in _w),
            "⛔음성 BC P1 rescue 봉투: **%s** 이면 거부한다" % _nm)
    chk("생성기의 rescue 모드" in C12_RESCUE_ENVELOPE["⛔_아직_없는_것"],
        "BC P1: 봉투는 있고 **생성기 모드는 아직 없다**는 것을 산출물이 스스로 "
        "말한다 (없는 것을 있다고 하지 않는다)")

    # ══ 회신 BC P1 — **C-12 형태에서 D·verdict 가 실제로 나오는가** ═══════════
    #  ⛔ 종전 완주 e2e 는 레거시 쌍 경로 번들이라 `prereg_closure` 가 아예 없었고,
    #    그래서 "끝까지 돈다" 만 보고 **무엇을 냈는지**는 보지 않았다. 보고량을
    #    선언한 번들에서 D 와 판정어가 나오는지를 여기서 친다.
    _c12_ok = _closure_estimand(_man7, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    _d12 = (_c12_ok.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV")
    chk(_d12 is not None and isinstance(_d12, (int, float)),
        "BC P1: C-12 형태에서 **D 가 실제로 나온다** (%s eV)" % _d12)
    chk(_c12_ok.get("verdict") is None
        or not str(_c12_ok["verdict"]).startswith("NO_VALUE"),
        "BC P1: 정상 묶음이 **NO_VALUE 로 닫히지 않는다** (%s)"
        % str(_c12_ok.get("verdict"))[:40])
    chk(_final_verdict({}, {}) == [] and
        _final_verdict({"verdict": "NO_VALUE(x)"}, {}) != [],
        "BC P1: `_final_verdict` 자체는 빈 closure 를 막지 않는다 — **보고량을 "
        "선언한 번들일 때만** 호출부가 막는다 (레거시 쌍 경로를 깨뜨리지 않는다)")

    _r = _cs(dict(_GBOK, reference_files_state=dict(
        _GBOK["reference_files_state"], **{
            _CLAIM0: dict(_GBOK["reference_files_state"][_CLAIM0],
                          superseded=True)})))
    chk(any("SUPERSEDED" in x for x in _r["blockers"]),
        "⛔음성 BB P0-4: 참조 문서가 **SUPERSEDED** 면 그 사실을 이름으로 말한다 "
        "(단순 미비준과 다른 문제다 — 폐기 문서는 비준해도 안 된다)")
    # ⛔ 회신 BB P0-4 실물 — provenance 가 폐기 문서를 가리키지 않는가
    _pcd = _closure_estimand(_man7, _RES(), lambda j: _en7.get(j), _emol,
                             _jb7)["prereg_doc"]
    _pcd = _pcd if isinstance(_pcd, list) else [_pcd]
    chk(all("prereg_sdcp_neutral_contrast_2026_08_29" not in x for x in _pcd)
        and any("sdcp_c12_claim_prereg" in x for x in _pcd),
        "⛔음성 BB P0-4 (실물): `prereg_closure.prereg_doc` 이 **SUPERSEDED 된** "
        "2026-08-29 문서가 아니라 C-12 정본을 가리킨다 (%s)"
        % [x.rsplit("/", 1)[-1] for x in _pcd])
    chk(citation_status({"potcar_identity_policy": {"manuscript_citable": True}},
                        {"overall_citable_at_0.01eV": True,
                         "potcar_identity": {"allowed_claim": "paw_release_attested"}}
                        )["manuscript_citable"] is False,
        "⛔음성 BA 해제조건 3: `governance_binding` 이 아예 없는 **구판 번들**도 "
        "인용 불가다 (없음을 통과로 세지 않는다)")
    _cs_anchor = citation_status(
        {"potcar_identity_policy": {"mode": "require_attestation",
                                    "manuscript_citable": True}},
        {"overall_citable_at_0.01eV": True,
         "potcar_identity": {"allowed_claim": "self_declared_label_only"}})
    chk(_cs_anchor["manuscript_citable"] is False,
        "⛔음성 BA P0-3: 자기선언 label 만 있으면 인용 불가다 (외부 앵커가 없다)")
    chk(_final_verdict(_r_ok, _VCOK) == [],
        "⛔음성 AS 1: 정상 pm1/net4 에서 최종 판정이 **exit 0** 이다 "
        "(정본 blocks 를 읽던 종전 코드는 여기서 무조건 exit 2 였다)")
    chk(_final_verdict(dict(_r_ok, primary_estimand_blocks=["X(합성)"]), _VCOK),
        "⛔음성 AS 1: primary 뷰에 차단이 있으면 **exit 2** 다")
    chk(_final_verdict(dict(_r_ok, verdict="NO_VALUE — 합성"), _VCOK),
        "⛔음성 AS 1: NO_VALUE 면 exit 2 다")
    chk(_final_verdict(_r_ok, {"applicable": True, "pass": False}),
        "⛔음성 AS 1: 진공 판정이 실패하면 exit 2 다")
    # 구판 결과(강등 뷰 없음)는 정본으로 되돌아간다 — 조용히 통과시키지 않는다
    chk(_final_verdict({"blocks": ["OLD(합성)"]}, _VCOK),
        "⛔음성 AS 1: primary 뷰가 아예 없는 구판 결과는 **정본으로 막는다**")

    # ══ 회신 AS 해제조건 2 — canary 만 성공하면 **예외로 죽지 않는다** ══════════
    _en_np = {k: v for k, v in _en.items()
              if k != "refs/mol__sdcp_neutral__box24"}      # 부모만 없앤다
    _emol_np = {"sdcp_neutral": None, "ptfe_c10": -100.0}
    _r_np = _closure_estimand(_man, _RES(), lambda j: _en_np.get(j), _emol_np, _jobs)
    chk(any("MOLECULAR_SPIN_CONTROL_PARENT_MISSING" in b for b in _r_np["blocks"]),
        "⛔음성 AS 2: box24 부모가 없고 canary 만 있으면 **구조화 차단**이다 "
        "(종전엔 `e1 - None` 으로 예외 사망)")

    # ══ 회신 AS 해제조건 3 — pooled 가 **살아남은 부분집합**으로 계산되지 않는다 ══
    _jb_gate = dict(_jobs)
    _jb_gate["prospective/sdcp_neutral__b01__afm2424_pm1"] = dict(
        _jb_gate["prospective/sdcp_neutral__b01__afm2424_pm1"],
        ok=False, gates=["MAGNETIC_COLLAPSE(합성)"])
    _r_gate = _closure_estimand(_man, _RES(), _E, _emol, _jb_gate)
    _pc = _r_gate.get("pool_completeness") or {}
    chk(_pc.get("ok") is False
        and any("GATED_POSE" in r["msg"] for r in _r_gate["block_records"])
        and (_r_gate.get("pooled_effect") or {}).get("secondary_G_citable") is False
        and _r_gate.get("secondary_G_eV") is None,
        "⛔음성 AS 3: 계획된 자세 하나가 게이트되면 **GATED_POSE 가 실제로 기록되고** "
        "pooled 값이 비인용이 된다 (종전엔 ok=false 를 먼저 건너뛰어 도달조차 못 했다)")
    # 결과가 아예 없는 경우도 같다 (계획엔 있는데 안 돌아왔다)
    _jb_miss = {k: v for k, v in _jobs.items()
                if k != "prospective/sdcp_neutral__b01__afm2424_pm1"}
    _r_miss = _closure_estimand(_man, _RES(), _E, _emol, _jb_miss)
    chk((_r_miss.get("pool_completeness") or {}).get("ok") is False
        and (_r_miss.get("pooled_effect") or {}).get("pooled_min_citable") is False,
        "⛔음성 AS 3: 계획된 자세가 **회수되지 않아도** pooled 를 비인용으로 한다")
    chk((r.get("pool_completeness") or {}).get("ok") is True,
        "회신 AS 3 양성: 계획된 자세가 전건 사용가능하면 pool 이 완전하다 · %s"
        % (r.get("pool_completeness") or {}).get("expected"))

    # ══ 회신 AR P1-9 · 해제조건 6 — net4 topology 실패가 **실제로** 막는가 ═════
    #   `usable_as_sensitivity` 를 저장만 하고 안 읽어서, 두 complex 가 다른
    #   basin 이어도 D_net4 가 계산되고 complete 로 보고됐다.
    _KN4A = "prospective/sdcp_neutral__b09__afm2424_net4"
    _KN4B = "prospective/ptfe_c10__b09__afm2424_net4"
    _mixfp = [1.2] * 23 + [-1.2] + [-1.2] * 23 + [1.2]     # 배열이 다르다
    _jb7t = dict(_jb7)
    _jb7t[_KN4A] = _J8([1.2] * 24 + [-1.2] * 24, _KN4A)
    _jb7t[_KN4B] = _J8(_mixfp, _KN4B)
    _r7t = _closure_estimand(_man7n, _RES(), lambda j: _en7.get(j), _emol, _jb7t)
    _bs7 = _r7t.get("branch_sensitivity") or {}
    chk(_bs7.get("status") == "suppressed_topology"
        and _bs7.get("D_net4_eV") is None
        and _bs7.get("D_net4_minus_D_pm1_eV") is None
        and _r7t.get("sensitivity_complete") is False
        and (_r7t.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "⛔음성 AR P1-9: net4 두 complex 가 다른 basin 이면 **D_net4 값과 status 를 "
        f"같이 막는다** (D_pm1 은 산다) · {_bs7.get('status')}")
    # 모멘트 표를 못 읽어도 마찬가지다 — 확인 못 한 것은 통과가 아니다
    _jb7u = dict(_jb7)
    for _k in (_KN4A, _KN4B):
        _ju = _BAS("aaaa1111", _k)
        _ju["geom"]["magnetic"] = {"realized_basin_id": "aaaa1111"}
        _jb7u[_k] = _ju
    _r7u = _closure_estimand(_man7n, _RES(), lambda j: _en7.get(j), _emol, _jb7u)
    chk((_r7u.get("branch_sensitivity") or {}).get("status") == "suppressed_topology"
        and _r7u.get("sensitivity_complete") is False,
        "⛔음성 AR P1-9: net4 topology 를 **못 읽어도** 민감도를 완료로 보고하지 않는다")

    # 🔴 회신 BE P0-1 — 민감도 봉인(net4)도 같은 의미 검사를 받는다 — 값이 아니라 status 가 막힌다
    _man7n_bad = dict(_man7n, estimand_job_keys_net4=dict(
        _man7n["estimand_job_keys_net4"],
        E_C_sdcp=_man7n["estimand_job_keys_net4"]["E_C_control"],
        E_C_control=_man7n["estimand_job_keys_net4"]["E_C_sdcp"]))
    _r7n_bad = _closure_estimand(_man7n_bad, _RES(), lambda j: _en7.get(j), _emol, _jb7)
    chk((_r7n_bad.get("branch_sensitivity") or {}).get("status") in ("unavailable", "suppressed_topology")
        and (_r7n_bad.get("branch_sensitivity") or {}).get("D_net4_eV") is None
        and (_r7n_bad.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "⛔음성 BE P0-1: net4 봉인의 complex 를 교환하면 D_net4 는 안 나오고(status 차단) "
        "D_pm1 은 영향받지 않는다 · status=%s"
        % (_r7n_bad.get("branch_sensitivity") or {}).get("status"))

    # ══ 회신 AR P1-10 · 해제조건 6 — 대안 자세를 **봉인식**으로 낸다 ══════════
    _KPA = "prospective/sdcp_neutral__b04__afm2424_pm1"
    _KPB = "prospective/ptfe_c10__b04__afm2424_pm1"
    _enp = dict(_en7, **{_KPA: -201.15, _KPB: -100.52})
    # ⚠ 회신 BE P0-1 — 대안 자세는 planned 에 **ALT 역할로 선언**돼 있고 job.json 도 같은
    #   역할이어야 한다 (primary 를 민감도 자리에 재사용하면 의미 검사가 막는다).
    _PLANNED_ALT = dict(_man7n["planned"], **{_KPA: _PL(_KPA, role="sensitivity"),
                                              _KPB: _PL(_KPB, role="sensitivity")})
    _manp = dict(_man7n, planned=_PLANNED_ALT, estimand_job_keys_pose_alt={
        "sensitivity": {"E_C_sdcp": _KPA, "E_C_control": _KPB,
                        "E_G_sdcp": "refs/mol__sdcp_neutral__box24",
                        "E_G_control": "refs/mol__ptfe_c10__box24",
                        "branch": "afm2424_pm1",
                        "formula": "D_pose[sensitivity] = ..."},
        "⛔": "주석 키 — 순회에서 건너뛰어야 한다"})
    _up = [1.2] * 24 + [-1.2] * 24
    _jbp = dict(_jb7, **{_KPA: _J8(_up, _KPA, role="sensitivity"),
                         _KPB: _J8(_up, _KPB, role="sensitivity")})
    _rp = _closure_estimand(_manp, _RES(), lambda j: _enp.get(j), _emol, _jbp)
    _ps = (_rp.get("pose_sensitivity") or {}).get("sensitivity") or {}
    chk(_ps.get("status") == "computed" and _ps.get("D_pose_eV") is not None
        and _ps.get("D_pose_minus_D_pm1_eV") is not None
        and _rp.get("sensitivity_complete") is True,
        "회신 AR P1-10 양성: 대안 자세가 봉인돼 있으면 **D_pose − D_pm1 을 낸다** "
        f"· {_ps.get('D_pose_minus_D_pm1_eV')} eV")
    # ⛔음성 2026-08-31 실측 — 실물 c12 는 두 조각의 대안 자세 **역할 이름이 다르다**
    #   (sdcp=stress_sensitivity · ptfe=sensitivity). 같은 역할끼리만 짝지으면
    #   봉인이 통째로 비어 스테이지 2 의 네 잡이 아무 정의된 양도 못 낸다.
    _manrp = dict(_man7n, planned=_PLANNED_ALT, estimand_job_keys_pose_alt={
        "role_pair": {"E_C_sdcp": _KPA, "E_C_control": _KPB,
                      "E_G_sdcp": "refs/mol__sdcp_neutral__box24",
                      "E_G_control": "refs/mol__ptfe_c10__box24",
                      "branch": "afm2424_pm1",
                      "formula": "D_pose[role_pair] = ...",
                      "roles": {"sdcp_neutral": ["stress_sensitivity"],
                                "ptfe_c10": ["sensitivity"]},
                      "⚠_역할_비대칭": "두 조각의 대안 자세를 다른 이유로 골랐다"}})
    _rrp = _closure_estimand(_manrp, _RES(), lambda j: _enp.get(j), _emol, _jbp)
    _prp = (_rrp.get("pose_sensitivity") or {}).get("role_pair") or {}
    chk(_prp.get("status") == "computed"
        and _prp.get("D_pose_minus_D_pm1_eV") is not None
        and _rrp.get("sensitivity_complete") is True,
        "회신 AR P1-10 (실측 보정): 두 조각의 대안 자세 **역할이 달라도** "
        f"role_pair 로 봉인하면 값이 나온다 · {_prp.get('D_pose_minus_D_pm1_eV')} eV")
    # ⛔음성 — 두 자세 complex 가 다른 basin 이면 값도 status 도 막는다
    _jbp2 = dict(_jbp, **{_KPB: _J8(_mixfp, _KPB)})
    _rp2 = _closure_estimand(_manp, _RES(), lambda j: _enp.get(j), _emol, _jbp2)
    _ps2 = (_rp2.get("pose_sensitivity") or {}).get("sensitivity") or {}
    chk(_ps2.get("status") == "suppressed_topology" and _ps2.get("D_pose_eV") is None
        and _rp2.get("sensitivity_complete") is False
        and any("POSE_SENSITIVITY_INCOMPLETE" in n
                for n in (_rp2.get("nonprimary_notes") or []))
        and (_rp2.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "⛔음성 AR P1-10: 자세 두 complex 가 다른 basin 이면 D_pose 를 막고 "
        "'자세에 강건' 서술을 금지한다 (D_pm1 은 산다)")
    # ⛔음성 — 잡이 게이트돼 있으면 unavailable
    _jbp3 = dict(_jbp)
    _jbp3[_KPA] = dict(_jbp3[_KPA], gates=["MAGNETIC_COLLAPSE(합성)"])
    _rp3 = _closure_estimand(_manp, _RES(), lambda j: _enp.get(j), _emol, _jbp3)
    chk(((_rp3.get("pose_sensitivity") or {}).get("sensitivity") or {}).get("status")
        == "unavailable" and _rp3.get("sensitivity_complete") is False,
        "⛔음성 AR P1-10: 자세 잡이 게이트되면 unavailable 이고 완료가 아니다")
    # 봉인이 아예 없으면 **탐색용**임을 명시한다 (완료 여부만 보고하지 않는다)
    _rp4 = _closure_estimand(dict(_man7n, altpose_purpose="탐색용"),
                             _RES(), lambda j: _en7.get(j), _emol, _jb7)
    chk((_rp4.get("pose_sensitivity") or {}).get("status") == "exploratory_only",
        "회신 AR P1-10: 봉인식이 없으면 **탐색용**이라고 결과에 박는다")

    # ── 회신 AP #11 — δ_gas 를 **최종 estimand 에 직접** 건다 ────────────
    _rg = _closure_estimand(_man, _RES(), _E, _emol, _jobs)
    chk((_rg.get("gas_box_delta") or {}).get("pass") is True,
        f"AP #11 양성: δ_gas {_rg.get('gas_box_delta', {}).get('delta_gas_meV')} meV "
        f"≤ {_rg.get('gas_box_delta', {}).get('tol_meV')} — 0.01 eV 보고 가능")
    # ⛔음성 — 조각별로는 각각 작아도 **부호가 반대면 차에서 커진다**
    _enbad = dict(_en, **{"refs/mol__sdcp_neutral__box20": _GASE["refs/mol__sdcp_neutral__box24"] - 0.004,
                          "refs/mol__ptfe_c10__box20": _GASE["refs/mol__ptfe_c10__box24"] + 0.004})
    _rgb = _closure_estimand(_man, _RES(), lambda j: _enbad.get(j), _emol, _jobs)
    _gd = _rgb.get("gas_box_delta") or {}
    # 🔴 회신 AV P1-5 — AP #11 의 요점(조각별이 아니라 차에 문턱)은 유지하되,
    #   측정된 초과는 이제 **차단이 아니라 0.01 eV 인용 자격 상실**이다.
    chk(not any("GAS_BOX_DELTA" in b for b in _rgb["blocks"])
        and any("GAS_BOX_DELTA" in a for a in (_rgb.get("advisories") or []))
        and _gd.get("pass") is False
        and _rgb.get("tested_axes_stable_at_0.01eV") is False
        and _rgb.get("rounded_value_under_tested_axes_eV") is None
        and _rgb.get("D_raw_eV") is not None,
        "⛔음성 AP #11·AV P1-5: 조각별 4 meV 씩이어도 부호가 반대면 δ_gas 8 meV → "
        "**0.01 eV 인용 자격 상실 (D_raw 는 보존)** "
        f"(실제 {_gd.get('delta_gas_meV')} meV · 조각별 {_gd.get('by_fragment_meV')})")
    chk(abs((_gd.get("delta_gas_meV") or 0)) > 5.0
        and all(abs(v) <= 5.0 for v in (_gd.get("by_fragment_meV") or {}).values()),
        "⛔음성 AP #11 요점: **조각별 문턱이었으면 통과했을** 경우다 "
        "(그래서 조각별이 아니라 차에 건다)")
    # ⛔ 회신 AR P0-3 재현 — **조각별로는 크고 차는 작은** 경우. 옛 조각별 10 meV
    #   게이트가 살아 있으면 두 emol 이 None 이 되고 A(f,p) 에서 `float − None` 으로
    #   **예외로 죽었다** (리뷰가 재현한 그 모양이다). 지금은 δ_gas 1 meV 로 통과한다.
    _en2019 = dict(_en, **{"refs/mol__sdcp_neutral__box20": _GASE["refs/mol__sdcp_neutral__box24"] - 0.020,
                           "refs/mol__ptfe_c10__box20": _GASE["refs/mol__ptfe_c10__box24"] - 0.019})
    _r2019 = _closure_estimand(_man, _RES(), lambda j: _en2019.get(j), _emol, _jobs)
    _g19 = _r2019.get("gas_box_delta") or {}
    chk(_g19.get("pass") is True and abs(_g19.get("delta_gas_meV") or 0) <= 5.0
        and all(abs(v) >= 15.0 for v in (_g19.get("by_fragment_meV") or {}).values())
        and not any("GAS_BOX" in b for b in _r2019["blocks"])
        and (_r2019.get("diagnostic_only") or {}).get("primary_ddE_lowE_eV") is not None,
        "회신 AR P0-3 재현: 조각별 %s meV 인데 δ_gas %s meV → **통과하고 예외로 "
        "죽지 않는다** (옛 조각별 게이트가 죽이던 경우)"
        % (_g19.get("by_fragment_meV"), _g19.get("delta_gas_meV")))
    # ⛔음성 — box20 이 아예 없으면 "측정 안 함" 으로 막는다 (선행값으로 때우지 않는다)
    _enno = {k: v for k, v in _en.items() if not k.endswith("box20")}
    chk(any("GAS_BOX_NOT_MEASURED" in b for b in
            _closure_estimand(_man, _RES(), lambda j: _enno.get(j),
                              _emol, _jobs)["blocks"]),
        "⛔음성 AP #11: box20 이 없으면 **이 묶음에서 재지 못했다**고 막는다 "
        "(선행 대조로 때우지 않는다)")

    # ══ 🔴 회신 BE P0-2 — 기체 쌍을 **POSCAR 실물**에 결박 (리뷰어 재현) ═════════════
    _GROOT_SAME = pathlib.Path(__import__("tempfile").mkdtemp()) / "est_same"
    for _f0 in ("sdcp_neutral", "ptfe_c10"):
        _write_gas_poscars(_GROOT_SAME, _f0, same_cell=(_f0 == "sdcp_neutral"))
    _rgs = _closure_estimand(dict(_man, _root=str(_GROOT_SAME)), _RES(), _E, _emol, _jobs)
    chk(any(b.startswith("GAS_PAIR_CONTRACT") and "셀" in b for b in _rgs["blocks"])
        and (_rgs.get("gas_box_delta") or {}).get("pass") is not True,
        "⛔음성 BE P0-2 (리뷰어 재현): box20/24 가 실물에서 **같은 셀**이면 자기 선언 sha 가 "
        "같아도 계약 위반 — δ_gas 통과로 세지 않는다")
    _GROOT_SHIFT = pathlib.Path(__import__("tempfile").mkdtemp()) / "est_shift"
    for _f0 in ("sdcp_neutral", "ptfe_c10"):
        _write_gas_poscars(_GROOT_SHIFT, _f0, shift=(2.0 if _f0 == "sdcp_neutral" else 1.3))
    _rgt = _closure_estimand(dict(_man, _root=str(_GROOT_SHIFT)), _RES(), _E, _emol, _jobs)
    chk(any(b.startswith("GAS_PAIR_CONTRACT") and "강체" in b for b in _rgt["blocks"]),
        "⛔음성 BE P0-2: 좌표가 +2.0 Å 강체 평행이동이 아니면(중심 배치 아님) 계약 위반")
    _gasneg({"refs/mol__sdcp_neutral__box20": {"gas_placement": "not_centered"}},
            "⛔음성 BE P0-2 (리뷰어 재현): gas_placement 를 not_centered 로 선언하면 계약 위반")
    _gasneg({"refs/mol__sdcp_neutral__box24": {"box_margin_A": 20.0}},
            "⛔음성 BE P0-2: box24 잡의 box_margin_A 가 24 가 아니면 계약 위반")
    _rgn = _closure_estimand({k: v for k, v in _man.items() if k != "_root"},
                             _RES(), _E, _emol, _jobs)
    chk(any(b.startswith("GAS_PAIR_CONTRACT") and "실물" in b for b in _rgn["blocks"]),
        "⛔음성 BE P0-2: POSCAR 실물을 못 보면(루트 미상) 확인 못 한 것 = 통과 아님")

    _jb_slab = dict(_jobs)
    _jb_slab["refs/clean_slab__afm2424_pm1"] = _BAS(
        "cccc3333", "prospective/sdcp_neutral__b00__afm2424_pm1",
        kind="clean_ref", fragment=None, basin_id=None)
    _rs = _closure_estimand(_man, _RES(), _E, _emol, _jb_slab)
    chk(any("BASIN_MISMATCH_SLAB" in b for b in _rs["blocks"]),
        "⛔음성: clean slab 이 복합체와 다른 basin 이면 흡착에너지를 만들지 않는다")
    chk(abs(r["diagnostic_only"]["primary_ddE_lowE_eV"] - (-0.5)) < 1e-6,
        f"[V P0-4] primary = min-min = -0.5 · 실제 {r.get('primary_ddE_lowE_eV')}")
    # G = min(A_c10) - max(A_sdcp) = -0.5 - (-0.9) = +0.4.
    #   G>0 = 가장 약한 SDCP 도 가장 센 c10 보다 더 음수 (사전등록 정의와 일치).
    chk(r["secondary_G_eV"] is None and "영구 비인용" in str(r.get("secondary_G_⛔"))
        and (r.get("pooled_effect") or {}).get("citable", "").startswith("no"),
        "🔴 AT Q5(a): secondary_G 와 pooled min 이 **영구 비인용**이다 "
        "(추가 잡 0 · 자세 탐색의 폭은 MLIP 가 진다)")
    chk(abs(r["secondary_G_eV_diagnostic"] - 0.4) < 1e-6,
        f"[V P0-4] secondary G = +0.4 (>0 = 최약 SDCP 도 최강 c10 보다 음수) · "
        f"실제 {r.get('secondary_G_eV')}")
    chk(str(r["verdict"]).startswith("보고 가능 (시험한 축 조건부)")
        and r["rounded_value_under_tested_axes_eV"] == -0.5
        and "reported_X_eV" not in r,
        "[V P0-4 + AZ P0-5] guard(-0.10) 통과 + 0.01 eV 반올림은 "
        "**시험한 축 조건부 필드**로만 나온다")
    # 음성: guard band 미달
    _en2 = dict(_en)
    _en2["prospective/sdcp_neutral__b00__afm2424_pm1"] = -200.55
    _en2["prospective/sdcp_neutral__b01__afm2424_pm1"] = -200.55
    _jb2 = {k: (dict(v, dense={"normal_end": True, "E0": _en2[k] + 0.010})
                if k in _KJ else v) for k, v in _jobs.items()}
    r2 = _closure_estimand(_man, _RES(), lambda j: _en2.get(j), _emol, _jb2)
    chk(r2["verdict"] == "NO_DIRECTIONAL_CLAIM",
        f"[음성 V P0-4] primary {r2.get('primary_ddE_lowE_eV')} > -0.10 → 방향성 주장 금지")
    # 음성: 비영 시작이 더 낮으면 값을 내지 않는다
    _en3 = dict(_en); _en3["mol__sdcp_neutral__box24__nzmag"] = -200.3
    r3 = _closure_estimand(_man, _RES(), lambda j: _en3.get(j), _emol, _jobs)
    chk(any("MOLECULAR_STATE_UNRESOLVED" in b for b in r3["blocks"])
        and "primary_ddE_lowE_eV" not in r3,
        "[음성 V P0-3] 비영 MAGMOM 대조가 더 낮으면 **MOLECULAR_STATE_UNRESOLVED 로 막고 "
        "값을 안 낸다** (자동 채택 금지)")
    # 음성: 자기 topology 게이트된 자세는 버리고 값도 안 낸다
    _j4 = dict(_jobs)
    _j4["prospective/sdcp_neutral__b00__afm2424_pm1"] = {
        **_BAS("aaaa1111", "prospective/sdcp_neutral__b00__afm2424_pm1"),
        "gates": ["MAGNETIC_PARTIAL_FLIP(3/48 Ni)"]}
    r4 = _closure_estimand(_man, _RES(), _E, _emol, _j4)
    chk(any("GATED_POSE" in b for b in r4["blocks"]) and "primary_ddE_lowE_eV" not in r4,
        "[음성 V P0-4] 자기 topology 게이트된 자세는 **다음 순위로 조용히 대체하지 않는다**")
    # 음성: 대조가 아예 없으면
    r5 = _closure_estimand({"fragments": ["sdcp_neutral", "ptfe_c10"]},
                           {"pairs": {}}, _E, _emol, _jobs)
    chk(any("MOLECULAR_SPIN_CONTROL_MISSING" in b for b in r5["blocks"]),
        "[음성 V P0-3] 자기상태 대조가 없으면 그것도 block")

    # ══ 회신 AR 해제조건 5 — 1단계 선결조건이 **여덟 개를 다 본다** ═══════════
    #   AR: "analyze_results.py 는 GAS_BOX_DELTA 와 ESTIMAND_TOPOLOGY_MISMATCH 를
    #   보지 않으므로, 이미 primary estimand 가 실패한 뒤에도 STAGE1_PASS.json 을
    #   쓰고 stage 2 를 열 수 있다."
    _VC_OK = {"pass": True, "verdict": "VACUUM_CONVERGED", "applicable": True}
    _RES_OK = {"gas_canary_geom": {f: {"same": True} for f in
                                   ("sdcp_neutral", "ptfe_c10")}}
    _CL_OK = {
        "blocks": [], "block_records": [],
        "potcar_identity": {"blocking": [], "identity_scope": "sealed_root_v13 …",
                            "root_seal_coverage": {"ok": True, "why": "포괄"}},
        "gas_box_delta": {"pass": True, "delta_gas_meV": 0.1, "tol_meV": 5.0},
        "gas_pair_contract": {"ok": True},
        "estimand_topology": {"pm1": {"same": True, "blocks": [], "why": "동일"}},
    }
    _p0 = _stage1_prereqs(_CL_OK, _VC_OK, _RES_OK)
    chk(len(_p0) == 8 and all(v["pass"] for v in _p0.values()),
        "회신 AR 5 양성: 선결조건 **8개**가 다 통과할 때만 2단계가 열린다 (%s)"
        % sorted(_p0))
    for _need5 in ("vacuum", "molecular_state", "canary_geometry", "potcar_identity",
                   "gas_box_delta", "estimand_topology_pm1", "closure_blocks_clear",
                   "root_seal_covers_plan"):
        chk(_need5 in _p0, "AR 5: 선결조건에 `%s` 가 있다" % _need5)
    # ⛔음성 — 여덟 축을 하나씩 깨뜨리면 그 축이 실패한다
    def _p5(mut, vc=None, res=None):
        return _stage1_prereqs(dict(_CL_OK, **mut), vc or _VC_OK, res or _RES_OK)
    _cases5 = [
        ("gas_box_delta", {"gas_box_delta": {"pass": False, "delta_gas_meV": 9.0},
                           "blocks": ["GAS_BOX_DELTA(δ_gas 9.0 meV > 5)"]},
         "δ_gas 가 문턱을 넘으면"),
        ("gas_box_delta", {"gas_pair_contract": {"ok": False}},
         "기체 쌍 계약이 깨지면 (δ_gas 수치가 작아도)"),
        ("estimand_topology_pm1",
         {"estimand_topology": {"pm1": {"same": False,
                                        "blocks": ["ESTIMAND_TOPOLOGY_MISMATCH(pm1)"]}}},
         "pm1 두 complex 가 다른 자기 basin 이면"),
        ("estimand_topology_pm1", {"estimand_topology": {}},
         "pm1 topology 판정이 **아예 없으면** (확인 못 함 = 통과 아님)"),
        ("closure_blocks_clear",
         {"block_records": [{"code": "X", "msg": "X(합성)", "scope": "estimand",
                             "affects_estimand": True}],
          "blocks": ["X(합성)"]},
         "잔여 exact-estimand block 이 있으면"),
        ("closure_blocks_clear",
         {"blocks": ["POTCAR_IDENTITY:합성(구조화 안 된 전역 차단)"]},
         "구조화되지 않은 전역 차단이 남아 있으면"),
        ("root_seal_covers_plan",
         {"potcar_identity": {"blocking": [], "identity_scope": "x",
                              "root_seal_coverage": {"ok": False, "why": "반쪽 봉인"}}},
         "root seal 이 계획을 포괄하지 못하면"),
        ("root_seal_covers_plan",
         {"potcar_identity": {"blocking": [], "identity_scope": "x"}},
         "root seal 포괄 검사 결과가 **없으면**"),
    ]
    for _ax, _mut, _why in _cases5:
        _pp = _p5(_mut)
        chk(_pp[_ax]["pass"] is False,
            "⛔음성 AR 5: %s `%s` 가 실패한다 → 2단계를 열지 않는다" % (_why, _ax))
    # pooled_diagnostic 강등은 1단계를 막지 않는다 (그 강등의 근거는 AP #3 에 있다)
    _pp_pooled = _p5({"block_records": [
        {"code": "BASIN_HETEROGENEOUS", "msg": "BASIN_HETEROGENEOUS(합성)",
         "scope": "pooled_diagnostic", "affects_estimand": False}],
        "blocks": ["BASIN_HETEROGENEOUS(합성)"]})
    chk(_pp_pooled["closure_blocks_clear"]["pass"] is True,
        "AR 5: pooled_diagnostic 로 강등된 block 은 1단계를 막지 않는다 "
        "(정본 blocks 에는 남아 있어도 scope 로 거른다)")

    # ══ 회신 BF (2026-09-03 · 마지막 codex 리뷰) — P0 4건 + P1 ═══════════════════
    # ── P0-1: estimand 네 키는 **비준 protocol 의 exact map** 에 결박된다 ─────────
    _KB12 = "prospective/sdcp_neutral__b12__afm2424_pm1"
    _jobs_b12 = dict(_jobs, **{_KB12: _BAS("aaaa1111", _KB12)})            # job 메타도 primary
    _man_b12 = dict(_man, planned=dict(_PLANNED, **{_KB12: _PL(_KB12)}))    # planned 도 primary
    _sem_b12 = _estimand_semantics_check(dict(_EJK_PM1, E_C_sdcp=_KB12), _jobs_b12, _man_b12,
                                         "pm1", "primary")
    chk(any(b.startswith("ESTIMAND_NOT_RATIFIED_KEY") for b in _sem_b12["blocks"]),
        "⛔음성 BF P0-1 (리뷰어 재현): b12 를 job/planned 메타까지 primary 로 맞춰 넣어도 비준 "
        "protocol 의 b00 경로가 아니면 막힌다")
    _K00 = _EJK_PM1["E_C_sdcp"]
    _jobs_norole = dict(_jobs, **{_K00: dict(_jobs[_K00], meta={
        k: v for k, v in _jobs[_K00]["meta"].items() if k != "role"})})
    _sem_norole = _estimand_semantics_check(dict(_EJK_PM1), _jobs_norole, _man, "pm1", "primary")
    chk(any("role 가 없다" in b for b in _sem_norole["blocks"]),
        "⛔음성 BF P0-1: role 이 없는 잡을 primary 로 간주하지 않는다 (기본값 제거)")
    _pl_nob = dict(_PLANNED, **{_K00: dict(_PLANNED[_K00], meta={
        k: v for k, v in _PLANNED[_K00]["meta"].items() if k != "basin_id"})})
    _sem_nob = _estimand_semantics_check(dict(_EJK_PM1), _jobs, dict(_man, planned=_pl_nob),
                                         "pm1", "primary")
    chk(any("planned.basin_id 가 없다" in b for b in _sem_nob["blocks"]),
        "⛔음성 BF P0-1: planned.meta 의 kind/fragment/role/seed/basin_id 는 **필수**다 — 하나가 "
        "빠지면 막힌다 (있을 때만 비교하지 않는다)")
    _sem_noproto = _estimand_semantics_check(dict(_EJK_PM1), _jobs, dict(_man, governance_binding={}),
                                             "pm1", "primary")
    chk(any(b.startswith("ESTIMAND_PROTOCOL_MAP_UNVERIFIED") for b in _sem_noproto["blocks"]),
        "⛔음성 BF P0-1: 번들에 protocol 원문 사본이 없으면 exact map 을 확인 못 한 것 = 통과 아님")
    _sem_ok = _estimand_semantics_check(dict(_EJK_PM1), _jobs, _man, "pm1", "primary")
    chk(not _sem_ok["blocks"], "BF P0-1 양성: 비준 경로 그대로면 통과한다 (%s)" % _sem_ok["blocks"][:1])
    # ── P0-3: 기체 상자 — 상대 이동만이 아니라 **절대 관계** ─────────────────────
    def _gas_root_variant(**kw):
        _r = pathlib.Path(__import__("tempfile").mkdtemp()) / "estv"
        for _f0 in ("sdcp_neutral", "ptfe_c10"):
            _write_gas_poscars(_r, _f0, **kw)
        return _r
    _bad_cs = _gas_bytes_check(dict(_man, _root=str(_gas_root_variant(center_shift=1.0))), "sdcp_neutral")
    chk(any("질량중심" in b for b in _bad_cs),
        "⛔음성 BF P0-3 (리뷰어 재현): 두 상자를 **함께** 중심 밖으로 옮겨도 COM ≠ (0.5,0.5,0.5) 로 막힌다")
    _bad_bx = _gas_bytes_check(dict(_man, _root=str(_gas_root_variant(box_extra=2.0))), "sdcp_neutral")
    chk(any("절대 상자 크기" in b for b in _bad_bx),
        "⛔음성 BF P0-3 (리뷰어 재현): 둘 다 더 큰 상자로 바꿔도 상자 − span ≠ margin 으로 막힌다")
    _bad_ph = _gas_bytes_check(_man, "sdcp_neutral",
                               planned={"refs/mol__sdcp_neutral__box20": {"phases": ["relax", "static"]}})
    chk(any("planned.phases" in b for b in _bad_ph),
        "⛔음성 BF P0-3: planned.phases ≠ ['static'] 이면 막힌다 (fixed_geometry_static=true 를 믿지 않는다)")
    _bad_sha = _gas_bytes_check(_man, "sdcp_neutral",
                                metas={"20": dict(_GASJOBS["refs/mol__sdcp_neutral__box20"]["meta"],
                                                  internal_geometry_sha="geo-LIE"),
                                       "24": _GASJOBS["refs/mol__sdcp_neutral__box24"]["meta"]})
    chk(any("좌표에서 재계산" in b for b in _bad_sha),
        "⛔음성 BF P0-3: 메타의 internal_geometry_sha 가 좌표에서 재계산한 값과 다르면 막힌다 (메타를 믿지 않는다)")
    _bad_rc = _gas_bytes_check(dict(_man, staged_runner="run_staged.sh"), "sdcp_neutral")
    chk(any("반송 receipt 가 없어" in b for b in _bad_rc),
        "⛔음성 BF P0-3: staged 번들에서 receipt 가 없으면 실행 상 집합을 확인 못 한 것 = 통과 아님")
    _RCROW = "t\t%s\tx\tx\tnone\t1\t-\t-\t-\n"
    for _b0 in ("20", "24"):
        (_GROOT_EST / "refs" / ("mol__sdcp_neutral__box%s" % _b0) / "EXECUTABLE_RECEIPT.tsv").write_text(
            _RCROW % "_runner_start" + _RCROW % "static", encoding="utf-8")
    _ok_rc = _gas_bytes_check(dict(_man, staged_runner="run_staged.sh"), "sdcp_neutral",
                              metas={"20": _GASJOBS["refs/mol__sdcp_neutral__box20"]["meta"],
                                     "24": _GASJOBS["refs/mol__sdcp_neutral__box24"]["meta"]},
                              planned=_man["planned"])
    chk(not _ok_rc, "BF P0-3 양성: COM 중앙 · span+margin · 지문 재계산 · static 단독 receipt 면 통과 (%s)"
        % _ok_rc[:1])
    (_GROOT_EST / "refs" / "mol__sdcp_neutral__box20" / "EXECUTABLE_RECEIPT.tsv").write_text(
        _RCROW % "_runner_start" + _RCROW % "relax" + _RCROW % "static", encoding="utf-8")
    _bad_rl = _gas_bytes_check(dict(_man, staged_runner="run_staged.sh"), "sdcp_neutral")
    chk(any("실행된 상 집합" in b for b in _bad_rl),
        "⛔음성 BF P0-3: receipt 에 relax 상이 있으면 막힌다 (상자별 이완이 δ_gas 에 섞인다)")
    for _b0 in ("20", "24"):
        (_GROOT_EST / "refs" / ("mol__sdcp_neutral__box%s" % _b0) / "EXECUTABLE_RECEIPT.tsv").unlink()
    _ok_all = _closure_estimand(_man, _RES(), _E, _emol, _jobs)
    chk(not any(b.startswith("GAS_PAIR_CONTRACT") for b in _ok_all["blocks"]),
        "BF P0-3 양성: 실물 계약대로 만든 픽스처는 GAS_PAIR_CONTRACT 에 걸리지 않는다 (%s)"
        % [b[:70] for b in _ok_all["blocks"] if b.startswith("GAS")][:1])
    # ── P0-4: provenance 폐포 완전성 · bundled_sources containment · 비준 기록 형식 ──
    _r_min = _csp(_PVOK_MINIMAL)
    chk(_r_min["manuscript_citable"] is False
        and any("PROVENANCE_INCOMPLETE" in x for x in _r_min["blockers"]),
        "⛔음성 BF P0-4 (리뷰어 재현): {clean:true, dirty:[], unknown:[]} 만 남긴 계보는 인용 불가다 "
        "(목록·SHA·개수·필수 집합을 본다)")
    _r_drop = _csp(dict(_PVOK, files={k: v for k, v in _PVOK["files"].items() if k != _CLAIM0},
                        n_files=len(_PVOK["files"]) - 1))
    chk(any("필수 입력" in x for x in _r_drop["blockers"]),
        "⛔음성 BF P0-4: 필수 입력(비준 참조 문서)이 계보 목록에서 빠지면 막힌다")
    _r_sha = _csp(dict(_PVOK, files=dict(_PVOK["files"], **{_CLAIM0: dict(_PVOK["files"][_CLAIM0],
                                                                          sha256="0" * 64)})))
    chk(any("governance 기록" in x for x in _r_sha["blockers"]),
        "⛔음성 BF P0-4: 계보의 참조 문서 SHA 가 governance 기록과 다르면 막힌다")
    _r_dl = _csp(dict(_PVOK, files=dict(_PVOK["files"], **{_CLAIM0: dict(_PVOK["files"][_CLAIM0],
                                                                         git="modified")})))
    chk(any("dirty 목록" in x for x in _r_dl["blockers"]),
        "⛔음성 BF P0-4: 항목은 modified 인데 dirty 목록이 비어 있으면 요약이 거짓이다 (재계산 대조)")
    chk(_csp(_PVOK)["manuscript_citable"] is True, "BF P0-4 양성: 완전한 registry 는 통과한다")
    _r_esc = _cs(dict(_GBOK, bundled_sources=dict(_GSRC, **{_CLAIM0: "../" + _GSRC[_CLAIM0]})))
    chk(any("번들 밖" in x for x in _r_esc["blockers"]),
        "⛔음성 BF P0-4: bundled_sources 가 `../` 로 번들 밖을 가리키면 막힌다 (containment)")
    _r_sup = _cs(dict(_GBOK, reference_files_state=dict(_GBOK["reference_files_state"], **{
        _CLAIM0: dict(_GBOK["reference_files_state"][_CLAIM0], superseded="false")})))
    chk(any("불리언 False 가 아니다" in x for x in _r_sup["blockers"]),
        "⛔음성 BF P1: superseded 가 문자열 'false' 면 막힌다 (문자열은 참이다)")
    _tdoc = pathlib.Path(__import__("tempfile").mkdtemp())
    (_tdoc / "noby.json").write_text(json.dumps(_ratified_doc({"status": "ratified", "x": 1}, by=None)),
                                     encoding="utf-8")
    _st_noby = ref_doc_state(_tdoc / "noby.json")
    chk(_st_noby["ratified"] is False and _st_noby.get("record_problems"),
        "⛔음성 BF P0-4: 비준 기록에 actor(by/actor_id) 가 없으면 ratified=False (%s)"
        % _st_noby.get("record_problems"))
    (_tdoc / "mal.json").write_text(json.dumps({"status": "ratified", "ratification": ["x"]}),
                                    encoding="utf-8")
    _st_mal = ref_doc_state(_tdoc / "mal.json")
    chk(_st_mal["ratified"] is False and "객체가 아니다" in str(_st_mal.get("why")),
        "⛔음성 BF P1: 비준 기록이 list 면 예외로 죽지 않고 형식 위반으로 ratified=False")
    (_tdoc / "ok.json").write_text(json.dumps(_ratified_doc({"status": "ratified", "x": 1})), encoding="utf-8")
    chk(ref_doc_state(_tdoc / "ok.json")["ratified"] is True,
        "BF P0-4 양성: at·by·state·role·content_digest 를 갖춘 기록은 비준으로 읽힌다")



def selftest_k() -> int:
    """k 라벨·guard band 의 **순수 산술**을 시험한다 (음성 포함).

    이 시험이 못 하는 것: OUTCAR 회수·게이트 연동. 그건 번들 selftest 몫이다.
    """
    ok = True
    # ⛔ 회신 AR P1-12 — **개수를 재현 가능하게** 센다 (문서에 적은 수와 실행 결과가
    #   갈라지지 않게). 리스트인 이유는 _selftest_closure 와 공유하기 위해서다.
    _CHKN = [0, 0]

    def chk(c, m):
        nonlocal ok
        _CHKN[0] += 1
        _CHKN[1] += bool(c)
        print(("  ✓ " if c else "  ✗ ") + m)
        ok = ok and bool(c)

    F = ["c10", "doped", "neutral", "dimer"]
    C = ["c10", "doped"]
    # 양성: 보정자 둘이 작고 서로 가까우면 나머지는 전이 심사 통과
    kt, lb, _ = k_transfer_gate(C, {"c10": 0.003, "doped": 0.005}, F)
    chk(kt["pass"] and lb["c10"] == "K_DIRECTLY_CHECKED"
        and lb["neutral"] == "K_TRANSFER_SCREENED",
        f"κ +3/+5 meV → 전이 통과 · 라벨 {lb['neutral']}")
    # ★★ 음성 (이 함수를 만든 이유): 부호가 반대면 크기만으로는 통과해 버린다
    kt2, lb2, _ = k_transfer_gate(C, {"c10": 0.009, "doped": -0.009}, F)
    chk(not kt2["pass"] and lb2["neutral"] == "K_UNVERIFIED",
        f"κ +9/−9 meV → **탈락** (각각은 10 이하지만 range {kt2['range_meV']} meV)")
    chk(max(abs(v) for v in kt2["kappa_eV"].values()) <= GUARD_EV,
        "  ↑ 전제 확인: 절대값만 봤다면 통과했을 사례다")
    # 음성: 크기가 크면 탈락
    kt3, lb3, _ = k_transfer_gate(C, {"c10": 0.025, "doped": 0.026}, F)
    chk(not kt3["pass"] and lb3["dimer"] == "K_UNVERIFIED",
        f"κ +25/+26 meV → 탈락 (range 는 작아도 max {kt3['max_abs_meV']} meV)")
    # 음성: 보정자 하나가 결측이면 전이 불가
    kt4, lb4, _ = k_transfer_gate(C, {"c10": 0.002}, F)
    chk(not kt4["pass"] and lb4["c10"] == "K_DIRECTLY_CHECKED"
        and lb4["doped"] == "K_UNVERIFIED",
        "보정자 1/2 회수 → 전이 불가 (회수된 쪽은 여전히 직접 검증)")
    # 음성: 보정자 미지정이면 조용히 통과시키지 않는다
    kt5, lb5, _ = k_transfer_gate([], {}, F)
    chk(not kt5["pass"] and set(lb5.values()) == {"K_UNVERIFIED"},
        "보정자 미지정 + κ 도 없음 → 전 조각 K_UNVERIFIED")
    # ★ 라벨은 **선언이 아니라 데이터**를 따른다 — dense 를 돌렸으면 직접 검증이다
    kt6, lb6, _ = k_transfer_gate([], {"c10": 0.004, "doped": 0.006}, F)
    chk(lb6["c10"] == "K_DIRECTLY_CHECKED" and lb6["neutral"] == "K_TRANSFER_SCREENED",
        "보정자 미선언이어도 κ 를 잰 조각은 직접 검증 (선언만 보면 headline 이 막힌다)")

    # ── 전역 부호 정규화 (Codex 5차 P1-2) ────────────────────────────────
    #   static 과 dense 가 이 규칙을 따로 구현해서, dense 가 **완전한 시간반전**으로
    #   수렴하면 전부 불일치로 잡는 거짓 차단이 났다. 한 함수로 두고 여기서 시험한다.
    _w = {0: 1.0, 1: -1.0, 2: 1.0, 3: -1.0}
    _same = {0: 1.2, 1: -1.2, 2: 1.2, 3: -1.2}
    chk(global_sign(_same, _w) == (1.0, []), "시드와 같은 배치 → sg=+1, 불일치 0")
    _rev = {k: -v for k, v in _same.items()}
    chk(global_sign(_rev, _w) == (-1.0, []),
        "**완전한 시간반전** → sg=−1, 불일치 0 (같은 상태다)")
    _part = dict(_same); _part[1] = +1.2          # 하나만 뒤집힘
    _sg, _bad = global_sign(_part, _w)
    chk(_bad == [1], f"부분 반전 하나 → 그것만 잡는다 ({_bad})")
    _half = {0: 1.2, 1: 1.2, 2: -1.2, 3: -1.2}    # 절반 반전 (모호)
    _sg2, _bad2 = global_sign(_half, _w)
    chk(len(_bad2) == 2, f"절반 반전 → 어느 부호로 봐도 2개 불일치 ({_bad2})")
    _zero = {k: 0.0 for k in _w}
    chk(len(global_sign(_zero, _w)[1]) == len(_w),
        "모멘트 전부 0 → 전부 불일치 (붕괴를 통과시키지 않는다)")

    # ── realized_basin_id (회신 Z P0-4) ──────────────────────────────────
    #   pm1/net4 는 초기 seed 이름이지 최종 basin 이 아니다. 지문이 **수렴 결과**를
    #   따라가는지, 그리고 안 따라가야 할 것(시간반전)에 안 따라가는지 본다.
    _NS = {str(i): v for i, v in _w.items()}
    _b_same, _d_same = realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {})
    _b_rev, _d_rev = realized_basin_id([-1.2, 1.2, -1.2, 1.2], _NS, {})
    chk(_b_same is not None and _b_same == _b_rev,
        "완전한 시간반전은 **같은 basin** (전역 부호 정규화 후 지문)")
    chk(len(_b_same) == 64 and _d_same["id_short"] == _b_same[:12],
        "지문은 canonical JSON 의 **full SHA256** — 12자는 표시용 (회신 AA Q5-b)")
    _b_flip, _d_flip = realized_basin_id([1.2, 1.2, 1.2, -1.2], _NS, {})
    chk(_b_flip is not None and _b_flip != _b_same,
        "⛔음성: Ni 하나가 뒤집히면 **다른 basin** (wave1.5 의 실제 사고 모양)")
    _b_col, _ = realized_basin_id([1.2, -1.2, 0.1, -1.2], _NS, {})
    chk(_b_col != _b_same and _b_col is not None,
        "⛔음성: 모멘트 붕괴도 다른 basin (부호는 살아 있어도 상태가 다르다)")
    # ★ 회신 AA Q5-c — 두 문턱. 회색은 판정하지 않는다
    _b_gray, _dg = realized_basin_id([1.2, -1.2, 0.40, -1.2], _NS, {})
    chk(_b_gray is None and "회색구간" in _dg["why"],
        f"⛔음성: 회색구간(0.25–0.55 μB) 모멘트는 **unresolved** — 단일 문턱이면 "
        f"0.4 를 자성으로 오판했다")
    _MS = {"4": 1.0}
    _b_o1, _ = realized_basin_id([1.2, -1.2, 1.2, -1.2, 0.9], _NS, _MS)
    _b_o2, _ = realized_basin_id([1.2, -1.2, 1.2, -1.2, -0.9], _NS, _MS)
    chk(_b_o1 != _b_o2,
        "⛔음성: Ni 는 같은데 **유기종 상대스핀**만 갈려도 다른 basin")
    chk(realized_basin_id(None, _NS, {})[0] is None
        and realized_basin_id([1.2], _NS, {})[0] is None,
        "⛔음성: 표가 없거나 짧으면 **추측하지 않고** None (뺄셈을 막는다)")
    _b_o1b, _ = realized_basin_id([-1.2, 1.2, -1.2, 1.2, -0.9], _NS, _MS)
    chk(_b_o1b == _b_o1,
        "유기종까지 통째로 반전해도 같은 basin (시간반전은 상대부호를 안 바꾼다)")
    # ★ 회신 AA Q5 — 시간반전을 접을 수 있는 계인지 INCAR 로 확인
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"LSORBIT": ".TRUE."})[0] is None,
        "⛔음성: SOC 가 켜져 있으면 시간반전을 접지 않는다 (전제가 깨진다)")
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"I_CONSTRAINED_M": "1"})[0] is None,
        "⛔음성: signed spin constraint 가 걸려 있으면 접지 않는다")
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"LSORBIT": ".FALSE.", "ISPIN": "2"})[0] is not None,
        "양성: collinear·무SOC·무제약이면 접는다")
    # ★ basin_distance (회신 AA Q5-c) — "얼마나 다른가"
    _dd = basin_distance(_d_same, _d_flip)
    chk(_dd["hamming"] == 1 and _dd["flipped_index_poscar"] == [1] and not _dd["same"],
        f"거리: Ni 하나 뒤집힘 → hamming 1, 인덱스 {_dd['flipped_index_poscar']}")
    _dd2 = basin_distance(_d_same, _d_rev)
    chk(_dd2["same"] and _dd2["hamming"] == 0 and _dd2["moment_rms_muB"] < 1e-9,
        "거리: 시간반전끼리는 hamming 0 · RMS 0 (전역부호로 정규화해 비교한다)")
    _b_big, _d_big = realized_basin_id([2.0, -2.0, 2.0, -2.0], _NS, {})
    _dd3 = basin_distance(_d_same, _d_big)
    chk(_dd3["hamming"] == 0 and not _dd3["same"] and _dd3["moment_rms_muB"] > 0.3,
        f"⛔음성: 부호가 같아도 **크기**가 벌어지면 동일 판정 안 한다 "
        f"(RMS {_dd3['moment_rms_muB']} > {MOM_RMS_TOL})")

    # ── 닫힘 조건 C1 · C3 (회신 AA P0-4 — 코드로 낸다) ────────────────────
    def _J(kind, _edisp=None, _mom=(1.2, -1.2, 1.2, -1.2), **kw):
        m = {"kind": kind, "d3": "on"}; m.update(kw)
        return {"ok": True, "gates": [], "meta": m,
                # C3 v2 는 OUTCAR 의 Edisp 를 읽는다 — 픽스처도 실물과 같은 자리에 둔다
                "static": {"edisp_eV": _edisp, "edisp_n": 0 if _edisp is None else 1,
                           "incar_echo": {"NSW": "0"}},
                # ★ P0-4 — 해시만이 아니라 **상세 지문**도 실물과 같은 자리에 둔다.
                #   없으면 same_basin() 이 (옳게) 통과시키지 않는다.
                "geom": {"magnetic": {
                    "realized_basin_id": "B",
                    "realized_basin": {
                        "ni_sign_vector": [1 if x > 0 else -1 for x in _mom],
                        "ni_index_poscar": [0, 1, 2, 3],
                        "collapsed_ni_positions": [],
                        "ni_moments_muB": list(_mom), "global_sign": 1.0}}}}

    _en3, _jb3 = {}, {}
    _CS = "refs/clean_slab__" + SEED_MAIN
    _jb3[_CS] = _J("clean_ref", seed=SEED_MAIN, _edisp=-1.0); _en3[_CS] = -900.0
    _jb3[_CS + "__d3off"] = _J("clean_ref", seed=SEED_MAIN, d3="off", d3_twin_of=_CS)
    _en3[_CS + "__d3off"] = -899.0                    # d_slab = -1.0 = Edisp_slab
    for _f, _em, _dm in (("sdcp_neutral", -200.0, -0.5), ("ptfe_c10", -100.0, -0.2)):
        _mk = "refs/mol__%s__box24" % _f
        _jb3[_mk] = _J("mol_ref", fragment=_f, _edisp=_dm); _en3[_mk] = _em
        _jb3[_mk + "__d3off"] = _J("mol_ref", fragment=_f, d3="off", d3_twin_of=_mk)
        _en3[_mk + "__d3off"] = _em - _dm             # d_mol = _dm = Edisp_mol
        for _i in range(4):
            _k = "prospective/%s__b%02d__%s" % (_f, _i, SEED_MAIN)
            _dcx = -2.0 if _f == "sdcp_neutral" else -1.0
            _jb3[_k] = _J("prospective_pose", fragment=_f, seed=SEED_MAIN,
                          basin_id="b%02d" % _i, role="calibration",
                          uma_E_pose_eV=0.10 + 0.01 * _i, _edisp=_dcx)
            _en3[_k] = -900.0 + _em + (-1.20 - 0.01 * _i)   # 잔차 range = 0.06
            _jb3[_k + "__d3off"] = _J("prospective_pose", fragment=_f, seed=SEED_MAIN,
                                      basin_id="b%02d" % _i, d3="off", d3_twin_of=_k)
            _en3[_k + "__d3off"] = _en3[_k] - _dcx
    _E3 = lambda j: _en3.get(j)                       # noqa: E731
    _emol3 = {"sdcp_neutral": -200.0, "ptfe_c10": -100.0}
    _F3 = ["sdcp_neutral", "ptfe_c10"]

    #   ★ manifest 를 준다 — 기대 자세 수의 정본이다 (회수분에서 세지 않는다)
    # ⛔ 회신 BA P1 (2026-09-02) — 픽스처가 `planned` 에 **meta 를 안 실었다.**
    #   실물 생성기는 kind·fragment·role·seed·basin_id·vacconv·species_order 를 넣는다.
    #   meta 없는 픽스처로는 "고르는 술어 = 세는 술어" 를 시험할 수 없다
    #   (이 파일 11345행이 이미 같은 함정을 기록해 뒀다 — 또 밟았다).
    def _planned_meta(k):
        _f = "sdcp_neutral" if "sdcp_neutral" in k else "ptfe_c10"
        return {"meta": {"kind": "prospective_pose", "fragment": _f,
                         "role": "primary", "seed": SEED_MAIN}}
    _man3 = {"planned": {k: _planned_meta(k) for k in _jb3
                         if k.startswith("prospective/") and k.endswith(SEED_MAIN)}}
    _c1 = closure_C1(_man3, _jb3, _E3, _emol3, _F3)
    chk(all(abs(_c1["by_frag"][f]["S_f_eV"] - 0.06) < 1e-6 for f in _F3),
        "C1: S_f 가 **range** 로 계산된다 (0.06) — 실제 %s"
        % [round(_c1["by_frag"][f]["S_f_eV"], 4) for f in _F3])
    _jb_p = dict(_jb3); _jb_p.pop("prospective/sdcp_neutral__b03__" + SEED_MAIN)
    chk(closure_C1(_man3, _jb_p, _E3, _emol3, _F3)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C1: 자세 하나가 빠지면 **unresolved** — 남은 것으로 range 를 내면 "
        "표본이 줄어 통과 쪽으로 편향된다")
    _kb = "prospective/ptfe_c10__b01__" + SEED_MAIN
    _jb_b = dict(_jb3)
    _jb_b[_kb] = dict(_jb3[_kb], geom={"magnetic": {"realized_basin_id": "OTHER"}})
    chk(closure_C1(_man3, _jb_b, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]["verdict"]
        == "unresolved",
        "⛔음성 C1: 네 자세 중 basin 이 다른 것이 있으면 unresolved")
    # ⛔ 음성 P0-4 — **해시는 같은데 크기가 벌어진** 경우. 종전엔 해시만 봐서
    #   1.2 μB 와 2.0 μB 가 같은 basin 으로 통과했다. basin_distance 의 RMS 규칙은
    #   selftest 밖에서 한 번도 안 불렸다 (살아 있는 척하는 죽은 코드).
    _jb_m = dict(_jb3)
    _jb_m[_kb] = _J("prospective_pose", fragment="ptfe_c10", seed=SEED_MAIN,
                    basin_id="b01", role="calibration", uma_E_pose_eV=0.11,
                    _edisp=-1.0, _mom=(2.0, -2.0, 2.0, -2.0))    # 부호 같음, 크기 다름
    _r_m = closure_C1(_man3, _jb_m, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]
    chk(_r_m["verdict"] == "unresolved"
        and any("RMS" in str(x) for x in (_r_m.get("missing") or [])),
        "⛔음성 P0-4: 부호가 같아도 **모멘트 크기**가 벌어지면 unresolved — "
        "해시만 보면 통과했다 (%s)" % (_r_m.get("missing") or [])[:1])
    # ⛔ 음성 P0-4b — 상세 지문이 아예 없으면 **통과가 아니다**
    _jb_n4 = dict(_jb3)
    _jb_n4[_kb] = dict(_jb3[_kb],
                       geom={"magnetic": {"realized_basin_id": "B"}})   # 상세 없음
    _r_n4 = closure_C1(_man3, _jb_n4, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]
    chk(_r_n4["verdict"] == "unresolved",
        "⛔음성 P0-4b: 상세 지문이 없으면 해시가 같아도 통과시키지 않는다")

    # ── 🔴 회신 AV P0-3 — clean slab 0개 · vacconv 혼입 ─────────────────────
    _jb_ns = {k: v for k, v in _jb3.items() if "clean_slab" not in k}
    _c1_ns = closure_C1(_man3, _jb_ns, _E3, _emol3, _F3)
    chk(str(_c1_ns.get("verdict", "")).startswith("n/a"),
        "AV P0-3: clean slab 0개 번들에서 C1 은 **명시적 n/a** 다 (unresolved 아님) "
        "— 미해결은 약속하고 못 지킨 상태고, 이 번들은 절대 E_ads 를 약속하지 않았다")
    _kv = "prospective/sdcp_neutral__vacconv_c2__" + SEED_MAIN
    _jb_vc = dict(_jb3)
    _jb_vc[_kv] = _J("prospective_pose", fragment="sdcp_neutral", seed=SEED_MAIN,
                     basin_id="b00", vacconv="c2", _edisp=-99.0)
    _c1_vc = closure_C1(_man3, _jb_vc, _E3, _emol3, _F3)
    chk(_c1_vc["by_frag"]["sdcp_neutral"].get("n") == 4,
        "⛔음성 AV P0-3: vacconv 잡이 섞여도 C1 이 자세로 세지 않는다 (4행 유지)")
    _man3v = {"planned": {**_man3["planned"],
                          _kv: {"meta": dict(_planned_meta(_kv)["meta"],
                                             vacconv="c2")}}}
    chk(closure_C1(_man3v, _jb_vc, _E3, _emol3, _F3)["by_frag"]["sdcp_neutral"]
        .get("n") == 4,
        "⛔음성 AV P0-3: planned 에 vacconv 가 있어도 기대 자세 수(n_want)에 안 센다")

    # ── P0-5 회귀: **production 이 실제로 쓰는 경로**로 친다 ─────────────────
    #   read_outcar 는 `{k: _echo_val(t, k) for k in AUDIT_KEYS_RUNTIME}` 로
    #   되울림을 만든다. 손으로 만든 dict 를 넣으면 그 키가 목록에 없어도 통과한다 —
    #   회신 AB P0-5 가 잡은 것이 정확히 그 상태였다. 그래서 **같은 식으로** 만든다.
    for _k5 in ("LNONCOLLINEAR", "LSORBIT", "I_CONSTRAINED_M", "BEXT"):
        chk(_k5 in AUDIT_KEYS_RUNTIME,
            "⛔음성 P0-5: %s 가 AUDIT_KEYS_RUNTIME 에 있다 — 없으면 read_outcar 가 "
            "안 읽어서 _spin_setup_ok 이 **실제로는 안 돈다**" % _k5)
    _echo = lambda t: {k: _echo_val(t, k) for k in AUDIT_KEYS_RUNTIME}   # noqa: E731
    _e5 = _echo("  ENCUT  =  520.0 eV\n  ISMEAR =      0\n")
    chk(_spin_setup_ok(_e5)[0] is True,
        "⛔음성 P0-5: 그 넷이 **미출력이면 통과**다 (VASP 기본값은 안 찍는다). "
        "종전엔 str(None)='NONE' 이 되어 전 잡을 '스핀 제약 있음' 으로 막았다: %s"
        % (_spin_setup_ok(_e5)[1],))
    chk(_spin_setup_ok(_echo("  LSORBIT =      T\n"))[0] is False,
        "⛔음성 P0-5: SOC 가 켜져 있으면 같은 경로에서 잡힌다")
    chk(_spin_setup_ok(_echo("  I_CONSTRAINED_M =      1\n"))[0] is False,
        "⛔음성 P0-5: 스핀 제약이 켜져 있으면 같은 경로에서 잡힌다")

    # ══ C5 — ΔΔE_obs (12자세 · 홀드아웃 게이트) ═══════════════════════════
    #   이것이 Figure 2e 의 숫자를 내는 조건이다. 게이트가 하나라도 새면 값을
    #   만들면 안 되므로 음성을 촘촘히 친다.
    def _mk12(a_by_role):
        """조각별 12자세 픽스처 — cal 4 + holdout 8, A 값을 지정한다."""
        jb, en = {}, {}
        for f, (cal, hld) in a_by_role.items():
            mk = "refs/mol__%s__box24" % f
            jb[mk] = _J("mol_ref", fragment=f); en[mk] = -100.0
            for i, (role, a) in enumerate([("calibration", x) for x in cal]
                                          + [("holdout", x) for x in hld]):
                k = "prospective/%s__b%02d__%s" % (f, i, SEED_MAIN)
                jb[k] = _J("prospective_pose", fragment=f, seed=SEED_MAIN,
                           basin_id="b%02d" % i, role=role, _edisp=-1.0)
                en[k] = -100.0 + a                       # A = E_cx − E_mol = a
        return jb, en

    _F5 = ["sdcp_neutral", "ptfe_c10"]
    _em5 = {"sdcp_neutral": -100.0, "ptfe_c10": -100.0}
    _A5 = {"sdcp_neutral": ([-1.20, -1.10, -1.05, -1.00], [-1.15] + [-0.9] * 7),
           "ptfe_c10":     ([-0.80, -0.75, -0.70, -0.65], [-0.74] + [-0.6] * 7)}
    _jb5, _en5 = _mk12(_A5)
    _man5 = {"planned": {k: _planned_meta(k) for k in _jb5
                         if k.startswith("prospective/")}}
    _E5 = lambda j: _en5.get(j)                          # noqa: E731
    _MG = {'ok': True, 'schema': 'merge_compat/v1', 'n_bundles': 2}
    _c5 = closure_C5(_man5, _jb5, _E5, _em5, _F5, _MG)
    chk(abs(_c5.get("ddE_obs_eV", 0) - (-0.40)) < 1e-6,
        "C5 양성: ΔΔE_obs = min(SDCP) − min(c10) = −1.20 − (−0.80) = −0.40 (실제 %s)"
        % _c5.get("ddE_obs_eV"))
    chk(all(_c5["by_frag"][f]["H1_class"] == "holds" for f in _F5),
        "C5: 홀드아웃이 calibration 최저를 30 meV 넘게 웃돌면 H1 = holds")

    # ── 회신 AF P0-3/P0-4 게이트 ────────────────────────────────────────────
    # ── 판정바닥 δ = max(30 meV 하한, 실측 S_f) ─────────────────────────────
    #   30 meV 는 MLIP(UMA) 실무 해상도라 DFT 값에 옮겨 쓸 근거가 없다. 하한으로만 쓴다.
    chk(h1_tolerance({"by_frag": {"a": {"S_f_eV": 0.004}}})["a"]["tol_eV"]
        == C5_H1_FLOOR_EV, "δ 는 S_f 와 무관하다 (작을 때)")
    chk(h1_tolerance({"by_frag": {"a": {"S_f_eV": 0.470}}})["a"]["tol_eV"]
        == C5_H1_FLOOR_EV,
        "⛔음성 AF P0-5: S_f 470 meV 여도 δ 가 **안 커진다** — 커지면 미해결 띠만 "
        "넓어져 나쁜 selector 가 자기 실패를 가린다 (그 설계는 철회됐다)")
    chk(h1_tolerance({"by_frag": {"a": {}}})["a"]["tol_eV"] == C5_H1_FLOOR_EV,
        "[음성] S_f 미측정이어도 δ 는 정의된다 (조용히 0 이 되지 않는다)")

    # ── 진공 두께 수렴 시험 (회신 AJ) ───────────────────────────────────────
    # 🔴 회신 BE P0-2 — 진공 시험은 이제 c1/c2 POSCAR **실물**과 exact key 도 본다.
    #   픽스처 루트에 Direct+Selective POSCAR 를 쓴다 (poscar_set_c 가 하듯 c2 는 z 분율만
    #   되scale — Cartesian 좌표는 같다).
    _VROOT = pathlib.Path(__import__("tempfile").mkdtemp()) / "vac"
    _VC1, _VC2 = 36.6551, 40.6551

    def _vposcar(key, c, move=0.0, tilt=0.0, flags2="T T T"):
        _d = _VROOT / key
        _d.mkdir(parents=True, exist_ok=True)
        _z = [8.0, 12.0 + move]                          # Cartesian z (Å)
        # 🔴 회신 BF P0-2 — `tilt` 는 c 벡터를 (tilt, 0, c) 로 기울인다 (리뷰어 재현) ·
        #   `flags2` 는 둘째 원자의 3축 selective-dynamics 플래그
        _lines = ["slab fixture", "1.0", "  10.0 0.0 0.0", "  0.0 10.0 0.0",
                  "  %.6f 0.0 %.6f" % (tilt, c), "  Ni O", "  1 1", "Selective dynamics", "Direct",
                  "  0.1 0.1 %.10f F F F" % (_z[0] / c), "  0.2 0.2 %.10f %s" % (_z[1] / c, flags2)]
        (_d / "POSCAR").write_text("\n".join(_lines) + "\n", encoding="utf-8")

    _GB_VAC = _write_proto_fixture(_VROOT)                # 회신 BF P0-2 — protocol 의 c1_A/c2_A
    _VM = {"vacuum_convergence": {"c1_A": _VC1, "c2_A": _VC2}, "_root": str(_VROOT),
           "governance_binding": dict(_GB_VAC),
           "estimand_job_keys": {"E_C_sdcp": "c1/sdcp_neutral__c1",
                                 "E_C_control": "c1/ptfe_c10__c1"}}
    _emv = {"sdcp_neutral": -100.0, "ptfe_c10": -50.0}

    def _vjobs(d_sdcp_c1, d_sdcp_c2, d_ptfe_c1, d_ptfe_c2, rb="r1", rb_c2=None,
               geom_break=0.0, dc_break=False, abs_shift=0.0, tilt_c2=0.0, flags_c2="T T T"):
        jb, en = {}, {}
        for f, (a1, a2) in (("sdcp_neutral", (d_sdcp_c1, d_sdcp_c2)),
                            ("ptfe_c10", (d_ptfe_c1, d_ptfe_c2))):
            # ⛔ 2026-08-31 (회신 AM P0-2) — 픽스처가 옛 규약(kind="vacuum_convergence")을
            #   쓰고 있었다. **실물 번들은 c2 도 kind="prospective_pose" + vacconv="c2"** 다.
            #   픽스처가 실물과 다르면 이 시험은 아무것도 보증하지 못한다 (실제로 그래서
            #   분석기가 c2 를 못 찾는 걸 selftest 가 못 잡았다).
            for cell, kind, a in (("c1", "prospective_pose", a1),
                                  ("c2", "prospective_pose", a2)):
                k = "%s/%s__%s" % (cell, f, cell)
                # 🔴 BF P0-2 음성 손잡이: abs_shift(두 셀 함께 +N Å · Δc 유지) · tilt_c2 · flags_c2
                _vposcar(k, (_VC1 if (cell == "c1" or dc_break) else _VC2) + abs_shift,
                         move=(geom_break if cell == "c2" else 0.0),
                         tilt=(tilt_c2 if cell == "c2" else 0.0),
                         flags2=(flags_c2 if cell == "c2" else "T T T"))
                jb[k] = {"meta": {"kind": kind, "fragment": f, "seed": SEED_MAIN,
                                  "role": "primary",
                                  **({"vacconv": "c2"} if cell == "c2" else {})},
                         "gates": [],
                         "geom": {"magnetic": {"realized_basin_id":
                                               (rb_c2 or rb) if cell == "c2" else rb}}}
                en[k] = _emv[f] + a
        return jb, en

    # 양성: A 가 네 값 모두 같은 만큼 움직이면 대비는 안 변한다
    _jv, _ev = _vjobs(-1.20, -1.19, -0.80, -0.79)
    _rv = closure_vacconv(_VM, _jv, lambda j: _ev.get(j), _emv,
                          ["sdcp_neutral", "ptfe_c10"])
    chk(_rv["pass"] and abs(_rv["delta_vac_eV"]) < 1e-9,
        "진공 양성: 두 조각이 같이 움직이면 Δ_vac = 0 (조각별 변화 10 meV 여도 통과)")
    chk(abs(_rv["D_eV"]["c1"] - (-0.40)) < 1e-9,
        "D(c1) = A_SDCP − A_PTFE = −0.40 (실제 %s)" % _rv["D_eV"]["c1"])

    # ⛔음성 ①: 대비가 6 meV 움직이면 막는다
    _jv2, _ev2 = _vjobs(-1.20, -1.206, -0.80, -0.80)
    _rv2 = closure_vacconv(_VM, _jv2, lambda j: _ev2.get(j), _emv,
                           ["sdcp_neutral", "ptfe_c10"])
    chk(_rv2["pass"] is False and "FAIL" in _rv2["verdict"],
        "⛔음성 AJ: Δ_vac 6 meV → 실패 (문턱 5 meV · 조각별로 보면 안 보인다)")

    # ② 5 meV 안이면 반올림이 갈려도 **통과**한다 (반올림은 정보용 — AM Q1·AY P0-3)
    #   경계를 **걸치게** 한다: −0.4048 → −0.40 · −0.4052 → −0.41 (차 0.4 meV)
    _jv3, _ev3 = _vjobs(-1.2048, -1.2052, -0.80, -0.80)
    _rv3 = closure_vacconv(_VM, _jv3, lambda j: _ev3.get(j), _emv,
                           ["sdcp_neutral", "ptfe_c10"])
    # ⛔ 2026-08-31 (회신 AM Q1) — 반올림 불일치는 이제 **통과**다 (표시 정보일 뿐).
    #   0.2 meV 차이가 0.00/0.01 로 갈리고, 기체 offset 만 더해도 판정이 뒤집혔다.
    chk(_rv3["within_tol"] and not _rv3["same_rounded"] and _rv3["pass"] is True,
        "⛔음성 AJ: 4 meV 로 문턱 안이어도 −0.40/−0.40 이 아니면 실패 "
        "(보고 자릿수에서 값이 달라진다) · %s" % _rv3["D_reported"])

    # ⛔음성 ③: 자기 topology 가 셀 사이에서 갈리면 셀 효과가 아니다
    _jv4, _ev4 = _vjobs(-1.20, -1.20, -0.80, -0.80, rb="r1", rb_c2="r2")
    _rv4 = closure_vacconv(_VM, _jv4, lambda j: _ev4.get(j), _emv,
                           ["sdcp_neutral", "ptfe_c10"])
    # ⛔ 2026-08-31 — `pass` 는 이제 **항상 있다**(기본 False). "키가 없다" 를 판정
    #   근거로 쓰면 안 된다 — 호출자가 KeyError 를 맞았다. 값으로 본다.
    chk(any("BASIN_MISMATCH" in b for b in _rv4["blocks"]) and _rv4["pass"] is False,
        "⛔음성 AJ: c1↔c2 realized topology 가 다르면 값을 안 만든다")

    # 🔴🔴 회신 BE P0-2 — c1/c2 실물 좌표·셀·exact key 결박 (리뷰어 재현)
    _jv5, _ev5 = _vjobs(-1.20, -1.20, -0.80, -0.80, geom_break=0.5)
    _rv5 = closure_vacconv(_VM, _jv5, lambda j: _ev5.get(j), _emv, ["sdcp_neutral", "ptfe_c10"])
    chk(any("VACCONV_GEOMETRY_MISMATCH" in b and "좌표" in b for b in _rv5["blocks"])
        and _rv5["pass"] is False,
        "⛔음성 BE P0-2 (리뷰어 재현): c2 가 **다른 자세**(원자 0.5 Å 이동)면 자기 지문이 "
        "같아도 값을 안 만든다")
    _jv6, _ev6 = _vjobs(-1.20, -1.20, -0.80, -0.80, dc_break=True)
    _rv6 = closure_vacconv(_VM, _jv6, lambda j: _ev6.get(j), _emv, ["sdcp_neutral", "ptfe_c10"])
    chk(any("VACCONV_GEOMETRY_MISMATCH" in b and "Δc" in b for b in _rv6["blocks"])
        and _rv6["pass"] is False,
        "⛔음성 BE P0-2: c2 셀이 선언한 Δc 만큼 크지 않으면(같은 셀) 진공 시험이 아니다")
    _jv7, _ev7 = _vjobs(-1.20, -1.20, -0.80, -0.80)
    _rv7 = closure_vacconv(dict(_VM, estimand_job_keys={
        "E_C_sdcp": "prospective/sdcp_neutral__b09__afm2424_pm1",
        "E_C_control": "c1/ptfe_c10__c1"}), _jv7, lambda j: _ev7.get(j), _emv,
        ["sdcp_neutral", "ptfe_c10"])
    chk(any("VACCONV_C1_NOT_PRIMARY" in b for b in _rv7["blocks"]) and _rv7["pass"] is False,
        "⛔음성 BE P0-2: c1 이 사전 고정 complex 가 아니면(다른 자세) 그 진공 수렴으로 "
        "primary 를 보증하지 않는다")
    _rv8 = closure_vacconv({k: v for k, v in _VM.items() if k != "_root"}, _jv7,
                           lambda j: _ev7.get(j), _emv, ["sdcp_neutral", "ptfe_c10"])
    chk(any("VACCONV_GEOMETRY_UNVERIFIED" in b for b in _rv8["blocks"]) and _rv8["pass"] is False,
        "⛔음성 BE P0-2: POSCAR 실물을 못 보면 확인 못 한 것 = 통과 아님")
    _rv9 = closure_vacconv(_VM, _jv7, lambda j: _ev7.get(j), _emv, ["sdcp_neutral", "ptfe_c10"])
    chk(_rv9["pass"] is True and not _rv9["blocks"],
        "BE P0-2 양성: 같은 좌표·같은 고정 플래그·Δc 일치·exact key 면 통과한다")
    # ══ 회신 BF P0-2 (2026-09-03) — **절대 셀 · full c 벡터 · 3축 플래그 · protocol 선언** ══
    #  ⚠ `_vjobs` 는 같은 경로의 POSCAR 를 덮어쓴다 — 각 음성은 만든 직후 바로 판정한다.
    _FR2 = ["sdcp_neutral", "ptfe_c10"]
    _jv_abs, _ev_abs = _vjobs(-1.20, -1.19, -0.80, -0.79, abs_shift=4.0)   # 두 셀 +4 Å · Δc 유지
    _rv_abs = closure_vacconv(_VM, _jv_abs, lambda j: _ev_abs.get(j), _emv, _FR2)
    chk(any("VACCONV_GEOMETRY_MISMATCH" in b and "절대 높이" in b for b in _rv_abs["blocks"])
        and _rv_abs["pass"] is False,
        "⛔음성 BF P0-2 (리뷰어 재현): 실제 셀을 +4 Å 로 바꾸고 Δc 만 유지해도 **절대 높이**가 "
        "선언 c1_A/c2_A 와 달라 막힌다 (종전엔 Δc 만 봤다)")
    _jv_tilt, _ev_tilt = _vjobs(-1.20, -1.19, -0.80, -0.79, tilt_c2=0.25)
    _rv_tilt = closure_vacconv(_VM, _jv_tilt, lambda j: _ev_tilt.get(j), _emv, _FR2)
    chk(any("기울어진 셀" in b for b in _rv_tilt["blocks"]) and _rv_tilt["pass"] is False,
        "⛔음성 BF P0-2 (리뷰어 재현): c2 를 (0.25, 0, c) 로 기울이면 막힌다 — full c 벡터를 본다")
    _jv_fl, _ev_fl = _vjobs(-1.20, -1.19, -0.80, -0.79, flags_c2="T T F")
    _rv_fl = closure_vacconv(_VM, _jv_fl, lambda j: _ev_fl.get(j), _emv, _FR2)
    chk(any("3축 selective-dynamics" in b for b in _rv_fl["blocks"]) and _rv_fl["pass"] is False,
        "⛔음성 BF P0-2: 원자별 3축 selective-dynamics 플래그가 다르면(T T T vs T T F) 막힌다")
    _jv_np, _ev_np = _vjobs(-1.20, -1.19, -0.80, -0.79)
    _rv_np = closure_vacconv(dict(_VM, governance_binding={}), _jv_np, lambda j: _ev_np.get(j), _emv, _FR2)
    chk(any("protocol 의 c1_A/c2_A" in b for b in _rv_np["blocks"]) and _rv_np["pass"] is False,
        "⛔음성 BF P0-2: 비준 protocol 사본이 번들에 없으면 선언 c1/c2 를 대조 못 한 것 = 통과 아님")
    _rv_pd = closure_vacconv(dict(_VM, vacuum_convergence={"c1_A": 36.6551, "c2_A": 44.6551}),
                             *(_vjobs(-1.20, -1.19, -0.80, -0.79, dc_break=False)[:1]),
                             lambda j: _ev_np.get(j), _emv, _FR2)
    chk(any("비준 protocol" in b for b in _rv_pd["blocks"]) and _rv_pd["pass"] is False,
        "⛔음성 BF P0-2: manifest 선언 c1/c2 가 비준 protocol 과 다르면 막힌다 (선언 자체를 결박)")
    _jv_p2, _ev_p2 = _vjobs(-1.20, -1.19, -0.80, -0.79)
    _rv_p2 = closure_vacconv(_VM, _jv_p2, lambda j: _ev_p2.get(j), _emv, _FR2)
    chk(_rv_p2["pass"] is True and not _rv_p2["blocks"],
        "BF P0-2 양성: 절대 셀·c 벡터·플래그·protocol 선언이 모두 맞으면 통과한다 (%s)"
        % _rv_p2["blocks"][:1])

    # [음성] 옛 번들에는 적용하지 않는다
    chk(closure_vacconv({}, {}, lambda j: None, _emv,
                        ["sdcp_neutral", "ptfe_c10"])["applicable"] is False,
        "[음성] vacconv 잡이 없는 번들에는 없는 계약을 요구하지 않는다")

    # ── clean slab 없이 자기 topology 판정 (회신 AJ ②) ──────────────────────
    # ⛔⛔ 2026-08-31 (회신 AN P0-2) — 픽스처가 **내가 지어낸 필드 이름**(`ni_moments`)을
    #   써서, 함수가 production 스키마(`realized_basin.ni_moments_muB`)를 못 읽는데도
    #   selftest 가 통과했다. 이제 픽스처는 `realized_basin()` 이 **실제로 내는 모양**을 쓴다.
    def _J3(mom):
        # ⚠ `_J3(None)` 로 "표가 없다" 를 시험하는 호출이 있다 — 그걸 깨지 말 것.
        if mom is None:
            return {"geom": {"magnetic": {"realized_basin": {}}}}
        return {"geom": {"magnetic": {"realized_basin": {
            "ni_moments_muB": list(mom),
            "ni_sign_vector": [1 if x > 0 else -1 for x in mom],
            "ni_index_poscar": list(range(len(mom))), "global_sign": 1.0}}}}

    def _J3_legacy(mom):                     # 하위호환 경로 (옛 기록)
        return {"geom": {"magnetic": {"ni_moments": mom}}}
    _up = [1.2, -1.2] * 24
    _dn = [-1.2, 1.2] * 24                     # 전역 반전 — 같은 상태여야 한다
    chk(magnetic_topology_direct(_J3(_up))[0] == magnetic_topology_direct(_J3(_dn))[0],
        "직접 topology: 전역 반전을 **동치로 접는다** (AFM 은 전체를 뒤집어도 같다)")
    chk(magnetic_topology_direct(_J3(_up))[0]
        != magnetic_topology_direct(_J3([1.2] * 48))[0],
        "직접 topology: 배열이 다르면 fingerprint 도 다르다")
    # ⛔음성 — production 스키마와 하위호환 경로가 **같은 답**을 내야 한다.
    #   (초판은 하위호환 쪽만 읽어서 실물에서 항상 MISSING 이었다)
    chk(magnetic_topology_direct(_J3(_up))[0]
        == magnetic_topology_direct(_J3_legacy(_up))[0],
        "⛔음성 AN P0-2: **production 스키마**(realized_basin.ni_moments_muB)를 읽는다 "
        "— 옛 픽스처 이름만 읽으면 실물에서 항상 MISSING 이 된다")
    chk(magnetic_topology_direct(
            {"geom": {"magnetic": {"realized_basin": {"ni_sign_vector": [1] * 48}}}})[0] is None,
        "⛔음성: realized_basin 은 있는데 모멘트 표가 없으면 판정하지 않는다 "
        "(부호벡터만으로 접지 않는다)")
    chk(magnetic_topology_direct(_J3(_up[:40]))[0] is None
        and "INCOMPLETE" in magnetic_topology_direct(_J3(_up[:40]))[1][0],
        "⛔음성 AJ: Ni 모멘트 표가 40/48 이면 **판정하지 않는다**")
    _col = list(_up); _col[7] = 0.05
    chk(magnetic_topology_direct(_J3(_col))[0] is None
        and "COLLAPSE_DIRECT" in magnetic_topology_direct(_J3(_col))[1][0],
        "⛔음성 AJ: near-zero 모멘트가 있으면 부호를 못 읽으므로 막는다")
    chk(magnetic_topology_direct(_J3(None))[0] is None,
        "⛔음성 AJ: 모멘트 표가 없으면 조용히 통과하지 않는다")
    chk(same_topology_direct(_J3(_up), _J3(_dn))[0]
        and not same_topology_direct(_J3(_up), _J3([1.2] * 48))[0],
        "직접 topology: 두 잡 비교가 전역 반전에는 관대하고 배열 차이엔 엄격하다")

    # ⛔ 회신 AF P0-6 — 정확히 ±δ 는 **둘 다 미해결**이다 (부동소수점으로 뒤집혔었다)
    for _sgn, _lbl in ((+1, "+30 meV"), (-1, "−30 meV")):
        _Ab = {"sdcp_neutral": ([-1.20, -1.10, -1.05, -1.00], [-1.15] + [-0.9] * 7),
               "ptfe_c10": ([-0.80, -0.75, -0.70, -0.65],
                            [round(-0.80 + _sgn * C5_H1_FLOOR_EV, 12)] + [-0.6] * 7)}
        _jbb, _enb = _mk12(_Ab)
        _cb = closure_C5({"planned": {k: _planned_meta(k) for k in _jbb
                                      if k.startswith("prospective/")}},
                         _jbb, lambda j: _enb.get(j), _em5, _F5, _MG)
        chk(_cb["by_frag"]["ptfe_c10"]["H1_class"] == "unresolved",
            f"⛔음성 AF P0-6: 정확히 {_lbl} 는 **미해결** "
            f"(실제 {_cb['by_frag']['ptfe_c10']['H1_class']})")
    # [음성] δ 가 커지면 종전에 통과하던 여유가 미해결로 바뀐다
    _A5t = {"sdcp_neutral": _A5["sdcp_neutral"],
            "ptfe_c10": ([-0.80, -0.75, -0.70, -0.65], [-0.74] + [-0.6] * 7)}
    _jb5t, _en5t = _mk12(_A5t)
    _man5t = {"planned": {k: {} for k in _jb5t if k.startswith("prospective/")}}
    _c5t = closure_C5(_man5t, _jb5t, lambda j: _en5t.get(j), _em5, _F5, _MG,
                      h1_tolerance({"by_frag": {f: {"S_f_eV": 0.080} for f in _F5}}))
    chk(_c5t["by_frag"]["ptfe_c10"]["H1_class"] == "holds",
        "⛔음성 AF P0-5: S_f 80 meV 가 있어도 여유 60 meV 는 **holds** 다 — "
        "S_f 가 판정을 삼키지 않는다")

    chk(closure_C5(_man5, _jb5, _E5, _em5, _F5).get("verdict", "").startswith("⛔ NOT_MERGED"),
        "⛔음성 AF: 묶음 하나만 주면 **값을 만들지 않는다** (12자세는 두 묶음에 걸쳐 있다)")
    chk(closure_C5(_man5, _jb5, _E5, _em5, _F5,
                   {"ok": False, "blocking": ["clean_slab 가 다르다"]}
                   ).get("verdict", "").startswith("⛔ MERGE_INCOMPATIBLE"),
        "⛔음성 AF: 두 묶음의 프로토콜이 갈리면 합치지 않는다")

    # [음성] H1 미해결 구간(±30 meV)을 통과로 승격하지 않는다
    _A5u = {"sdcp_neutral": _A5["sdcp_neutral"],
            "ptfe_c10": ([-0.80, -0.75, -0.70, -0.65], [-0.78] + [-0.6] * 7)}
    _jb5u, _en5u = _mk12(_A5u)
    _c5u = closure_C5({"planned": {k: {} for k in _jb5u if k.startswith("prospective/")}},
                      _jb5u, lambda j: _en5u.get(j), _em5, _F5, _MG)
    chk(_c5u["by_frag"]["ptfe_c10"]["H1_class"] == "unresolved"
        and "ddE_obs_eV" not in _c5u,
        "⛔음성 AF: 여유 20 meV 는 판정 해상도 안 → **미해결**이고 값을 안 만든다 "
        "(종전 두 갈래는 이걸 통과로 승격시켰다)")

    # [음성] 합이 12 라도 구성이 4+8 이 아니면 홀드아웃 시험이 성립하지 않는다
    _A5c = {"sdcp_neutral": ([-1.20] * 11, [-0.9]), "ptfe_c10": _A5["ptfe_c10"]}
    _jb5c2, _en5c2 = _mk12(_A5c)
    _c5c = closure_C5({"planned": {k: {} for k in _jb5c2 if k.startswith("prospective/")}},
                      _jb5c2, lambda j: _en5c2.get(j), _em5, _F5, _MG)
    chk(_c5c["by_frag"]["sdcp_neutral"]["verdict"].startswith("unresolved")
        and "ddE_obs_eV" not in _c5c,
        "⛔음성 AF: cal 11 + holdout 1 은 합이 12 여도 거부한다")
    chk("전역 최소" in str(_c5.get("⛔_금지_서술")),
        "C5 가 금지 서술을 결과에 함께 싣는다")

    # ── 분석기 쪽 게이트 (러너가 아니라 **반송물**을 우리가 직접 본다) ──────
    _M = {"files_sha256": {"j/POTCAR_ASSEMBLE.sh": "x"}}
    _meta_ok = {"species_order": ["Li", "Ni"], "potcar_spec": {"Li": "Li_sv",
                                                               "Ni": "Ni_pv"}}
    import tempfile as _tfx
    _jp = pathlib.Path(_tfx.mkdtemp()) / "pg"
    _jp.mkdir(parents=True, exist_ok=True)

    def _pg(payload, meta=None, marker=False):
        for q in _jp.iterdir():
            q.unlink()
        if payload is not None:
            (_jp / "POTCAR_PROVENANCE.json").write_text(json.dumps(payload), encoding="utf-8")
        if marker:
            (_jp / ".SELFTEST_FIXTURE").write_text("x", encoding="utf-8")
        return potcar_provenance_gates(str(_jp), meta or _meta_ok, "j", _M)

    _good = {"schema": "potcar_provenance/v1", "species_order": ["Li", "Ni"],
             "expected_variants": ["Li_sv", "Ni_pv"],
             "titel_lines": [" TITEL  = PAW_PBE Li_sv", " TITEL  = PAW_PBE Ni_pv"],
             "allowlist": "/a", "allowlist_sha256": "0" * 64,
             "allowlist_waived": False, "assembled_sha256": "1" * 64}
    chk(_pg(_good) == [], "분석기 양성: 정상 provenance 는 게이트 0건")
    chk(any("MISSING" in g for g in _pg(None)),
        "⛔음성 P0-7: 반송물에 provenance 가 없으면 막는다")
    chk(any("WAIVED" in g for g in _pg({**_good, "allowlist_waived": True})),
        "⛔음성 P0-7: 면제본은 막는다")
    chk(any("UNPINNED" in g for g in
            _pg({k: v for k, v in _good.items() if k != "allowlist_sha256"})),
        "⛔음성 P0-7: allowlist 내용 SHA 가 없으면 막는다")
    chk(any("SPECIES_ORDER_MISMATCH" in g for g in
            _pg({**_good, "species_order": ["Ni", "Li"]})),
        "⛔음성 P0-7: 종 순서가 잡과 다르면 막는다 (다른 계를 계산한 것이다)")
    chk(any("VARIANT_NOT_IN_TITEL" in g for g in
            _pg({**_good, "titel_lines": [" TITEL  = PAW_PBE Li", " TITEL  = PAW_PBE Ni"]})),
        "⛔음성 P0-7: 선언한 variant 가 TITEL 에 없으면 막는다 (Ni vs Ni_pv)")
    chk(any("FIXTURE_MARKER" in g for g in _pg(_good, marker=True)),
        "⛔음성 P0-7: 시험 표시 파일이 반송물에 섞이면 막는다")
    chk(potcar_provenance_gates(str(_jp), _meta_ok, "other", _M) == [],
        "[음성] 조립기를 안 실어 보낸 잡에는 계약을 요구하지 않는다")

    # ── 🔴 회신 AV P0-2 — 실행파일 receipt 를 분석기가 **직접** 게이트한다 ──
    _rjp = pathlib.Path(_tfx.mkdtemp()) / "rj"
    _rjp.mkdir(parents=True, exist_ok=True)
    _SEAL_SHA = "a" * 64
    _MRC = {"staged_runner": "run_staged.sh",
            "files_sha256": {"j/run_job.sh": "x"},
            # ⛔ 회신 AY P0-1 — 봉인에 **launcher 해시도** 있어야 대조가 성립한다
            "_potcar_root_seal": {"vasp_executable_sha256": _SEAL_SHA,
                                  "launcher_kind": "mpirun",
                                  "launcher_path": "/opt/ompi/bin/mpirun",
                                  "launcher_sha256": "c" * 64}}

    def _erg(text, man=None, executed=("static",), rel="j"):
        f = _rjp / "EXECUTABLE_RECEIPT.tsv"
        if text is None:
            f.unlink(missing_ok=True)
        else:
            f.write_text(text, encoding="utf-8")
        return executable_receipt_gates(str(_rjp), rel, man or _MRC, list(executed))

    # 9열 (AY P0-1 · BE P1): ts phase exe_sha exe kind nproc launcher launcher_sha potcar_sha
    _LSHA = "c" * 64
    # 🔴 회신 BF P1 — 분석기가 상 폴더 POTCAR **실물**을 다시 해시하므로 픽스처도 실물을 둔다
    _PBYTES = b"PAW_PBE fixture POTCAR (selftest)\n"
    (_rjp / "static").mkdir(exist_ok=True)
    (_rjp / "static" / "POTCAR").write_bytes(_PBYTES)
    _PSHA = hashlib.sha256(_PBYTES).hexdigest()      # 상 폴더 POTCAR 해시 (BE P1 · BF P1 실물)
    _ROW = ("2026-08-31T00:00:00Z\t%s\t%s\t/x/vasp_std\t%s\t48"
            "\t/opt/ompi/bin/mpirun\t%s\t" + _PSHA + "\n")
    _ok_rcpt = (_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                + _ROW % ("static", _SEAL_SHA, "mpirun", _LSHA))
    # 🔴 회신 BF P1 — receipt 9열과 반송 상 폴더 POTCAR **실물**을 대조한다
    (_rjp / "static" / "POTCAR").write_bytes(b"PAW_PBE SWAPPED after run\n")
    chk(any("RECEIPT_POTCAR_FILE_MISMATCH" in g for g in _erg(_ok_rcpt)),
        "⛔음성 BF P1: 상 폴더 POTCAR 실물 해시 ≠ receipt 9열이면 막힌다 (receipt 문자열만 믿지 않는다)")
    (_rjp / "static" / "POTCAR").unlink()
    # 🔴 회신 BG P0-1 — 계약(`_return_contract`)이 POTCAR 를 반송 목록에 넣지 **않으므로**
    #   없음은 게이트가 아니다. BF P1 의 이 시험은 계약과 어긋나 16/16 잡을 막고 있었다.
    chk(not any("RECEIPT_POTCAR_FILE_MISSING" in g for g in _erg(_ok_rcpt)),
        "🔴 BG P0-1: 반송 계약이 POTCAR 를 요구하지 않으므로 **없음은 게이트가 아니다** "
        "— 계약대로 회수한 트리에서 전 잡이 막히던 것을 푼다 (결박은 receipt 9열 + "
        "POTCAR_PROVENANCE + root seal 이 이미 한다)")
    (_rjp / "static" / "POTCAR").write_bytes(_PBYTES)          # 원상복구 — 아래 양성이 쓴다
    chk(_erg(_ok_rcpt) == [], "AV P0-2 양성: 봉인과 같은 해시의 receipt 는 게이트 0건")
    chk(any("RECEIPT_MISSING" in g for g in _erg(None)),
        "⛔음성 AV P0-2: receipt 가 없으면 막는다 (분석기가 실제로 **읽는다**)")
    chk(any("RECEIPT_EXE_MISMATCH" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + _ROW % ("static", "b" * 64, "mpirun", _LSHA))),
        "⛔음성 AV P0-2: 봉인 밖 바이너리 해시면 막는다")
    # ⛔⛔ 회신 AY P0-1 — PATH 앞의 가짜 mpirun
    chk(any("RECEIPT_LAUNCHER_MISMATCH" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + _ROW % ("static", _SEAL_SHA, "mpirun", "f" * 64))),
        "⛔음성 AY P0-1: **launcher 해시가 봉인과 다르면 막는다** "
        "(PATH 앞의 가짜 mpirun — AV 판이 놓쳤던 구멍)")
    chk(any("RECEIPT_RUNNER_START" in g for g in
            _erg(_ROW % ("static", _SEAL_SHA, "mpirun", _LSHA))),
        "⛔음성 AY P0-2: `_runner_start` 가 없으면 막는다 (러너를 안 거친 실행)")
    chk(any("RECEIPT_RUNNER_START" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA) * 2
                 + _ROW % ("static", _SEAL_SHA, "mpirun", _LSHA))),
        "⛔음성 AY P0-2: `_runner_start` 가 둘이면 막는다 (이어붙인 receipt)")
    chk(any("RECEIPT_MALFORMED" in g for g in
            _erg("2026-08-31T00:00:00Z\tstatic\t%s\t/x/vasp_std\tnone\t48\n" % _SEAL_SHA)),
        "⛔음성 AY P1: 열이 9개가 아니면 막는다 (종전 `<6` 은 열이 남아도 통과시켰다)")
    chk(any("RECEIPT_MALFORMED" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + ("2026-08-31T00:00:00Z\tstatic\t%s\t/x/vasp_std\tmpirun\t48"
                    "\t/opt/ompi/bin/mpirun\t%s\n" % (_SEAL_SHA, _LSHA)))),
        "⛔음성 BE P1: 옛 8열 행(potcar 열 없음)은 이제 malformed 다 — 결박 없는 행을 "
        "그냥 통과시키지 않는다")
    chk(any("RECEIPT_NPROC" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + ("2026-08-31T00:00:00Z\tstatic\t%s\t/x/vasp_std\tmpirun\t0"
                    "\t/opt/ompi/bin/mpirun\t%s\t%s\n" % (_SEAL_SHA, _LSHA, _PSHA)))),
        "⛔음성 AY P1: nproc 가 양의 정수가 아니면 막는다")
    chk(any("RECEIPT_TIME_FORMAT" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + ("어제\tstatic\t%s\t/x/vasp_std\tmpirun\t48"
                    "\t/opt/ompi/bin/mpirun\t%s\t%s\n" % (_SEAL_SHA, _LSHA, _PSHA)))),
        "⛔음성 AY P1: UTC 형식이 아니면 막는다")
    # 🔴 회신 BE P1 — 상 폴더 POTCAR 해시 결박
    chk(any("RECEIPT_POTCAR_SHA_MISSING" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + ("2026-08-31T00:00:00Z\tstatic\t%s\t/x/vasp_std\tmpirun\t48"
                    "\t/opt/ompi/bin/mpirun\t%s\t-\n" % (_SEAL_SHA, _LSHA)))),
        "⛔음성 BE P1: 상별 행의 potcar_sha 가 '-' 면 결박 없음 = 통과 아님")
    (_rjp / "POTCAR_PROVENANCE.json").write_text(
        json.dumps({"assembled_sha256": _PSHA}), encoding="utf-8")
    chk(_erg(_ok_rcpt) == [],
        "BE P1 양성: 상 폴더 POTCAR 해시가 조립 provenance 와 같으면 게이트 0건")
    (_rjp / "POTCAR_PROVENANCE.json").write_text(
        json.dumps({"assembled_sha256": "e" * 64}), encoding="utf-8")
    chk(any("RECEIPT_POTCAR_MISMATCH" in g for g in _erg(_ok_rcpt)),
        "⛔음성 BE P1: 상 폴더 POTCAR 가 조립본과 다르면(조립 뒤 바꿔치기) 막는다")
    (_rjp / "POTCAR_PROVENANCE.json").unlink()
    chk(any("RECEIPT_PHASE_MISSING" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA))),
        "⛔음성 AV P0-2: OUTCAR 가 있는 상의 receipt 행이 없으면 막는다 "
        "(run_job.sh 밖 실행)")
    chk(any("RECEIPT_LAUNCHER_KIND" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + _ROW % ("static", _SEAL_SHA, "env", _LSHA))),
        "⛔음성 AV P0-2: 허용 밖 launcher(env)가 receipt 에 있으면 막는다")
    chk(any("RECEIPT_UNVERIFIABLE" in g for g in
            _erg(_ROW % ("_runner_start", _SEAL_SHA, "mpirun", _LSHA)
                 + _ROW % ("static", _SEAL_SHA, "mpirun", _LSHA),
                 man={**_MRC, "_potcar_root_seal": {}})),
        "⛔음성 AV P0-2: 봉인에 실행파일 해시가 없으면 '확인 못 함 = 통과 아님'")
    chk(_erg(_ok_rcpt, man={"files_sha256": {"j/run_job.sh": "x"}}) == [],
        "[음성] 비-staged 구판 번들에는 receipt 계약을 소급 요구하지 않는다")
    chk(_erg(None, man=_MRC, rel="other") == [],
        "[음성] 러너를 안 실어 보낸 잡에는 요구하지 않는다")

    # ⛔ 회신 AI §B — 자기일관적 허위. 회신 JSON 안에서 expected_variants 와
    #    titel_lines 가 서로 맞으면 종전 코드는 통과시켰다. 우리 규격이 기준이어야 한다.
    _M2 = {"files_sha256": {"j/POTCAR_ASSEMBLE.sh": "x"},
           "potcar_spec": {"Li": "Li_sv", "Ni": "Ni_pv"}}

    def _pg2(payload):
        for q in _jp.iterdir():
            q.unlink()
        (_jp / "POTCAR_PROVENANCE.json").write_text(json.dumps(payload), encoding="utf-8")
        return potcar_provenance_gates(str(_jp), _meta_ok, "j", _M2)

    _liar = {**_good, "expected_variants": ["Li", "Ni"],
             "titel_lines": [" TITEL  = PAW_PBE Li", " TITEL  = PAW_PBE Ni"]}
    _gl = _pg2(_liar)
    chk(any("VARIANT_NOT_IN_TITEL" in g for g in _gl)
        and any("SPEC_DISAGREES" in g for g in _gl),
        "⛔음성 AI: 회신 안에서 앞뒤가 맞는 **허위**(Li/Ni 로 통일)도 우리 규격과 "
        "대조해 잡는다")
    chk(_pg2(_good) == [], "양성: 우리 규격(Li_sv·Ni_pv)과 맞으면 통과")
    chk(any("SPEC_UNAVAILABLE" in g for g in potcar_provenance_gates(
            str(_jp), {"species_order": ["Li", "Ni"]}, "j",
            {"files_sha256": {"j/POTCAR_ASSEMBLE.sh": "x"}})),
        "⛔음성 AI: 우리 쪽 규격이 없으면 **통과시키지 않는다** "
        "(회신끼리만 맞춰 보는 것은 검증이 아니다)")

    # ── 묶음 전체 신원 (잡 하나씩으로는 못 잡는 것) ─────────────────────────
    # ⛔ 회신 AO P0-8 — 픽스처의 sha 를 **64자리 실물 모양**으로 만든다. 종전엔
    #   "aa" 같은 짧은 문자열이라, "원본 sha 가 64자리인가" 를 아무도 안 봤다.
    #   (그 결과 실물에서 sha 가 잘리거나 비어도 split 만 없으면 통과했다)
    def _H64(tag):
        return (tag * 32)[:64]

    # ⛔⛔ 회신 AP #8 — 픽스처를 **실물 record 모양**으로 만든다. 생성부는 미실행
    #   잡에도 `static: None` 키를 넣는데, 종전 픽스처는 키 자체를 빼서
    #   `"static" in jr` 버그를 **재현하지 못했다** (회신 AL P0-3 과 같은 방식).
    #   ran=False 는 이제 `static: None` 이고, 이 모양으로도 통과해야 맞다.
    def _J2(sha, ver, els=("Ni",), ran=True, normal=True, e0=-1.0, asm=None):
        # ⛔ 회신 AS 4 — 반송 provenance 의 **조립본 해시**를 봉인과 대조한다.
        #   픽스처도 실물처럼 그 값을 담아야 한다.
        d = {"_prov": {"source_sha256": {e: _H64(sha) for e in els},
                       "assembled_sha256": asm},
             "meta": {"species_order": list(els)},
             "static": None}
        if ran:
            d["static"] = {"vasp_version": ver, "normal_end": normal,
                           "E0": (e0 if normal else None)}
        return d
    #   잡 키를 계획(`p/a`·`p/b`)과 맞추고 조립본 해시를 봉인과 일치시킨다
    _one = {"p/a": _J2("aa", "6.4.1", asm=_H64("1a")),
            "p/b": _J2("aa", "6.4.1", asm=_H64("1b"))}
    # ⛔음성 AO P0-8 — 완주했는데 원본 sha 가 **64자리가 아니면** 막는다
    _short = {"a": {"_prov": {"source_sha256": {"Ni": "aa"}},
                    "meta": {"species_order": ["Ni"]},
                    "static": {"vasp_version": "6.4.1", "normal_end": True, "E0": -1.0}}}
    chk(any("SOURCE_INCOMPLETE" in g for g in
            potcar_identity_gates(_short, {})["blocking"]),
        "⛔음성 AO P0-8: 원본 sha 가 64자리가 아니면 막는다 (누락을 '갈리지 않음' 으로 읽지 않는다)")
    # ⛔음성 AO P0-8 — 기대 variant 하나가 **아예 빠져도** 막는다
    _miss = {"a": {"_prov": {"source_sha256": {"Ni": _H64("aa")}},
                   "meta": {"species_order": ["Ni", "O"]},
                   "static": {"vasp_version": "6.4.1", "normal_end": True, "E0": -1.0}}}
    chk(any("SOURCE_INCOMPLETE" in g for g in
            potcar_identity_gates(_miss, {})["blocking"]),
        "⛔음성 AO P0-8: 기대 variant 중 하나라도 sha 가 없으면 막는다")
    # ⛔음성 AO P0-8 — VASP 버전 관측이 0개면 막는다 (0개 관측은 일치가 아니다)
    _nov = {"a": {"_prov": {"source_sha256": {"Ni": _H64("aa")}},
                  "meta": {"species_order": ["Ni"]},
                  "static": {"normal_end": True, "E0": -1.0}}}
    chk(any("VASP_VERSION_UNOBSERVED" in g for g in
            potcar_identity_gates(_nov, {})["blocking"]),
        "⛔음성 AO P0-8: 완주잡에 VASP 버전 관측이 없으면 막는다")
    # ⛔음성 AO P0-8 — 완주했는데 provenance 자체가 없으면 막는다
    chk(any("PROVENANCE_MISSING" in g for g in
            potcar_identity_gates(
                {"a": {"static": {"vasp_version": "6.4.1", "normal_end": True,
                                  "E0": -1.0}}}, {})["blocking"]),
        "⛔음성 AO P0-8: 완주잡에 provenance 가 없으면 막는다")
    # 양성 — **아직 안 돈 잡**은 완전성 대상이 아니다 (단계별 실행에서 정상)
    #   ⚠ ran=False 는 이제 실물처럼 `static: None` 이다 (AP #8)
    _mix = {"a": _J2("aa", "6.4.1"), "b": _J2("aa", "6.4.1", ran=False)}
    _rm = potcar_identity_gates(_mix, {})
    chk(_rm["ok"] and _rm["completeness"]["n_completed"] == 1,
        "양성 AP #8: `static: None` 인 미실행 잡은 완전성 대상이 아니다 "
        f"(completed {_rm['completeness']['n_completed']}/2 · "
        f"census {_rm['completeness']['stage_census']})")
    # ⛔음성 AP #8 — 종전 판정(`"static" in jr`)이면 미실행 잡도 완주로 세서
    #   provenance 를 요구했다. 그 잡에 provenance 를 빼도 통과해야 맞다.
    _mix2 = {"a": _J2("aa", "6.4.1"),
             "b": {"meta": {"species_order": ["Ni"]}, "static": None}}
    chk(potcar_identity_gates(_mix2, {})["ok"],
        "⛔음성 AP #8: 미실행 잡에 provenance 가 없어도 막지 않는다 "
        "(종전엔 `\"static\" in jr` 이라 **항상 참**이라 막았다)")
    # ⛔음성 AP #8 — OUTCAR 는 있는데 **완주가 아닌** 잡도 완전성 대상이 아니다
    _att = {"a": _J2("aa", "6.4.1"),
            "b": _J2("aa", "6.4.1", normal=False)}
    _ra = potcar_identity_gates(_att, {})
    chk(_ra["ok"] and _ra["completeness"]["stage_census"].get("attempted") == 1,
        "⛔음성 AP #8: 정상 종료 못 한 잡은 **attempted** 이지 completed 가 아니다 "
        f"({_ra['completeness']['stage_census']})")
    # ⛔음성 AO Q1 — 생산 전 봉인(root seal)과 관측이 다르면 막는다
    chk(any("ROOT_SEAL_MISMATCH" in g for g in potcar_identity_gates(
            _one, {"_potcar_root_seal": {"source_sha256": {"Ni": _H64("bb")}}}
            )["blocking"]),
        "⛔음성 AO Q1: 생산 전 봉인한 root 와 관측 fingerprint 가 다르면 막는다")
    # ⛔음성 AO Q1 — 봉인에 없는 variant 가 관측되면 막는다
    chk(any("ROOT_SEAL_INCOMPLETE" in g for g in potcar_identity_gates(
            {"a": _J2("aa", "6.4.1", els=("Ni", "O"))},
            {"_potcar_root_seal": {"source_sha256": {"Ni": _H64("aa")}}}
            )["blocking"]),
        "⛔음성 AO Q1: 봉인에 없는 variant 가 관측되면 막는다")
    # 양성 — 봉인과 관측이 일치하면 라벨이 sealed_root_v13 로 올라간다
    # ⛔ 회신 AP #7 — 봉인 픽스처도 **실물 v2 스키마**여야 한다
    # ⛔ 회신 AR P0-5 — 봉인 schema 를 **전부** 요구한다. 반쪽 봉인은 사전 승인이 아니다.
    _SEALOK = {"source_sha256": {"Ni": _H64("aa")}, "schema": "potcar_root_seal/v2",
               "sealed_before_production": True,
               "sealed_before_production_evidence": "봉인 시 산출물 0건",
               "allowlist_sha256": _H64("ab"), "manifest_sha256": _H64("dc"),
               "bundle_zip_sha256": _H64("ed"),
               "vasp_executable": "/opt/vasp/bin/vasp_std",
               "vasp_executable_sha256": _H64("fa"),
               # 🔴 렌즈4 P0-1 — v34 SEAL 은 **토큰만** 봉인한다. 픽스처가 전문("… 24Jul23")
               #   이던 동안 `raw not in banner` 의 방향 오류가 숨었다. 실물 모양으로 둔다.
               "vasp_version_banner": "vasp.6.4.1",
               "sealed_at_utc": "2026-08-31T00:00:00Z",
               "assembled_sha256_by_job": {"p/a": _H64("1a"), "p/b": _H64("1b")}}
    # 계획 잡 — 봉인 variant 집합과 **일치**해야 한다 (미실행 잡 포함)
    _PLAN = {"p/a": {"meta": {"species_order": ["Ni"]}},
             "p/b": {"meta": {"species_order": ["Ni"]}}}
    _MBASE = {"files_sha256": {"x": "y"}, "_manifest_sha256_actual": _H64("dc"),
              "_zip_sha256_observed": _H64("ed"), "planned": _PLAN,
              "potcar_spec": {"Ni": "Ni"}}
    _sealed = potcar_identity_gates(_one, dict(_MBASE, _potcar_root_seal=_SEALOK))
    chk(str(_sealed.get("identity_scope", "")).startswith("sealed_root_v13"),
        "양성 AO Q1: 봉인 일치 + 완전성 통과면 라벨이 **sealed_root_v13** 다 "
        f"(실제 {str(_sealed.get('identity_scope'))[:40]})")
    # ⛔음성 AP #7 — 생산 전 봉인이라는 근거가 없으면 sealed 라벨을 안 준다
    _nopre = potcar_identity_gates(
        _one, dict(_MBASE, _potcar_root_seal={k: v for k, v in _SEALOK.items()
                                              if k != "sealed_before_production"}))
    chk(any("NOT_PREPRODUCTION" in g for g in _nopre["blocking"])
        and not str(_nopre.get("identity_scope", "")).startswith("sealed_root"),
        "⛔음성 AP #7: `sealed_before_production` 근거가 없으면 막고 sealed 라벨도 "
        "안 준다 (계산 뒤에 만든 봉인과 구별되지 않는다)")
    # ⛔음성 AP #7 — 봉인이 **다른 묶음**의 MANIFEST 에 대한 것이면 막는다
    _wrong = potcar_identity_gates(
        _one, dict(_MBASE, _manifest_sha256_actual=_H64("ca"),
                   _potcar_root_seal=dict(_SEALOK, manifest_sha256=_H64("da"))))
    chk(any("WRONG_BUNDLE" in g for g in _wrong["blocking"]),
        "⛔음성 AP #7: 봉인이 다른 MANIFEST 에 대한 것이면 막는다")

    # ══ 회신 AR P0-5 · 해제조건 7 — 봉인 검증의 fail-open 을 닫는다 ═══════════
    #   AR 이 재현한 것: `source_sha256` 과 `sealed_before_production:true` 만 있는
    #   **반쪽 봉인**도 `sealed_root_v13` 라벨을 받았다.
    _half = potcar_identity_gates(
        _one, dict(_MBASE, _potcar_root_seal={
            "source_sha256": {"Ni": _H64("aa")}, "sealed_before_production": True}))
    chk(any("ROOT_SEAL_INCOMPLETE_SCHEMA" in g for g in _half["blocking"])
        and not str(_half.get("identity_scope", "")).startswith("sealed_root")
        and _half["root_seal_coverage"]["ok"] is False,
        "⛔음성 AR P0-5: 반쪽 봉인(source_sha256 + 선언만)은 막고 sealed 라벨을 "
        "안 준다 — 리뷰가 재현한 fail-open 이다")
    for _mut, _code, _why in (
            ({"schema": "potcar_root_seal/v1"}, "ROOT_SEAL_SCHEMA", "schema 가 v2 가 아니다"),
            ({"manifest_sha256": "deadbeef"}, "ROOT_SEAL_BAD_HASH", "해시가 64자리가 아니다"),
            ({"bundle_zip_sha256": _H64("cb")}, "ROOT_SEAL_ZIP_MISMATCH",
             "봉인한 ZIP 이 받은 ZIP 과 다르다"),
            ({"vasp_version_banner": "vasp.5.4.4"}, "ROOT_SEAL_VASP_MISMATCH",
             "봉인 배너에 관측 버전이 없다"),
            ({"assembled_sha256_by_job": {"p/a": _H64("1a")}}, "ROOT_SEAL_JOB_COVERAGE",
             "계획 잡 하나가 봉인 밖이다")):
        chk(any(_code in g for g in potcar_identity_gates(
                _one, dict(_MBASE, _potcar_root_seal=dict(_SEALOK, **_mut)))["blocking"]),
            "⛔음성 AR P0-5: %s → %s" % (_why, _code))
    # 봉인이 **계획 잡이 요구하는 variant** 를 다 포괄하지 않으면 막는다
    chk(any("ROOT_SEAL_PLAN_COVERAGE" in g for g in potcar_identity_gates(
            _one, dict(_MBASE, planned={"p/a": {"meta": {"species_order": ["Ni", "O"]}}},
                       potcar_spec={"Ni": "Ni", "O": "O"},
                       _potcar_root_seal=_SEALOK))["blocking"]),
        "⛔음성 AR P0-5: 미실행 잡이 요구하는 variant 가 봉인 밖이면 막는다 "
        "(사전 승인은 **앞으로 돌 잡**까지 포괄해야 한다)")
    chk(any("ROOT_SEAL_PLAN_UNREADABLE" in g for g in potcar_identity_gates(
            _one, dict(_MBASE, planned={"p/a": {"meta": {}}},
                       _potcar_root_seal=_SEALOK))["blocking"]),
        "⛔음성 AR P0-5: 계획 잡에 species_order 가 없어 필요한 variant 를 못 세면 "
        "**통과가 아니라 차단**이다")
    # ══ 회신 AS 해제조건 4 — 봉인한 POTCAR 와 **실제로 쓴 POTCAR** 대조 ═══════
    #   종전엔 assembled_sha256_by_job 의 **키만** 봤다. 봉인 뒤에 POTCAR 를
    #   갈아끼워도 잡히지 않았다.
    _swap = {"p/a": _J2("aa", "6.4.1", asm=_H64("de")),      # 조립본이 바뀌었다
             "p/b": _J2("aa", "6.4.1", asm=_H64("1b"))}
    _rsw = potcar_identity_gates(_swap, dict(_MBASE, _potcar_root_seal=_SEALOK))
    chk(any("ROOT_SEAL_ASSEMBLED_MISMATCH" in g for g in _rsw["blocking"])
        and _rsw["assembled_crosscheck"]["mismatch"] == 1,
        "⛔음성 AS 4: 봉인한 조립본 해시와 **반송 값**이 다르면 막는다 "
        "(종전엔 키만 봐서 POTCAR 를 갈아끼워도 통과)")
    _noasm = {"p/a": _J2("aa", "6.4.1"), "p/b": _J2("aa", "6.4.1")}   # asm=None
    chk(any("ROOT_SEAL_ASSEMBLED_UNVERIFIED" in g for g in potcar_identity_gates(
            _noasm, dict(_MBASE, _potcar_root_seal=_SEALOK))["blocking"]),
        "⛔음성 AS 4: 반송에 조립본 해시가 없으면 **확인 못 함 = 통과 아님**")

    # ── 회신 AP #12 — release attestation 이 Methods 문구를 정한다 ────────
    # ⛔ 회신 AR P0-6 — attestation 도 **전 필드 + 3자 집합 일치 + 교차 결박**이다
    _ATT = {"schema": "potcar_attestation/v1", "made_before_production": True,
            "made_before_production_evidence": "생성 시 산출물 0건",
            "release_label": "potpaw_PBE.54", "site": "테스트",
            "created_utc": "2026-08-31T00:00:00Z",
            "manifest_sha256": _H64("dc"), "allowlist_sha256": _H64("ab"),
            "bundle_zip_sha256": _H64("ed"),
            "vasp_version_raw": "vasp.6.4.1",
            "vasp_executable": "/opt/vasp/bin/vasp_std",
            "vasp_executable_sha256": _H64("fa"),
            "variants": {"Ni": {"element": "Ni", "source_sha256": _H64("aa"),
                                "titel": "TITEL  = PAW_PBE Ni 01Jan2000",
                                "embedded_hash": "SHA256 = abc"}}}
    _MB2 = dict(_MBASE, _potcar_root_seal=_SEALOK)
    _ra = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=_ATT))
    # ⛔ 회신 BA P0-3 — **외부 앵커(potcar_pin)가 있어야** attested 로 올린다.
    # ⛔ 회신 BB P0-6 · Q4 — 앵커는 **{label + 전체 source SHA map}** 을 함께
    #   결박해야 한다. 바이트만 있는 pin 은 이름을 인증하지 못한다.
    _PINOK = {"source_sha256": {k: v.get("source_sha256")
                                for k, v in (_ATT.get("variants") or {}).items()},
              "release_label": _ATT.get("release_label")}
    _ra_anch = potcar_identity_gates(
        _one, dict(_MB2, _potcar_attestation=_ATT, potcar_pin=_PINOK))
    chk(_ra_anch["attestation"]["usable"] and "PAW-PBE datasets from the" in
        _ra_anch["methods_candidate"],
        "양성 AP #12 + BA P0-3: attestation **과 외부 앵커**가 둘 다 있어야 release 를 "
        "적는 Methods 문구가 나온다")
    _rn = potcar_identity_gates(_one, _MB2)
    chk(not _rn["attestation"]["present"]
        and "단정하지 않는다" in _rn["methods_candidate"]
        and "원고 Methods 로는 약하다" in str(_rn.get("methods_candidate_⛔")),
        "⛔음성 AP #12: attestation 이 없으면 release 를 **단정하지 않고**, "
        "그 문구가 원고엔 약하다고 명시한다 (AP Q3)")
    chk(any("ATTESTATION_WRONG_BUNDLE" in g for g in potcar_identity_gates(
            _one, dict(_MB2, _potcar_attestation=dict(_ATT,
                                                      manifest_sha256=_H64("fe"))))
            ["blocking"]),
        "⛔음성 AP #12: 다른 묶음의 attestation 이면 막는다")
    chk(any("ATTESTATION_SEAL_MISMATCH" in g for g in potcar_identity_gates(
            _one, dict(_MB2, _potcar_attestation=dict(
                _ATT, variants={"Ni": {"source_sha256": _H64("bb")}})))["blocking"]),
        "⛔음성 AP #12: attestation 과 root seal 의 원본 sha 가 다르면 막는다")
    chk(any("ATTESTATION_NOT_PREPRODUCTION" in g for g in potcar_identity_gates(
            _one, dict(_MB2, _potcar_attestation=dict(
                _ATT, made_before_production=False)))["blocking"]),
        "⛔음성 AP #12: 계산 전에 만든 근거가 없는 attestation 은 막는다")

    # ══ 회신 AR P0-6 · 해제조건 7 — attestation fail-open 을 닫는다 ══════════
    #   AR 이 재현한 것: `FAKE_RELEASE` 와 **실제 사용 집합에 없는** `UNRELATED`
    #   variant 하나만 준 합성 attestation 이 usable:true 가 되고 강한 Methods
    #   문장을 냈다. 이제 세 집합의 완전일치를 요구한다:
    #     attestation variants = root-seal source variants = 계획 잡 POTCAR variants
    _fake = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=dict(
        _ATT, release_label="FAKE_RELEASE",
        variants={"UNRELATED": {"element": "Xx", "source_sha256": _H64("ce"),
                                "titel": "TITEL  = PAW_PBE Xx", "embedded_hash": "h"}})))
    chk(_fake["attestation"]["usable"] is False
        and any("ATTESTATION_SET_MISMATCH" in g for g in _fake["blocking"])
        and any("ATTESTATION_PLAN_MISMATCH" in g for g in _fake["blocking"])
        and "단정하지 않는다" in _fake["methods_candidate"],
        "⛔음성 AR P0-6: FAKE_RELEASE + 쓰지도 않는 UNRELATED variant 는 "
        "usable 이 아니고 강한 Methods 문구도 안 나온다 — 리뷰가 재현한 fail-open")
    for _mut, _code, _why in (
            ({"bundle_zip_sha256": _H64("cb")}, "ATTESTATION_ZIP_MISMATCH",
             "받은 ZIP 과 다른 ZIP 을 말한다"),
            ({"allowlist_sha256": _H64("ba")}, "ATTESTATION_ALLOWLIST_MISMATCH",
             "봉인과 다른 allowlist"),
            ({"vasp_executable_sha256": _H64("bd")}, "ATTESTATION_VASP_MISMATCH",
             "봉인과 다른 VASP 바이너리"),
            ({"vasp_version_raw": "vasp.5.4.4"}, "ATTESTATION_VASP_VERSION_MISMATCH",
             "봉인 배너와 다른 버전"),
            ({"made_before_production_evidence": ""},
             "ATTESTATION_PREPRODUCTION_UNEVIDENCED", "생산 전 근거가 선언뿐이다"),
            ({"site": None}, "ATTESTATION_INCOMPLETE", "site 가 없다"),
            ({"created_utc": None}, "ATTESTATION_INCOMPLETE", "created_utc 가 없다"),
            ({"variants": {"Ni": {"element": "Ni", "source_sha256": _H64("aa")}}},
             "ATTESTATION_VARIANT_FIELDS", "variant 에 titel/embedded_hash 가 없다")):
        _rr = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=dict(_ATT, **_mut)))
        chk(any(_code in g for g in _rr["blocking"]) and not _rr["attestation"]["usable"],
            "⛔음성 AR P0-6: %s → %s" % (_why, _code))
    # 🔴🔴 렌즈4 P0-1 (2026-09-03) 회귀 — MAKE 가 적는 raw 가 **여러 줄 배너**(실물 VASP
    #   stdout)여도, 봉인이 **토큰만** 담아도, 토큰이 같으면 불일치가 아니다. v34 까지는
    #   이 조합이 항상 MISMATCH 였고(1단계 111 h 뒤 발견), 픽스처는 반대 방향이라 못 잡았다.
    _RAW_ML = (" running on    1 total cores\n distrk:  each k-point on    1 cores\n"
               " distr:  one band on    1 cores\n using from now: INCAR\n"
               " vasp.6.4.1 24Jul23 (build Aug 01 2023) complex")
    _ml = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=dict(
        _ATT, vasp_version_raw=_RAW_ML), potcar_pin=_PINOK))
    chk(not any("ATTESTATION_VASP_VERSION" in g for g in _ml["blocking"])
        and _ml["attestation"]["usable"],
        "양성 렌즈4 P0-1: 여러 줄 raw vs 토큰 봉인 — 토큰이 같으면 불일치가 아니다 "
        "(v34 는 여기서 항상 MISMATCH 였다)")
    _v33 = potcar_identity_gates(_one, dict(
        _MB2, _potcar_root_seal=dict(_SEALOK, vasp_version_banner=
                                     "vasp.6.4.1 24Jul23 (build x) complex"),
        _potcar_attestation=_ATT, potcar_pin=_PINOK))
    chk(not any("ATTESTATION_VASP_VERSION" in g for g in _v33["blocking"]),
        "양성 렌즈4 P0-1: v33 식 전문 봉인 vs 토큰 raw 도 여전히 일치다 (하위 호환)")
    _unr = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=dict(
        _ATT, vasp_version_raw="실행 실패: FileNotFoundError")))
    chk(any("ATTESTATION_VASP_VERSION_UNREADABLE" in g for g in _unr["blocking"])
        and not _unr["attestation"]["usable"],
        "⛔음성 렌즈4 P0-1: raw 에 버전 토큰이 없으면 '확인 못 함' 으로 막는다")
    # 🔴 회신 AT P0-4 음성 — 스키마·불리언·시각·root seal 결박
    for _mut, _code, _why in (
            ({"schema": None}, "ATTESTATION_INCOMPLETE", "schema 필드가 없다"),
            ({"schema": "totally_made_up/v9"}, "ATTESTATION_SCHEMA_UNKNOWN",
             "위조 schema 값"),
            ({"made_before_production": "true"}, "ATTESTATION_NOT_PREPRODUCTION",
             "**문자열** 'true' — 파이썬에서 참이지만 증서가 아니다"),
            ({"made_before_production": 1}, "ATTESTATION_NOT_PREPRODUCTION",
             "정수 1 — 역시 참이지만 불리언이 아니다"),
            ({"created_utc": "어제쯤"}, "ATTESTATION_TIME_MALFORMED",
             "시각이 ISO Z 형식이 아니다")):
        _rr = potcar_identity_gates(_one, dict(_MB2, _potcar_attestation=dict(_ATT, **_mut)))
        chk(any(_code in g for g in _rr["blocking"]) and not _rr["attestation"]["usable"],
            "⛔음성 AT P0-4: %s → %s" % (_why, _code))
    # root seal 이 **없으면** attestation 만으로 release 를 주장하지 않는다
    _nos = potcar_identity_gates(
        _one, {k: v for k, v in dict(_MB2, _potcar_attestation=_ATT).items()
               if k != "_potcar_root_seal"})
    chk(any("ATTESTATION_WITHOUT_ROOT_SEAL" in g for g in _nos["blocking"])
        and not _nos["attestation"]["usable"],
        "⛔음성 AT P0-4: **root seal 이 없으면** 임의 release label 의 attestation 이 "
        "usable 로 가지 않는다 (종전엔 집합 대조가 통째로 건너뛰어졌다)")

    # ZIP 관측이 아예 없으면 "결박 확인 못 함" 이고 그것은 통과가 아니다
    _nz = potcar_identity_gates(_one, dict(_MB2, _zip_sha256_observed=None,
                                           _potcar_attestation=_ATT))
    chk(any("ATTESTATION_ZIP_UNBOUND" in g for g in _nz["blocking"])
        and not _nz["attestation"]["usable"],
        "⛔음성 AR P0-6: 받은 ZIP 의 SHA 를 모르면 **확인 못 함 = 통과 아님**")
    # 관측 TITEL 과 attestation 의 TITEL 이 다르면 막는다
    _jt = {"a": dict(_J2("aa", "6.4.1"),
                     static={"vasp_version": "6.4.1", "normal_end": True, "E0": -1.0,
                             "titels": ["PAW_PBE Ni 09Sep1999"]})}
    chk(any("ATTESTATION_TITEL_MISMATCH" in g for g in potcar_identity_gates(
            _jt, dict(_MB2, _potcar_attestation=_ATT))["blocking"]),
        "⛔음성 AR P0-6: 관측 TITEL 에 없는 TITEL 을 attestation 이 주장하면 막는다")
    # 양성 — allowed_claim 이 두 상태를 구분한다 (필드명 AR Q5)
    chk(_ra_anch.get("allowed_claim") == "paw_release_attested"
        and _rn.get("allowed_claim") == "bundle_conditional_only"
        and "후보 문구" in str(_ra_anch.get("methods_candidate_⚠")),
        "회신 AR Q5: 필드명이 methods_candidate/allowed_claim 이고 **후보**임을 "
        "명시한다 (도구가 원고를 채택하지 않는다)")
    # ⛔⛔ 회신 BA P0-3 재현 — 자기선언 label 은 독립 증거가 아니다
    chk(_ra.get("allowed_claim") == "self_declared_label_only"
        and _ra.get("release_label_anchor") is None
        and "자기선언" in str(_ra.get("release_label_⛔")),
        "⛔음성 BA P0-3: attestation 이 통과해도 **외부 앵커가 없으면** "
        "`paw_release_attested` 로 올리지 않는다 (실제 %r)" % _ra.get("allowed_claim"))
    _ra_fake = potcar_identity_gates(
        _one, dict(_MB2, _potcar_attestation=dict(_ATT, release_label="FAKE_RELEASE"),
                   potcar_pin=_PINOK))
    # ⛔⛔ 회신 BB P0-6 (2026-09-02) — 이 시험은 종전에 **구멍을 기록**하고 있었다:
    #   "앵커가 있어도 label 문자열은 검증하지 못한다" 를 통과 조건으로 박아 뒀다.
    #   BB P0-6 · Q4 가 그 구멍을 닫으라고 했다 — 바이트 앵커는 이름을 인증하지
    #   않으므로, pin 이 label 을 함께 결박하지 않으면 이름을 주장하지 않는다.
    #   ⇒ 시험을 **뒤집는다**: 같은 `FAKE_RELEASE` 재현이 이제 차단돼야 한다.
    chk(_ra_fake.get("allowed_claim") == "self_declared_label_only"
        and "FAKE_RELEASE" not in str(_ra_fake.get("methods_candidate"))
        and _ra_fake.get("site_reported_release_label") == "FAKE_RELEASE"
        and _ra_fake["release_label_anchor_detail"]["label_matches_site_report"]
        is False,
        "⛔음성 BB P0-6 (BA 때 열려 있던 구멍): 현장이 label 을 `FAKE_RELEASE` 로 "
        "바꾸면 pin 의 label 과 어긋나 **이름을 주장하지 않는다**. 이름은 "
        "`site_reported_release_label` 메타데이터로만 남는다 (실제 %r)"
        % _ra_fake.get("allowed_claim"))
    # SHA map 이 variant 를 다 안 덮으면 그것도 앵커가 아니다
    _ra_part = potcar_identity_gates(
        _one, dict(_MB2, _potcar_attestation=_ATT,
                   # ⚠ 픽스처의 variant 는 하나뿐이라 "첫 항목만 남기기" 로는
                   #   uncovered 가 안 생긴다 — **다른 variant** 를 담은 pin 을 준다
                   #   (실측: 빈 목록으로 시험이 공허하게 참이 됐다).
                   potcar_pin=dict(_PINOK,
                                   source_sha256={"Zz_other": _H64("zz")})))
    chk(_ra_part.get("allowed_claim") == "self_declared_label_only"
        and _ra_part["release_label_anchor_detail"]["uncovered_variants"],
        "⛔음성 BB P0-6: pin 의 SHA map 이 attestation variant 를 **전부** 덮지 "
        "않으면 앵커가 아니다 — 덮이지 않은 variant 를 이름으로 말한다 (%s)"
        % _ra_part["release_label_anchor_detail"]["uncovered_variants"][:3])
    chk("바이트 pin 만으로는" in str(
        _ra_anch["release_label_anchor_detail"].get("⛔")),
        "BB P0-6: 앵커 판정의 **근거를 산출물에 적는다** (무엇을 봤고 무엇을 못 "
        "보는가)")

    # ⛔음성 AP #7 — blocking 이 있으면 **절대** sealed 라벨이 안 나온다
    _mm = potcar_identity_gates(
        _one, dict(_MBASE, _potcar_root_seal=dict(_SEALOK,
                                                  source_sha256={"Ni": _H64("bb")})))
    chk(any("ROOT_SEAL_MISMATCH" in g for g in _mm["blocking"])
        and not str(_mm.get("identity_scope", "")).startswith("sealed_root"),
        "⛔음성 AP #7: ROOT_SEAL_MISMATCH 와 sealed 라벨이 **동시에** 나오지 않는다 "
        f"(실제 {str(_mm.get('identity_scope'))[:24]})")
    # ⛔음성 — 완전성이 깨지면 라벨이 'unverified' 로 내려간다 (있는 척하지 않는다)
    _unv = potcar_identity_gates(_short, {"files_sha256": {"x": "y"}})
    chk(str(_unv.get("identity_scope", "")).startswith("unverified"),
        "⛔음성 AO P0-8: 원본 fingerprint 가 불완전하면 라벨이 **unverified** 다 "
        "('신원 일치 확인' 이라고 쓰지 않는다)")
    chk(potcar_identity_gates(_one, {})["ok"], "양성: 전 잡이 같은 원본·같은 VASP")
    chk(any("SOURCE_SPLIT" in g for g in
            potcar_identity_gates({"a": _J2("aa", "6.4.1"), "b": _J2("bb", "6.4.1")},
                                  {})["blocking"]),
        "⛔음성 AI: 잡마다 PAW 원본이 다르면 막는다 (잡 하나씩은 다 자기일관적이다)")
    chk(any("VASP_VERSION_SPLIT" in g for g in
            potcar_identity_gates({"a": _J2("aa", "6.4.1"), "b": _J2("aa", "5.4.4")},
                                  {})["blocking"]),
        "⛔음성 AI: VASP 세대가 갈리면 막는다")
    chk(any("PIN_MISMATCH" in g for g in potcar_identity_gates(
            _one, {"potcar_pin": {"source_sha256": {"Ni": "zz"}}})["blocking"]),
        "⛔음성 AI: 사전 고정값과 다르면 막는다 (외부 기준 대조)")

    # ⛔ 회신 AJ — pin 대조의 fail-open 세 갈래를 막았는지
    _MB = {"files_sha256": {"x": "y"}, "potcar_spec": {"Ni": "Ni_pv"}}
    _r_np = potcar_identity_gates(_one, _MB)
    chk(not any("PIN_ABSENT" in g for g in _r_np["blocking"])
        and _r_np.get("pin_absent") is True
        and "self_consistent_only" in str(_r_np.get("identity_scope")),
        "배포 번들에 pin 이 없으면 **차단이 아니라 라벨**이다 (2026-08-31) — "
        "D 는 번들 안에서 닫힌 양이고, 우리는 '승인 트리를 썼다' 를 주장하지 않는다")
    chk("사전 승인된 트리와 대조하지 않았다" in str(_r_np.get("identity_scope")),
        "⛔음성: 그 라벨이 **무엇을 확인 못 했는지** 명시한다 (없는 검증을 있는 척하지 않는다)")
    chk(any("SOURCE_UNOBSERVED" in g for g in potcar_identity_gates(
            {"a": {"static": {"vasp_version": "6.4.1"}}},
            {**_MB, "potcar_pin": {"source_sha256": {"Ni_pv": "aa"},
                                   "vasp_version": "6.4.1"}})["blocking"]),
        "⛔음성 AJ: pin 은 있는데 회신에 원본 sha 가 **하나도 없으면** 막는다 "
        "(빈 관측을 통과로 읽지 않는다)")
    chk(any("VASP_VERSION_UNOBSERVED" in g for g in potcar_identity_gates(
            {"a": {"_prov": {"source_sha256": {"Ni_pv": "aa"}}, "static": {}}},
            {**_MB, "potcar_pin": {"source_sha256": {"Ni_pv": "aa"},
                                   "vasp_version": "6.4.1"}})["blocking"]),
        "⛔음성 AJ: VASP 버전이 하나도 안 읽히면 막는다")
    # variant 키 정규화 — 조립기는 Ni_pv 로 쓰고 pin 예시는 Ni 였다
    _norm = potcar_identity_gates(
        {"a": {"_prov": {"source_sha256": {"Ni_pv": _H64("aa")}},
               "meta": {"species_order": ["Ni"]},
               "static": {"vasp_version": "6.4.1"}}},
        {**_MB, "potcar_pin": {"source_sha256": {"Ni": _H64("aa")},
                               "vasp_version": "6.4.1"}})
    chk(_norm["ok"] and _norm["pin_normalized_variants"] == ["Ni_pv"],
        "⛔음성 AJ: 원소 키 pin(Ni)을 potcar_spec 으로 **variant(Ni_pv)로 정규화**해 "
        "대조한다 (종전엔 관측 없음으로 처리돼 조용히 우회됐다)")
    chk("⚠" in potcar_identity_gates(_one, {}),
        "[음성] 사전 고정이 없으면 '잡 사이 일치만 봤다' 를 결과에 적는다")
    # ⛔ 음성 C5-a — 홀드아웃이 더 낮으면 **SELECTOR_FAIL**, 값을 안 만든다
    _A5b = dict(_A5, sdcp_neutral=([-1.20, -1.10, -1.05, -1.00],
                                   [-1.40] + [-0.9] * 7))   # 홀드아웃이 200 meV 더 낮다
    _jb5b, _en5b = _mk12(_A5b)
    _c5b = closure_C5(_man5, _jb5b, lambda j: _en5b.get(j), _em5, _F5, _MG)
    chk("ddE_obs_eV" not in _c5b
        and "SELECTOR_FAIL" in _c5b["by_frag"]["sdcp_neutral"]["verdict"],
        "⛔음성 C5: 홀드아웃이 calibration 최저를 30 meV 이상 밑돌면 **값을 안 만든다** "
        "— '더 낮은 자세를 찾았다' 로 흡수하면 선택기 실패가 사라진다")
    # ⛔ 음성 C5-b — 자세가 하나라도 빠지면 unresolved
    _jb5c = dict(_jb5); _jb5c.pop("prospective/sdcp_neutral__b11__" + SEED_MAIN)
    chk(closure_C5(_man5, _jb5c, _E5, _em5, _F5, _MG)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C5: 12자세 중 하나라도 빠지면 unresolved (표본이 줄면 min 이 올라간다)")
    # ⛔ 음성 C5-c — 홀드아웃 역할이 아예 없으면(= calibration 전용 tranche) 값 없음
    _jb5d = {k: (dict(v, meta=dict(v["meta"], role="calibration"))
                 if k.startswith("prospective/") else v) for k, v in _jb5.items()}
    _c5d = closure_C5(_man5, _jb5d, _E5, _em5, _F5, _MG)
    chk("ddE_obs_eV" not in _c5d,
        "⛔음성 C5: 홀드아웃이 없으면 값을 만들지 않는다 — 그 시험이 이 양의 **전제**다")
    # ⛔ 음성 C5-d — basin 이 갈리면 unresolved
    _kx5 = "prospective/ptfe_c10__b03__" + SEED_MAIN
    _jb5e = dict(_jb5)
    _jb5e[_kx5] = dict(_jb5[_kx5], geom={"magnetic": {"realized_basin_id": "Z"}})
    chk(closure_C5(_man5, _jb5e, _E5, _em5, _F5, _MG)["by_frag"]["ptfe_c10"]["verdict"]
        == "unresolved",
        "⛔음성 C5: 12자세가 서로 다른 basin 이면 unresolved")

    _c3 = closure_C3(_man3, _jb3, _E3, _F3)
    # ── 🔴 회신 AV P0-3 — slab 소거의 **대수적 확인**: 슬랩을 빼고 계산한 D 가
    #   슬랩을 넣고 계산한 D 와 정확히 같아야 한다 (같은 픽스처, 잡만 제거)
    _c3_ns = closure_C3(_man3, {k: v for k, v in _jb3.items()
                                if "clean_slab" not in k}, _E3, _F3)
    chk(_c3_ns.get("D_eV") is not None
        and abs(_c3_ns["D_eV"] - _c3["D_eV"]) < 1e-9
        and "n/a" in str(_c3_ns.get("clean_slab")),
        "AV P0-3: clean slab 0개 번들에서 C3 가 **그대로 판정한다** — slab Edisp 는 "
        "D 에서 소거된다 (D %s = %s)" % (_c3_ns.get("D_eV"), _c3.get("D_eV")))
    _c3_vc = closure_C3(_man3, _jb_vc, _E3, _F3)
    chk(_c3_vc["by_frag"]["sdcp_neutral"].get("n") == 4
        and abs(_c3_vc["D_eV"] - _c3["D_eV"]) < 1e-9,
        "⛔음성 AV P0-3: 오염된 Edisp(-99)를 단 vacconv 잡이 섞여도 C3 의 D 가 "
        "안 움직인다 (자세로 세지 않는다)")
    chk(abs(_c3["D_eV"] - (-0.7)) < 1e-6,
        "C3: D = mean(δ_SDCP) − mean(δ_c10) = −0.7 (실제 %s)" % _c3.get("D_eV"))
    # ★★ 부호 규약 (회신 AB P0-3). 봉인된 0.90 eV 는 **(UMA − DFT)** 규약이고
    #   D3 는 additive 라 offset ≈ −δ 다 ⇒ 예측 오프셋 차등 = −D.
    #   ⚠ 2026-08-30 이전 이 두 시험은 **틀린 규약을 그대로 인코딩**하고 있었다 —
    #     코드와 시험이 서로 동의하면서 둘 다 틀렸다. 정확히 설명적인 D=−0.7 을
    #     "반대 부호" 로 기각했다. 그래서 여기 규약을 글로 박아 둔다.
    chk(abs(_c3["predicted_offset_gap_eV"] - 0.7) < 1e-6,
        "C3: 예측 오프셋 차등 = −D = +0.7 (offset 규약, 실제 %s)"
        % _c3.get("predicted_offset_gap_eV"))
    chk(_c3["ratio"] > 0 and _c3["ratio"] >= C3_HI and "수치상" in _c3["verdict"],
        "C3 양성: −D 가 +0.90 과 같은 부호이고 비율 %s ≥ 0.70 → '수치상 설명'"
        % _c3.get("ratio"))
    _en3p, _jb3p = dict(_en3), dict(_jb3)
    for _i in range(4):
        for _f, _d in (("sdcp_neutral", 2.0), ("ptfe_c10", 1.0)):
            _k = "prospective/%s__b%02d__%s" % (_f, _i, SEED_MAIN)
            _en3p[_k + "__d3off"] = _en3p[_k] - _d      # d_cx = E_on − E_off = +_d
            # 항등식이 성립하도록 Edisp 도 같이 뒤집는다 — 안 그러면 교차검증에 걸린다
            _jb3p[_k] = dict(_jb3[_k],
                             static=dict(_jb3[_k]["static"], edisp_eV=_d))
    _c3b = closure_C3(_man3, _jb3p, lambda j: _en3p.get(j), _F3)
    chk(_c3b["D_eV"] > 0 and "미해결" in _c3b["verdict"] and "부호" in _c3b["verdict"],
        "⛔음성 C3: D 가 양수면 예측 오프셋 차등(−D)이 관측 +0.90 과 **반대 부호** → "
        "미해결 (절댓값이면 %s 로 '설명' 오판했다)" % abs(_c3b.get("ratio", 0)))
    # ⛔ 음성 C3-e — **평균이 맞아도 조각내 일관성이 깨지면 미해결.**
    #   D3 는 기하 의존 항이라 자세마다 달라야 하는데 관측 오프셋은 조각 안에서
    #   상수(SDCP 6 meV)였다. δ 가 그보다 훨씬 흔들리면 D3 귀속이 성립 안 한다.
    _jb_w = dict(_jb3)
    for _i, _d in enumerate((-2.0, -2.3, -1.7, -2.0)):
        _kw = "prospective/sdcp_neutral__b%02d__%s" % (_i, SEED_MAIN)
        _jb_w[_kw] = dict(_jb3[_kw],
                          static=dict(_jb3[_kw]["static"], edisp_eV=_d))
        # 이 픽스처는 **조각내 range** 를 시험한다. 쌍둥이를 남겨 두면 항등식
        # 교차검증이 먼저 걸려서(그 자체는 정상 동작) 시험하려던 경로에 못 간다.
        _jb_w.pop(_kw + "__d3off", None)
    _c3w = closure_C3(_man3, _jb_w, _E3, _F3)
    chk("조각내 일관성" in _c3w["verdict"]
        and _c3w["within_fragment"]["sdcp_neutral"]["ok"] is False,
        "⛔음성 C3: δ 의 조각내 range 0.6 eV 가 관측 오프셋 상수성(6 meV)의 5배를 "
        "넘으면 **평균이 맞아도** 미해결 (%s)" % _c3w["verdict"][:40])
    chk(_c3["within_fragment"]["sdcp_neutral"]["ok"] is True,
        "양성 대조: δ 가 조각내 상수면 일관성 통과 (range %s)"
        % _c3["within_fragment"]["sdcp_neutral"]["delta_range_eV"])
    _kx = "prospective/sdcp_neutral__b00__%s__d3off" % SEED_MAIN
    _jb_x = dict(_jb3)
    _jb_x[_kx] = dict(_jb3[_kx], geom={"magnetic": {"realized_basin_id": "Z"}})
    chk(closure_C3(_man3, _jb_x, _E3, _F3)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C3: on/off 가 다른 realized basin 이면 unresolved "
        "(그 차이는 D3 기여가 아니다)")
    # ⛔ 음성 C3-c — **Edisp 가 없으면 unresolved.** IVDW 가 실제로 안 걸린 잡을
    #   "D3 기여 0" 으로 조용히 읽으면 D 가 통째로 틀린다.
    _kn = "prospective/sdcp_neutral__b02__" + SEED_MAIN
    _jb_n = dict(_jb3)
    _jb_n[_kn] = dict(_jb3[_kn], static=dict(_jb3[_kn]["static"], edisp_eV=None))
    _r_n = closure_C3(_man3, _jb_n, _E3, _F3)["by_frag"]["sdcp_neutral"]
    chk(_r_n["verdict"] == "unresolved" and any("Edisp" in str(x) for x in
                                                (_r_n.get("missing") or [])),
        "⛔음성 C3: OUTCAR 에 Edisp 가 없으면 unresolved (0 으로 읽지 않는다)")
    # ⛔ 음성 C3-d — **항등식이 깨지면 unresolved.** 쌍둥이가 남아 있는데
    #   (E_on−E_off) 와 Edisp 가 다르면 IVDW 말고 다른 축이 갈린 것이다.
    _jb_i = dict(_jb3)
    _jb_i[_kn] = dict(_jb3[_kn],
                      static=dict(_jb3[_kn]["static"], edisp_eV=-2.5))  # 참값은 -2.0
    _r_i = closure_C3(_man3, _jb_i, _E3, _F3)["by_frag"]["sdcp_neutral"]
    chk(_r_i["verdict"] == "unresolved" and any("항등식" in str(x) for x in
                                                (_r_i.get("missing") or [])),
        "⛔음성 C3: (E_on−E_off) ≠ Edisp 면 unresolved — 쌍둥이가 IVDW 밖에서 갈렸다")

    # guard band
    D = 0.030
    chk(apply_k_guard("ROBUST", 0.005, "K_DIRECTLY_CHECKED", D).startswith("UNRESOLVED_SIGN"),
        "|ΔE| 5 meV → 부호 미정 (직접 dense 여도)")
    chk(apply_k_guard("ROBUST", 0.025, "K_TRANSFER_SCREENED", D)
        .startswith("UNRESOLVED_K_GUARD"),
        "25 meV + 전이심사 → **판정 보류** (옛 판은 그대로 통과시켰다)")
    chk(apply_k_guard("ROBUST", 0.025, "K_DIRECTLY_CHECKED", D) == "ROBUST",
        "25 meV + 직접 dense → 판정 유지 (직접 쟀으면 띠가 적용되지 않는다)")
    # ★ K_UNVERIFIED 는 **크기와 무관하게** 막는다 (Codex zip 감사) — 전이 게이트가
    #   실패했으면 k 오차에 유한한 경계가 없다. 크니까 괜찮다는 논리는 성립 안 한다.
    chk(apply_k_guard("ROBUST", 0.080, "K_UNVERIFIED", D).startswith("UNRESOLVED_K"),
        "80 meV 라도 K_UNVERIFIED 면 막는다 (경계 없는 값에 판정을 붙이지 않는다)")
    chk(apply_k_guard("ROBUST", 0.015, "K_UNVERIFIED", D).startswith("UNRESOLVED_K"),
        "15 meV 도 마찬가지")
    # ★ 대조: 전이 심사를 **통과한** 라벨은 띠 밖이면 판정이 유지돼야 한다
    chk(apply_k_guard("ROBUST", 0.080, "K_TRANSFER_SCREENED", D) == "ROBUST",
        "80 meV + 전이 통과 → 판정 유지 (막는 건 UNVERIFIED 뿐)")
    chk(apply_k_guard("ROBUST", 0.015, "K_TRANSFER_SCREENED", D) == "ROBUST",
        "15 meV + 전이 통과 → 바닥 아래 결론 유지")
    chk(apply_k_guard("X", -0.025, "K_TRANSFER_SCREENED", D)
        .startswith("UNRESOLVED_K_GUARD"), "음수 ΔE 도 절대값으로 본다")

    # ── e2e: OUTCAR **파일** → read_outcar → phase_gates (codex E-2차 필수4) ──
    #   1차 리뷰가 지적한 그대로 — 광고한 e2e 가 배포본 selftest 에 없으면
    #   "자체검증된다" 는 README 주장이 거짓이 된다. 배포본 자신이 돈다.
    import tempfile
    _BODY = (" vasp.5.4.4.18Apr17-6-g9f103f2a35 (build test) complex\n"
             "|      So try LREAL= Auto  in the INCAR   file.        |\n"
             "   ENCUT  =  520.0 eV  38.22 Ry\n"
             "   LREAL  =      T    real-space projection\n"
             "   NUPDOWN=      4.0000    fix difference up-down\n"
             "   LMAXMIX     =    4 max onsite mixed and CHGCAR\n"
             " LDA+U is selected, type is set to LDAUTYPE =  2\n"
             "   U (eV)           for each species LDAUU =   0.0  6.2  0.0\n"
             "  energy(sigma->0) =     -100.000000\n"
             " General timing and accounting\n")
    _EXP = {"ENCUT": "520", "LREAL": "Auto", "NUPDOWN": "4", "LDAUTYPE": "2",
            "LDAUU": "0.0 6.2 0.0", "LDAU": ".TRUE.", "LMAXMIX": "4"}

    def _e2e(body, want=None, gz_trunc=False, both=False):
        with tempfile.TemporaryDirectory() as _d:
            _o = os.path.join(_d, "OUTCAR")
            if gz_trunc:
                full = gzip.compress(body)
                open(_o + ".gz", "wb").write(full[:len(full) // 2])
            elif both:
                open(_o, "wb").write(body)
                open(_o + ".gz", "wb").write(gzip.compress(body))
            else:
                open(_o, "wb").write(body)
            _oc = read_outcar(_o)
            return _oc, phase_gates(_oc, "static",
                                    {"incar_expected": {"static": want or _EXP}}, {})
    _oc, _g = _e2e(_BODY.encode())
    chk(not any("INCAR" in x for x in _g), f"e2e 정상: INCAR 게이트 0건 ({_g})")
    _au = _oc["incar_audit"]
    chk("LDAUU" in _au["verified_exact"] and "NUPDOWN" in _au["verified_exact"]
        and "LMAXMIX" in _au["verified_exact"] and "LDAU" in _au["verified_exact"],
        f"e2e: 목록·NUPDOWN·LDAU·LMAXMIX 가 exact ({_au['verified_exact']})")
    chk("LREAL" in _au["verified_equivalence_class"], "e2e: LREAL 은 등가류")
    chk(any(x.startswith("MAGMOM") for x in _au["unverified"]),
        "e2e: MAGMOM 명시적 unverified")
    _oc, _g = _e2e(_BODY.encode(), want=dict(_EXP, LDAUU="0.0 5.0 0.0"))
    chk(any("INCAR_MISMATCH(static.LDAUU" in x for x in _g),
        "⛔e2e음성: LDAUU 실제 차이(6.2vs5.0)가 전 경로에서 잡힌다")
    _oc, _g = _e2e(_BODY.encode(), want=dict(_EXP, NUPDOWN="-1"))
    chk(any("INCAR_MISMATCH(static.NUPDOWN" in x for x in _g),
        "⛔e2e음성: release 상에 NUPDOWN=4 잔류 → 하드게이트 (기대 -1)")
    _oc, _g = _e2e(_BODY.encode().replace(b"ENCUT", b"ENC\xffUT"))
    chk(any("OUTCAR_READ_ERROR" in x for x in _g), "⛔e2e음성: 깨진 바이트 → 판독 실패")
    _oc, _g = _e2e(_BODY.encode(), gz_trunc=True)
    chk(any("OUTCAR_READ_ERROR" in x and "gzip" in x for x in _g),
        "⛔e2e음성: 잘린 gzip → 게이트 (예외 아님)")
    _oc, _g = _e2e(_BODY.encode(), both=True)
    chk(any("둘 다" in x for x in _g), "⛔e2e음성: plain/.gz 공존 → 정본 판정 불가")
    _two = (_BODY.replace("-100.000000", "-1.000000")
            + _BODY.replace("-100.000000", "-2.000000")).encode()
    _oc, _g = _e2e(_two)
    chk(any("MULTI_RUN_OUTCAR" in x for x in _g) and _oc["E0"] == -2.0,
        f"⛔e2e음성: 2실행 이어붙음 → MULTI_RUN + 마지막 완결만 (E0={_oc['E0']})")

    # ── check_pin 스위트 (배포본 상주 — E-5차: 번들에만 있던 검사를 이사) ────
    def _pin_job(dirp, flip_one=False, nup_echo="4.0000", ldauu_echo="0.0 6.2 0.0",
                 double_run=False, kmesh=True, incar_tamper=False):
        jd = pathlib.Path(dirp); (jd / "static_pin").mkdir(parents=True)
        sign = {"0": 1.0, "1": -1.0, "2": 1.0, "3": 1.0}
        _meta = {"ni_sign_poscar_idx": sign, "counts": [4], "species_order": ["Ni"],
                 "potcar_spec": {"Ni": "Ni_pv"},
                 "incar_expected": {"static_pin": {"NUPDOWN": "4",
                                                   "LDAUU": "0.0 6.2 0.0"}}}
        if kmesh:
            _meta["kmesh"] = {"static_pin": "1 1 1"}
        (jd / "job.json").write_text(json.dumps(_meta), encoding="utf-8")
        (jd / "static_pin" / "INCAR").write_text("NUPDOWN = 4\n", encoding="utf-8")
        _isha = hashlib.sha256((jd / "static_pin" / "INCAR").read_bytes()).hexdigest()
        (jd / "MANIFEST_RESCUE.json").write_text(json.dumps(
            {"sha256": {"static_pin/INCAR": _isha}}), encoding="utf-8")
        if incar_tamper:
            (jd / "static_pin" / "INCAR").write_text("NUPDOWN = 4\nENCUT = 400\n", encoding="utf-8")
        mom = [1.2, -1.2, 1.2, 1.2]
        if flip_one:
            mom[1] = 1.2
        rows = "\n".join(f"{i + 1:5d}   0 0 {m:7.3f} {m:7.3f}"
                          for i, m in enumerate(mom))
        body = (" vasp.5.4.4 test\n TITEL  = PAW_PBE Ni_pv 01Jan2000\n"
                "   NIONS =      4\n   NKPTS =      1\n"
                f"   NUPDOWN=      {nup_echo}    fix difference up-down\n"
                f"   U (eV)           for each species LDAUU =   {ldauu_echo}\n"
                "  energy(sigma->0) =  -1.0\n"
                "\n magnetization (x)\n\n# of ion  s p d tot\n----\n" + rows +
                "\n----\n General timing and accounting\n")
        if double_run:
            body = body + body
        (jd / "static_pin" / "OUTCAR").write_text(body, encoding="utf-8")
        (jd / "static_pin" / "CHGCAR").write_text("density " * 10, encoding="utf-8")
        return jd
    with tempfile.TemporaryDirectory() as _d:
        _D = pathlib.Path(_d)
        chk(check_pin(_pin_job(_D / "ok")) == 0, "check_pin 양성: 정상 pin 수용")
        for nm, kw, why in (
            ("f", {"flip_one": True}, "⛔check_pin 음성: topology 위반 → 거부"),
            ("n", {"nup_echo": "-1.0000"}, "⛔check_pin 음성: NUPDOWN 미적용 → 거부"),
            ("u", {"ldauu_echo": "0.0 5.0 0.0"},
             "⛔check_pin 음성: LDAUU=5.0 → 거부 (E-3차 재현 구멍)"),
            ("m", {"double_run": True}, "⛔check_pin 음성: 2실행 이어붙음 → 거부"),
            ("k", {"kmesh": False}, "⛔check_pin 음성(P0-1): kmesh 결측 → 거부"),
            ("i", {"incar_tamper": True}, "⛔check_pin 음성: pin INCAR 변조 → 거부"),
        ):
            chk(check_pin(_pin_job(_D / nm, **kw)) == 1, why)

    # ── provenance 스위트 (배포본 상주 · E-6차 계약) ─────────────────────────
    _OC_FILE = (" vasp.5.4.4 test\n initial charge density was supplied:\n"
                " keeping initial charge density in first step\n"
                "  energy(sigma->0) =  -1.0\n General timing and accounting\n")
    _OC_ATOMS = (" vasp.5.4.4 test\n initial charge density was supplied:\n"
                 " charge density of overlapping atoms calculated\n"
                 " keeping initial charge density in first step\n"
                 "  energy(sigma->0) =  -1.0\n General timing and accounting\n")

    def _prov_job(dirp, pv_patch=None, pc_patch=None, skip_disk=(), man_drop=(),
                  tamper_incar=False, static_outcar=_OC_FILE, parent_break=False):
        jd = pathlib.Path(dirp)
        (jd / "static_pin").mkdir(parents=True); (jd / "static").mkdir()
        base = {"POSCAR": "p", "KPOINTS": "k", "static_pin/INCAR": "i1",
                "static/INCAR": "i2", "static_pin/KPOINTS": "k",
                "static/KPOINTS": "k", "run_job.sh": "r"}
        man = {}
        for f, body in base.items():
            if f not in skip_disk:
                (jd / f).write_text(body, encoding="utf-8")
            man[f] = hashlib.sha256(body.encode()).hexdigest()
        # job.json 은 부모 해시를 담아야 하므로 마지막에 (자기 해시는 그 뒤 계산)
        par = {"POSCAR": ("deadbeef" if parent_break else man["POSCAR"]),
               "KPOINTS": man["KPOINTS"]}
        jj = json.dumps({"rescue": {"parent_sha256": par}})
        if "job.json" not in skip_disk:
            (jd / "job.json").write_text(jj, encoding="utf-8")
        man["job.json"] = hashlib.sha256(jj.encode()).hexdigest()
        for f in man_drop:
            man.pop(f, None)
        (jd / "MANIFEST_RESCUE.json").write_text(json.dumps({"sha256": man}), encoding="utf-8")
        if static_outcar is not None:
            (jd / "static" / "OUTCAR").write_text(static_outcar, encoding="utf-8")
        rec = {f: man.get(f, "x") for f in ("POSCAR", "KPOINTS",
                                            "static_pin/INCAR", "static/INCAR")}
        rec["POTCAR"] = "pt"
        for ph in ("static_pin", "static"):
            rec[ph + "/POSCAR"] = rec["POSCAR"]
            rec[ph + "/KPOINTS"] = rec["KPOINTS"]
            rec[ph + "/POTCAR"] = "pt"
        pv = {"run_id": "20260825T000000Z_host", "utc": "2026-08-25T00:00:00Z",
              "preflight_problems": [], "inputs_sha256": rec,
              "parent_match": {"POSCAR": True, "KPOINTS": True},
              "chgcar_sha256": {"pin": "aa", "static_copy": "aa", "identical": True},
              "chgcar_read_evidence": ["grid : charge from CHGCAR file"]}
        pv.update(pv_patch or {})
        (jd / "RUN_PROVENANCE.json").write_text(json.dumps(pv), encoding="utf-8")
        pc = {"pass": True, "chgcar": {"sha256": "aa"}}
        pc.update(pc_patch or {})
        (jd / "static_pin" / "PIN_CHECK.json").write_text(json.dumps(pc), encoding="utf-8")
        if tamper_incar:
            (jd / "static_pin" / "INCAR").write_text("i1-modified", encoding="utf-8")
        return jd
    with tempfile.TemporaryDirectory() as _d:
        _D = pathlib.Path(_d)
        chk(rescue_provenance_ok(_prov_job(_D / "g"))[0] is True,
            "provenance 양성: 완비(OUTCAR 승계 마커 포함) → supersede 허용")
        for nm, kw, why in (
            ("q1", {"pv_patch": {"parent_match": {}}},
             "⛔provenance P0-4: parent_match={} → 거부"),
            ("q2", {"pv_patch": {"chgcar_sha256": {"pin": "aa", "static_copy": "bb",
                                                    "identical": True}}},
             "⛔provenance P0-4: identical 거짓 플래그 → sha 직접 비교 거부"),
            ("q3", {"pc_patch": {"chgcar": None}},
             "⛔provenance P0-4: PIN_CHECK 에 CHGCAR sha 없음 → 거부"),
            ("q4", {"static_outcar": _OC_ATOMS},
             "⛔provenance E-6차: OUTCAR 가 'overlapping atoms 새로 만듦' → 승계 안 됨 거부"),
            ("q5", {"static_outcar": " vasp.5\n General timing and accounting\n"},
             "⛔provenance E-6차: 승계 마커 부재(판별 불가) → 거부"),
            ("q6", {"static_outcar": None},
             "⛔provenance E-6차: static OUTCAR 자체가 없으면 거부"),
            ("q7", {"pv_patch": {"chgcar_read_evidence": "NOT_FOUND"}},
             "⛔provenance P0-5: 문자열 타입(문자 순회 함정) → 형식 거부"),
            ("q8", {"pv_patch": {"preflight_problems": ["bad"]}},
             "⛔provenance E-5차: preflight_problems 비어있지 않음 → 거부"),
            ("q9", {"pv_patch": {"preflight_problems": None}},
             "⛔provenance E-5차: preflight 필드 위조/부재 → 거부"),
            ("qa", {"skip_disk": ("static/INCAR",)},
             "⛔provenance P0-3: 배포 파일 디스크 부재 → 거부"),
            ("qb", {"skip_disk": ("static/KPOINTS",)},
             "⛔provenance P0-2: phase KPOINTS 디스크 부재 → 거부"),
            ("qc", {"man_drop": ("static_pin/KPOINTS",)},
             "⛔provenance: MANIFEST 에 phase KPOINTS 해시 없음 → 거부"),
            ("qd", {"tamper_incar": True},
             "⛔provenance: 디스크 INCAR 사후 변조 → 거부"),
            ("qe", {"pv_patch": {"inputs_sha256": None}},
             "⛔provenance P0-3: 실행 기록 해시 없음 → 거부"),
            ("qf", {"parent_break": True},
             "⛔provenance E-6차: 배포≠부모 (재계산 사슬) → 기록 불리언과 무관하게 거부"),
        ):
            _r = rescue_provenance_ok(_prov_job(_D / nm, **kw))
            chk(_r[0] is False, f"{why} ({_r[1][:38]})")

    # ⛔⛔ 회신 AR P1-12 · 해제조건 10 (2026-08-31) — 사전등록 estimand 판정
    #   (`_closure_estimand`)을 **배포본 안에서** 친다. 종전엔 생성기 selftest 에만
    #   있어서, 이 파일만 받은 쪽은 production 판정 경로를 하나도 검증할 수 없었다.
    _n0 = _CHKN[0]
    _selftest_closure(chk)
    print("  ── estimand 판정 검사 %d건 (배포본 안에서 실행) ──"
          % (_CHKN[0] - _n0))
    print("selftest %d/%d · %s"
          % (_CHKN[1], _CHKN[0], "PASS" if ok else "FAIL"))
    print("  재현: python3 analyze_results.py --selftest")
    print("k-selftest PASS" if ok else "k-selftest FAIL")
    return 0 if ok else 1


def _icharg1_chgcar_gate(oc, ph):
    """`ICHARG=1` 상은 **실제로 CHGCAR 를 읽었다는 증거**가 있어야 한다. → [gate] | []

    ⛔⛔ 2026-08-31 (회신 AN P0-6) — 종전엔 `read_outcar()` 가 `chgcar_from_file` 을
      읽어 두고도 일반 `phase_gates()` 가 **그것을 안 썼다.** 파일 존재만 보고 넘어갔다.
      C-12 에서 `ICHARG=1` 인 상은 **기체 기준 static 둘**이고, 그 둘은 D 에 직접 들어간다.
      VASP 는 CHGCAR 가 없거나 못 읽으면 **조용히 원자중첩으로 시작**한다 —
      그러면 "승계했다" 는 기록만 남고 실제로는 다른 시작점이다.

    ⛔ 못 하는 것: 읽은 CHGCAR 가 **맞는 것**인지는 모른다 (읽었다는 사실만 본다).
    """
    if str(oc.get("incar_echo", {}).get("ICHARG", "")).strip() != "1":
        return []
    cff = oc.get("chgcar_from_file")
    if cff is True:
        return []
    return ["CHGCAR_NOT_READ(%s — ICHARG=1 인데 %s. VASP 는 못 읽으면 조용히 "
            "원자중첩으로 시작한다)"
            % (ph, "overlapping atoms 로 새로 만듦" if cff is False else "마커 부재")]


def phase_gates(oc, ph, meta, spec, want_ionic=False):
    """상 하나의 fail-closed 검사. oc 가 None 이면 NOT_RUN.

    ⚠ **게이트 통과가 보증하는 것** (codex E-2, 과대해석 금지):
      "제공된 단일 완결 실행 세그먼트에서, incar_expected 에 등록된 유한한 키
       집합이 되울림과 일치했다" — 딱 여기까지다.
    보증하지 못하는 것: 등록되지 않은 키 전부 · POTCAR 원문 해시 · WAVECAR/CHGCAR
    실제 내용과 승계 계보 · 기본값/명시값 구분 · LREAL 의 정확한 모드(등가류까지만).
    ISTART/ICHARG 되울림은 재시작 파일이 **실제로 쓰였다는 증거가 아니다.**
    각 상의 incar_audit(4분류)가 이 경계의 기계 기록이다.

    ✅ 2026-08-31 (회신 AT P0-2) — **k 격자·시프트는 이제 보증한다.** KPOINTS 제목에
      `phase=… k=… shift=…` 를 실어 OUTCAR ` KPOINTS:` 되울림과 정확히 대조한다.
      종전에는 `NKPTS ≤ 격자곱` 상한뿐이라 coarse OUTCAR 를 dense 폴더에 넣어도
      통과했다. 단 **되울림이 없으면 통과가 아니라 UNVERIFIED** 다.
    """
    g = []
    if oc is None:
        return [f"NOT_RUN({ph})"]
    if oc.get("read_error"):
        # 판독 실패는 NOT_RUN 이 아니다 — 파일은 있는데 믿고 읽을 수 없는 상태
        return [f"OUTCAR_READ_ERROR({ph}: {oc['read_error']})"]
    seg = oc.get("run_segments") or {}
    if seg.get("n", 1) > 1:
        g.append(f"MULTI_RUN_OUTCAR({ph}: 실행 {seg['n']}개 이어붙음 — "
                 f"{seg['used']}(#{seg['used_index']}) 세그먼트만 읽음. "
                 "단일 실행 계약과 어긋난다 — 출처 확인 전 인용 금지)")
    if oc.get("suffix_magic_mismatch"):
        g.append(f"OUTCAR_FORMAT_MISMATCH({ph}: 확장자와 실제 형식({oc.get('read_format')})이 다름)")
    if not oc["normal_end"]:
        g.append(f"NOT_TERMINATED({ph} — General timing 없음, 잘린 OUTCAR)")
    if oc["E0"] is None:
        g.append(f"NO_ENERGY({ph})")
    if oc["nelm_hit"]:
        g.append(f"ELECTRONIC_NELM_HIT({ph})")
    if want_ionic and not oc["ionic_conv"]:
        g.append(f"IONIC_NOT_CONVERGED({ph})")
    expect = [spec.get(e, e) for e in meta.get("species_order", [])]
    got = [x.split()[1] if len(x.split()) > 1 else x for x in oc["titels"]]
    # ⚠ TITEL 이 아예 없으면 "검사 못 함" 이지 "통과" 가 아니다
    if expect and not got:
        g.append(f"POTCAR_UNVERIFIED({ph} — TITEL 없음)")
    elif expect and got and len(got) != len(expect):
        g.append(f"POTCAR_COUNT({ph}: {len(got)}!={len(expect)})")
    elif expect and got and got != expect:
        # ⛔ 2026-08-12 — 옛 판은 여기서 변형 문자열을 **비교하지 않았고**, 뒤의 전역
        #   검사도 "준중심 접미사가 있는가" 라는 boolean 만 봐서 Ni_pv→Ni_sv 가 경고로
        #   통과했다. 고정 protocol 에서는 한 글자만 달라도 다른 Hamiltonian 이다.
        g.append(f"POTCAR_VARIANT({ph}: {got}!={expect})")
    nat = sum(meta.get("counts", []) or [])
    if nat and oc["nions"] and oc["nions"] != nat:
        g.append(f"NIONS_MISMATCH({ph}: {oc['nions']}!={nat})")
    # ── 이 상이 **선언한 대로** 돌았는지: k 점 수 + INCAR 되울림 (Codex P0-5) ──
    #   dense 폴더에 static OUTCAR 를 복사해도 에너지만 맞으면 통과하던 구멍을 막는다.
    #   ⚠ NKPTS 절대값은 대칭 축약(ISYM·시간반전) 때문에 예측이 불안정하다 —
    #   상한(전체 격자 곱)만 여기서 보고, **상 사이 단조성**은 main() 에서 본다.
    want_k = (meta.get("kmesh") or {}).get(ph)
    if want_k:
        prod = 1
        for x in str(want_k).split():
            prod *= int(x)
        if not oc.get("nkpts"):
            g.append(f"KMESH_UNVERIFIED({ph} — OUTCAR 에 NKPTS 없음)")
        elif oc["nkpts"] > prod:
            g.append(f"KMESH_MISMATCH({ph}: NKPTS {oc['nkpts']} > 격자 {want_k} 의 {prod})")
    # 🔴🔴 회신 AT P0-2 — 위 상한 검사는 **coarse OUTCAR 를 dense 폴더에 넣어도
    #   통과한다** (3 4 1 = 12 ≤ 4 6 1 = 24). 격자·시프트를 **정확히** 대조한다:
    #   KPOINTS 제목에 실어 둔 `phase=…  k=…  shift=…` 가 OUTCAR 되울림과 같아야 한다.
    _kpe = (meta.get("kpoints_expected") or {}).get(ph)
    if _kpe:
        _gott = oc.get("kpoints_title")
        if not _gott:
            g.append(f"KPOINTS_TITLE_UNVERIFIED({ph} — OUTCAR 에 ` KPOINTS:` 되울림이 "
                     f"없다. 확인 못 한 것은 통과가 아니다)")
        elif _gott.strip() != str(_kpe.get("title", "")).strip():
            g.append(f"KPOINTS_MISMATCH({ph}: 되울림 {_gott!r} ≠ 기대 "
                     f"{_kpe.get('title')!r} — 다른 상의 OUTCAR 이거나 격자·시프트가 "
                     f"다르다)")
    elif ph in ("dense", "dense_cand"):
        # dense 는 δ_k 로 **판정에 직접 들어가는** 상이다 — 기대값이 없으면 막는다
        g.append(f"KPOINTS_EXPECTED_MISSING({ph} — job.json 에 kpoints_expected 가 "
                 f"없다. 구판 번들이다 (회신 AT P0-2))")
    # 🔴 회신 AT P0-2 — dense 의 INCAR 기대값이 없으면 그 상의 INCAR 감사가 통째로
    #   비어 fail-open 이 된다. 판정에 들어가는 상에서는 그것을 막는다.
    if ph in ("dense", "dense_cand") and not (meta.get("incar_expected") or {}).get(ph):
        g.append(f"INCAR_EXPECTED_MISSING({ph} — 기대 INCAR 이 없어 이 상의 감사가 "
                 f"통째로 비어 있다. ENCUT·IVDW·ISPIN·LDAU·ICHARG 가 무엇이든 "
                 f"통과한다 (회신 AT P0-2))")
    audit = {"verified_exact": [], "verified_equivalence_class": [],
             "unverified": [], "mismatch": []}
    expected = (meta.get("incar_expected") or {}).get(ph, {})
    for k2 in AUDIT_KEYS_RUNTIME:
        got2 = (oc.get("incar_echo") or {}).get(k2)
        want = expected.get(k2)
        if k2 in _ECHO_ABSENT:
            # 원리적 검증불가 — 게이트 없이 **명시적으로** unverified (조용한 통과 금지)
            audit["unverified"].append(f"{k2}(OUTCAR 미되울림 — 원리적 검증불가, "
                                       "선언은 INCAR sha256 무결성으로만 보증)")
            continue
        if want is None:
            if got2 is not None:
                audit["unverified"].append(f"{k2}(기대값 미등록 — 되울림 {got2} 은 비교 안 됨)")
            continue
        if got2 is None:
            audit["unverified"].append(k2)
            g.append(f"INCAR_UNVERIFIED({ph}.{k2})")
            continue
        ok, kind = _incar_match(k2, got2, want)
        if not ok:
            audit["mismatch"].append(k2)
            g.append(f"INCAR_MISMATCH({ph}.{k2}: {got2}!={want})")
        elif kind == "equivalence_class":
            audit["verified_equivalence_class"].append(k2)
        else:
            audit["verified_exact"].append(k2)
    oc["incar_audit"] = audit                  # RESULTS.json 에 그대로 실린다
    # ⛔⛔ 회신 AO P0-5 (2026-08-31) — 이 게이트가 **정의만 되고 호출되지 않았다.**
    #   `ICHARG=1`, `chgcar_from_file=False` 인 재현 입력도 게이트 결과가 빈 목록이라
    #   fail-open 이었다. C-12 에서 `ICHARG=1` 상은 기체 기준 static 둘이고
    #   그 둘은 D 에 직접 들어간다. 여기서 실제로 연결한다.
    g += _icharg1_chgcar_gate(oc, ph)
    return g


def check_pin(jobdir):
    """rescue 1상(static_pin)의 수용 검사 — 통과 전에는 release 를 돌리면 안 된다.

    ⛔ v1 은 자기만의 축소판 검사(NUPDOWN·topology)였다 — codex E-3차가
      **LDAUU 를 5.0 으로 바꾼 pin 도 통과**함을 재현했다. v2 는 상 게이트
      전체(phase_gates: 등록된 INCAR 기대키 전부 · MULTI_RUN · 판독오류 ·
      형식 불일치 · E0 · NIONS · POTCAR TITEL · KPOINTS 상한)를 그대로 태우고,
      그 위에 topology·모멘트 붕괴·CHGCAR 해시만 얹는다.

    이 검사가 못 하는 것: pin 이 '어느' basin 인지의 절대 판정 — 시드 topology
    와의 일치까지만 본다.
    """
    jd = pathlib.Path(jobdir)
    meta = json.load(open(jd / "job.json", encoding="utf-8"))
    spec = meta.get("potcar_spec") or {}
    bad = []
    if not spec:
        bad.append("job.json 에 potcar_spec 이 없다 — POTCAR TITEL 검증 불가 (fail-closed)")
    # ⛔ codex E-4차 P0-1 — phase_gates 는 kmesh 결측을 **조용히 건너뛴다** (wave1
    #   호환 때문). release 사슬에서는 그 관용이 fail-open 이다 — 여기서 막는다.
    if not (meta.get("kmesh") or {}).get("static_pin"):
        bad.append("job.json 에 kmesh.static_pin 이 없다 — KPOINTS 검증 불가 (fail-closed)")
    # 배포 기준과 pin INCAR 대조 (MANIFEST_RESCUE — 있으면 강제, 없으면 거부)
    _mr = jd / "MANIFEST_RESCUE.json"
    if not _mr.is_file():
        bad.append("MANIFEST_RESCUE.json 없음 — 배포 기준 해시 부재 (fail-closed)")
    else:
        try:
            _man = (json.load(open(_mr, encoding="utf-8")) or {}).get("sha256") or {}
            _inc = jd / "static_pin" / "INCAR"
            if _inc.is_file() and _man.get("static_pin/INCAR"):
                _h = hashlib.sha256(open(_inc, "rb").read()).hexdigest()
                if _h != _man["static_pin/INCAR"]:
                    bad.append("static_pin/INCAR 가 배포본과 다르다 (변조/수정)")
            else:
                bad.append("pin INCAR 또는 그 배포 해시가 없다")
        except ValueError:
            bad.append("MANIFEST_RESCUE 파싱 실패")
    oc = read_outcar(str(jd / "static_pin" / "OUTCAR"))
    # 상 게이트 전체 — release 사슬에서 하나라도 걸리면 여기서 끝난다
    bad += phase_gates(oc, "static_pin", meta, spec)
    if oc and not oc.get("read_error"):
        seg = oc.get("run_segments") or {}
        if seg.get("n", 1) != 1:
            pass                                  # MULTI_RUN 게이트가 이미 bad 에 있다
        want = {int(k): v for k, v in (meta.get("ni_sign_poscar_idx") or {}).items()}
        mom = {i: v for i, v in enumerate(oc.get("moments") or [])}
        if not mom:
            bad.append("모멘트 표 없음 (LORBIT 확인)")
        elif want:
            sg, flip = global_sign(mom, want)
            small = [i for i in want if abs(mom.get(i, 0.0)) < 0.4]
            if flip:
                bad.append(f"⛔ pin 이 시드 topology 가 아님 — flip {len(flip)}개 "
                           f"(0-based {sorted(flip)[:4]}…)")
            if small:
                bad.append(f"모멘트 붕괴 의심 {len(small)}개 (<0.4 μB)")
    chg = jd / "static_pin" / "CHGCAR"
    chg_info = None
    if chg.is_file() and chg.stat().st_size > 0:
        h = hashlib.sha256()
        with open(chg, "rb") as fh:
            for b in iter(lambda: fh.read(1 << 20), b""):
                h.update(b)
        chg_info = {"sha256": h.hexdigest(), "bytes": chg.stat().st_size,
                    "mtime": chg.stat().st_mtime}
    else:
        bad.append("CHGCAR 없음/빈 파일")
    out = {"pass": not bad, "problems": bad, "chgcar": chg_info,
           "nupdown_echo": ((oc or {}).get("incar_echo") or {}).get("NUPDOWN"),
           "incar_audit": (oc or {}).get("incar_audit"),
           "run_segments": (oc or {}).get("run_segments"),
           "checked": "static_pin"}
    (jd / "static_pin").mkdir(exist_ok=True)
    (jd / "static_pin" / "PIN_CHECK.json").write_text(
        json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    print(("✅ pin 수용 — release 진행 가능" if not bad else
           "⛔ pin 거부 — release 를 돌리지 말 것") + f"  ({jd})")
    for x in bad:
        print("   ·", x)
    if chg_info:
        print(f"   CHGCAR sha256 {chg_info['sha256'][:16]}… ({chg_info['bytes']} B)")
    return 0 if not bad else 1


#: ⛔⛔ 회신 BC P1 (2026-09-02) — **C-12 rescue 의 봉투**를 300 h 잡 **전에** 박는다.
#:   리뷰어 판정: 실패별 SCF 처방은 실패 후 정해도 되지만, 계보·봉인 구조는 미리
#:   고정해야 한다. 실패가 난 뒤에 만들면 그때는 이미 시간이 없다.
#:   ⚠ **생성기 모드는 아직 없다** — 여기 있는 것은 봉투(스키마)와 그 검사기다.
#:     무엇을 만들지 정해 두면 실패 형태를 보고 *내용*만 채우면 된다.
C12_RESCUE_ENVELOPE = {
    "schema": "c12_rescue/v1",
    "필수": ["parent_bundle_zip_sha256", "parent_manifest_sha256", "parent_job_key",
             "parent_input_sha256", "attempt_id", "supersedes", "reason"],
    "supersedes": ("정확히 **그 잡 하나**를 가리킨다 (`parent_job_key` 와 같아야 "
                   "한다). 번들 전체나 여러 잡을 한 번에 대체하지 않는다."),
    "원본_보존": ("부모 번들의 산출물은 **손대지 않는다**. rescue 는 새 폴더에 "
                  "만들고, 분석은 둘을 **같이** 본다."),
    "자동_대체_금지": ("rescue 결과가 부모 값을 자동으로 덮지 않는다. 어느 것을 쓸지는 "
                       "판정 규칙이 정하고, 그 규칙은 사전등록에 있어야 한다."),
    "⛔_아직_없는_것": ("생성기의 rescue 모드. 이 봉투는 **무엇을 만들지**를 고정한 "
                        "것이고, 실패별 SCF 처방(ALGO·NELM·AMIX…)은 실패를 보고 "
                        "정한다 (회신 BC Q4)."),
    "⛔_이_검사가_못_하는_것": ("부모 번들이 손에 없으면 `parent_job_key` 가 **실제로 "
                               "존재하는 잡인지** 확인할 수 없다 — 여기서는 키의 "
                               "**모양**만 본다. 존재 확인은 rescue 생성기가 부모 "
                               "MANIFEST 를 받아서 해야 한다 (회신 BD P1)."),
}


def c12_rescue_envelope_ok(meta):
    """rescue 봉투가 갖춰졌나 → (ok, 사유 목록). **전부 fail-closed.**

    ⛔ 못 하는 것: 그 rescue 를 **돌려도 되는가**는 판정하지 않는다 (사전등록의 몫).
    """
    r = (meta or {}).get("rescue") or {}
    bad = []
    if not r:
        return False, ["`rescue` 봉투가 없다 — 이 잡이 무엇을 대체하는지 말하지 못한다"]
    for k in C12_RESCUE_ENVELOPE["필수"]:
        v = r.get(k)
        if v in (None, "", [], {}):
            bad.append("`rescue.%s` 가 없다" % k)
    _sup, _pj = r.get("supersedes"), r.get("parent_job_key")
    if _sup and _pj and _sup != _pj:
        bad.append("`supersedes`(%r) 가 `parent_job_key`(%r) 와 다르다 — rescue 는 "
                   "**그 잡 하나**만 대체한다" % (_sup, _pj))
    if isinstance(_sup, (list, tuple, set)):
        bad.append("`supersedes` 가 목록이다 — 여러 잡을 한 번에 대체하지 않는다")
    if r.get("auto_replace_parent"):
        bad.append("`auto_replace_parent` 가 참이다 — rescue 결과가 부모 값을 "
                   "**자동으로 덮지 않는다** (어느 것을 쓸지는 사전등록이 정한다)")
    if r.get("overwrote_parent"):
        bad.append("부모 산출물을 덮었다고 기록돼 있다 — 원본은 보존해야 한다")
    # ⛔ 회신 BD P1 (2026-09-02) — 부모 SHA 에 `"x"` 를 넣고 **없는 job** 을 써도
    #   통과했다. 봉투가 "칸이 채워졌나" 만 보고 **값의 모양**을 안 봤다.
    for _k in ("parent_bundle_zip_sha256", "parent_manifest_sha256"):
        _v = str(r.get(_k) or "")
        if _v and not re.match(r"^[0-9a-f]{64}$", _v):
            bad.append("`rescue.%s` 가 64-hex 가 아니다 (%r)" % (_k, r.get(_k)))
    _pin = r.get("parent_input_sha256")
    if _pin is not None:
        if not isinstance(_pin, dict) or not _pin:
            bad.append("`rescue.parent_input_sha256` 가 비어 있지 않은 dict 여야 한다")
        else:
            _badh = sorted(k for k, v in _pin.items()
                           if not re.match(r"^[0-9a-f]{64}$", str(v or "")))
            if _badh:
                bad.append("`rescue.parent_input_sha256` 의 값이 64-hex 가 아니다 %s"
                           % _badh[:3])
    #   job 키는 `<tier>/<잡이름>` 모양이어야 한다 (존재 확인은 부모 번들이 있어야
    #   가능하므로 여기서는 **모양**만 본다 — 그 한계를 적는다)
    if _pj and not re.match(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$", str(_pj)):
        bad.append("`rescue.parent_job_key` 가 `<tier>/<잡>` 모양이 아니다 (%r)" % _pj)
    _aid = str(r.get("attempt_id") or "")
    if _aid and not re.match(r"^\d{8}T\d{6}Z_[A-Za-z0-9_.-]+$", _aid):
        bad.append("`attempt_id` 형식이 아니다 (YYYYMMDDTHHMMSSZ_라벨): %r" % _aid)
    return (not bad), bad


def rescue_provenance_ok(jd):
    """supersede 의 추가 조건 — **모든 필드가 fail-closed** (codex E-4차 P0 5건).

    v1 의 구멍 (전부 적대 재현됨):
      · parent_match={} → all({})==True 로 우회      → 키별 is True 요구
      · identical 플래그만 믿음 (거짓 기록 가능)      → pin/static sha 직접 비교
      · PIN_CHECK 에 chgcar 없으면 교차검증 생략       → 없으면 거부
      · 'could not be read' 같은 **부정문도 증거로 통과** → 부정 마커 필터
      · 배포 입력(MANIFEST_RESCUE)과 대조 없음         → 기록·디스크 양쪽 대조

    → (ok, why)
    """
    jd = pathlib.Path(jd)
    pc_p = jd / "static_pin" / "PIN_CHECK.json"
    pv_p = jd / "RUN_PROVENANCE.json"
    mr_p = jd / "MANIFEST_RESCUE.json"
    for f, w in ((pc_p, "PIN_CHECK.json 없음 — pin 수용검사 미실행"),
                 (pv_p, "RUN_PROVENANCE.json 없음 — 해시·승계 증거 미기록"),
                 (mr_p, "MANIFEST_RESCUE.json 없음 — 배포 기준 해시 부재")):
        if not f.is_file():
            return False, w
    try:
        pc, pv, mr = (json.load(open(x, encoding="utf-8")) for x in (pc_p, pv_p, mr_p))
    except ValueError as e:
        return False, f"provenance 파싱 실패: {e}"
    if not pc.get("pass"):
        return False, "PIN_CHECK.pass=false"
    if not re.match(r"^\d{8}T\d{6}Z_\S+$", str(pv.get("run_id") or "")):
        return False, f"run_id 형식 오류: {pv.get('run_id')!r}"
    if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", str(pv.get("utc") or "")):
        return False, f"utc 형식 오류: {pv.get('utc')!r}"
    # ⛔ E-5차 — runner 는 preflight_problems 를 **항상** [] 로 기록한다.
    #   필드 부재(위조 pv)도, 비어있지 않음도 전부 거부다.
    if pv.get("preflight_problems") != []:
        return False, f"preflight 미기록/실패: {pv.get('preflight_problems')!r}"
    # 부모 대조 — 빈 dict 는 통과가 아니다: 키별로 is True 를 요구한다
    pm = pv.get("parent_match") or {}
    for k in ("POSCAR", "KPOINTS"):
        if pm.get(k) is not True:
            return False, f"부모 대조 결측/실패: {k}={pm.get(k)!r}"
    # 배포 기준(MANIFEST_RESCUE) ↔ 실행 기록 ↔ 현재 디스크 3중 대조
    man = mr.get("sha256") or {}
    rec = pv.get("inputs_sha256") or {}
    # ⛔ E-5차 — '있으면 대조' 는 fail-open 이다: 파일이 없으면 대조가 조용히
    #   생략됐다. 배포에 포함된 파일은 **존재 자체가 필수**다.
    _DISK_REQUIRED = ("POSCAR", "KPOINTS", "static_pin/INCAR", "static/INCAR",
                      "static_pin/KPOINTS", "static/KPOINTS",
                      "job.json", "run_job.sh")
    for f in _DISK_REQUIRED:
        if not man.get(f):
            return False, f"MANIFEST_RESCUE 에 {f} 해시 없음"
        fp = jd / f
        if not fp.is_file():
            return False, f"배포 파일이 디스크에 없다: {f}"
        h = hashlib.sha256(open(fp, "rb").read()).hexdigest()
        if h != man[f]:
            return False, f"디스크 파일이 배포본과 다름(사후 변조?): {f}"
    for f in ("POSCAR", "KPOINTS", "static_pin/INCAR", "static/INCAR"):
        if rec.get(f) != man[f]:
            return False, f"실행 기록 해시 ≠ 배포 해시: {f}"
    # ⛔ E-6차 — parent_match 는 runner 가 **기록한 불리언**이라 위조 가능하다.
    #   재계산 사슬로 검증한다: 디스크==배포해시(위에서 확인) 이고, 배포해시==부모해시
    #   (job.json 은 자체가 해시 앵커됨) 이면 부모 대조가 독립적으로 선다.
    try:
        _meta = json.load(open(jd / "job.json", encoding="utf-8"))
    except ValueError as e:
        return False, f"job.json 파싱 실패: {e}"
    _par = ((_meta.get("rescue") or {}).get("parent_sha256") or {})
    for f in ("POSCAR", "KPOINTS"):
        if not _par.get(f):
            return False, f"job.json 에 부모 해시 없음: {f}"
        if man[f] != _par[f]:
            return False, f"배포 {f} 가 부모와 다르다 (재계산 대조 실패)"
    # phase 디렉터리 사본 — **VASP 가 실제로 읽는 파일** (P0-2·3)
    for f in ("static_pin/KPOINTS", "static/KPOINTS",
              "static_pin/POSCAR", "static/POSCAR",
              "static_pin/POTCAR", "static/POTCAR"):
        if not rec.get(f):
            return False, f"실행 기록에 phase 사본 해시 없음: {f}"
    if rec["static_pin/KPOINTS"] != man["KPOINTS"] or rec["static/KPOINTS"] != man["KPOINTS"]:
        return False, "phase KPOINTS 사본이 배포본과 다르다"
    if rec["static_pin/POSCAR"] != man["POSCAR"] or rec["static/POSCAR"] != man["POSCAR"]:
        return False, "phase POSCAR 사본이 배포본과 다르다"
    if not (rec.get("POTCAR") and rec["static_pin/POTCAR"] == rec["POTCAR"]
            and rec["static/POTCAR"] == rec["POTCAR"]):
        return False, "POTCAR 조립본과 phase 사본이 서로 다르다"
    # CHGCAR 승계 — 플래그를 믿지 않는다: sha 문자열 직접 비교 + PIN_CHECK 교차
    ch = pv.get("chgcar_sha256") or {}
    if not (ch.get("pin") and ch.get("static_copy")):
        return False, "CHGCAR sha 미기록"
    if ch["pin"] != ch["static_copy"]:
        return False, "CHGCAR pin/사본 sha 불일치"
    pc_sha = (pc.get("chgcar") or {}).get("sha256")
    if not pc_sha:
        return False, "PIN_CHECK 에 CHGCAR sha 없음 — 교차검증 불가"
    if ch["pin"] != pc_sha:
        return False, "PIN_CHECK 의 CHGCAR sha 와 provenance 가 다르다 (다른 실행 혼입?)"
    # ── CHGCAR 승계 증거 (E-6차 전면 교체) ────────────────────────────────
    #   vasp.log 문자열 게이트는 **블랙리스트 두더지잡기**였다 — 'hello'(양성 패턴
    #   부재), "NOT_FOUND" 문자순회, 부정문 변형("can't", "skipped", …)이 계속
    #   나온다. 판별자는 stdout 이 아니라 **회신된 static OUTCAR 자체**에 있다
    #   (wave1 실측: ICHARG=1 은 `initial charge density was supplied:` 만,
    #   ICHARG=2 는 그 밑에 `charge density of overlapping atoms calculated`).
    #   stdout 기록(chgcar_read_evidence)은 정보용으로 강등 — 게이트하지 않되
    #   타입 오염(str 순회 함정)만은 거부한다.
    ev = pv.get("chgcar_read_evidence")
    if ev is not None and (not isinstance(ev, list)
                           or not all(isinstance(x, str) for x in ev)):
        return False, f"chgcar_read_evidence 형식 오류 (list[str] 아님): {type(ev).__name__}"
    st_oc = read_outcar(str(jd / "static" / "OUTCAR"))
    if st_oc is None or st_oc.get("read_error"):
        return False, ("static OUTCAR 판독 불가 — CHGCAR 승계 검증 불가: "
                       + str((st_oc or {}).get("read_error", "파일 없음")))
    cff = st_oc.get("chgcar_from_file")
    if cff is not True:
        return False, ("static OUTCAR 에 CHGCAR 승계 증거 없음 "
                       + ("(overlapping atoms 로 새로 만듦 — ICHARG=1 미작동)"
                          if cff is False else "(마커 부재 — 판별 불가)"))
    return True, "ok"



#: 사전등록 문턱 — `prereg_sdcp_neutral_contrast_2026_08_29.json` 과 **같은 값**이어야 한다.
#:   ⚠ 두 곳에 복사돼 있다. 고치면 그 json 도 같이 고칠 것.
PREREG_GUARD_EV = -0.10           # primary 가 이 값 이하일 때만 방향성 주장
PREREG_ROUND_EV = 0.01            # 보고 반올림
PREREG_SELECTOR_AGREE_EV = 0.05   # 두 selector 차가 이 미만이면 "시험한 selector 간 일치"


#: ⚠ 분석기는 **번들 안에 단독 배포**된다 — 생성기 상수를 못 본다. 판정 branch 를
#:   여기 따로 박는다 (문자열이 갈라지면 C1·C3 가 조용히 빈다).
SEED_MAIN = "afm2424_pm1"

#: 닫힘 조건 문턱 — db/properties/sdcp_stageA_closure_conditions_2026_08_29.json
#: 에 **DFT 0잡 시점**으로 등록된 값. 코드와 문서가 갈라지면 문서가 정본이다.
C1_S_TOL_EV = 0.050          # 조각 내 잔차 range 허용
C3_REF_GAP_EV = 0.90         # 설명 대상 — 관측된 조각 간 UMA 오프셋 차등
C3_HI, C3_LO = 0.70, 0.30    # 채택 / 기각 비율
# D3 항등식 `E_on − E_off == Edisp` 의 허용 오차. 두 SCF 가 독립 수렴하므로
# EDIFF(1e-6 eV) 급 잔차는 정상이고, 그보다 훨씬 크면 쌍둥이가 IVDW 말고 다른
# 데서 갈렸다는 뜻이다. 1 meV 는 EDIFF 의 1000배 — 넉넉하되 실제 결함은 잡는다.
C3_EDISP_TOL_EV = 1.0e-3
#: ★ 0.90 eV 의 **원자료 정의를 봉인한다** (회신 AB P0-3).
#:   정본 db/properties/prereg_sdcp_neutral_contrast_2026_08_29.json
#:   → `🔬_UMA_대_DFT_오프셋_실측_2026_08_29.오프셋_UMA_빼기_DFT_eV`
#:   부호규약은 문자 그대로 **(UMA − DFT)** 다. 흡착에너지 오프셋이지
#:   총에너지 오프셋이 아니므로 원소별 energy-zero 는 소거된다 (AB P0-3 후단 해소).
C3_OFFSET_UMA_MINUS_DFT = {
    "sdcp_neutral": {"Li_top": 1.0728, "Ni_top": 1.0667},
    "ptfe_c10": {"Li_top": 0.1855, "Ni_top": 0.1484},
}
#: 조각 내 오프셋 **상수성** (관측 range). D3 가설이 살아남으려면 δ 의 조각내
#: range 가 이 정도여야 한다 — D3 는 기하 의존이라 자세마다 달라야 하는데
#: 관측 오프셋은 조각 안에서 상수였다 (prereg ⛔_분산_귀속_철회_2026_08_29).
C3_OFFSET_RANGE_EV = {"sdcp_neutral": 0.0061, "ptfe_c10": 0.0371}
#: 조각내 일관성 판정의 여유배수 — δ range 가 관측 range 의 이 배를 넘으면
#: "D3 로 설명" 은 성립하지 않는다 (평균이 맞아도).
C3_WITHIN_SLACK = 5.0


def _pick(jobs, **want):
    """구조화 필드로 잡을 고른다 (이름 파싱 금지)."""
    out = []
    for jn, jr in jobs.items():
        m = jr.get("meta") or {}
        if all(m.get(k) == v for k, v in want.items()):
            out.append(jn)
    return sorted(out)


def _expected_pose_keys(man, f, seed=None):
    """조각 f 의 **기대 자세 키**를 동결된 manifest 에서 고른다 (이름 파싱 금지).

    ⛔⛔ 회신 BB P1 (2026-09-02) — 이 술어가 **두 벌**이었다. BA P1 이 C1(J_f) 쪽만
      구조화 필드로 고쳤고, C3(Edisp) 쪽은 여전히 `startswith("prospective/")` +
      `endswith(SEED_MAIN)` 로 **잡 키 문자열**을 파싱했다. 게다가 그쪽은
      d3-off 쌍둥이를 기대에는 넣고 선택(`d3="on"`)에서는 빼서
      **정상 2자세×2seed 에서도 used<required → 영구 unresolved** 였다.
      ⇒ 술어를 하나로 합친다. 두 벌이면 또 갈라진다 (이번이 두 번째다).

    ⚠ `planned.meta` 에는 `d3` 가 없다 — d3-off 쌍둥이는 `d3_twin_of` 유무로 뺀다
      (있는 필드로만 맞춘다).
    """
    _sd = SEED_MAIN if seed is None else seed
    out = []
    for k, v in (man.get("planned") or {}).items():
        m = (v or {}).get("meta") or {}
        if (m.get("kind") == "prospective_pose" and m.get("fragment") == f
                and m.get("seed") == _sd and m.get("vacconv") is None
                and not m.get("d3_twin_of")):
            out.append(k)
    return sorted(out)


def _twin_of(jobs, parent_key):
    """그 잡의 D3-off 쌍둥이 키. `d3_twin_of` 로만 찾는다 (접미어 추측 금지)."""
    for jn, jr in jobs.items():
        if (jr.get("meta") or {}).get("d3_twin_of") == parent_key:
            return jn
    return None


def _basin_of(jr):
    """잡 → (id, detail). 없으면 (None, None) — 호출부가 fail-closed 로 처리한다."""
    m = ((jr or {}).get("geom") or {}).get("magnetic") or {}
    return m.get("realized_basin_id"), m.get("realized_basin")


def same_basin(ja, jb):
    """두 잡이 **같은 자기 basin 인가** → (bool, 사유).

    🔴 회신 AB P0-4 — 종전엔 `realized_basin_id` **해시만** 비교했다. 그 해시는
      부호 벡터·붕괴 위치·유기물 상대 스핀만 담고 **크기를 안 담는다**. 그래서
      1.2 μB 와 2.0 μB 처럼 부호는 같고 크기가 크게 다른 상태가 같은 basin 으로
      통과했다. `basin_distance()` 의 RMS ≤ MOM_RMS_TOL 규칙은 selftest 밖에서
      **한 번도 호출되지 않았다** — 살아 있는 척하는 죽은 코드였다.
      ⇒ 해시가 같아도 상세 지문으로 한 번 더 본다. 지문이 없으면 통과가 아니다.
    """
    ia, da = _basin_of(ja)
    ib, db = _basin_of(jb)
    if ia is None or ib is None:
        return False, "realized_basin_id 없음 (미판정) — 통과로 읽지 않는다"
    if ia != ib:
        return False, f"basin 해시 불일치 {str(ia)[:8]} vs {str(ib)[:8]}"
    d = basin_distance(da, db)
    if d is None:
        return False, "상세 지문 없음 — 크기 비교 불가 (해시만으로 통과시키지 않는다)"
    if not d.get("same"):
        return False, ("해시는 같지만 상세가 다르다 (hamming %s · collapse %s · "
                       "RMS %s μB > %s)" % (d.get("hamming"), d.get("collapse_symdiff"),
                                            d.get("moment_rms_muB"), MOM_RMS_TOL))
    return True, "ok"


def executable_receipt_gates(job_dir, rel, man, executed_phases):
    """반송된 `EXECUTABLE_RECEIPT.tsv` 를 **분석기가 직접 읽고** 게이트한다.

    🔴 회신 AV P0-2 — 종전엔 러너가 receipt 를 만들기만 하고 아무도 읽지 않았다.
    "봉인된 그 바이너리로 돌았다" 는 주장은 receipt 의 상별 해시가 root seal 과
    같을 때만 성립한다. staged 번들(run_staged.sh 경로)에만 적용한다 —
    비-staged 구판 번들에는 이 계약이 없었으므로 소급 요구하지 않는다.

    행 형식(9열): ts phase exe_sha256 exe kind nproc launcher launcher_sha256 potcar_sha256
      (러너 헤더행은 phase=`_runner_start` — **정확히 하나** 있어야 한다 · potcar 열은 "-")
    🔴 회신 BE P1 (2026-09-03) — 9열 potcar_sha256 은 **상 폴더에 실제로 복사된** POTCAR 의
      실행 직전 해시다. 종전엔 루트 POTCAR 만 provenance 와 대조했고 상 폴더 사본은
      반송물 어디에도 결박되지 않았다. 이제 `POTCAR_PROVENANCE.assembled_sha256` 과 대조한다.

    ⛔ 이 함수가 못 하는 것: receipt 는 외주처 기계가 쓴 텍스트다 — **위조 자체**는
      막지 못한다. 이 게이트의 몫은 "위조하지 않은 정직한 우회"(다른 바이너리로
      그냥 돌림)를 잡는 것이고, 위조는 형사가 아니라 계약 문제다.
    """
    g = []
    if not (man or {}).get("staged_runner"):
        return g
    _fh = (man or {}).get("files_sha256") or {}
    if rel is not None and _fh and ("%s/run_job.sh" % rel) not in _fh:
        return g                       # 우리가 러너를 실어 보낸 잡에만 요구한다
    seal = (man or {}).get("_potcar_root_seal") or {}
    want = seal.get("vasp_executable_sha256")
    rp = os.path.join(job_dir, "EXECUTABLE_RECEIPT.tsv")
    if not os.path.isfile(rp):
        return ["RECEIPT_MISSING(EXECUTABLE_RECEIPT.tsv 가 반송물에 없다 — 어떤 "
                "바이너리로 돌았는지 확인할 수 없다. run_staged.sh 경로로 돌았다면 "
                "잡마다 남는다)"]
    want_l = seal.get("launcher_sha256")
    want_w = seal.get("launcher_wrapper_sha256")
    # ⛔⛔ 회신 AZ P0-2 (2026-09-01) — **kind·path 를 봉인과 대조한다.**
    #   종전엔 kind 가 허용 목록 안이기만 하면 통과였고, path 는 아예 안 봤다.
    #   그래서 봉인이 `mpirun` 인데 receipt 가 `kind=none` 이면 launcher 해시 검사
    #   자체를 건너뛰어 게이트 `[]` 로 통과했다 (리뷰어가 재현). launcher 신원은
    #   **불변량**이지 행마다 고를 수 있는 값이 아니다.
    want_k = seal.get("launcher_kind")
    want_p = seal.get("launcher_path")
    rows, n_start, start_rows = [], 0, []
    n_resume, resume_rows = 0, []
    for ln in open(rp, encoding="utf-8", errors="replace").read().splitlines():
        if not ln.strip():
            continue
        c = ln.split("\t")
        # ⛔ 회신 AY P1 — **열 수를 정확히** 본다. 종전 `len(c) < 6` 은 열이 남아도
        #   통과시켰고, 그래서 줄바꿈 주입으로 열이 늘어난 행을 못 잡았다.
        if len(c) != 9:
            g.append("RECEIPT_MALFORMED(%r — 열 %d개, 9개여야 한다 · BE P1 이후 potcar_sha 열 포함)"
                     % (ln[:60], len(c)))
            continue
        if c[1] == "_runner_start":
            n_start += 1
            start_rows.append(c)
        if c[1] in ("_runner_resume", "_runner_continue"):
            n_resume += 1
            resume_rows.append(c)
        rows.append(c)
    # ⛔ 회신 AY P0-2 — `_runner_start` 가 **정확히 하나** 있어야 한다. 없으면
    #   run_staged.sh 를 거치지 않은 실행이고, 여럿이면 이어붙인 것이다.
    if n_start != 1:
        g.append("RECEIPT_RUNNER_START(%d개 — 정확히 1개여야 한다. 0이면 러너를 "
                 "거치지 않은 실행, 2개 이상이면 이어붙인 receipt 다)" % n_start)
    # ⛔ 회신 AZ P1 — 헤더행의 **내용**도 본다. 종전엔 개수만 셌다 (아무 값이나
    #   `_runner_start` 라고 적으면 통과했다).
    if n_start == 1:
        h = start_rows[0]
        if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", h[0]):
            g.append("RECEIPT_RUNNER_START_MALFORMED(시각 %r — UTC ...Z 가 아니다)" % h[0][:32])
        if want and h[2] != want:
            g.append("RECEIPT_RUNNER_START_MALFORMED(헤더의 실행파일 %s ≠ 봉인 %s)"
                     % (h[2][:12], want[:12]))
        if want_k and h[4] != want_k:
            g.append("RECEIPT_RUNNER_START_MALFORMED(헤더의 kind %r ≠ 봉인 %r)"
                     % (h[4][:16], want_k))
    # ⛔ 회신 AZ P1 — 재개행이 있으면 **그 사실을 보고**하고, 신원이 첫 실행과
    #   같은지 본다. 재개 자체는 계약이 허용하지만(NOTES.txt 선언 필요) 다른
    #   바이너리로 이어 돌린 것은 아니어야 한다.
    if n_resume:
        # 계획된 이어달리기(dense 승격)는 허용된다 — DENSE_PLAN.json 이 증거다.
        _planned = all(c[1] == "_runner_continue" for c in resume_rows) and \
            os.path.isfile(os.path.join(job_dir, "..", "..", "DENSE_PLAN.json"))
        if not _planned:
            g.append("RECEIPT_RESUMED(%d회 — 중단 복구 재개는 **폐지됐다**(회신 BA "
                     "해제조건 7). 계획된 이어달리기라면 `_runner_continue` 행과 "
                     "DENSE_PLAN.json 이 있어야 한다)" % n_resume)
        for c in resume_rows:
            if want and c[2] != want:
                g.append("RECEIPT_RESUME_IDENTITY(재개 시 실행파일 %s ≠ 봉인 %s)"
                         % (c[2][:12], want[:12]))
            if want_k and c[4] != want_k:
                g.append("RECEIPT_RESUME_IDENTITY(재개 시 kind %r ≠ 봉인 %r)"
                         % (c[4][:16], want_k))
    _HDR = ("_runner_start", "_runner_resume", "_runner_continue")
    ph_rows = {c[1] for c in rows if c[1] not in _HDR}
    # ⛔ 회신 AZ P1 — 같은 상이 **두 번** 찍히면 막는다 (ALLOW_RESUME 로 이어붙인
    #   receipt 가 이 형태다). 상 하나에 실행 하나가 계약이다.
    _seen_ph = {}
    for c in rows:
        if c[1] in _HDR:
            continue
        _seen_ph[c[1]] = _seen_ph.get(c[1], 0) + 1
    _dupe = sorted(k for k, n in _seen_ph.items() if n > 1)
    if _dupe:
        g.append("RECEIPT_PHASE_DUPLICATE(%s — 상 하나에 실행 하나가 계약이다. "
                 "이어달리기로 receipt 를 덮어썼거나 이어붙였다)" % _dupe[:3])
    if not want_k:
        g.append("RECEIPT_LAUNCHER_UNSEALED(root seal 에 launcher_kind 가 없다 — "
                 "AY P0-1 이전 봉인이다. 확인 못 함은 통과가 아니다)")
    # 🔴 회신 BE P1 — 상 폴더 POTCAR 해시(9열)를 조립 provenance 와 대조할 기준
    _asm_sha = None
    try:
        with open(os.path.join(job_dir, "POTCAR_PROVENANCE.json"), encoding="utf-8") as _pf:
            _asm_sha = str(json.load(_pf).get("assembled_sha256") or "") or None
    except Exception:                                        # noqa: BLE001
        _asm_sha = None            # 없으면 potcar_provenance_gates 가 따로 막는다
    for c in rows:
        if c[1] in _HDR:
            continue
        # 🔴 회신 BE P1 — 실행 시점 POTCAR 결박. "-" 나 비-hex 는 결박 없음 = 통과 아님.
        if not _HEX64.match(c[8] or ""):
            g.append("RECEIPT_POTCAR_SHA_MISSING(%s 상: 9열 potcar_sha256 이 %r — 실행 시점 "
                     "POTCAR 가 반송물에 결박되지 않았다)" % (c[1], (c[8] or "")[:12]))
        elif _asm_sha and c[8] != _asm_sha:
            g.append("RECEIPT_POTCAR_MISMATCH(%s 상의 POTCAR %s ≠ 조립본 %s — 조립 뒤 바뀐 "
                     "POTCAR 로 돌았다)" % (c[1], c[8][:12], _asm_sha[:12]))
        # 🔴 회신 BF P1 — 반송된 상 폴더 POTCAR **실물**을 다시 해시해 receipt 문자열과 대조한다
        #   (receipt 만 믿지 않는다). 반송물에 POTCAR 가 없으면 대조 불가 = 통과 아님.
        _pf_path = os.path.join(job_dir, c[1], "POTCAR")
        if _HEX64.match(c[8] or ""):
            if not os.path.isfile(_pf_path):
                # 🔴 회신 BG P0-1 — 계약상 POTCAR 는 반송되지 않는다. 없음은 이행이지 구멍이
                #   아니다 (결박은 9열 + PROVENANCE + root seal). 계약을 바꿔 반송을 요구하는
                #   날에는 C12_POTCAR_RETURNED 를 True 로 — 그때만 없음이 게이트다.
                if C12_POTCAR_RETURNED:
                    g.append("RECEIPT_POTCAR_FILE_MISSING(%s 상: 반송 계약이 POTCAR 를 요구하는데 "
                             "%s/POTCAR 가 없어 receipt 해시를 실물과 대조할 수 없다)" % (c[1], c[1]))
            else:
                _pf_h = hashlib.sha256(open(_pf_path, "rb").read()).hexdigest()
                if _pf_h != c[8]:
                    g.append("RECEIPT_POTCAR_FILE_MISMATCH(%s 상: 실물 POTCAR %s ≠ receipt %s — "
                             "receipt 문자열과 실물이 다르다 · BF P1)" % (c[1], _pf_h[:12], c[8][:12]))
        if not want:
            g.append("RECEIPT_UNVERIFIABLE(root seal 에 실행파일 해시가 없어 receipt "
                     "를 대조할 수 없다 — 확인 못 함은 통과가 아니다)")
            break
        if c[2] != want:
            g.append("RECEIPT_EXE_MISMATCH(%s 상의 실행파일 %s ≠ 봉인 %s — 봉인 밖 "
                     "바이너리로 돌았다)" % (c[1], c[2][:12], want[:12]))
        if c[4] not in ("mpirun", "mpiexec", "srun", "none", "wrapper"):
            g.append("RECEIPT_LAUNCHER_KIND(%s — 허용 밖 launcher)" % c[4])
        # ⛔⛔ 회신 AZ P0-2 — kind 는 봉인과 **정확히 같아야** 한다.
        elif want_k and c[4] != want_k:
            g.append("RECEIPT_LAUNCHER_KIND(%s 상의 kind %r ≠ 봉인 %r — launcher 종류는 "
                     "불변량이다. kind 를 바꿔 해시 검사를 건너뛸 수 없다)"
                     % (c[1], c[4], want_k))
        # ⛔⛔ 회신 AZ P0-2 — 경로도 봉인과 정확히 같아야 한다 (해시만으로는
        #   같은 내용의 다른 파일을 구별 못 한다).
        if c[4] in ("mpirun", "mpiexec", "srun"):
            if not want_p:
                g.append("RECEIPT_LAUNCHER_UNSEALED(%s 상: root seal 에 launcher_path 가 "
                         "없다)" % c[1])
            elif c[6] != want_p:
                g.append("RECEIPT_LAUNCHER_PATH(%s 상의 launcher 경로 %r ≠ 봉인 %r)"
                         % (c[1], c[6][:40], str(want_p)[:40]))
        # ⛔ 회신 AY P1 — 시각·프로세스 수 형식
        if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", c[0]):
            g.append("RECEIPT_TIME_FORMAT(%r — UTC ...Z 형식이 아니다)" % c[0][:32])
        if not (c[5].isdigit() and int(c[5]) > 0):
            g.append("RECEIPT_NPROC(%r — 양의 정수가 아니다)" % c[5][:24])
        # ⛔⛔ 회신 AY P0-1 — **launcher 도 봉인과 대조한다.**
        #   종전엔 실행파일만 봤다. 그래서 PATH 앞의 가짜 mpirun 이 통과했다.
        if c[4] in ("mpirun", "mpiexec", "srun"):
            if not want_l:
                g.append("RECEIPT_LAUNCHER_UNSEALED(%s 상: root seal 에 launcher 해시가 "
                         "없다 — PATH 에서 집은 launcher 를 대조할 수 없다)" % c[1])
            elif c[7] != want_l:
                g.append("RECEIPT_LAUNCHER_MISMATCH(%s 상의 launcher %s ≠ 봉인 %s — "
                         "봉인 밖 launcher 로 돌았다)" % (c[1], c[7][:12], want_l[:12]))
        elif c[4] == "wrapper":
            if not want_w:
                g.append("RECEIPT_LAUNCHER_UNSEALED(%s 상: wrapper 가 봉인돼 있지 않다)"
                         % c[1])
            elif c[7] != want_w:
                g.append("RECEIPT_LAUNCHER_MISMATCH(%s 상의 wrapper %s ≠ 봉인 %s)"
                         % (c[1], c[7][:12], want_w[:12]))
    for ph in executed_phases or []:
        if ph not in ph_rows:
            g.append("RECEIPT_PHASE_MISSING(%s 상의 OUTCAR 는 있는데 receipt 행이 "
                     "없다 — run_job.sh 밖에서 돌았다)" % ph)
    return g


def potcar_provenance_gates(job_dir, meta, rel=None, man=None):
    """반송된 `POTCAR_PROVENANCE.json` 을 **분석기가 직접 읽고** 게이트한다.

    ⛔ 회신 AF P0-7 — 종전엔 러너만 봤다. 러너는 외주처 기계에서 돌고 우리는 그 결과를
    믿을 근거가 없다. 반송물에 provenance 가 있어야 하고, 그 내용이 이 잡의 종 순서·
    variant 와 맞아야 한다.

    ⛔ 이 함수가 못 하는 것: POTCAR **원본 파일**을 우리가 갖고 있지 않으므로
       `source_sha256` 이 진짜 그 배포판인지는 확인 못 한다. 사이트가 사전 승인된
       allowlist 를 썼다는 것과, 조립 뒤 바꿔치기가 없었다는 것만 본다.
    """
    g = []
    # 계약은 **우리가 조립기를 실어 보낸 잡**에만 적용한다. 그 사실은 files_sha256 에
    # 박혀 있어 지울 수 없다 (지우면 무결성 검사가 따로 잡는다). 합성 픽스처처럼
    # 조립기가 없는 잡에는 요구하지 않는다 — 없는 계약을 만들지 않기 위해서다.
    _fh = (man or {}).get("files_sha256") or {}
    if rel is not None and _fh and ("%s/POTCAR_ASSEMBLE.sh" % rel) not in _fh:
        return []
    if rel is not None and not _fh and not os.path.isfile(
            os.path.join(job_dir, "POTCAR_ASSEMBLE.sh")):
        return []
    pp = os.path.join(job_dir, "POTCAR_PROVENANCE.json")
    if os.path.isfile(os.path.join(job_dir, ".SELFTEST_FIXTURE")):
        return ["PROVENANCE_FIXTURE_MARKER(.SELFTEST_FIXTURE 가 반송물에 있다 — "
                "시험 장치 표시가 production 결과에 섞였다)"]
    if not os.path.isfile(pp):
        return ["POTCAR_PROVENANCE_MISSING(반송물에 없다 — 어떤 POTCAR 로 돌았는지 "
                "확인할 방법이 없다)"]
    try:
        d = json.load(open(pp, encoding="utf-8"))
    except Exception as e:                                   # noqa: BLE001
        return ["POTCAR_PROVENANCE_UNPARSEABLE(%s)" % e]
    if d.get("allowlist_waived"):
        g.append("POTCAR_ALLOWLIST_WAIVED(면제본 — 이 계약에서 폐지됐다)")
    if not d.get("allowlist_sha256"):
        g.append("POTCAR_ALLOWLIST_UNPINNED(allowlist 내용 SHA 가 없다 — 경로만으로는 "
                 "어느 목록이었는지 모른다)")
    if not d.get("assembled_sha256"):
        g.append("POTCAR_ASSEMBLED_SHA_MISSING")
    want_sp = list((meta or {}).get("species_order") or [])
    got_sp = list(d.get("species_order") or [])
    if want_sp and got_sp and want_sp != got_sp:
        g.append("POTCAR_SPECIES_ORDER_MISMATCH(잡 %s vs provenance %s — 종 순서가 "
                 "다르면 다른 계를 계산한 것이다)" % (want_sp, got_sp))
    # ⛔ 회신 AI §B — 종전엔 `expected_variants` 와 `titel_lines` 를 **둘 다 회신 JSON**
    #    에서 읽어 대조했다. 자기일관적인 허위 기록이 그대로 통과한다.
    #    대조 기준은 **우리가 만든** manifest 의 potcar_spec 이어야 한다.
    spec = (man or {}).get("potcar_spec") or (meta or {}).get("potcar_spec") or {}
    ours = [spec.get(e, e) for e in want_sp] if (spec and want_sp) else []
    tit = d.get("titel_lines") or []
    if ours:
        for v in ours:
            if not any(v in str(x) for x in tit):
                g.append("POTCAR_VARIANT_NOT_IN_TITEL(우리 규격 %s 가 회신 TITEL 에 "
                         "없다)" % v)
        if list(d.get("expected_variants") or []) != ours:
            g.append("POTCAR_SPEC_DISAGREES(회신 expected_variants %s ≠ 우리 규격 %s)"
                     % (d.get("expected_variants"), ours))
    else:
        g.append("POTCAR_SPEC_UNAVAILABLE(우리 쪽 규격이 없어 회신을 대조할 기준이 "
                 "없다 — 회신끼리만 맞춰 보는 것은 검증이 아니다)")
    return g


def potcar_identity_gates(jobs, man):
    """묶음 **전체**에서 POTCAR 원본과 VASP 가 하나인가 (회신 AI §B).

    잡 하나씩 봐서는 못 잡는 것을 본다: 잡마다 다른 PAW 배포판이나 다른 VASP 로
    돌았으면, 각 잡은 자기일관적이어도 **에너지를 뺄 수 없다**.

    `man["potcar_pin"]` 이 있으면 그것과도 대조한다 — 그것이 유일한 **외부 기준**이다.
    없으면 잡 사이 일치만 본다(자기일관성). 그 한계를 결과에 적는다.
    """
    res = {"schema": "potcar_identity/v1", "blocking": [], "n_with_prov": 0,
           "pin": (man or {}).get("potcar_pin"), "observed": {}}
    _spec_map = (man or {}).get("potcar_spec") or {}
    src, ver = {}, {}
    # ⛔ 회신 AR P0-6 — attestation 의 TITEL 을 **관측과 대조**하려면 관측 TITEL 을
    #   variant 별로 모아야 한다. provenance 의 titel_lines 와 OUTCAR 의 titels
    #   둘 다 " PAW_PBE Ni_pv 06Sep2000" 꼴이라 variant 토큰으로 색인한다.
    _titel_obs = {}

    def _titel_index(line):
        for _tok in str(line or "").replace("=", " ").split():
            if _tok in _spec_map.values() or _tok in _spec_map:
                _titel_obs.setdefault(_tok, set()).add(str(line).strip())

    for jn, jr in sorted((jobs or {}).items()):
        pv = (jr.get("geom") or {}).get("potcar_provenance") or jr.get("_prov")
        for _tl in ((pv or {}).get("titel_lines") or []):
            _titel_index(_tl)
        for _tl in (((jr.get("static") or {}) or {}).get("titels") or []):
            _titel_index(_tl)
        if not pv:
            continue
        res["n_with_prov"] += 1
        for e, s in (pv.get("source_sha256") or {}).items():
            src.setdefault(e, {}).setdefault(str(s), []).append(jn)
        v = ((jr.get("static") or {}) or {}).get("vasp_version")
        if v:
            ver.setdefault(str(v), []).append(jn)
    for e, d in src.items():
        if len(d) > 1:
            res["blocking"].append(
                "POTCAR_SOURCE_SPLIT(%s 의 원본 sha 가 묶음 안에서 %d 종 — 다른 PAW "
                "배포판의 에너지를 뺄 수 없다)" % (e, len(d)))
    if len(ver) > 1:
        res["blocking"].append(
            "VASP_VERSION_SPLIT(묶음 안에서 %s — 다른 코드 세대의 에너지를 뺄 수 없다)"
            % sorted(ver))
    res["observed"] = {"source_sha256": {e: sorted(d) for e, d in src.items()},
                       "vasp_version": sorted(ver),
                       "titel_by_variant": {k: sorted(v) for k, v in
                                            sorted(_titel_obs.items())}}
    # ⛔⛔ 회신 AO P0-8 (2026-08-31) — 종전 검사는 **관측된 것끼리 갈리지 않으면 통과**
    #   였다. source sha 가 일부·전부 없어도, VASP 버전이 0개 관측이어도 막지 않았다.
    #   그래서 `identity_scope = self_consistent_only`("14잡 신원 일치 확인") 라벨이
    #   사실보다 강했다. ⇒ **에너지를 낸 모든 잡**에 대해 기대되는 **모든 variant** 의
    #   원본 SHA256(64자리)과 정확한 VASP 버전을 필수로 한다.
    #   ⚠ 아직 안 돈 잡은 세지 않는다 (단계별 실행에서 2단계가 비어 있는 것은 정상).

    def _is_hex64(x):
        x = str(x or "")
        return len(x) == 64 and all(c in "0123456789abcdefABCDEF" for c in x)

    # ⛔⛔ 회신 AP #8/Q7 (2026-08-31) — 완주 판정이 **실제 record 모양과 달랐다.**
    #   생성부는 `rec = {..., "static": ocs.get("static"), ...}` 로 **미실행 잡에도
    #   `static: None` 키를 넣는다.** 그런데 여기서는 `"static" in jr` 로 완주를 셌다
    #   ⇒ 안 돈 잡까지 전부 "완주" 로 세고 provenance 를 요구했다.
    #   내 selftest 픽스처는 키 자체를 빼서 이 버그를 **재현하지 못했다** —
    #   회신 AL P0-3 과 같은 실패 방식이다(픽스처가 내 오해를 그대로 옮겼다).
    #   ⇒ AP 가 지정한 세 단계로 나눈다:
    #     attempted  : OUTCAR 를 읽었다 (static 레코드가 있다)
    #     completed  : 정상 종료 + 최종 에너지가 있다
    #     usable     : completed + 그 상의 게이트를 통과했다
    #   완전성(provenance·fingerprint·버전)은 **completed** 에만 건다.
    def _job_stage(jr):
        st = jr.get("static")
        if not isinstance(st, dict):
            return "not_attempted"          # None 이거나 키가 없다 = 안 돌았다
        if not st.get("normal_end") or st.get("E0") is None:
            return "attempted"              # OUTCAR 는 있는데 완주가 아니다
        return "completed" if not jr.get("gates") else "completed_gated"

    _ran, _noprov, _incomplete, _nover = [], [], [], []
    _stage_census = {}
    for jn, jr in sorted((jobs or {}).items()):
        _sg = _job_stage(jr)
        _stage_census[_sg] = _stage_census.get(_sg, 0) + 1
        if not _sg.startswith("completed"):
            continue                       # 안 돌았거나 완주 못 한 잡 — 완전성 대상 아님
        _ran.append(jn)
        pv = (jr.get("geom") or {}).get("potcar_provenance") or jr.get("_prov")
        if not pv:
            _noprov.append(jn)
            continue
        _els = list((jr.get("meta") or {}).get("species_order") or [])
        _want_v = ([str(_spec_map.get(e, e)) for e in _els]
                   or sorted((pv.get("source_sha256") or {})))
        _have = {str(k): v for k, v in (pv.get("source_sha256") or {}).items()}
        # ⚠ 조립기는 **variant 키**(Ni_pv)로 기록하고 옛 기록은 **원소 키**(Ni)다.
        #   pin 대조와 **같은 정규화**를 쓴다 — 요구하는 것은 "그 fingerprint 가
        #   있고 64자리인가" 이지 키 철자가 아니다.
        _alias = {str(_spec_map.get(e, e)): e for e in _els}
        _miss = [v for v in _want_v
                 if not (_is_hex64(_have.get(v))
                         or _is_hex64(_have.get(_alias.get(v, v))))]
        if _miss:
            _incomplete.append("%s:%s" % (jn, _miss))
        if not ((jr.get("static") or {}).get("vasp_version")):
            _nover.append(jn)
    if _ran:
        if _noprov:
            res["blocking"].append(
                "POTCAR_PROVENANCE_MISSING(%d/%d 완주잡에 provenance 가 없다 %s — "
                "없는 것을 '갈리지 않음' 으로 읽지 않는다)"
                % (len(_noprov), len(_ran), _noprov[:3]))
        if _incomplete:
            res["blocking"].append(
                "POTCAR_SOURCE_INCOMPLETE(%d잡에서 기대 variant 의 원본 SHA256 이 "
                "빠졌거나 64자리가 아니다 %s)" % (len(_incomplete), _incomplete[:3]))
        if _nover:
            res["blocking"].append(
                "VASP_VERSION_UNOBSERVED(%d/%d 완주잡에 VASP 버전 관측이 없다 %s — "
                "0개 관측은 일치가 아니다)" % (len(_nover), len(_ran), _nover[:3]))
    res["completeness"] = {"n_jobs": len(jobs or {}),
                           "n_completed": len(_ran),
                           "stage_census": _stage_census,
                           "n_with_prov": res["n_with_prov"],
                           "n_no_prov": len(_noprov),
                           "n_incomplete_variants": len(_incomplete),
                           "n_without_vasp_version": len(_nover),
                           "판정": ("완전성은 **completed**(정상 종료 + 최종 에너지) "
                                    "잡에만 건다. 미실행·중단 잡은 대상이 아니다 — "
                                    "단계별 실행에서 2단계가 비어 있는 것은 정상이다")}
    # ⛔ 회신 AO Q1 — **생산 전에 봉인한** variant 별 원본 fingerprint(root seal)와
    #   대조한다. 사후 provenance 끼리만 비교하는 것은 사전 승인과 같지 않다.
    _seal = ((man or {}).get("_potcar_root_seal") or {}).get("source_sha256") or {}
    _seal_rec = ((man or {}).get("_potcar_root_seal") or {})
    # ⛔⛔ 회신 AR P0-5/P0-6 · 해제조건 7 (2026-08-31) — 종전 검증은 **fail-open** 이었다.
    #   `source_sha256` 과 `sealed_before_production:true` 만 있는 반쪽 봉인도
    #   `sealed_root_v13` 라벨을 받았고, `FAKE_RELEASE` + 실제로 쓰지 않는
    #   `UNRELATED` variant 하나짜리 합성 attestation 도 `usable:true` 가 됐다.
    #   ⇒ ① 봉인 schema 를 **전부 필수**로 ② 봉인·attestation·실제 계획 잡의
    #     variant 집합을 **완전일치**로 ③ manifest/ZIP/allowlist/VASP 신원까지 결박.
    #   ⚠ 여기서 "계획 잡" 은 미실행 2단계를 포함한다 — 봉인은 앞으로 돌 잡의
    #     기대 POTCAR 까지 포괄해야 사전 승인이다 (AR Q4).
    # 🔴 회신 AV P0-1 — planned 에 없으면 **그 잡의 job.json** 에서 읽는다.
    #   manifest 한 곳에만 의존하면 구판 번들에서 통째로 막힌다.
    _plan_var, _plan_nospec = set(), []
    for _pj, _pl in sorted(((man or {}).get("planned") or {}).items()):
        _els = list(((_pl or {}).get("meta") or {}).get("species_order") or [])
        if not _els:
            try:
                _jf = os.path.join(str((man or {}).get("_root") or "."), _pj, "job.json")
                if os.path.isfile(_jf):
                    _els = list((json.load(open(_jf, encoding="utf-8"))
                                 .get("species_order")) or [])
            except Exception:                                # noqa: BLE001
                _els = []
        if not _els:
            _plan_nospec.append(_pj)
            continue
        _plan_var |= {str(_spec_map.get(e, e)) for e in _els}
    _mh = (man or {}).get("_manifest_sha256_actual")
    _zip_obs = (man or {}).get("_zip_sha256_observed")
    _cov, _covwhy = False, []
    if _seal:
        res["root_seal_variants"] = sorted(_seal)
        res["root_seal_meta"] = {
            k: _seal_rec.get(k) for k in
            ("schema", "allowlist_sha256", "manifest_sha256", "vasp_executable",
             "vasp_executable_sha256", "vasp_version_banner", "sealed_at_utc",
             "sealed_before_production")}
        # ── ① schema 전부 필수 (없는 것은 통과가 아니다) ──────────────────
        _seal_need = ("schema", "allowlist_sha256", "manifest_sha256",
                      "vasp_executable", "vasp_executable_sha256",
                      "vasp_version_banner", "sealed_at_utc", "bundle_zip_sha256",
                      "assembled_sha256_by_job", "sealed_before_production_evidence")
        _seal_miss = [k for k in _seal_need if not _seal_rec.get(k)]
        if _seal_miss:
            res["blocking"].append(
                "ROOT_SEAL_INCOMPLETE_SCHEMA(봉인에 %s 가 없다 — 반쪽 봉인은 "
                "사전 승인이 아니다)" % _seal_miss)
        if str(_seal_rec.get("schema") or "") != "potcar_root_seal/v2":
            res["blocking"].append(
                "ROOT_SEAL_SCHEMA(schema=%r — potcar_root_seal/v2 가 아니다)"
                % _seal_rec.get("schema"))
        for _hk in ("allowlist_sha256", "manifest_sha256", "vasp_executable_sha256",
                    "bundle_zip_sha256"):
            if _seal_rec.get(_hk) and not _is_hex64(_seal_rec[_hk]):
                res["blocking"].append("ROOT_SEAL_BAD_HASH(%s)" % _hk)
        # 봉인이 말하는 ZIP 과 실제로 받은 ZIP 이 같은가 (둘 다 있을 때만 대조)
        if (_zip_obs and _seal_rec.get("bundle_zip_sha256")
                and _seal_rec["bundle_zip_sha256"] != _zip_obs):
            res["blocking"].append(
                "ROOT_SEAL_ZIP_MISMATCH(봉인 %s ≠ 받은 ZIP %s — 다른 배포본을 "
                "봉인했다)" % (str(_seal_rec["bundle_zip_sha256"])[:12], str(_zip_obs)[:12]))
        # ── ② 봉인이 **계획 잡 전체**를 포괄하는가 ────────────────────────
        if _plan_nospec:
            res["blocking"].append(
                "ROOT_SEAL_PLAN_UNREADABLE(계획 잡 %d개에 species_order 가 없어 "
                "필요한 variant 를 셀 수 없다: %s)"
                % (len(_plan_nospec), _plan_nospec[:3]))
        elif _plan_var and set(_seal) != _plan_var:
            res["blocking"].append(
                "ROOT_SEAL_PLAN_COVERAGE(봉인 variant %s ≠ 계획 잡이 요구하는 %s — "
                "미실행 잡의 기대 POTCAR 까지 포괄해야 사전 승인이다)"
                % (sorted(_seal), sorted(_plan_var)))
        _asm = (_seal_rec.get("assembled_sha256_by_job") or {})
        _plan_dirs = sorted((man or {}).get("planned") or {})
        _asm_miss = [j for j in _plan_dirs if j not in _asm]
        if _asm and _asm_miss:
            res["blocking"].append(
                "ROOT_SEAL_JOB_COVERAGE(봉인의 assembled 해시에 계획 잡 %d개가 "
                "없다: %s)" % (len(_asm_miss), _asm_miss[:3]))
        # ⛔⛔ 회신 AS 해제조건 4 (2026-08-31) — 종전엔 **키만** 봤다. 봉인이
        #   기록한 조립본 해시를 **반송된 provenance 의 실제 값**과 대조하지
        #   않으면, 봉인 뒤에 POTCAR 를 갈아끼워도 잡히지 않는다.
        _asm_bad, _asm_unver = [], []
        for _jn, _jr in sorted((jobs or {}).items()):
            _pv = (_jr.get("geom") or {}).get("potcar_provenance") or _jr.get("_prov")
            if not _pv:
                continue                      # 완전성 게이트가 따로 본다
            _got = _pv.get("assembled_sha256")
            _want = _asm.get(_jn)
            if _want is None:
                _asm_unver.append(_jn)
            elif not _got:
                _asm_unver.append("%s(반송에 assembled 없음)" % _jn)
            elif str(_got) != str(_want):
                _asm_bad.append("%s: 봉인 %s ≠ 반송 %s"
                                % (_jn, str(_want)[:12], str(_got)[:12]))
        if _asm_bad:
            res["blocking"].append(
                "ROOT_SEAL_ASSEMBLED_MISMATCH(봉인한 POTCAR 와 실제로 쓴 POTCAR 가 "
                "다르다 %d건: %s)" % (len(_asm_bad), _asm_bad[:3]))
        if _asm_unver and _ran:
            res["blocking"].append(
                "ROOT_SEAL_ASSEMBLED_UNVERIFIED(조립본 해시를 대조하지 못한 잡 "
                "%d건: %s — 확인 못 한 것은 통과가 아니다)"
                % (len(_asm_unver), _asm_unver[:3]))
        res["assembled_crosscheck"] = {
            "compared": len([1 for j, r in (jobs or {}).items()
                             if ((r.get("geom") or {}).get("potcar_provenance")
                                 or r.get("_prov"))]),
            "mismatch": len(_asm_bad), "unverified": len(_asm_unver)}
        # ── ③ 이 묶음의 MANIFEST 인가 (해시가 없으면 그것도 실패다) ────────
        if not _seal_rec.get("manifest_sha256") or not _mh:
            res["blocking"].append(
                "ROOT_SEAL_MANIFEST_UNBOUND(봉인 또는 현재 MANIFEST 해시가 없어 "
                "결박을 확인할 수 없다)")
        elif _seal_rec["manifest_sha256"] != _mh:
            res["blocking"].append(
                "ROOT_SEAL_WRONG_BUNDLE(봉인이 다른 MANIFEST 에 대한 것이다: "
                "봉인 %s ≠ 지금 %s)" % (_seal_rec["manifest_sha256"][:12], _mh[:12]))
        if _seal_rec.get("sealed_before_production") is not True:
            res["blocking"].append(
                "ROOT_SEAL_NOT_PREPRODUCTION(봉인이 생산 전이라는 근거가 없다)")
        # ── ④ 실제로 돌린 VASP 와 결박 ────────────────────────────────────
        _seal_ver = str(_seal_rec.get("vasp_version_banner") or "")
        _obs_ver = sorted(ver)
        _ver_bad = [v for v in _obs_ver if v and v not in _seal_ver]
        if _obs_ver and _seal_ver and _ver_bad:
            res["blocking"].append(
                "ROOT_SEAL_VASP_MISMATCH(봉인 배너 %r 에 관측 버전 %s 가 없다 — "
                "봉인한 바이너리로 돌았다는 근거가 없다)" % (_seal_ver[:40], _ver_bad[:2]))
        for _v, _sh in sorted(_seal.items()):
            _got = sorted(src.get(_v, {}))
            if _ran and not _got:
                res["blocking"].append(
                    "ROOT_SEAL_UNOBSERVED(%s: 봉인돼 있는데 회신에 원본 sha 가 없다)" % _v)
            elif _got and _got != [str(_sh)]:
                res["blocking"].append(
                    "ROOT_SEAL_MISMATCH(%s: 봉인 %s ≠ 관측 %s — 생산 전에 승인한 "
                    "Hamiltonian root 가 아니다)" % (_v, str(_sh)[:12], [g[:12] for g in _got]))
        _unsealed = sorted(set(src) - set(_seal))
        if _unsealed:
            res["blocking"].append(
                "ROOT_SEAL_INCOMPLETE(봉인에 없는 variant 가 관측됐다 %s)" % _unsealed)
    elif _ran and (man or {}).get("files_sha256"):
        res["root_seal_absent"] = True
    # ⛔⛔ 회신 AP #12 — 원고 Methods 문구를 **여기서 하나로** 만든다. 사람이
    #   고르게 두면 강한 쪽을 고르게 된다. attestation 유무가 문구를 정한다.
    _att = (man or {}).get("_potcar_attestation") or {}
    _att_ok = False
    _att_why = []
    if _att:
        # ⛔⛔ 회신 AR P0-6 · 해제조건 7 — **exact-set 및 교차 결박**을 요구한다.
        #   종전엔 `FAKE_RELEASE` + 실제 쓰지 않는 `UNRELATED` variant 하나짜리
        #   합성 attestation 도 usable:true 였다. 다음 셋의 **완전일치**를 본다:
        #     attestation variants = root-seal source variants = 계획 잡 POTCAR variants
        # 🔴 회신 AT P0-4 — 필수 목록에 `schema` 가 없었다. 스키마가 무엇이든
        #   나머지가 채워져 있으면 통과했다.
        _need_att = ("schema", "release_label", "variants", "vasp_version_raw",
                     "vasp_executable", "vasp_executable_sha256", "allowlist_sha256",
                     "manifest_sha256", "bundle_zip_sha256", "site", "created_utc",
                     "made_before_production_evidence")
        _att_miss = [k for k in _need_att if not _att.get(k)]
        _av = set(_att.get("variants") or {})
        if _att_miss:
            _att_why.append("ATTESTATION_INCOMPLETE(필드 누락 %s)" % _att_miss)
        if _att.get("schema") and _att["schema"] != "potcar_attestation/v1":
            _att_why.append("ATTESTATION_SCHEMA_UNKNOWN(%r — 이 도구가 아는 스키마가 "
                            "아니다)" % (_att["schema"],))
        # 🔴 회신 AT P0-4 — `made_before_production` 을 **불리언으로** 본다
        #   (문자열 "true" 는 파이썬에서 참이지만 증서가 아니다)
        if _att.get("made_before_production") is not True:
            _att_why.append("ATTESTATION_NOT_PREPRODUCTION(made_before_production 이 "
                            "불리언 True 가 아니다: %r)"
                            % (_att.get("made_before_production"),))
        if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$",
                        str(_att.get("created_utc") or "")):
            _att_why.append("ATTESTATION_TIME_MALFORMED(created_utc %r)"
                            % (_att.get("created_utc"),))
        # 🔴🔴 회신 AT P0-4 — **root seal 이 없으면 attestation 을 쓸 수 없다.**
        #   종전엔 집합 대조가 `if _seal and …` 이라 봉인이 없으면 통째로 건너뛰었고,
        #   임의 release label + 비정상 hash 의 attestation 이 usable:true 로 갔다.
        if not _seal:
            _att_why.append("ATTESTATION_WITHOUT_ROOT_SEAL(root seal 이 없다 — "
                            "attestation 만으로 release 를 주장하지 않는다. 봉인이 "
                            "'이 계산들이 한 트리에서 나왔다' 를 대는 쪽이다)")
        if (_att.get("manifest_sha256") and _mh
                and _att["manifest_sha256"] != _mh):
            _att_why.append("ATTESTATION_WRONG_BUNDLE(다른 MANIFEST 에 대한 "
                            "attestation 이다: %s ≠ %s)"
                            % (str(_att["manifest_sha256"])[:12], str(_mh)[:12]))
        elif not _mh:
            _att_why.append("ATTESTATION_MANIFEST_UNBOUND(현재 MANIFEST 해시가 없다)")
        # 정확한 ZIP SHA — 받은 ZIP 과 결박한다 (관측값이 없으면 결박 실패다)
        if not _zip_obs:
            _att_why.append("ATTESTATION_ZIP_UNBOUND(받은 ZIP 의 SHA256 이 없다 — "
                            "`--zip_sha256 <sha>` 로 넘기거나 ZIP_SHA256.txt 를 "
                            "번들에 넣어야 정확한 ZIP 결박을 확인할 수 있다)")
        elif str(_att.get("bundle_zip_sha256") or "") != str(_zip_obs):
            _att_why.append("ATTESTATION_ZIP_MISMATCH(attestation %s ≠ 받은 ZIP %s)"
                            % (str(_att.get("bundle_zip_sha256"))[:12], str(_zip_obs)[:12]))
        if (_att.get("allowlist_sha256") and _seal_rec.get("allowlist_sha256")
                and _att["allowlist_sha256"] != _seal_rec["allowlist_sha256"]):
            _att_why.append("ATTESTATION_ALLOWLIST_MISMATCH(봉인과 다른 allowlist)")
        for _k in ("vasp_executable", "vasp_executable_sha256"):
            if (_att.get(_k) and _seal_rec.get(_k) and _att[_k] != _seal_rec[_k]):
                _att_why.append("ATTESTATION_VASP_MISMATCH(%s: attestation 과 봉인이 "
                                "다른 바이너리를 말한다)" % _k)
        # 🔴🔴 렌즈4 P0-1 (2026-09-03) — 버전은 **토큰끼리** 비교한다. 종전 `raw not in
        #   banner` 는 v34 봉인(BH P0-1)이 `vasp.<버전>` 토큰만 담게 되자, MAKE 가 적은
        #   여러 줄 stdout 원문이 토큰의 부분문자열일 수 없어 **항상** 불일치였다 —
        #   선택 attestation 을 성실히 돌린 외주처가 1단계를 다 돌린 **뒤에야** potcar_identity 에서
        #   막히는 함정. 픽스처는 방향이 반대(banner 쪽이 더 김)여서 425/425 가 통과했다.
        #   토큰이 attestation 쪽에 없으면 그것도 '확인 못 함 = 일치 아님' 이다.
        # 🔴 렌즈1′ P1-1 — 행 앵커 (경로 에코를 버전으로 읽지 않는다) + 앞뒤 공백 제거 후 비교
        _VTOK = r"(?m)^[ \t]*vasp\.[0-9][A-Za-z0-9._-]*"
        _vt_att = re.search(_VTOK, str(_att.get("vasp_version_raw") or ""))
        _vt_seal = re.search(_VTOK, str(_seal_rec.get("vasp_version_banner") or ""))
        if _att.get("vasp_version_raw") and _seal_rec.get("vasp_version_banner"):
            if not _vt_att:
                _att_why.append("ATTESTATION_VASP_VERSION_UNREADABLE(attestation 의 "
                                "vasp_version_raw %r 에 'vasp.<버전>' 토큰이 없다 — "
                                "확인 못 한 것은 일치가 아니다)"
                                % (str(_att["vasp_version_raw"])[:40],))
            elif _vt_seal and _vt_att.group(0).strip() != _vt_seal.group(0).strip():
                _att_why.append("ATTESTATION_VASP_VERSION_MISMATCH(%r vs 봉인 %r)"
                                % (_vt_att.group(0), _vt_seal.group(0)))
        _att_var_bad = [v for v, d in (_att.get("variants") or {}).items()
                        if not _is_hex64((d or {}).get("source_sha256"))]
        if _att_var_bad:
            _att_why.append("ATTESTATION_VARIANT_SHA_BAD(%s)" % _att_var_bad[:3])
        # variant **집합**의 완전일치 — 부분집합도 초과집합도 안 된다
        if _seal and _av != set(_seal):
            _att_why.append("ATTESTATION_SET_MISMATCH(attestation %s ≠ root seal %s)"
                            % (sorted(_av), sorted(_seal)))
        if _plan_var and _av != _plan_var:
            _att_why.append("ATTESTATION_PLAN_MISMATCH(attestation %s ≠ 계획 잡이 "
                            "요구하는 %s — 쓰지도 않는 variant 로는 release 를 "
                            "주장할 수 없다)" % (sorted(_av), sorted(_plan_var)))
        # TITEL·embedded hash 를 variant 마다 요구하고 관측과 대조한다
        for _v, _d in sorted((_att.get("variants") or {}).items()):
            _d = _d or {}
            if not _d.get("titel") or not _d.get("embedded_hash"):
                _att_why.append("ATTESTATION_VARIANT_FIELDS(%s: titel/embedded_hash "
                                "가 없다)" % _v)
            if _seal.get(_v) and _seal[_v] != _d.get("source_sha256"):
                _att_why.append("ATTESTATION_SEAL_MISMATCH(%s: attestation 과 root "
                                "seal 의 원본 sha 가 다르다)" % _v)
            _obs_t = sorted(set(_titel_obs.get(_v) or []))
            if _obs_t and _d.get("titel") and _d["titel"] not in _obs_t:
                _att_why.append("ATTESTATION_TITEL_MISMATCH(%s: attestation %r 가 "
                                "관측 TITEL %s 에 없다)" % (_v, _d["titel"], _obs_t[:2]))
        # `made_before_production` 은 **자기선언이 아니라 산출물 부재**로 입증한다
        if _att.get("made_before_production") is not True:
            _att_why.append("ATTESTATION_NOT_PREPRODUCTION(계산 전에 만든 근거가 없다)")
        elif not str(_att.get("made_before_production_evidence") or "").strip():
            _att_why.append("ATTESTATION_PREPRODUCTION_UNEVIDENCED(선언만 있고 "
                            "산출물 부재 검사 기록이 없다)")
        _att_ok = not _att_why
        res["blocking"].extend(_att_why)
    res["attestation"] = {
        "present": bool(_att), "usable": _att_ok,
        "why_not": _att_why[:6],
        "checked": ["schema 필드 전건", "manifest 해시", "정확한 ZIP 해시",
                    "allowlist", "VASP 경로·해시·버전", "variant 집합 3자 완전일치",
                    "variant 별 TITEL·embedded hash·원본 sha", "생산 전 근거"],
        "release_label": _att.get("release_label"),
        "site": _att.get("site"), "created_utc": _att.get("created_utc")}
    # ── 회신 AR 해제조건 5 — stage-1 선결조건이 읽는 **봉인 포괄** 판정 ────
    _seal_blk = [b for b in res["blocking"] if b.startswith("ROOT_SEAL")]
    _cov = bool(_seal) and not _seal_blk
    res["root_seal_coverage"] = {
        "ok": _cov,
        "why": (_seal_blk[:3] if _seal_blk else
                ("봉인이 없다 — 생산 전 root seal 을 만들지 않았다" if not _seal else
                 "봉인이 현재 MANIFEST·계획 잡 %d개·variant %s 를 포괄한다"
                 % (len((man or {}).get("planned") or {}), sorted(_seal)))),
        "sealed_variants": sorted(_seal),
        "planned_variants": sorted(_plan_var),
        "⛔": ("이 판정은 '봉인이 이 묶음을 포괄한다' 까지다 — 봉인한 트리가 "
               "공식 배포판인지는 attestation 의 몫이다")}
    _vv = sorted(ver) or [_att.get("vasp_version_raw")]
    # ⛔ 회신 AR Q5 — 필드명을 `methods_sentence` 에서 바꾼다. 도구는 **후보 문구**를
    #   고를 뿐 원고 채택 권한이 없다. 최종 채택은 사람의 검토를 거친다.
    # ⛔⛔ 회신 BA P0-3 (2026-09-02) — **자기선언 label 은 공식 release 의 독립
    #   증거가 아니다.** 리뷰어 재현: `release_label` 만 `FAKE_RELEASE` 로 바꾸고
    #   나머지 봉인·variant 를 맞추니 `blocking=[]` · `paw_release_attested` 가 나왔다.
    #   attestation 은 "현장이 이 트리를 이렇게 부른다" 를 기록할 뿐, 그 이름이
    #   아카이브된 배포판과 같은지는 **우리가 확인한 적이 없다.**
    #   ⇒ 외부 앵커(사전 승인 해시 또는 서명)가 없으면 `attested` 로 올리지 않는다.
    # ⛔⛔ 회신 BB P0-6 (2026-09-02) — **바이트 앵커는 이름을 인증하지 않는다.**
    #   BA P0-3 에서 `potcar_pin.source_sha256` 만 있으면 `paw_release_attested`
    #   로 올렸는데, 그 pin 은 *우리가* 적어 둔 바이트 지문이다. "이 바이트가 pin 과
    #   같다" 는 말하지만 "그 바이트가 potpaw_PBE.54 다" 는 말하지 못한다.
    #   즉 자기선언 `release_label` 이 바이트 pin 하나로 공식 release 이름으로
    #   승격됐다. 리뷰어 Q4: label 은 `site_reported_release_label` **메타데이터로만**
    #   남길 수 있고, 공식 release 를 주장하려면 외부 앵커가 **{label, 전체 source
    #   SHA map}** 을 함께 결박해야 한다.
    #   ⇒ pin 이 label 을 담고, 그 label 이 현장 신고와 같고, pin 의 SHA map 이
    #     attestation 의 variant 를 **전부** 덮을 때만 이름을 주장한다.
    _anchor = (man or {}).get("potcar_pin") or {}
    _pin_map = _anchor.get("source_sha256") or {}
    _att_vars = set((_att.get("variants") or {}))
    _pin_label = _anchor.get("release_label")
    _label_bound = bool(_pin_label) and _pin_label == _att.get("release_label")
    _map_covers = bool(_att_vars) and _att_vars <= set(_pin_map)
    _anchored = bool(_pin_map) and _label_bound and _map_covers
    res["release_label_anchor_detail"] = {
        "pin_has_sha_map": bool(_pin_map),
        "pin_declares_label": _pin_label,
        "label_matches_site_report": _label_bound,
        "sha_map_covers_all_variants": _map_covers,
        "uncovered_variants": sorted(_att_vars - set(_pin_map)),
        "⛔": ("바이트 pin 만으로는 **이름**을 인증하지 못한다 (회신 BB P0-6 · Q4). "
               "`{label, 전체 source SHA map}` 을 함께 결박한 외부 앵커여야 한다."),
    }
    if _att_ok and not (res.get("blocking") or []) and _anchored:
        res["allowed_claim"] = "paw_release_attested"
        res["release_label_anchor"] = "potcar_pin (label + 전체 SHA map 결박)"
        res["methods_candidate"] = (
            "Calculations were performed using VASP %s with PAW-PBE datasets from the "
            "%s release (%s). Each source dataset was identified by its embedded VASP "
            "hash and a full-file SHA-256 fingerprint fixed before production; the "
            "fingerprints were identical across all energy-bearing calculations. "
            "No numerical equivalence to earlier calculation waves was assumed."
            % (_vv[0], _att.get("release_label"),
               ", ".join(sorted(_att.get("variants") or {}))))
    elif _att_ok and not (res.get("blocking") or []) and not _anchored:
        # attestation 은 통과했지만 **이름을 결박한 외부 앵커가 없다.**
        res["allowed_claim"] = "self_declared_label_only"
        res["release_label_anchor"] = None
        # ⛔ 회신 BB P0-6 · Q4 — 이름은 **메타데이터**로만 남긴다
        res["site_reported_release_label"] = _att.get("release_label")
        res["release_label_⛔"] = (
            "attestation 의 `release_label`(%r)은 **현장 자기선언**이다. 아카이브된 "
            "배포판과 같은지 확인한 적이 없다 — 리뷰어가 `FAKE_RELEASE` 로 바꿔도 "
            "통과하는 것을 재현했다 (회신 BA P0-3). 외부 앵커(`--potcar_pin` 또는 "
            "서명)가 있어야 `paw_release_attested` 로 올린다."
            % _att.get("release_label"))
        res["methods_candidate"] = (
            "⚠ 공식 release 를 단정하지 않는다 — attestation 은 있으나 그 label 이 "
            "**자기선언**이라 외부 배포판과 결박되지 않았다. 허용 문구: 'the reported "
            "value is conditional on this bundle's PAW dataset; the dataset label was "
            "reported by the computing site and not independently anchored.'")
        res["methods_candidate_⛔"] = (
            "이 문구는 **탐색용**이다. 원고 인용에는 외부 앵커가 필요하다 (BA P0-3·Q5).")
    else:
        res["allowed_claim"] = "bundle_conditional_only"
        res["methods_candidate"] = (
            "⚠ 공식 release 를 단정하지 않는다 — 계산 전 attestation 이 %s. "
            "허용 문구: 'the reported D is conditional on this bundle's PAW dataset; "
            "the fingerprints were not independently matched to an archived POTCAR "
            "release.' (회신 AP #12·Q3)"
            % ("없다" if not _att else "있으나 사용 불가"))
        res["methods_candidate_⛔"] = (
            "이 문구는 내부 기록용으로는 되지만 **원고 Methods 로는 약하다**(AP Q3). "
            "원고에 PAW release 를 적으려면 POTCAR_ATTESTATION_REQUEST.md 를 "
            "외주처에 보내 계산 전에 받아야 한다")
    res["methods_candidate_⚠"] = ("이것은 **후보 문구**다 (회신 AR Q5). 도구가 "
                                  "검증 상태로 상한을 정할 뿐이고, 원고 채택은 "
                                  "사람이 검토한 뒤에 한다. 더 강한 문장으로 "
                                  "바꿔 쓰지 말 것.")
    # ⛔ 회신 AJ — 종전 pin 대조는 **세 군데가 fail-open** 이었다:
    #   ① 관측이 비면 `if got and ...` 이 참이 안 돼 조용히 건너뛰었다
    #   ② VASP 버전이 하나도 관측 안 되면 `sorted(ver) in ([], ...)` 이 통과시켰다
    #   ③ 조립기는 **variant 키**(Li_sv·Ni_pv)로 기록하는데 pin 예시는 **원소 키**(Li·Ni)라
    #      관측이 안 잡혀 ①로 빠졌다. ⇒ pin 을 variant 키로 정규화해 대조한다.
    pin = res["pin"] or {}
    if not pin:
        # 거부의 **1차 위치는 생성기**다 (--potcar_pin 없으면 번들을 안 만든다).
        # 분석기는 실물 번들(배포 해시를 가진 manifest)에서만 부재를 막는다 —
        # 합성 픽스처에 없는 계약을 요구하지 않기 위해서다.
        if (man or {}).get("files_sha256"):
            # ⚠⚠ 2026-08-31 판정 — **차단에서 라벨로 내린다.**
            #   회신 AN Q4 는 사전 pin 을 요구했다. 그 근거는 "승인한 트리를 썼는가" 인데,
            #   **우리는 그 주장을 하지 않는다** (v12 를 새 provenance root 로 선언했고
            #   2026-08-12 wave 와의 동등성은 이미 철회했다).
            #   그리고 D 는 **이 번들 안에서 닫힌 양**이다 — 네 에너지가 전부 같은 런,
            #   같은 POTCAR 에서 나오므로 트리가 무엇이든 그 안에서 일관되면 D 는 유효하다.
            #   ⇒ 잡 사이 일치가 확인되면 값을 내되, **무엇을 확인하지 못했는지 라벨로
            #     결과에 박는다.** 없는 검증을 있는 척하지 않는 것이 요점이다.
            #   ⛔ 잡 사이 일치조차 깨지면 그건 여전히 blocking 이다 (아래 다른 게이트들).
            res["pin_absent"] = True
            # ⛔ 회신 AO P0-8/Q1 — 종전 문구("14잡의 POTCAR 신원이 서로 일치")는
            #   실측보다 강했다. 위 완전성 게이트가 통과했을 때만 그렇게 말할 수 있고,
            #   root seal 이 있을 때만 "생산 전에 고정한 root" 라고 말할 수 있다.
            _c = res.get("completeness") or {}
            _complete = bool(_c.get("n_completed")) and not (
                _c.get("n_no_prov") or _c.get("n_incomplete_variants")
                or _c.get("n_without_vasp_version"))
            # ⛔⛔ 회신 AP #7 — 종전엔 `ROOT_SEAL_MISMATCH` 가 있어도 동시에
            #   `sealed_root_v13` 라벨이 나올 수 있었다. **identity blocking 이
            #   하나라도 있으면 sealed 라벨을 발행하지 않는다.**
            _no_block = not (res.get("blocking") or [])
            res["identity_scope"] = (
                ("sealed_root_v13 — variant 별 원본 SHA256 을 **생산 전에 봉인**하고 "
                 "완주 전 잡이 그 봉인과 일치함을 확인했다. 이전 wave 와의 수치적 "
                 "동등성은 가정하지 않는다. ⚠ 공식 release 여부는 이 라벨이 "
                 "보증하지 않는다 (POTCAR_ATTESTATION.json 이 그 몫이다)"
                 if res.get("root_seal_variants") and _complete and _no_block else
                 "self_consistent_only — 완주 잡들의 POTCAR 신원이 서로 일치한다. "
                 "**사전 승인된 트리와 대조하지 않았다** (생산 전 root seal 없음). "
                 "따라서 '이전 wave 와 같은 PP' 는 주장하지 않는다"
                 if _complete and _no_block else
                 "unverified — 원본 fingerprint 또는 VASP 버전 관측이 불완전하다. "
                 "'신원 일치 확인' 이라고 쓰지 말 것"))
            res["⚠"] = ("pin 없음 — 사후 provenance 로 잡 사이 일치만 본다. "
                        "미리 고정하려면 생성 시 `--potcar_pin`")
        else:
            res["⚠"] = "pin 없음 (합성 입력 — 배포 번들이 아니다)"
    else:
        spec = (man or {}).get("potcar_spec") or {}
        want = {}
        for k, s in (pin.get("source_sha256") or {}).items():
            v = s.get("sha256") if isinstance(s, dict) else s
            key = (s.get("variant") if isinstance(s, dict) else None) or spec.get(k, k)
            want[str(key)] = str(v)
        res["pin_normalized_variants"] = sorted(want)
        if not want:
            res["blocking"].append("POTCAR_PIN_EMPTY(pin 에 source_sha256 이 없다)")
        for e, s in want.items():
            got = sorted(src.get(e, {}))
            if not got:
                res["blocking"].append(
                    "POTCAR_SOURCE_UNOBSERVED(%s: 사전 고정돼 있는데 회신에 원본 sha 가 "
                    "**하나도 없다** — 빈 관측을 통과로 읽지 않는다)" % e)
            elif got != [s]:
                res["blocking"].append(
                    "POTCAR_PIN_MISMATCH(%s: 사전 고정 %s ≠ 회신 %s)" % (e, s, got))
        _pv = pin.get("vasp_version")
        if not _pv:
            res["blocking"].append("VASP_PIN_ABSENT(pin 에 vasp_version 이 없다)")
        elif not ver:
            res["blocking"].append(
                "VASP_VERSION_UNOBSERVED(에너지를 내는 OUTCAR 에서 VASP 버전이 **하나도** "
                "안 읽혔다 — 무엇으로 돌았는지 모른다)")
        elif sorted(ver) != [str(_pv)]:
            res["blocking"].append(
                "VASP_PIN_MISMATCH(사전 고정 %s ≠ 회신 %s)" % (_pv, sorted(ver)))
    res["ok"] = not res["blocking"]
    return res

def merge_compat(bundles):
    """두 묶음을 합쳐도 되는가 — **해시 결속 + 프로토콜 동일성** (회신 AF P0-3).

    왜 합치나: 12자세는 calibration(4) + holdout(8) 이고, 기체 기준계는
    calibration 묶음에만 있다. 어느 한쪽만으로는 조각 간 대비가 정의되지 않는다.

    막는 것 (하나라도 걸리면 blocking 에 들어가고 값을 만들지 않는다):
      · clean slab 파일이 다르다        → E_ads 에서 슬랩이 소거되지 않는다
      · POTCAR 사양이 다르다            → 다른 유사퍼텐셜의 총에너지를 뺀다
      · k 격자가 다르다                 → 다른 적분 격자의 값을 뺀다
      · 게이트 판(gate_version)이 다르다 → 다른 판정 규칙으로 거른 값을 합친다
      · freeze 비율 · 슬랩 원자수가 다르다

    ⛔ 이 함수가 못 하는 것: VASP 실행 바이너리·PAW 배포판이 같은지는 **여기서**
       못 본다 (MANIFEST 에 없다). 그것은 회수된 OUTCAR 의 되울림으로 따로 본다.
    """
    keys = [("clean_slab", lambda m: ((m.get("clean_slab") or {}).get("sha256"))),
            ("potcar_spec", lambda m: m.get("potcar_spec")),
            ("kmesh_effective", lambda m: m.get("kmesh_effective") or m.get("kmesh")),
            ("gate_version", lambda m: m.get("gate_version")),
            ("freeze_frac_dft", lambda m: m.get("freeze_frac_dft")),
            ("nslab", lambda m: m.get("nslab"))]
    info = {"schema": "merge_compat/v1", "n_bundles": len(bundles),
            "roots": [b[0] for b in bundles], "blocking": [], "bound": []}
    for r, m in bundles:
        mp = os.path.join(r, "MANIFEST.json")
        info["bound"].append({
            "root": r,
            "candidate_set": m.get("candidate_set"),
            "n_jobs": m.get("n_jobs"),
            "manifest_sha256": (hashlib.sha256(open(mp, "rb").read()).hexdigest()
                                if os.path.isfile(mp) else None)})
    ref = bundles[0][1]
    for name, get in keys:
        want = get(ref)
        for r, m in bundles[1:]:
            if get(m) != want:
                info["blocking"].append(
                    "%s 가 묶음마다 다르다 (%r vs %r) — 합치면 다른 계의 에너지를 뺀다"
                    % (name, want, get(m)))
    if want is None and not info["blocking"]:
        pass
    if (ref.get("clean_slab") or {}).get("sha256") is None:
        info["blocking"].append(
            "clean_slab sha 가 없다 — 두 묶음이 같은 슬랩을 썼는지 확인할 수 없다")
    info["ok"] = not info["blocking"]
    return info

VACCONV_TOL_EV = 0.005          # 보고 최소단위(0.01 eV)의 **절반** — 물리 상수가 아니다
VACCONV_REPORT_DIGITS = 2       # 0.01 eV 로 보고한다 (사전 고정)


NI_MOMENT_MIN_MUB = 0.30        # 이보다 작으면 "붕괴" — 부호를 읽을 수 없다


def magnetic_topology_direct(jr, n_ni_expected=48):
    """clean slab **없이** 실현된 Ni 자기 topology 를 직접 판정한다 (회신 AJ ②).

    C-12 는 clean slab 을 만들지 않으므로 `Q/Q_clean` 기준이 없다. 대신 잡 자체에서:
      ① Ni 모멘트 표가 **완전**해야 한다 (48개)
      ② near-zero 모멘트가 있으면 **막는다** — 부호를 읽을 수 없다
      ③ 부호 fingerprint 를 만들되 **전역 반전을 동치로 접는다**
         (AFM 은 전체를 뒤집어도 같은 상태다)

    반환 (fingerprint | None, gates[])

    ⛔ 못 하는 것: 그 topology 가 **바닥상태인지** 말하지 못한다. 두 계산이 같은
       상태인지만 본다.
    """
    g = []
    # ⛔⛔ 2026-08-31 (회신 AN P0-2) — 초판은 `ni_moments` 를 읽었다. **그런 필드는 없다.**
    #   실제 저장 스키마는 `geom.magnetic.realized_basin.ni_moments_muB` 다
    #   (`realized_basin()` 이 그 키로 쓴다). ⇒ production 결과에서는 이 게이트가
    #   **항상 MAGNETIC_MOMENTS_MISSING 으로 막혔을** 것이다 — clean slab 을 뺀 자리를
    #   메우라고 만든 게이트가 정작 실물에서 안 돈다.
    #   더 나쁜 것: selftest 픽스처가 **내가 지어낸 그 이름**을 써서 통과했다.
    #   ⇒ 아래 selftest 는 `realized_basin()` 이 실제로 내는 dict 를 그대로 쓴다.
    _mag = (jr.get("geom") or {}).get("magnetic") or {}
    _rb = _mag.get("realized_basin") or {}
    mom = _rb.get("ni_moments_muB")
    if mom is None:                       # 하위호환 — 옛 기록/픽스처
        mom = _mag.get("ni_moments") or (jr.get("static") or {}).get("ni_moments")
    if not mom:
        return None, ["MAGNETIC_MOMENTS_MISSING(Ni 모멘트 표가 없다 — "
                      "LORBIT 출력을 회수하지 못했다)"]
    if len(mom) != n_ni_expected:
        return None, ["MAGNETIC_MOMENTS_INCOMPLETE(%d/%d)" % (len(mom), n_ni_expected)]
    small = [i for i, m in enumerate(mom) if abs(float(m)) < NI_MOMENT_MIN_MUB]
    if small:
        return None, ["MAGNETIC_COLLAPSE_DIRECT(%d/%d Ni 가 |m| < %.2f μB — 부호를 "
                      "읽을 수 없다)" % (len(small), n_ni_expected, NI_MOMENT_MIN_MUB)]
    sig = "".join("+" if float(m) > 0 else "-" for m in mom)
    inv = sig.translate(str.maketrans("+-", "-+"))
    return min(sig, inv), g          # 전역 반전을 동치로 접는다


def same_topology_direct(ja, jb, n_ni_expected=48):
    """두 잡이 같은 실현 topology 인가 — clean slab 없이."""
    fa, ga = magnetic_topology_direct(ja, n_ni_expected)
    fb, gb = magnetic_topology_direct(jb, n_ni_expected)
    if fa is None or fb is None:
        return False, "판정 불가: " + "; ".join(ga + gb)
    return (fa == fb), ("같음" if fa == fb else "부호 fingerprint 가 다르다")

def closure_vacconv(man, jobs, E, emol, frags):
    """진공 두께 수렴 시험 — **두 조각의 대비 변화**로 판정한다 (회신 AJ).

        D(c) = [E_C^SDCP(c) − E_G^SDCP] − [E_C^PTFE(c) − E_G^PTFE]
        Δ_vac = D_primary,pm1(c2) − D_primary,pm1(c1)

    통과: **|Δ_vac| ≤ 5 meV 하나만**이 hard gate 다.
    ⛔ 2026-09-01 (회신 AY P0-3) — 이 줄은 *"그리고 0.01 eV 반올림이 같다"* 라고
      적혀 있었는데 **코드는 2026-08-31(회신 AM Q1)에 이미 반올림을 정보용으로 내렸다.**
      문서만 낡아 두 판정이 공존했고, `D(c1)=0.0049 · D(c2)=0.0051` 이면 코드는
      PASS 인데 문서 기준으로는 FAIL 이었다. 코드 쪽으로 일원화한다 —
      `same_rounded` 는 **표시 안정성 정보**이지 물리 게이트가 아니다.

    🔑 왜 조각별 변화가 아니라 대비인가 — 기체 항은 c 에 무관하고 슬랩 항은 두 조각에
       공통이라, 대비를 취하면 둘 다 소거된다. 조각별로 보면 소거되지 않는 항이 남는다.

    ⛔ 이 함수가 못 하는 것
      · 절대 E_ads 의 수렴을 말하지 못한다 — clean slab 이 대비에서 소거되므로 여기
        들어오지 않는다. 절대값을 인용하려면 별도 시험이 필요하다.
      · c2 보다 큰 셀에서 무슨 일이 나는지 모른다. 두 점 시험이다.
    """
    # ⛔ 2026-08-31 — `pass` 를 **처음부터** 넣는다. 초판은 마지막에만 넣어서, 조기
    #   반환 경로(적용 불가·blocks)에서 호출자가 `res["pass"]` 로 **KeyError** 를 맞았다.
    #   판정 키가 없는 것은 "통과 아님" 이지 예외가 아니다.
    res = {"schema": "closure_vacconv/v1", "tol_eV": VACCONV_TOL_EV,
           "report_digits": VACCONV_REPORT_DIGITS,
           "⚠_5meV_출처": "물리 상수가 아니라 보고 최소단위(0.01 eV)의 절반",
           "pass": False, "by_cell": {}, "blocks": []}
    # 이 시험은 **둘째 셀을 실은 판(C-12)** 에만 있다. 옛 번들에는 vacconv 잡이 없고,
    # 없는 계약을 요구하면 legacy 결과가 통째로 막힌다.
    if not (man or {}).get("vacuum_convergence") and not any(
            (jr.get("meta") or {}).get("vacconv") for jr in (jobs or {}).values()):
        res["verdict"] = "n/a — 이 번들에 진공 수렴 시험 잡이 없다"
        res["applicable"] = False
        return res
    res["applicable"] = True

    def _one(frag, cell):
        """`cell` ∈ {"c1","c2"} 인 그 조각의 primary 잡 하나.

        ⛔⛔ 2026-08-31 (회신 AM P0-2) — 초판은 c1 을 `kind="prospective_pose"`,
          c2 를 `kind="vacuum_convergence"` 로 골랐다. **둘 다 틀렸다.**
          실물 `job.json` 은 c2 도 `kind="prospective_pose"` 이고 구분은 `vacconv="c2"`
          필드에 있다. ⇒ c1 후보가 **둘(ambiguous)**, c2 후보가 **0** 이 되어
          결과가 다 있어도 진공 판정이 안 나왔다.
          이제 **생성기가 실제로 쓰는 필드**(`vacconv`)로 고른다.
        """
        js = [j for j in _pick(jobs, kind="prospective_pose",
                               fragment=frag, seed=SEED_MAIN)
              if (jobs[j].get("meta") or {}).get("role") in (None, "primary")
              and ((jobs[j].get("meta") or {}).get("vacconv")
                   or "c1") == cell]
        if len(js) != 1:
            res["blocks"].append("VACCONV_JOB_AMBIGUOUS(%s/%s: %d개)"
                                 % (frag, cell, len(js)))
            return None
        jr = jobs[js[0]]
        if jr.get("gates"):
            res["blocks"].append("VACCONV_JOB_GATED(%s: %s)"
                                 % (js[0], jr["gates"][:1]))
            return None
        e = E(js[0])
        if e is None:
            res["blocks"].append("VACCONV_JOB_MISSING(%s)" % js[0])
            return None
        return js[0], e, jr

    # ⛔⛔ 2026-08-31 (회신 AM P0-3) — **Δ_vac 에는 기체 기준이 필요 없다.**
    #     Δ_vac = [E_C^S(c₂)−E_C^S(c₁)] − [E_C^P(c₂)−E_C^P(c₁)]
    #   에서 두 조각의 기체 에너지가 **정확히 소거된다** (셀 높이와 무관한 상수라서).
    #   초판은 `emol` 이 없으면 `VACCONV_NO_GAS_REF` 로 막았는데, 그건 `--refs_minimal`
    #   번들에서 진공 판정 자체를 불가능하게 만들었다 (분석기가 box20 도 요구했다).
    #   ⇒ 기체가 있으면 쓰고(A 가 그대로 E_ads), 없으면 **복합체 에너지만으로** 낸다.
    #     Δ_vac 값은 어느 쪽이든 같다 — 그게 소거의 뜻이다.
    picks, A = {}, {}
    _gas_used = {f: (emol.get(f) is not None) for f in frags}
    res["gas_reference_used"] = _gas_used
    res["⚠_기체_불필요"] = ("Δ_vac 에서 기체 에너지는 대수적으로 소거된다 — "
                            "기체가 없어도 판정은 유효하다 (회신 AM P0-3). "
                            "단 **최종 D** 에는 기체가 필요하다.")
    for frag in frags:
        for cell in ("c1", "c2"):
            got = _one(frag, cell)
            if got is None:
                continue
            jn, e, jr = got
            picks[(frag, cell)] = jn
            A[(frag, cell)] = e - (emol.get(frag) or 0.0)

    # 🔴🔴 회신 BE P0-2 (2026-09-03) — c1/c2 가 **같은 자세의 같은 좌표**인지 실물에서 본다.
    #   리뷰어 재현: c1 을 pose-A/b00, c2 를 pose-B/다른 basin 으로 바꿔도 자기 지문만
    #   같으면 pass=true 였다. 진공 시험은 "같은 계를 c 만 늘려 다시 잰 것" 이어야 한다.
    #   ⇒ ① c1 은 estimand_job_keys 의 **그 잡**이어야 하고(exact key)
    #     ② c1/c2 POSCAR 실물의 원소·개수·고정 플래그·Cartesian 좌표가 같고
    #     ③ a,b 벡터는 같고 c 만 선언한 Δ(c2_A − c1_A) 만큼 다르다.
    #     (poscar_set_c 는 Cartesian 좌표를 보존한다 — 그것이 검사의 근거다)
    _ejk_v = (man or {}).get("estimand_job_keys") or {}
    _vcm = (man or {}).get("vacuum_convergence") or {}
    _root_v = (man or {}).get("_root")
    _sd_v = next((f for f in frags if "sdcp" in str(f)), None)
    for frag in frags:
        _j1, _j2 = picks.get((frag, "c1")), picks.get((frag, "c2"))
        if not (_j1 and _j2):
            continue
        _kexp = _ejk_v.get("E_C_sdcp" if frag == _sd_v else "E_C_control")
        if _ejk_v and _kexp != _j1:
            res["blocks"].append(
                "VACCONV_C1_NOT_PRIMARY(%s: c1=%s 이 사전 고정 complex %s 가 아니다 — "
                "다른 자세의 진공 수렴으로 primary 를 보증할 수 없다)" % (frag, _j1, _kexp))
        if not _root_v:
            res["blocks"].append(
                "VACCONV_GEOMETRY_UNVERIFIED(%s: 번들 루트가 없어 c1/c2 POSCAR 실물을 "
                "확인할 수 없다 — 확인 못 한 것은 통과가 아니다)" % frag)
            continue
        _p1 = read_poscar(os.path.join(_root_v, *_j1.split("/"), "POSCAR"))
        _p2 = read_poscar(os.path.join(_root_v, *_j2.split("/"), "POSCAR"))
        if _p1 is None or _p2 is None:
            res["blocks"].append(
                "VACCONV_GEOMETRY_UNVERIFIED(%s: c1/c2 POSCAR 실물을 읽을 수 없다)" % frag)
            continue
        _gbad = []
        if _p1["syms"] != _p2["syms"] or _p1["counts"] != _p2["counts"]:
            _gbad.append("원소·개수가 다르다")
        elif _p1["fixed"] != _p2["fixed"]:
            _gbad.append("고정 플래그가 다르다")
        # 🔴 회신 BF P0-2 — 원자별 **3축** selective-dynamics 플래그까지 같아야 한다
        elif _p1.get("sd_flags") != _p2.get("sd_flags"):
            _gbad.append("원자별 3축 selective-dynamics 플래그가 다르다")
        for _ax in (0, 1):
            if any(abs(_p1["cell"][_ax][i] - _p2["cell"][_ax][i]) > 1e-6 for i in range(3)):
                _gbad.append("%s 벡터가 다르다" % "ab"[_ax])
        # 🔴🔴 회신 BF P0-2 (2026-09-03) — **절대 셀과 full c 벡터**를 본다. 종전엔 a·b 와
        #   c[2][2] 의 차만 봤다. 리뷰어 재현: 실제 셀을 46.66→50.66 Å 로 바꾸고 Δc=4 만
        #   유지해도 PASS · c2 를 (0.25, 0, 40.66) 로 기울여도 PASS.
        #   ⇒ ① c 벡터는 (0, 0, c) 여야 한다 (기울기 금지) ② c 의 **절대값**이 manifest 선언
        #     c1_A/c2_A 와 같아야 한다 ③ 그 선언이 **비준 protocol** 의 c1_A/c2_A 와 같아야 한다.
        for _lab, _pp in (("c1", _p1), ("c2", _p2)):
            if abs(_pp["cell"][2][0]) > 1e-6 or abs(_pp["cell"][2][1]) > 1e-6:
                _gbad.append("%s 의 c 벡터가 (0,0,c) 가 아니다 (%.4f, %.4f, %.4f) — 기울어진 셀"
                             % (_lab, _pp["cell"][2][0], _pp["cell"][2][1], _pp["cell"][2][2]))
        try:
            _c1_decl, _c2_decl = float(_vcm.get("c1_A")), float(_vcm.get("c2_A"))
        except (TypeError, ValueError):
            _c1_decl = _c2_decl = None
        if _c1_decl is None:
            _gbad.append("manifest 에 c1_A/c2_A 가 없어 절대 셀을 대조할 수 없다")
        else:
            if abs(_p1["cell"][2][2] - _c1_decl) > 1e-3:
                _gbad.append("c1 절대 높이 %.4f Å ≠ 선언 %.4f Å" % (_p1["cell"][2][2], _c1_decl))
            if abs(_p2["cell"][2][2] - _c2_decl) > 1e-3:
                _gbad.append("c2 절대 높이 %.4f Å ≠ 선언 %.4f Å" % (_p2["cell"][2][2], _c2_decl))
            _pvc, _pvw = _protocol_vacuum_cells(man)
            if _pvc is None:
                _gbad.append("비준 protocol 의 c1_A/c2_A 를 번들에서 읽을 수 없다 (%s) — 선언을 "
                             "protocol 과 대조하지 못하면 확인 못 함이다" % _pvw)
            elif abs(_pvc[0] - _c1_decl) > 1e-6 or abs(_pvc[1] - _c2_decl) > 1e-6:
                _gbad.append("manifest 선언 c1/c2 (%.4f/%.4f) ≠ 비준 protocol (%.4f/%.4f)"
                             % (_c1_decl, _c2_decl, _pvc[0], _pvc[1]))
        _dc = _p2["cell"][2][2] - _p1["cell"][2][2]
        try:
            _want_dc = float(_vcm.get("c2_A")) - float(_vcm.get("c1_A"))
        except (TypeError, ValueError):
            _want_dc = None
        if _want_dc is None:
            _gbad.append("manifest 에 c1_A/c2_A 가 없어 Δc 를 대조할 수 없다")
        elif abs(_dc - _want_dc) > 1e-3:
            _gbad.append("Δc %.4f Å ≠ 선언 %.4f Å" % (_dc, _want_dc))
        if not _gbad:
            _mx = 0.0
            for _a1, _a2 in zip(_p1["pos"], _p2["pos"]):
                for _ax in range(3):
                    _mx = max(_mx, abs(_a2[_ax] - _a1[_ax]))
            if _mx > 1e-4:
                _gbad.append("Cartesian 좌표가 다르다 (최대 %.4f Å) — 다른 자세다" % _mx)
        if _gbad:
            res["blocks"].append("VACCONV_GEOMETRY_MISMATCH(%s: %s — 셀 효과가 아니라 "
                                 "다른 계를 재게 된다)" % (frag, "; ".join(_gbad)))

    # 자기 topology 가 네 잡에서 같아야 한다 — 다르면 셀 효과가 아니라 상태 차이를 잰다
    #   clean slab 이 없을 수 있으므로 **직접 topology** 를 먼저 쓰고, 없으면 legacy
    #   realized_basin_id 로 떨어진다 (회신 AJ ②).
    _rb = {}
    for k, v in picks.items():
        f, _g = magnetic_topology_direct(jobs[v])
        if f is None:
            f = ((jobs[v].get("geom") or {}).get("magnetic") or {}).get(
                "realized_basin_id")
        _rb[k] = f
    if len(picks) == 4:
        if any(v is None for v in _rb.values()):
            res["blocks"].append(
                "VACCONV_BASIN_UNRESOLVED(네 잡 중 realized topology 미판정이 있다)")
        elif len(set(_rb.values())) > 1:
            res["blocks"].append(
                "VACCONV_BASIN_MISMATCH(%s — 셀 효과가 아니라 자기 상태 차이를 재게 된다)"
                % _rb)
    res["jobs"] = {"%s/%s" % k: v for k, v in sorted(picks.items())}
    res["A_eV"] = {"%s/%s" % k: round(v, 6) for k, v in sorted(A.items())}

    sd = next((f for f in frags if "sdcp" in f), None)
    ct = next((f for f in frags if f != sd), None)
    if not (sd and ct) or len(A) != 4 or res["blocks"]:
        res["verdict"] = "unresolved — 네 잡이 전부 회수·통과해야 판정한다"
        return res

    D = {c: A[(sd, c)] - A[(ct, c)] for c in ("c1", "c2")}
    res["D_eV"] = {c: round(v, 6) for c, v in D.items()}
    res["D_reported"] = {c: round(v, VACCONV_REPORT_DIGITS) for c, v in D.items()}
    d_vac = D["c2"] - D["c1"]
    res["delta_vac_eV"] = round(d_vac, 6)
    # ⛔ 정확한 경계가 부동소수점으로 뒤집히지 않게 μeV 정수로 비교 (회신 AF P0-6 과 같은 이유)
    within = abs(int(round(d_vac * 1e6))) <= int(round(VACCONV_TOL_EV * 1e6))
    same_round = res["D_reported"]["c1"] == res["D_reported"]["c2"]
    res["within_tol"] = within
    res["same_rounded"] = same_round
    # ⛔⛔ 2026-08-31 (회신 AM Q1) — **반올림 일치를 hard gate 에서 내린다.**
    #   0.0049 vs 0.0051 eV 는 차이가 **0.2 meV** 인데 표시는 0.00 / 0.01 로 갈린다.
    #   더 나쁜 것: c 에 무관한 기체 offset 을 더하면 Δ_vac 은 그대로인데 **반올림 판정만
    #   바뀐다** — 물리와 무관한 양이 판정을 뒤집는다는 뜻이다.
    #   ⇒ 물리 gate 는 `|Δ_vac| ≤ 5 meV` 하나. `same_rounded` 는 **표시 안정성 정보**다.
    #     반올림만 불일치하면 Figure 삭제가 아니라 **불확도 병기 또는 한 자리 추가 보고**.
    res["pass"] = bool(within)
    res["gate"] = "|Δ_vac| ≤ %.0f meV (물리 gate)" % (1000 * VACCONV_TOL_EV)
    res["rounding_note"] = (
        "표시 안정성 정보 — 판정에 안 들어간다. 반올림만 불일치하면 "
        "0.01 eV 대신 한 자리 더(0.001 eV) 보고하거나 불확도를 병기한다.")
    # ⚠ 판정 범위를 좁힌다 — 두 점은 '+4 Å 증가에 대한 안정성' 이지 무한진공 수렴이 아니다.
    res["claim_scope"] = (
        "시험한 b00·%s branch 에서 c %+.0f Å 증가에 대한 안정성. "
        "**무한진공 수렴의 증명이 아니다.**" % (SEED_MAIN, 4.0))
    res["verdict"] = ("ok — Δ_vac %.1f meV (문턱 %.0f) · 반올림 %s"
                      % (1000 * d_vac, 1000 * VACCONV_TOL_EV,
                         "일치" if same_round else "불일치(정보용)")
                      if res["pass"] else
                      "⛔ FAIL — Δ_vac %.1f meV > 문턱 %.0f meV. "
                      "추가 셀 탐색 없이 Figure 2e 를 제거한다"
                      % (1000 * d_vac, 1000 * VACCONV_TOL_EV))
    return res

def closure_C1(man, jobs, E, emol, frags):
    """C1 — **선택된 네 자세에서의 국소 calibration 일관성**.

      e_{f,p} = E_ads^DFT(f,p) − E_ads^UMA(f,p)
      S_f     = max_p e − min_p e          ← **range 다 (SD 아님)**

    branch 는 pm1 · D3-on 만. 조각당 사전 지정 4자세 **전부**가 있어야 하고
    하나라도 빠지면 `unresolved` — 남은 자세로 계산하면 표본이 줄어 range 가
    자동으로 작아져 **통과 쪽으로 편향된다**.

    ⛔ 이 값이 말하지 않는 것: 후보 전체의 selector 검증이 **아니다.** UMA 가
    고른 자세만 DFT 로 봤으므로 통과는 독립 검증이 아니다. 일반 selector 주장은
    sealed audit 이나 UMA 순위를 가로지르는 사전 층화 holdout 이 있어야 한다.
    """
    res = {"schema": "closure_C1/v1", "S_tol_eV": C1_S_TOL_EV,
           "⚠": "선택된 네 자세의 국소 일관성. selector 일반 검증이 아니다",
           "by_frag": {}}
    slabs = _pick(jobs, kind="clean_ref", seed=SEED_MAIN, d3="on")
    # 🔴 회신 AV P0-3 — clean slab **0개는 번들 설계**지 결함이 아니다 (C-12 exact-cell
    #   번들은 절대 E_ads 를 약속하지 않아 슬랩을 싣지 않는다). 그 경우 이 조건은
    #   "미해결" 이 아니라 **명시적 n/a** 다 — 미해결은 약속하고 못 지킨 상태다.
    #   S_f 자체는 슬랩이 소거되는 양이지만, C1 의 행이 절대 E_ads 로 정의돼 있으므로
    #   슬랩 없는 번들에서 조용히 다른 양으로 바꿔 계산하지 않는다.
    if not slabs:
        res["verdict"] = ("n/a — 이 번들에는 clean slab 이 없다 (절대 E_ads 기반 "
                          "C1 을 정의하지 않는다 · 회신 AV P0-3)")
        return res
    if len(slabs) != 1:
        res["verdict"] = f"unresolved — clean slab(pm1·D3-on)이 {len(slabs)}개"
        return res
    e_slab = E(slabs[0])
    # 🔴 회신 AB P0-4 후단 — `S_f = max_p e − min_p e` 에서는 같은 조각의 슬랩·분자
    #   항이 **정확히 소거된다**. 그러므로 필요한 것은 네 complex 자세가 서로 같은
    #   basin 인가이지, 각 자세가 clean slab 과 같은 basin인가가 **아니다**.
    #   clean slab 일치는 **절대 E_ads** 를 주장할 때 따로 요구한다(그 게이트는
    #   BASIN_MISMATCH_SLAB 로 이미 별도로 있다). 종전 구현은 여기서 슬랩 일치를
    #   요구해 과잉차단이었다.
    res["⚠_basin_규칙"] = ("네 자세가 **서로** 같은 basin 이면 된다 — S_f 에서 슬랩·분자가 "
                          "소거되기 때문. clean slab 일치는 절대 E_ads 쪽 요구조건이다")
    for f in frags:
        # 🔴 회신 AV P0-3 — vacconv(c2 셀) 잡은 진공 수렴 시험이지 자세가 아니다.
        #   섞이면 조각당 행수가 기대와 어긋나 영구 unresolved 가 된다.
        poses = _pick(jobs, kind="prospective_pose", fragment=f,
                      seed=SEED_MAIN, d3="on", vacconv=None)
        rows, miss = [], []
        for jn in poses:
            jr = jobs[jn]
            m = jr.get("meta") or {}
            rb = ((jr.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
            ec, um = E(jn), m.get("uma_E_pose_eV")
            if jr.get("gates") or ec is None or um is None or e_slab is None:
                miss.append(f"{jn}(게이트/에너지 결측)"); continue
            if rb is None:
                miss.append(f"{jn}(basin 미판정)"); continue
            rows.append({"job": jn, "basin": m.get("basin_id"),
                         "E_ads_DFT_eV": round(ec - e_slab - emol[f], 6),
                         "E_ads_UMA_eV": round(float(um), 6),
                         "residual_eV": round(ec - e_slab - emol[f] - float(um), 6)})
        # ★ 기대 자세 수는 **동결된 manifest** 에서 온다. 회수된 잡에서 세면
        #   빠진 자세를 영영 못 잡는다 (없으면 기대도 같이 줄어든다).
        # ⛔⛔ 회신 BA P1 (2026-09-02) — **고르는 술어와 세는 술어가 달랐다.**
        #   `_pick` 은 구조화 meta(`kind/fragment/seed/d3/vacconv`)로 고르는데
        #   기대 수는 **잡 키 문자열**(`endswith`)로 셌다. 우리 코드가 스스로 금지한
        #   "이름 파싱" 을 여기서 하고 있었고, 그 결과 실물에서 `n_used=1 ·
        #   n_required=2 → 영구 unresolved` 가 됐다 (대안자세 net4 두 잡이 분석에
        #   전혀 쓰이지 않는 상태).
        #   ⇒ **같은 술어**로 센다. 그리고 어느 키를 세고 어느 키를 썼는지 남겨
        #     다음번엔 왜 어긋났는지 바로 보이게 한다.
        #   ⚠ `planned.meta` 는 `kind·fragment·role·seed·basin_id·vacconv·
        #     species_order` 만 싣는다 (`d3` 는 없다). 그래서 d3-off 쌍둥이는
        #     `d3_twin_of` 유무로 뺀다 — 있는 필드로만 맞춘다.
        _want_keys = _expected_pose_keys(man, f)      # 술어는 한 곳이다 (BB P1)
        n_want = len(_want_keys)
        if not n_want:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": "MANIFEST.planned 에 이 조각의 pm1 자세가 없다 "
                                        "— 기대 자세 수를 회수분에서 세지 않는다"}
            continue
        # ★ 네 자세가 **서로** 같은 basin 인지 — 해시가 아니라 상세 지문으로 (P0-4)
        _het = []
        if len(rows) > 1:
            _ref = rows[0]["job"]
            for _r in rows[1:]:
                _ok, _why = same_basin(jobs[_ref], jobs[_r["job"]])
                if not _ok:
                    _het.append(f"{_r['job']}: {_why}")
        if _het:
            miss.extend(_het)
        if miss or len(rows) != n_want or not rows:
            res["by_frag"][f] = {"verdict": "unresolved", "missing": miss,
                                 "n_used": len(rows), "n_required": n_want,
                                 # ⛔ 회신 BA P1 — 어긋나면 **어느 키가** 어긋났는지
                                 #   보여야 한다. 수만 보면 원인을 못 찾는다.
                                 "required_keys": _want_keys[:6],
                                 "used_keys": [x["job"] for x in rows][:6],
                                 "예상밖": sorted(set(x["job"] for x in rows)
                                                  - set(_want_keys))[:4],
                                 "누락": sorted(set(_want_keys)
                                                - set(x["job"] for x in rows))[:4],
                                 "why": "4자세 전부가 있고 **서로 같은 basin** 이어야 한다 "
                                        "— 부분집합은 range 를 작게 만들어 통과 쪽으로 "
                                        "편향되고, 상태를 가로지르면 e 가 다른 양이 된다"}
            continue
        r = [x["residual_eV"] for x in rows]
        S = max(r) - min(r)
        res["by_frag"][f] = {
            "n": len(rows), "S_f_eV": round(S, 6), "rows": rows,
            "verdict": ("국소 calibration 일관 (이 네 자세 안에서 잔차 range 가 작다)"
                        if S <= C1_S_TOL_EV else
                        "⛔ 국소 일관성 실패 — 선택기를 쓴 근거가 약해진다")}
    return res


#: C5 게이트 — 결과 보기 전 고정 (D-2026-08-30-sdcp-neutral-ptfe-ddE-obs)
C5_N_CAL = 4                   # 사전등록 calibration 자세 (조각당)
C5_N_HOLDOUT = 8               # 층화 홀드아웃 자세 (조각당) — 선택기 시험용
C5_N_POSE = C5_N_CAL + C5_N_HOLDOUT   # = 12. ⚠ 합만 맞으면 안 된다 — 구성도 맞아야
C5_H1_FLOOR_EV = 0.030         # ⚠ **MLIP 유래 하한** — site_screen.py GATE["decision_floor_eV"]
#   (2026-08-11 UMA 실무 해상도). DFT 값에 옮겨 쓸 근거는 문서에 없다
#   (kb/questions/sdcp_site_preference.md 2026-08-28). 옮길 만하다고 볼 이유는
#   기하가 UMA 이완 결과라 UMA 오차가 모든 DFT 단일점에 실린다는 것이지만 추론이다.
#   ⇒ 상수로 쓰지 않고 **하한**으로만 쓰고, 실측 S_f 가 크면 그쪽이 이긴다.
C5_H1_TOL_EV = C5_H1_FLOOR_EV  # 하위호환 별칭 (판정은 h1_tolerance() 로 한다)


def h1_tolerance(c1_result):
    """홀드아웃 판정바닥 δ.

    ⛔ **2026-08-30 철회** — 한때 `δ = max(30 meV, S_f)` 로 두려 했다. 회신 AF P0-5 가
    기각했고 그 논거가 옳다: `S_f` 가 커질수록 holds 도 fail 도 어려워져 **미해결 띠만
    넓어진다.** 즉 '엄격해진다' 가 아니라 **판정력이 줄어든다** 이고, 나쁜 selector 가
    큰 `S_f` 로 자기 실패를 가리는 구조가 된다. 그래서 `S_f` 는 H1 문턱에 **넣지 않는다**.

    `S_f` 는 C1 의 독립 게이트(≤ 50 meV)로 **그대로 남는다** — 거기서는 '선택기가
    조각 안에서 일관적인가' 를 묻는 것이라 방향이 맞다.

    현재 δ 는 `C5_H1_FLOOR_EV` **한 값**이고, 그 값은 MLIP(UMA) 실무 해상도에서 왔다.
    ⚠ 그 이식 근거는 아직 등재돼 있지 않다 (kb/questions/sdcp_site_preference.md
    2026-08-28). 수치 허용폭은 dense-k · box · SCF 같은 **독립 수치검사**에서 따로
    정해야 하고, 그것이 나오기 전까지 이 값은 잠정이다.
    """
    out = {}
    for f, r in ((c1_result or {}).get("by_frag") or {}).items():
        s = r.get("S_f_eV") if isinstance(r, dict) else None
        out[f] = {"tol_eV": C5_H1_FLOOR_EV, "floor_eV": C5_H1_FLOOR_EV,
                  "S_f_eV": s, "binding": "floor(MLIP 유래 · 잠정)",
                  "⛔": "S_f 는 H1 문턱에 쓰지 않는다 (회신 AF P0-5). C1 게이트 전용"}
    return out


def closure_C5(man, jobs, E, emol, frags, merge_info=None, h1_tol=None):
    """C5 — ΔΔE_obs. **선언된 12자세에서의 조각 간 대비** (표본 조건부).

      A(f,p)   = E_complex(f,p) − E_mol(f, box24)
      ΔΔE_obs  = min_{p∈12} A(SDCP,p) − min_{q∈12} A(c10,q)      [pm1 · D3-on]

    왜 이 양이 별도로 있나 — 마감조건 §9 는 *"Stage A 결과로 어느 조각이 더 강하게
    붙는다를 종결형으로 쓰기"* 를 금지하고, 그 근거로 **"audit pose 가 없다"** 를 든다.
    즉 반대 이유는 *min 이 UMA 선택기의 산물일 수 있다* 이다. 층화 홀드아웃 8자세가
    UMA 점수 전 구간을 가로질러 **그 반대 이유를 직접 시험**하므로, 그 시험을 통과할
    때에 한해 **표본 조건부** 대비를 낸다.

    게이트 (하나라도 깨지면 값을 만들지 않는다):
      ① 조각당 12자세 전부 회수·게이트 통과   ② 12자세가 서로 같은 realized basin
      ③ H1 — 홀드아웃 최저가 calibration 최저를 30 meV 이상 **밑돌지 않는다**
      ④ 두 조각 기체 기준이 존재            ⑤ (슬랩은 A 에서 소거되므로 여기선 불필요)

    ⛔ 이 함수가 **못 하는 것**
      · 전역 최소를 주장하지 않는다. 후보풀 밖은 안 봤다.
      · `ΔΔE_lowE` / primary 가 아니다 — 그것은 창 W 전수 + audit 개봉을 전제한다.
      · H1 실패를 "더 낮은 자세를 찾았다" 로 흡수하지 않는다. **재개 사유**다.
    """
    res = {"schema": "closure_C5/v2", "name": "ddE_obs",
           "merge": merge_info,
           "n_pose_required": C5_N_POSE, "h1_tol": h1_tol or {},
           "h1_floor_eV": C5_H1_FLOOR_EV,
           "decision": "D-2026-08-30-sdcp-neutral-ptfe-ddE-obs (proposed)",
           "⚠": "표본 조건부 — 전역 최소가 아니다", "by_frag": {}}
    # ⛔ 12자세는 두 묶음(calibration 4 + holdout 8)에 걸쳐 있다. 한 묶음만 주면
    #    부분집합에서 min 을 뽑게 되므로 **값을 만들지 않는다** (회신 AF P0-3).
    if not merge_info:
        res["verdict"] = ("⛔ NOT_MERGED — 12자세는 calibration 묶음과 holdout 묶음에 "
                          "걸쳐 있다. `analyze_results.py <calib> --merge <holdout>` 로 "
                          "두 묶음을 함께 줘야 한다. 한 묶음만으로는 정의되지 않는다")
        return res
    if not merge_info.get("ok"):
        res["verdict"] = "⛔ MERGE_INCOMPATIBLE — " + "; ".join(merge_info["blocking"][:3])
        return res
    mins = {}
    for f in frags:
        if emol.get(f) is None:
            res["by_frag"][f] = {"verdict": "unresolved", "why": "기체 기준(box24) 없음"}
            continue
        rows, miss = [], []
        for jn in _pick(jobs, kind="prospective_pose", fragment=f,
                        seed=SEED_MAIN, d3="on", vacconv=None):
            jr = jobs[jn]
            ec = E(jn)
            if jr.get("gates") or ec is None:
                miss.append(f"{jn}(게이트/에너지 결측)"); continue
            rows.append({"job": jn, "role": (jr.get("meta") or {}).get("role"),
                         "basin_id": (jr.get("meta") or {}).get("basin_id"),
                         "A_eV": round(ec - emol[f], 6)})
        if len(rows) != C5_N_POSE or miss:
            res["by_frag"][f] = {
                "verdict": "unresolved", "n_used": len(rows),
                "n_required": C5_N_POSE, "missing": miss[:4],
                "why": ("선언된 12자세 전부가 있어야 한다 — 부분집합에서 min 을 뽑으면 "
                        "표본이 줄수록 min 이 올라가 대비가 흔들린다")}
            continue
        # ② 12자세 상호 동질성 (크기 포함) — 상태를 가로질러 min 을 뽑지 않는다
        _het = []
        for r in rows[1:]:
            ok, why = same_basin(jobs[rows[0]["job"]], jobs[r["job"]])
            if not ok:
                _het.append(f"{r['job']}: {why}")
        if _het:
            res["by_frag"][f] = {"verdict": "unresolved", "basin_mismatch": _het[:3],
                                 "why": "12자세가 서로 같은 realized basin 이어야 한다"}
            continue
        cal = [r for r in rows if r["role"] == "calibration"]
        hld = [r for r in rows if r["role"] == "holdout"]
        # ⛔ 회신 AF P0-4 — 12개면 되는 게 아니라 **정확히 4 + 8** 이어야 한다.
        #    11+1 도 12 라서 종전 검사를 통과했다. 그러면 홀드아웃 시험이 사라진다.
        if (len(cal), len(hld)) != (C5_N_CAL, C5_N_HOLDOUT):
            res["by_frag"][f] = {
                "verdict": "unresolved", "n_cal": len(cal), "n_holdout": len(hld),
                "why": "calibration %d · holdout %d — 정확히 %d + %d 이어야 한다 "
                       "(합이 12 라도 구성이 다르면 홀드아웃 시험이 성립하지 않는다)"
                       % (len(cal), len(hld), C5_N_CAL, C5_N_HOLDOUT)}
            continue
        a_cal, a_hld = min(r["A_eV"] for r in cal), min(r["A_eV"] for r in hld)
        # ③ H1 — **세 갈래**다 (회신 AF P0-4). 종전 두 갈래는 판정 해상도 안의
        #    미해결 구간(±30 meV)을 통과로 승격시켰다.
        # ⛔ 회신 AF P0-6 — 정확히 ±δ 인 경우가 부동소수점 때문에 뒤집혔다.
        #   계약상 ±δ 는 **둘 다 미해결**이다. μeV 정수로 양자화해 비교한다.
        _tol = float(((h1_tol or {}).get(f) or {}).get("tol_eV", C5_H1_FLOOR_EV))
        _m = a_hld - a_cal
        _mq = int(round((a_hld - a_cal) * 1e6))     # μeV
        _tq = int(round(_tol * 1e6))
        if _mq > _tq:
            h1 = "holds"          # 홀드아웃이 확실히 높다 — 선택기가 버텼다
        elif _mq < -_tq:
            h1 = "fail"           # 홀드아웃이 더 낮다 — 선택기 실패
        else:
            h1 = "unresolved"     # 판정 해상도 안 — 어느 쪽도 말하지 않는다
        h1_ok = (h1 == "holds")
        res["by_frag"][f] = {
            "n_pose": len(rows), "n_cal": len(cal), "n_holdout": len(hld),
            "A_min_calibration_eV": round(a_cal, 6),
            "A_min_holdout_eV": round(a_hld, 6),
            "H1_margin_eV": round(_m, 6), "H1_class": h1, "H1_pass": h1_ok,
            "H1_tol_eV": round(_tol, 6),
            "H1_tol_binding": ((h1_tol or {}).get(f) or {}).get("binding", "floor"),
            "A_min_eV": round(min(a_cal, a_hld), 6),
            "rows": sorted(rows, key=lambda r: r["A_eV"]),
            "verdict": ("ok" if h1 == "holds" else
                        ("⛔ SELECTOR_FAIL — 홀드아웃 최저가 calibration 최저를 "
                         "%.1f meV 밑돈다. 이 값을 min 으로 흡수하지 않는다; "
                         "사전등록 재개조건이 발동한다" % (1000 * -_m))
                        if h1 == "fail" else
                        "unresolved — 홀드아웃과 calibration 최저의 차 %.1f meV 가 "
                        "판정 해상도 %.0f meV 안이다. 선택기가 버텼다고도, 실패했다고도 "
                        "말하지 않는다" % (1000 * _m, 1000 * _tol))}
        if h1_ok:
            mins[f] = min(a_cal, a_hld)
    # ⛔ 회신 AF P0-3 — 조각 **안**에서만 배열을 맞추면 SDCP 와 PTFE 가 서로 다른
    #    자기 배열이어도 통과한다. 두 최저 자세끼리도 같은 배열이어야 뺄셈이 성립한다.
    _best_job = {}
    for f, _ in mins.items():
        _rows = res["by_frag"][f]["rows"]
        _best_job[f] = min(_rows, key=lambda r: r["A_eV"])["job"]
    if len(_best_job) == 2:
        _a, _b = list(_best_job.values())
        _ok, _why = same_basin(jobs[_a], jobs[_b])
        res["cross_fragment_basin"] = {"jobs": [_a, _b], "same": _ok, "why": _why}
        if not _ok:
            res["verdict"] = ("⛔ CROSS_FRAGMENT_BASIN — 두 조각의 최저 자세가 서로 "
                              "다른 자기 배열이다 (%s). 그 차에는 흡착이 아닌 것이 "
                              "섞인다" % _why)
            return res
    sd = next((f for f in mins if "sdcp" in f), None)
    ct = next((f for f in mins if f != sd), None)
    if not (sd and ct):
        res["verdict"] = ("unresolved — 두 조각 모두 게이트를 통과해야 한다 "
                          "(통과 %s)" % sorted(mins))
        return res
    res["ddE_obs_eV"] = round(mins[sd] - mins[ct], 6)
    res["verdict"] = (
        "조사한 %d자세(사전등록 %d + 층화 홀드아웃 %d)에서, 고정기하 단일점 규약 아래 "
        "중성 SDCP 반복단위 모델의 최저 흡착 전자에너지가 perfluorodecane 조각보다 "
        "%.4f eV %s았다" % (C5_N_POSE, 4, 8, abs(res["ddE_obs_eV"]),
                            "낮" if res["ddE_obs_eV"] < 0 else "높"))
    res["⛔_금지_서술"] = ["전역 최소", "가장 안정한 자세", "종결형",
                        "ΔΔE_lowE · primary 로 부르기"]
    return res


def closure_C3(man, jobs, E, frags):
    """C3 — D3 분해. **부호를 먼저 본다.**

      δ_{f,p} = [E_C,on − E_C,off] − [E_S,on − E_S,off] − [E_M,on − E_M,off]
              = Edisp_C(f,p) − Edisp_S − Edisp_M(f)          ← **v2: 쌍둥이 없이**
      D       = mean_p(δ_SDCP) − mean_p(δ_c10)      ← 부호 있는 값, 산술평균

    ⛔ **2026-09-01 (회신 AY Q2) — 우리가 리뷰에 적은 근거가 틀렸다.**
      리뷰 요청 AY 는 소거 근거를 *"두 조각이 슬랩을 다르게 편극시키지 않는다"* 로
      적었는데 그건 **아니다.** D3 계수는 원자종·배위 기하에 의존하므로 그런 전제는
      성립하지 않는다. 실제 근거는 아래 v2 개정에 적힌 것 하나다 — **D3 가 SCF 에
      안 들어가므로 고정기하에서 `E_on − E_off = Edisp` 가 항등식**이고, 그래서
      독립 reference-slab 항이 차의 차에서 대수적으로 소거된다.
      ⇒ C3 는 **exact-cell 차등량에 대한 전체 D3 기여**이지 조각–슬랩 쌍 분산만이
        아니다. 결론(쌍둥이 잡 불필요)은 그대로고, 이유가 정정됐다.

    ★ **v2 개정 (2026-08-30, DFT 결과 0잡 시점)** — D3-off 쌍둥이 잡을 쓰지 않는다.
      D3(IVDW=11)는 SCF 에 안 들어간다: 핵좌표만 보고 총에너지·힘에 **더해지는** 항이라
      KS 해밀토니안을 안 건드린다. 그래서 고정기하 static(NSW=0)에서
          E_on − E_off = Edisp
      가 근사가 아니라 **항등식**이고, 위 세 괄호가 각각 Edisp 로 접힌다.
      VASP 는 그 Edisp 를 OUTCAR 에 직접 찍는다 — repo 실물로 확인했다:
      `runs/sdcp_phaseB_vasp_v1_2026_08_08/{slab,mol_neutral,complex_neutral}/OUTCAR.gz`
      → −27.49493 / −0.71798 / −28.58614 ⇒ δ = **−0.373230 eV**.
      ⇒ 쌍둥이 16잡은 절충으로 버린 것이 아니라 **정보가 0이라** 버린 것이고,
        쌍둥이가 IVDW 말고 다른 축에서 갈릴 위험도 함께 사라진다.

    ⚠ 쌍둥이가 **있으면 버리지 않고 교차검증**한다 (v9 이하 번들 호환):
      |(E_on − E_off) − Edisp| > C3_EDISP_TOL_EV 면 그 조각은 unresolved 다.
      항등식이 깨졌다는 뜻이고 그건 D3 문제가 아니라 **번들 문제**다.

    D 와 0.90 eV 의 **부호가 같을 때만** 70/30 % 를 적용한다. 절댓값을 쓰면
    반대 방향 효과도 "설명" 으로 오판한다.

    ⛔ 허용 문구는 "원인의 70 % 를 증명" 이 아니라 **"이 네 자세에서 관측된
    0.90 eV 차등을 수치상 70 % 이상 설명"** — 인과가 아니라 수치 분해다.

    ⛔ 이 함수가 **못 하는 것**: Edisp 값 자체가 맞는지는 검증하지 않는다.
      VASP 가 찍은 수를 그대로 쓴다. 독립 D3 구현과 대조하지 않는다.
    """
    res = {"schema": "closure_C3/v3", "ref_gap_eV": C3_REF_GAP_EV,
           "hi": C3_HI, "lo": C3_LO, "edisp_tol_eV": C3_EDISP_TOL_EV,
           "source": "Edisp (eV) from the D3-on OUTCAR — no D3-off twin required",
           "offset_definition": C3_OFFSET_UMA_MINUS_DFT,
           "offset_within_fragment_range_eV": C3_OFFSET_RANGE_EV,
           # ⛔ 회신 AZ P1 (2026-09-01) — 이 단서를 **결과 객체에도** 싣는다.
           #   코드 주석에만 있으면 산출물을 읽는 사람에게 안 간다.
           "⚠_C3_가_무엇인가": {
               "ko": ("IVDW=11(D3 zero damping)의 correction 은 total energy 에 "
                      "**더해질 뿐 SCF 에 들어가지 않는다.** 그래서 고정기하 static 에서 "
                      "`E_on − E_off = Edisp` 가 항등식이고, 쌍둥이 D3-off 잡이 필요 없다. "
                      "⇒ C3 는 **exact-cell 차등량에 대한 전체 D3 기여**이지 "
                      "조각–슬랩 쌍 분산으로 분해한 값이 **아니다**."),
               "en": ("With IVDW=11 (D3, zero damping) the correction is added to the "
                      "total energy and does not enter the SCF, so at fixed geometry "
                      "E_on − E_off = Edisp identically and no D3-off twin is needed. "
                      "C3 is therefore the **total D3 contribution to the exact-cell "
                      "difference**, not a fragment–slab pair decomposition."),
               "출처": "https://vasp.at/wiki/IVDW",
               "⛔_틀린_근거": ("*'두 조각이 슬랩을 다르게 편극시키지 않는다'* 는 "
                               "**틀렸다** — D3 계수는 원자종·배위 기하에 의존한다 "
                               "(회신 AY Q2 정정)")},
           "by_frag": {}}

    def pair_delta(jn):
        """δ 의 한 항 = 그 잡의 Edisp. 없으면 (None, 사유).

        쌍둥이가 남아 있으면 (E_on − E_off) 와 대조해 항등식을 확인한다.
        """
        a = jobs.get(jn)
        if a is None:
            return None, f"{jn}: 잡 없음"
        if a.get("gates"):
            return None, f"{jn}: 게이트됨"
        st = a.get("static") or {}
        ed = st.get("edisp_eV")
        if ed is None:
            return None, (f"{jn}: OUTCAR 에 `Edisp (eV)` 가 없다 — IVDW=11 이 실제로 "
                          f"걸렸는지 확인해야 한다 (D3 없이 돈 잡일 수 있다)")
        if (st.get("edisp_n") or 0) > 1 and (st.get("incar_echo") or {}).get("NSW") not in (None, "0", 0):
            return None, (f"{jn}: Edisp 가 {st['edisp_n']}회 찍혔는데 NSW≠0 — 기하가 "
                          f"바뀌었으면 마지막 값이 어느 기하의 것인지 보장 못 한다")
        # ── 쌍둥이가 있으면 항등식을 **검사**한다 (없는 게 정상이다)
        tw = _twin_of(jobs, jn)
        if tw is not None and not (jobs[tw].get("gates")):
            ea, eb = E(jn), E(tw)
            if ea is not None and eb is not None:
                if abs((ea - eb) - ed) > C3_EDISP_TOL_EV:
                    return None, (f"{jn}: (E_on−E_off)={ea - eb:.6f} 인데 Edisp={ed:.6f} "
                                  f"— 차 {abs((ea - eb) - ed):.6f} eV 가 허용 "
                                  f"{C3_EDISP_TOL_EV} 를 넘는다. D3 항등식이 깨졌다 = "
                                  f"쌍둥이가 IVDW 말고 다른 데서 갈렸다는 뜻")
                ra = ((a.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
                rb = ((jobs[tw].get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
                if ra is not None and rb is not None and ra != rb:
                    return None, f"{jn}: on/off 가 다른 realized basin"
        return ed, None

    _slabs = _pick(jobs, kind="clean_ref", seed=SEED_MAIN, d3="on")
    if _slabs:
        d_slab, why = pair_delta(_slabs[0])
        if d_slab is None:
            # 슬랩이 **있는데** Edisp 가 안 나오는 것은 번들 문제다 — 그대로 막는다
            res["verdict"] = f"unresolved — clean slab D3 짝: {why}"
            return res
    else:
        # 🔴 회신 AV P0-3 — D = mean(δ_SDCP) − mean(δ_c10) 에서 slab Edisp 는 조각
        #   공통 상수라 **대수적으로 소거된다.** clean slab 0개 번들에서는 그 항을
        #   0 으로 두고 (Edisp_C,f − Edisp_G,f) 의 조각 간 차를 직접 계산한다 —
        #   잡을 추가할 필요가 없다. row 의 delta 는 slab 항이 빠진 값임을 명시한다.
        d_slab = 0.0
        res["clean_slab"] = ("n/a — 이 번들에 없다. slab Edisp 는 D 에서 소거되므로 "
                             "row delta 는 Edisp_C − Edisp_G 로 읽는다 (회신 AV P0-3)")
    means = {}
    for f in frags:
        mol = [j for j in _pick(jobs, kind="mol_ref", fragment=f, d3="on")
               if "box24" in j and "nzmag" not in j]
        if len(mol) != 1:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": f"box24 기체 기준이 {len(mol)}개"}
            continue
        d_mol, why_m = pair_delta(mol[0])
        if d_mol is None:
            res["by_frag"][f] = {"verdict": "unresolved", "why": why_m}
            continue
        rows, miss = [], []
        # 🔴 회신 AV P0-3 — vacconv 잡을 자세로 세지 않는다 (C1 과 같은 규율)
        for jn in _pick(jobs, kind="prospective_pose", fragment=f,
                        seed=SEED_MAIN, d3="on", vacconv=None):
            d_cx, why_c = pair_delta(jn)
            if d_cx is None:
                miss.append(why_c); continue
            rows.append({"job": jn, "delta_eV": round(d_cx - d_slab - d_mol, 6)})
        # ★ 기대 자세 수는 **동결된 manifest** 에서 온다 (C1 과 같은 규율) — 회수분에서
        #   세면 자세가 통째로 빠져도 기대가 같이 줄어 영영 못 잡는다.
        # ⛔ 회신 BB P1 — 여기가 **이름 파싱**이었고 d3-off 쌍둥이를 기대에만 넣어
        #   정상 묶음에서도 used<required 로 영구 unresolved 였다. C1 과 **같은
        #   술어**를 쓴다.
        _want_keys = _expected_pose_keys(man, f)
        n_want = len(_want_keys)
        if not n_want:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": "MANIFEST.planned 에 이 조각의 pm1 자세가 없다"}
            continue
        if miss or len(rows) != n_want or not rows:
            res["by_frag"][f] = {"verdict": "unresolved", "missing": miss,
                                 "n_used": len(rows), "n_required": n_want,
                                 "required_keys": _want_keys[:6],
                                 "used_keys": [x["job"] for x in rows][:6],
                                 "예상밖": sorted(set(x["job"] for x in rows)
                                                  - set(_want_keys))[:4],
                                 "누락": sorted(set(_want_keys)
                                                - set(x["job"] for x in rows))[:4],
                                 "why": "자세 하나라도 Edisp 가 없거나 검사에 걸리면 "
                                        "unresolved — 부분집합 평균을 내지 않는다"}
            continue
        m = sum(x["delta_eV"] for x in rows) / len(rows)
        means[f] = m
        res["by_frag"][f] = {"n": len(rows), "mean_delta_eV": round(m, 6),
                             "rows": rows, "d_slab_eV": round(d_slab, 6),
                             "d_mol_eV": round(d_mol, 6)}
    sd = next((f for f in means if "sdcp" in f), None)
    ct = next((f for f in means if f != sd), None)
    if not (sd and ct):
        res["verdict"] = "unresolved — 두 조각이 다 필요하다"
        return res
    D = means[sd] - means[ct]
    res["D_eV"] = round(D, 6)
    # ★★ 부호 규약 정정 (회신 AB P0-3) — 종전 코드는 **정확히 설명적인 경우를
    #    기각**했다. 봉인된 0.90 eV 는 (UMA − DFT) 규약이고, D3 는 총에너지에
    #    **더해지는** 항이므로
    #        offset_f = E_ads^UMA − E_ads^DFT ≈ −δ_f
    #    ⇒ 예측되는 오프셋 차등 = (−δ_SDCP) − (−δ_c10) = δ_c10 − δ_SDCP = **−D**
    #    이다. 그래서 비교하는 양을 offset 규약으로 **이름부터** 맞춘다 —
    #    부호를 뒤집는 게 아니라 같은 규약에서 재는 것이다.
    res["predicted_offset_gap_eV"] = round(-D, 6)
    res["ratio"] = round(-D / C3_REF_GAP_EV, 4)
    res["sign_convention"] = (
        "0.90 eV = mean(UMA − DFT)_SDCP − mean(UMA − DFT)_c10 = +0.9028 "
        "(prereg 오프셋_UMA_빼기_DFT_eV). D3 는 additive 이므로 offset ≈ −δ ⇒ "
        "예측 오프셋 차등 = −D. **흡착에너지 오프셋이지 총에너지 오프셋이 아니다** "
        "— 원소별 energy-zero 는 소거된다")

    # ★ 조각내 일관성 — **평균만으로 판정하지 않는다.** D3 는 기하 의존 항이라
    #   자세마다 달라야 하는데, 관측 오프셋은 조각 안에서 상수였다
    #   (SDCP 6 meV · c10 37 meV). δ 가 그보다 훨씬 크게 흔들리면 평균이 맞아도
    #   "D3 로 설명" 은 성립하지 않는다 (prereg ⛔_분산_귀속_철회_2026_08_29).
    within = {}
    for f, r in res["by_frag"].items():
        rows = r.get("rows") or []
        if len(rows) < 2:
            continue
        vals = [x["delta_eV"] for x in rows]
        rng = max(vals) - min(vals)
        obs = C3_OFFSET_RANGE_EV.get(f)
        within[f] = {"delta_range_eV": round(rng, 6),
                     "observed_offset_range_eV": obs,
                     "slack": C3_WITHIN_SLACK,
                     "ok": None if obs is None else bool(rng <= obs * C3_WITHIN_SLACK)}
        r["within_fragment_range_eV"] = round(rng, 6)
    res["within_fragment"] = within
    _bad = sorted(f for f, w in within.items() if w["ok"] is False)

    if -D * C3_REF_GAP_EV <= 0:
        res["verdict"] = ("**미해결** — 예측 오프셋 차등(−D)의 부호가 관측 "
                          f"{C3_REF_GAP_EV:+.2f} eV 와 반대다. 절댓값으로 비율을 "
                          "적용하면 반대 방향 효과를 '설명' 으로 오판한다")
    elif _bad:
        res["verdict"] = (
            "**미해결 — 조각내 일관성 실패** (%s). δ 의 조각내 range 가 관측 오프셋 "
            "상수성의 %g배를 넘는다. D3 는 기하 의존 항이라 자세마다 달라야 하는데 "
            "관측 오프셋은 조각 안에서 상수였다 — 평균 비율이 맞아도 D3 귀속은 "
            "성립하지 않는다 (prereg 분산 귀속 철회)." % (", ".join(_bad), C3_WITHIN_SLACK))
    elif res["ratio"] >= C3_HI:
        res["verdict"] = (f"이 네 자세에서 관측된 {C3_REF_GAP_EV} eV 차등을 "
                          f"**수치상 {res['ratio']:.0%} 설명**한다 (인과가 아니라 분해)")
    elif res["ratio"] <= C3_LO:
        res["verdict"] = "분산 기여로는 설명되지 않는다 — 원인은 기체 기준 오차 또는 자기 basin 쪽"
    else:
        res["verdict"] = "**미해결** — 어느 것도 채택하지 않는다"
    return res


def _estimand_topology_check(keys, jobs, label):
    """회신 AP #2 — D 에 들어가는 **두 complex** 가 같은 자기 topology 인가.

    → {"blocks": [...], "by_job": {...}, "same": bool|None}

    ⛔ 존재 확인이 아니라 **비교**다. 종전엔 각 잡에 realized_basin_id 가 있는지만
      보고 서로 같은지는 안 봤다 — 다른 basin 을 섞은 D 가 통과했다.
    ⚠ 전역 스핀 반전은 같은 상태로 본다 (same_topology_direct 규약).
    """
    out = {"blocks": [], "by_job": {}, "same": None, "branch": label}
    ks = [k for k in ("E_C_sdcp", "E_C_control") if keys.get(k)]
    if len(ks) < 2:
        out["blocks"].append(
            "ESTIMAND_TOPOLOGY_KEYS_MISSING(%s: complex key 가 둘이 아니다)" % label)
        return out
    ja, jb = jobs.get(keys[ks[0]]), jobs.get(keys[ks[1]])
    for k in ks:
        fp, why = magnetic_topology_direct(jobs.get(keys[k]) or {})
        out["by_job"][keys[k]] = {"fingerprint": fp, "why": why}
        if fp is None:
            out["blocks"].append(
                "ESTIMAND_TOPOLOGY_UNRESOLVED(%s %s=%s: %s — 어떤 자기 상태에서 "
                "잰 값인지 모른 채로 D 를 만들지 않는다)"
                % (label, k, keys[k], (why or ["사유 없음"])[0]))
    if out["blocks"]:
        return out
    same, why = same_topology_direct(ja, jb)
    out["same"], out["why"] = bool(same), why
    if not same:
        out["blocks"].append(
            "ESTIMAND_TOPOLOGY_MISMATCH(%s: 두 complex 가 **다른 자기 basin** 이다 "
            "(%s) — 상태를 가로질러 뺀 차는 조건부 D 가 아니다)" % (label, why))
    return out


#: 🔴 회신 BF P0-1 — 비준된 protocol 의 **정확한 네 잡 경로**가 estimand 의 정본이다.
C12_PROTOCOL_REL = "db/properties/sdcp_c12_protocol_2026_08_30.json"
#: protocol 의 job_key 이름 → manifest estimand_job_keys 이름 (PTFE = control 조각)
C12_PROTOCOL_KEY_MAP = {"E_C_SDCP": "E_C_sdcp", "E_C_PTFE": "E_C_control",
                        "E_G_SDCP": "E_G_sdcp", "E_G_PTFE": "E_G_control"}
#: 질량표 — 기체 상자의 **질량중심** 재계산용 (생성기 ase 질량과 같은 값, 소수 3자리)
C12_MASS = {"H": 1.008, "Li": 6.94, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998,
            "P": 30.974, "S": 32.06, "Cl": 35.45, "Ni": 58.693, "Nd": 144.242}


#: selftest 픽스처용 — 실물 protocol 의 **결박에 쓰이는 두 절**만 흉내낸 최소 사본.
#:   (selftest_k 와 _selftest_closure 둘 다 쓰므로 모듈 수준에 둔다 — 2026-09-03 NameError 실측)
_PROTO_FIX = {"schema": "fixture/protocol", "status": "ratified",
              "2b_D_의_job_key_사전고정_2026_08_31": {"job_key": {
                  "E_C_SDCP": "prospective/sdcp_neutral__b00__afm2424_pm1",
                  "E_C_PTFE": "prospective/ptfe_c10__b00__afm2424_pm1",
                  "E_G_SDCP": "refs/mol__sdcp_neutral__box24",
                  "E_G_PTFE": "refs/mol__ptfe_c10__box24"}},
              "4_진공_두께_수렴_시험": {"c1_A": 36.6551, "c2_A": 40.6551}}


def _write_proto_fixture(root, doc=None):
    """selftest 용 — 번들 루트에 protocol 원문 사본을 쓰고 governance_binding 조각을 돌려준다."""
    root = pathlib.Path(root)
    (root / "governance").mkdir(parents=True, exist_ok=True)
    (root / "governance" / "sdcp_c12_protocol_2026_08_30.json").write_text(
        json.dumps(doc if doc is not None else _PROTO_FIX, ensure_ascii=False, indent=1),
        encoding="utf-8")
    return {"bundled_sources": {C12_PROTOCOL_REL: "governance/sdcp_c12_protocol_2026_08_30.json"}}


def _bundled_ref_path(man, rel):
    """번들에 실린 참조 문서 원문 사본의 절대경로 → (path | None, 사유).

    🔴 회신 BF P0-4 — `bundled_sources` 경로가 번들 **안**에 있어야 한다 (`../` 이탈 금지).
    """
    root = (man or {}).get("_root")
    srcs = ((man or {}).get("governance_binding") or {}).get("bundled_sources") or {}
    if not root:
        return None, "번들 루트(_root)를 모른다"
    r = srcs.get(rel)
    if not r or not isinstance(r, str):
        return None, "%s: bundled_sources 에 원문 사본 경로가 없다" % rel
    if os.path.isabs(r) or ".." in r.replace("\\", "/").split("/"):
        return None, "%s: bundled_sources 경로 %r 가 번들 밖을 가리킨다 (절대경로·`..` 금지)" % (rel, r)
    f = os.path.realpath(os.path.join(root, *r.split("/")))
    if not (f == os.path.realpath(root) or f.startswith(os.path.realpath(root) + os.sep)):
        return None, "%s: 원문 사본 %r 이 번들 루트 밖으로 해석된다" % (rel, r)
    if not os.path.isfile(f):
        return None, "%s: 원문 사본이 번들에 없다 (%s)" % (rel, r)
    return f, None


def _protocol_exact_map(man):
    """비준 protocol 원문 사본에서 estimand 네 잡의 **정확한 경로**를 읽는다 → (map | None, 사유)."""
    f, why = _bundled_ref_path(man, C12_PROTOCOL_REL)
    if f is None:
        return None, why
    try:
        with open(f, encoding="utf-8") as _fh:
            pj = json.load(_fh)
    except Exception as e:                                   # noqa: BLE001
        return None, "protocol 원문 파싱 실패 (%r)" % (e,)
    jk = ((pj.get("2b_D_의_job_key_사전고정_2026_08_31") or {}).get("job_key") or {})
    out = {}
    for pk, mk in C12_PROTOCOL_KEY_MAP.items():
        v = jk.get(pk)
        if not v or not isinstance(v, str):
            return None, "protocol 의 job_key.%s 가 없다 — exact map 이 봉인되지 않았다" % pk
        out[mk] = v
    return out, None


def _protocol_vacuum_cells(man):
    """비준 protocol 원문 사본의 진공 시험 셀 높이 (c1_A, c2_A) → (tuple | None, 사유)."""
    f, why = _bundled_ref_path(man, C12_PROTOCOL_REL)
    if f is None:
        return None, why
    try:
        with open(f, encoding="utf-8") as _fh:
            pj = json.load(_fh)
        sec = pj.get("4_진공_두께_수렴_시험") or {}
        return (float(sec["c1_A"]), float(sec["c2_A"])), None
    except Exception as e:                                   # noqa: BLE001
        return None, "protocol 의 4_진공_두께_수렴_시험.c1_A/c2_A 를 읽을 수 없다 (%r)" % (e,)


def _com_frac_poscar(p):
    """POSCAR 판독 결과의 **질량중심** 분수좌표 (직교 대각 셀 전제 — 호출부가 확인)."""
    ms = [C12_MASS.get(str(s).capitalize(), 0.0) for s in p["syms"]]
    if not ms or sum(ms) <= 0:
        return None
    com = [sum(m * r[ax] for m, r in zip(ms, p["pos"])) / sum(ms) for ax in range(3)]
    return [com[ax] / p["cell"][ax][ax] for ax in range(3)]


def _gas_internal_sha(p):
    """생성기 `_emit_mol_job` 과 **같은 식**으로 내부기하 지문을 다시 만든다 (원소:COM기준 상대좌표).
    ⚠ 생성기는 `at.positions − box/2` 를 쓴다 — COM 이 셀 중앙이면 그것이 COM 기준 상대좌표다."""
    box = [p["cell"][ax][ax] for ax in range(3)]
    sig = "|".join("%s:%.6f,%.6f,%.6f" % (s, r[0] - box[0] / 2.0, r[1] - box[1] / 2.0,
                                          r[2] - box[2] / 2.0)
                   for s, r in zip(p["syms"], p["pos"]))
    return hashlib.sha256(sig.encode()).hexdigest()


def receipt_phase_set(job_dir):
    """반송된 EXECUTABLE_RECEIPT.tsv 의 **실행된 상 집합** → set | None(파일 없음)."""
    rp = os.path.join(job_dir, "EXECUTABLE_RECEIPT.tsv")
    if not os.path.isfile(rp):
        return None
    out = set()
    for ln in open(rp, encoding="utf-8", errors="replace").read().splitlines():
        c = ln.split("\t")
        if len(c) >= 2 and c[1] and not c[1].startswith("_runner_"):
            out.add(c[1])
    return out


def _estimand_semantics_check(keys, jobs, man, label, want_role):
    """D 에 들어가는 **네 키의 의미**를 구조화 meta 로 검사한다 → {"blocks", "by_key"}.

    🔴🔴 회신 BE P0-1 (2026-09-03) — 종전 검사는 네 키가 **있고 에너지가 있는지**만
      봤다. 리뷰어 재현(같은 합성 에너지): 두 complex 키 교환 → D=+200.5 · SDCP
      complex 를 stress-sensitivity 잡으로 교체 → D=−1.5 · gas reference 교환 →
      D=−200.5 — 셋 다 차단 없음. 키가 **무엇을 가리키는지** 아무도 안 봤다.
      ⇒ 키마다 기대 의미를 코드에 고정하고 job.json 실물 + manifest.planned 선언
        **양쪽**과 대조한다:
          E_C_sdcp    = sdcp 조각 · prospective_pose · 역할 want_role · seed = branch ·
                        vacconv 아님 · d3 on · d3-off twin 아님
          E_C_control = control 조각 · 같은 조건
          E_G_*       = 그 조각의 mol_ref · box24 · 고정기하 static ·
                        키 이름이 정확히 refs/mol__<frag>__box24 (canary·box20 아님)
        하나라도 어긋나면 D 를 만들지 않는다 (대체하지 않는다).

    ⛔ 못 하는 것: meta 가 **거짓으로 적혀 있으면** 못 잡는다 (그건 files_sha256 ·
      POSCAR/INCAR 실물 대조의 몫). 이 검사는 "정직한 키 바꿔치기" 를 막는다.
    """
    out = {"blocks": [], "by_key": {}, "branch": label}
    frags = list((man or {}).get("fragments") or [])
    sd = next((f for f in frags if "sdcp" in str(f)), None)
    ct = next((f for f in frags if f != sd), None)
    if not (sd and ct):
        out["blocks"].append("ESTIMAND_SEMANTICS_FRAGMENTS(%s: 조각 둘을 못 가렸다 %s)"
                             % (label, frags))
        return out
    branch = (keys or {}).get("branch")
    if not branch:
        out["blocks"].append("ESTIMAND_SEMANTICS_BRANCH(%s: 봉인에 branch(seed) 가 없다 — "
                             "어느 자기 분기의 D 인지 모른 채로 만들지 않는다)" % label)
    elif label == "pm1" and branch != SEED_MAIN:
        out["blocks"].append("ESTIMAND_SEMANTICS_BRANCH(pm1 봉인의 branch=%r ≠ %s)"
                             % (branch, SEED_MAIN))
    planned = (man or {}).get("planned") or {}
    want = {"E_C_sdcp": ("complex", sd), "E_C_control": ("complex", ct),
            "E_G_sdcp": ("gas", sd), "E_G_control": ("gas", ct)}
    # 🔴🔴 회신 BF P0-1 (2026-09-03) — **비준된 protocol 의 exact map 과 직접 대조한다.**
    #   종전엔 누락·빈 role 을 primary 로 간주하고 planned.meta 는 있을 때만 비교했다.
    #   리뷰어 재현: b12 를 넣고 job/planned metadata 를 함께 primary 로 바꾸면 통과.
    #   protocol 은 b00 네 경로를 이미 고정했다 — 그것과 다르면 D 를 만들지 않는다.
    _pmap, _pwhy = (None, None)
    if label == "pm1" and want_role == "primary":
        _pmap, _pwhy = _protocol_exact_map(man)
        if _pmap is None:
            out["blocks"].append("ESTIMAND_PROTOCOL_MAP_UNVERIFIED(%s: 비준 protocol 의 exact "
                                 "map 을 번들 안에서 읽을 수 없다 — %s. 확인 못 함은 통과가 아니다)"
                                 % (label, _pwhy))
    for k, (kind, frag) in want.items():
        jn = (keys or {}).get(k)
        if not jn:
            out["blocks"].append("ESTIMAND_SEMANTICS_KEY_MISSING(%s: %s 가 없다)" % (label, k))
            continue
        if _pmap is not None and _pmap.get(k) != jn:
            out["blocks"].append("ESTIMAND_NOT_RATIFIED_KEY(%s: %s=%s 이 비준 protocol 의 %s 와 "
                                 "다르다 — 메타를 primary 로 맞춰도 비준 경로가 아니면 D 가 아니다 "
                                 "· BF P0-1)" % (label, k, jn, _pmap.get(k)))
        jm = ((jobs.get(jn) or {}).get("meta") or {})
        pm = ((planned.get(jn) or {}).get("meta") or {})
        bad = []
        if jn not in planned:
            bad.append("planned 에 없는 잡")
        if not jm:
            bad.append("job.json meta 가 없다")
        if kind == "complex":
            if jm.get("kind") != "prospective_pose":
                bad.append("kind=%r≠prospective_pose" % (jm.get("kind"),))
            if jm.get("fragment") != frag:
                bad.append("fragment=%r≠%r" % (jm.get("fragment"), frag))
            # 🔴 BF P0-1 — role 기본값 없음. 없으면 그 자체가 위반이다.
            role = jm.get("role")
            if not role:
                bad.append("role 가 없다 (기본값을 primary 로 읽지 않는다 · BF P0-1)")
            elif want_role == "primary":
                if role != "primary":
                    bad.append("role=%r≠primary (대안 자세를 primary 자리에 넣었다)" % role)
            elif role not in tuple(want_role):
                bad.append("role=%r∉%s (primary 를 민감도 자리에 재사용했다)"
                           % (role, list(want_role)))
            if branch and jm.get("seed") != branch:
                bad.append("seed=%r≠branch %r" % (jm.get("seed"), branch))
            if jm.get("vacconv"):
                bad.append("vacconv(둘째 셀) 잡이다")
            if jm.get("d3_twin_of"):
                bad.append("d3-off twin 이다")
            if jm.get("d3") != "on":
                bad.append("d3=%r≠on" % (jm.get("d3"),))
            # 🔴 BF P0-1 — planned.meta 의 다섯 필드는 **필수**다 (있을 때만 비교하지 않는다)
            if not pm:
                bad.append("planned.meta 가 없다 (선언 없는 잡은 estimand 가 될 수 없다 · BF P0-1)")
            for fld in ("kind", "fragment", "role", "seed", "basin_id"):
                if not pm:
                    break
                if fld not in pm or pm.get(fld) in (None, ""):
                    bad.append("planned.%s 가 없다 (필수 선언 · BF P0-1)" % fld)
                elif pm.get(fld) != jm.get(fld):
                    bad.append("planned.%s=%r≠job.json %r" % (fld, pm.get(fld), jm.get(fld)))
        else:
            if jn != "refs/mol__%s__box24" % frag:
                bad.append("키가 refs/mol__%s__box24 가 아니다 (canary·box20·다른 조각 금지)" % frag)
            if jm.get("kind") != "mol_ref":
                bad.append("kind=%r≠mol_ref" % (jm.get("kind"),))
            if jm.get("fragment") != frag:
                bad.append("fragment=%r≠%r" % (jm.get("fragment"), frag))
            try:
                _bm = float(jm.get("box_margin_A"))
            except (TypeError, ValueError):
                _bm = None
            if _bm is None or abs(_bm - 24.0) > 1e-6:
                bad.append("box_margin_A=%r≠24" % (jm.get("box_margin_A"),))
            if jm.get("fixed_geometry_static") is not True:
                bad.append("fixed_geometry_static≠true")
            for fld in ("kind", "fragment"):
                if pm and fld in pm and pm.get(fld) != jm.get(fld):
                    bad.append("planned.%s=%r≠job.json %r" % (fld, pm.get(fld), jm.get(fld)))
        out["by_key"][k] = {"job": jn, "ok": not bad, "why": bad}
        if bad:
            out["blocks"].append("ESTIMAND_SEMANTICS(%s %s=%s: %s)"
                                 % (label, k, jn, "; ".join(bad)[:200]))
    return out


def _gas_bytes_check(man, frag, metas=None, planned=None):
    """box20/box24 POSCAR **실물**에서 셀·좌표 관계를 본다 → 위반 목록.

    🔴🔴 회신 BF P0-3 (2026-09-03) — 종전엔 **상대 관계**(셀 +4 Å · 좌표 +2 Å)만 봤다.
      두 상자를 함께 중심 밖으로 옮기거나 둘 다 더 큰 상자로 바꿔도 통과했고,
      `fixed_geometry_static=true` 는 믿을 뿐 실제 phase 집합을 요구하지 않았다.
      ⇒ 실물에서 ① 질량중심 = (0.5, 0.5, 0.5) ② 절대 상자 = 내부 span + 선언 margin(20/24)
        ③ 내부기하 지문(internal_geometry_sha)을 좌표에서 **재계산**해 메타와 대조
        ④ planned phase 집합 == ["static"] · 반송 receipt 의 실행 상 집합 == {"static"} 을 요구한다.

    🔴 회신 BE P0-2 (2026-09-03) — 리뷰어 재현: box20/24 를 **같은 셀**로 만들고
      `not_centered` 로 선언해도 계약과 수렴이 통과했다. 자기 선언(sha·필드)만 봤기
      때문이다. 요구를 실물에 건다:
        · 셀 대각이 축마다 정확히 +4.0 Å (20→24) · 직교 대각 셀
        · 모든 원자 좌표가 정확히 +2.0 Å 강체 평행이동 (= 같은 내부기하 · COM 이 두 셀
          중앙 — 생성기 `com_at_cell_center` 의 정의 그대로)
        · 원소 순서·개수 동일
      실물이 없으면 확인 못 한 것이고 그것은 통과가 아니다.
    """
    root = (man or {}).get("_root")
    if not root:
        return ["%s: 번들 루트가 없어 box20/24 POSCAR 실물을 확인할 수 없다 (BE P0-2)" % frag]
    p20 = read_poscar(os.path.join(root, "refs", "mol__%s__box20" % frag, "POSCAR"))
    p24 = read_poscar(os.path.join(root, "refs", "mol__%s__box24" % frag, "POSCAR"))
    if p20 is None or p24 is None:
        return ["%s: box20/box24 POSCAR 실물을 읽을 수 없다 — 실물 없이 셀 수렴을 "
                "인정하지 않는다 (BE P0-2)" % frag]
    bad = []
    if p20["syms"] != p24["syms"] or p20["counts"] != p24["counts"]:
        return ["%s: box20/24 원소·개수가 다르다 (%s/%s vs %s/%s)"
                % (frag, p20["species"], p20["counts"], p24["species"], p24["counts"])]
    for ax in range(3):
        for i2 in range(3):
            if i2 != ax and (abs(p20["cell"][ax][i2]) > 1e-6 or abs(p24["cell"][ax][i2]) > 1e-6):
                bad.append("%s: 기체 셀이 직교 대각이 아니다" % frag)
                return bad
        d = p24["cell"][ax][ax] - p20["cell"][ax][ax]
        if abs(d - 4.0) > 1e-4:
            bad.append("%s: 셀 %s축 차 %.4f Å ≠ 4.0 — box20/24 가 실제로 20/24 가 아니다"
                       % (frag, "abc"[ax], d))
    if bad:
        return bad
    mx = 0.0
    for a20, a24 in zip(p20["pos"], p24["pos"]):
        for ax in range(3):
            mx = max(mx, abs((a24[ax] - a20[ax]) - 2.0))
    if mx > 1e-4:
        bad.append("%s: 좌표가 +2.0 Å 강체 평행이동이 아니다 (최대 편차 %.4f Å) — "
                   "내부기하 또는 중심 배치가 다르다" % (frag, mx))
    # 🔴 BF P0-3 ① 질량중심이 두 셀 모두 **정확히 중앙**인가 (상대 이동만으로는 함께 밀린 것을 못 본다)
    metas = metas or {}
    for tag, pp in (("20", p20), ("24", p24)):
        com = _com_frac_poscar(pp)
        if com is None:
            bad.append("%s box%s: 질량표에 없는 원소라 질량중심을 재계산할 수 없다 (%s)"
                       % (frag, tag, sorted(set(pp["syms"]))))
            continue
        if max(abs(c - 0.5) for c in com) > 1e-3:
            bad.append("%s box%s: 질량중심 분수좌표 (%.4f, %.4f, %.4f) ≠ (0.5, 0.5, 0.5) — "
                       "COM 중심 배치가 아니다 (두 상자를 함께 옮겨도 잡힌다 · BF P0-3)"
                       % (frag, tag, com[0], com[1], com[2]))
        # ② 절대 상자 = 내부 span + 선언 margin (둘 다 더 큰 상자로 바꾼 것을 잡는다)
        span = [max(r[ax] for r in pp["pos"]) - min(r[ax] for r in pp["pos"]) for ax in range(3)]
        want_margin = float(tag)
        mm = metas.get(tag) or {}
        try:
            decl_margin = float(mm.get("box_margin_A"))
        except (TypeError, ValueError):
            decl_margin = None
        if decl_margin is not None and abs(decl_margin - want_margin) > 1e-6:
            bad.append("%s box%s: 메타 box_margin_A=%r ≠ %s" % (frag, tag, mm.get("box_margin_A"), tag))
        for ax in range(3):
            got = pp["cell"][ax][ax] - span[ax]
            if abs(got - want_margin) > 1e-3:
                bad.append("%s box%s: %s축 상자 − span = %.4f Å ≠ margin %.0f — 절대 상자 크기가 "
                           "선언과 다르다 (BF P0-3)" % (frag, tag, "abc"[ax], got, want_margin))
                break
        gap = min(min(r[ax] for r in pp["pos"]) for ax in range(3))
        gap2 = min(pp["cell"][ax][ax] - max(r[ax] for r in pp["pos"]) for ax in range(3))
        if min(gap, gap2) < 4.0 - 1e-6:
            bad.append("%s box%s: 최소 진공 여백 %.2f Å < 4 — 생성기 계약 위반" % (frag, tag, min(gap, gap2)))
        # ③ 내부기하 지문을 **좌표에서 재계산**해 메타와 대조 (메타만 같게 적은 것을 잡는다)
        if mm:
            _sha_now = _gas_internal_sha(pp)
            if mm.get("internal_geometry_sha") != _sha_now:
                bad.append("%s box%s: internal_geometry_sha 메타 %s… ≠ 좌표에서 재계산 %s… — 메타가 "
                           "실물을 말하지 않는다 (BF P0-3)"
                           % (frag, tag, str(mm.get("internal_geometry_sha"))[:12], _sha_now[:12]))
        # ④ phase 집합 — 선언(planned)과 실행(receipt) 둘 다 정확히 static 하나
        key = "refs/mol__%s__box%s" % (frag, tag)
        pl = ((planned or {}).get(key) or {})
        if pl and list(pl.get("phases") or []) != ["static"]:
            bad.append("%s box%s: planned.phases=%r ≠ ['static'] — 고정기하 static 단독이 아니다"
                       % (frag, tag, pl.get("phases")))
        if (man or {}).get("staged_runner"):
            ph = receipt_phase_set(os.path.join(root, "refs", "mol__%s__box%s" % (frag, tag)))
            if ph is None:
                bad.append("%s box%s: 반송 receipt 가 없어 실행된 상 집합을 확인할 수 없다 (통과 아님)"
                           % (frag, tag))
            elif ph != {"static"}:
                bad.append("%s box%s: 실행된 상 집합 %s ≠ {'static'} — 상자별 이완이 δ_gas 에 섞인다"
                           % (frag, tag, sorted(ph)))
    return bad


def _closure_estimand(man, results, E, emol, jobs, merge_info=None):
    """사전등록한 조각 간 대비를 **코드로** 계산한다 (회신 V P0-4).

      A(f,p) = E_complex(f,p) - E_mol(f)      <- 공통 슬랩이 소거되는 양
      primary   ddE_lowE = min_p A(SDCP,p) - min_q A(c10,q)
      secondary G        = min_q A(c10,q) - max_p A(SDCP,p)

    회신 V P0-3 — 기체 자기상태 대조(zero vs nzmag)를 **여기서 실제로 비교**한다.
    대조가 더 낮으면 `MOLECULAR_STATE_UNRESOLVED` 로 막고 **값을 내지 않는다.**

    ⛔ 이 함수가 못 하는 것:
      · 후보집합이 **사전등록된 것인지 검사하지 않는다** (그 manifest 가 아직 없다 —
        회신 V P0-5). `candidate_set` 에 무엇을 썼는지 기록만 한다.
      · 국소 Ni topology 판정을 다시 하지 않는다 — 잡별 `gates` 를 읽어 **버린다**.
      · dense/k 보정을 적용하지 않는다. coarse static 값이다.
      · 게이트된 자세를 다음 순위로 **대체하지 않는다** (회신 U C-2: 조용한 교체 금지).
    """
    frags = [f for f in (man.get("fragments") or []) if f in emol]
    if len(frags) < 2:
        return None

    # ══ cohort 조립은 **구조화 필드**로 한다 (회신 AA P0-3) ══════════════════
    #   경로 문자열 파싱은 임시봉합이다. job.json 이 이미 kind·role·fragment·
    #   seed·basin_id·source_pose·phases·d3 를 갖고 있으므로 그것으로 조립하고,
    #   **경로와 구조화 필드가 어긋나면 hard fail** 한다 (조용히 한쪽을 믿지 않는다).
    def _meta(jr):
        return (jr.get("meta") or {})

    def _is_vacconv(jr):
        """진공 수렴 시험용 둘째 셀 잡인가.

        ⛔ 회신 AJ — 종전엔 이 잡들이 `kind=prospective_pose` 라 **일반 자세와 똑같이**
           취급됐다. 그러면 ① min 후보 풀에 다른 셀의 에너지가 섞이고 ② 같은
           (basin, seed) 키라 c1 값을 c2 가 **덮어쓴다**. 셀이 다른 에너지를 한
           seed-pair 로 조립하게 된다. 코호트에서 뺀다.
        """
        return bool((jr.get("meta") or {}).get("vacconv"))

    def _cohort(jn, jr):
        """이 잡의 (kind, fragment, seed, basin, d3) — 전부 구조화 필드에서.

        ⛔ 회신 AJ — 진공 수렴 시험(둘째 셀) 잡은 `kind` 를 **바꿔서** 낸다.
           그대로 두면 일반 자세와 같은 (basin, seed) 키를 가져 ① min 후보 풀에
           다른 셀 에너지가 섞이고 ② c1 값을 c2 가 덮어쓴다.
        """
        m = _meta(jr)
        if _is_vacconv(jr):
            return {"kind": "vacuum_convergence", "fragment": m.get("fragment"),
                    "seed": m.get("seed"), "basin": m.get("basin_id"),
                    "d3": "on", "cell": m.get("vacconv")}
        return {"kind": m.get("kind"), "fragment": m.get("fragment"),
                "seed": m.get("seed"), "basin": m.get("basin_id"),
                "d3": m.get("d3"), "role": m.get("role")}

    #: primary 와 **같은 풀에 넣으면 안 되는** 역할 (회신 AJ ④).
    #   sensitivity·stress_sensitivity 는 '다른 앵커에서도 방향이 유지되나' 만 본다.
    #   min·평균·순위에 섞으면 그 시험이 사라지고 표본만 늘어난다.
    ALT_ROLES = ("sensitivity", "stress_sensitivity")

    def _is(jn, f):
        """조각 f 의 **primary 복합체**인가 — 구조화 필드로만 판단한다.

        ⛔ 회신 AJ ④ — 종전엔 role 을 안 봐서 대안 자세가 primary min 풀에 섞였다.
        """
        c = _cohort(jn, jobs.get(jn) or {})
        if c["kind"] != "prospective_pose" or c["fragment"] != f:
            return False
        return (c.get("role") or "primary") not in ALT_ROLES
    out = {
        "schema": "prereg_closure/v1",
        # ⛔⛔ 회신 BB P0-4 (2026-09-02) — **폐기된 사전등록을 가리키고 있었다.**
        #   `prereg_sdcp_neutral_contrast_2026_08_29.json` 은 스스로 `지위:
        #   ⛔ SUPERSEDED` 라고 적혀 있다. 그 문서의 primary estimand
        #   (`ΔΔE_lowE = min_p A(SDCP,p) − min_q A(c10,q)`)는 회신 X 가 NO-GO 를
        #   냈고, C-12 는 **다른 양**(사전 고정 네 잡의 직접 대입 D)을 잰다.
        #   결과 provenance 가 폐기 문서를 가리키면 "무엇을 사전등록했나" 가
        #   이어지지 않는다 — 이 캠페인이 내내 문제 삼은 형태 그대로다.
        "prereg_doc": ["db/properties/sdcp_c12_claim_prereg_2026_08_31.json",
                       "db/properties/sdcp_c12_protocol_2026_08_30.json"],
        "prereg_doc_note": (
            "보고량은 claim prereg, D 의 정의는 protocol §2b 다. 두 문서의 내용 SHA 와 "
            "비준 상태는 MANIFEST.governance_binding 에 결박돼 있다 (회신 BB P0-2)."),
        "superseded_origin": {
            "doc": "db/properties/prereg_sdcp_neutral_contrast_2026_08_29.json",
            "지위": "⛔ SUPERSEDED (2026-08-31) — estimand 가 다르다",
            "⚠": ("이 문서의 **실측 기록**(UMA–DFT 오프셋·술폰산 수소결합·표본밀도 "
                  "비대칭)은 여전히 유효하다. 폐기된 것은 estimand 이지 관측이 "
                  "아니다. 여기에 남기는 이유는 계보이지 근거가 아니다.")},
        "candidate_set": man.get("candidate_set") or "legacy_champion/cross (미동결)",
        "blocks": [], "block_records": [], "A_by_frag": {},
    }

    # ── 경로 ↔ 필드 정합성. 어긋나면 값을 만들지 않는다 ──────────────────────
    _incoh = []
    for _jn, _jr in jobs.items():
        _m = _meta(_jr)
        if not _m.get("kind"):
            _incoh.append(f"{_jn}: job.json 에 kind 없음")
            continue
        _base = _jn.rsplit("/", 1)[-1]
        _fg, _sd, _d3 = _m.get("fragment"), _m.get("seed"), _m.get("d3")
        if _fg and _m["kind"] == "prospective_pose" and not _base.startswith(_fg + "__"):
            _incoh.append(f"{_jn}: fragment={_fg} 인데 경로가 그렇지 않다")
        if _sd and _sd not in _base:
            _incoh.append(f"{_jn}: seed={_sd} 인데 경로에 없다")
        if _d3 not in ("on", "off"):
            _incoh.append(f"{_jn}: job.json 에 d3 필드가 없다 (필드 없는 잡이 남으면 "
                          f"분류가 다시 이름으로 샌다 — v7 실측)")
        elif (_d3 == "off") != _base.endswith("__d3off"):
            _incoh.append(f"{_jn}: d3={_d3} 인데 경로 접미어와 어긋난다")
    if _incoh:
        out["blocks"].append(
            "COHORT_INCOHERENT(%d건 — 경로와 구조화 필드가 어긋난다: %s). "
            "어느 쪽이 맞는지 우리가 정할 수 없으므로 값을 만들지 않는다"
            % (len(_incoh), _incoh[:3]))
    out["cohort_fields"] = {"checked": len(jobs), "incoherent": len(_incoh)}


    # (0) calibration 전용 tranche 면 **primary 를 내지 않는다** (회신 X P0-2)
    if str(out["candidate_set"]).startswith(("calibration_pilot", "motif_probe")):
        out["blocks"].append(
            "CALIBRATION_ONLY_TRANCHE — 이 잡들은 창 W 를 정하려고 돌린 것이고 "
            "후보집합이 아니다. primary 는 창 확정 → 창 안 전 자세 계산 → audit "
            "봉인해제 → regret 판정 순서를 마친 뒤에만 낸다 (회신 X Q6).")
    # ⛔⛔ 회신 AP #3 (2026-08-31) — block 을 **구조화**한다. 종전엔 문자열뿐이라
    #   "이 block 이 D 에 들어가는 네 잡을 언급하는가" 를 **문자열 매칭**으로 판단했다.
    #   그런데 `BASIN_HETEROGENEOUS` 문자열에는 job 경로가 없다 ⇒ 그 조건이 **항상
    #   참**이 되어 그 block 이 언제나 강등됐다. 막으려던 것을 못 막고 있었다.
    #   ⇒ code · job_keys · scope · affects_estimand 를 기록하고, 강등 판정은
    #     **문자열이 아니라 그 필드**로 한다.
    def _blk(code, msg, job_keys=None, scope="global", affects_estimand=True):
        out["blocks"].append(msg)
        out["block_records"].append({
            "code": code, "msg": msg, "job_keys": sorted(job_keys or []),
            "scope": scope, "affects_estimand": bool(affects_estimand)})

    # (0b) 층화 홀드아웃도 **primary 를 내지 않는다** (2026-08-30, 옵션 A).
    #   홀드아웃은 선택기 가정을 시험하는 별도 질문이다. 홀드아웃이 더 낮게 나오면
    #   그것은 primary 의 min 후보가 아니라 **재개 조건 발동**이다 — 넣으면
    #   사전등록 집합이 사라지고 min 이 표본크기를 따라 움직인다
    #   (champion pool size bias, kb/results/champion_pool_size_bias_2026_08_18.md).
    if str(out["candidate_set"]).startswith("holdout_stratified"):
        out["blocks"].append(
            "HOLDOUT_TRANCHE — 층화 홀드아웃은 선택기 가정(H1·H2)을 시험하는 집합이지 "
            "primary 후보집합이 아니다. 이 잡들의 값을 ΔΔE_lowE 의 min 에 넣지 않는다. "
            "estimand 카드: kb/questions/sdcp_stageA_holdout_selector_2026_08_30.md")

    # (1) 기체 자기상태 대조 — 값을 내기 **전에** 본다 (회신 V P0-3)
    ctls = man.get("molecular_spin_controls") or {}
    for f in frags:
        rel = ctls.get("mol__%s__box24" % f)
        if not rel:
            out["blocks"].append("MOLECULAR_SPIN_CONTROL_MISSING(%s)" % f)
            continue
        # ⛔ 회신 AJ — 종전엔 `refs/` 를 떼고 basename 을 넘겼다. E() 는 잡 상대경로로
        #   찾으므로 실제 잡이 있어도 **항상 PENDING** 이 됐다. 둘 다 시도한다.
        e1 = E(str(rel))
        if e1 is None:
            e1 = E(str(rel).split("/")[-1])
        e0 = emol.get(f)
        if e1 is None:
            out["blocks"].append("MOLECULAR_SPIN_CONTROL_PENDING(%s)" % f)
        elif e0 is None:
            # ⛔⛔ 회신 AS 해제조건 2 (2026-08-31) — box24 **부모가 실패하고**
            #   nzmag canary 만 성공하면 아래 `else` 에서 `e1 - None` 으로
            #   **예외로 죽었다**. 결측은 예외가 아니라 구조화 차단이고,
            #   차 계산은 건너뛴다 (확인 못 한 것은 통과가 아니다).
            out["blocks"].append(
                "MOLECULAR_SPIN_CONTROL_PARENT_MISSING(%s: canary 는 회수됐는데 "
                "부모 box24 에너지가 없다 — 뺄 기준이 없으므로 스핀 대조를 "
                "만들지 않는다)" % f)
        elif e1 < e0 - 1e-4:
            out["blocks"].append(
                "MOLECULAR_STATE_UNRESOLVED(%s: 비영 시작이 %.4f eV 더 낮다 — "
                "자동 채택하지 않는다. 전자상태 정의와 box 수렴을 다시 심사할 것)"
                % (f, e0 - e1))
        else:
            out.setdefault("spin_control_delta_eV", {})[f] = round(e1 - e0, 5)
        # ⛔⛔ 회신 AO P0-4 — 두 static 이 **같은 기하**일 때만 이 차가 스핀 검사다.
        #   다르면 구조 이완 에너지가 섞여 δ_m 이 아니다. 검사를 못 했으면 그것도 차단
        #   (fail-closed — 확인 못 한 것은 통과가 아니다).
        _gg = ((results or {}).get("gas_canary_geom") or {}).get(f)
        if _gg is None:
            out["blocks"].append(
                "CANARY_GEOM_UNCHECKED(%s: 부모/ canary static 기하 대조 결과가 없다)" % f)
        elif _gg.get("same") is not True:
            out["blocks"].append(
                "CANARY_GEOM_MISMATCH(%s: %s — 스핀 대조에 구조 이완 에너지가 섞인다)"
                % (f, _gg.get("why") or ("최대 Cartesian 차 %.3g Å · 셀 차 %.3g Å"
                                         % (_gg.get("max_cart_diff_A", float("nan")),
                                            _gg.get("max_cell_diff_A", float("nan"))))))

    # (2) A(f,p) — 게이트 통과한 복합체만. 게이트된 것은 **버리되 기록한다**
    #   ★ 회신 Z P0-4 — realized basin 을 같이 모은다. seed 이름(pm1/net4)으로
    #     짝지어 빼면 다른 상태를 가로질러 뺀 것이 된다.
    # ⛔⛔ 회신 AS 해제조건 3 (2026-08-31) — 종전엔 `not jr.get("ok")` 로 **먼저**
    #   건너뛰어서, 실제로 게이트된 잡은 아래 `GATED_POSE` 에 **도달하지 못했다**.
    #   그러면 pooled 값이 **살아남은 부분집합**으로 조용히 계산된다 — net4 가 전부
    #   게이트돼도 pm1 만으로 secondary_G 가 인용가능이 될 수 있었다.
    #   ⇒ 계획된 pool 전체를 세고, 하나라도 결측·게이트·미해결이면 pooled 를 막는다.
    _pool_expect, _pool_bad = {}, {}
    for _pj, _pl in ((man.get("planned") or {}).items()):
        _pm = (_pl.get("meta") or {})
        if _pm.get("kind") != "prospective_pose" or _pm.get("vacconv"):
            continue
        _pf = _pm.get("fragment")
        if _pf in frags:
            _pool_expect.setdefault(_pf, []).append(_pj)
    basins = {}
    for f in frags:
        rows = []
        for jn in sorted(_pool_expect.get(f, [])):
            jr = jobs.get(jn)
            if jr is None:
                # ⛔ 회신 AS 3 — 계획엔 있는데 **회수되지 않았다**. `_is()` 는
                #   jobs 를 보므로 여기서 False 가 되어 조용히 pool 밖으로 샌다.
                #   결측을 먼저 잡는다 (계획의 role 로 pool 대상인지 판단).
                _rl = ((( man.get("planned") or {}).get(jn) or {})
                       .get("meta") or {}).get("role") or "primary"
                if _rl not in ALT_ROLES:
                    _pool_bad.setdefault(f, []).append("%s: 결과 없음" % jn)
                continue
            if not _is(jn, f):
                continue                      # 대안 자세 역할 — pool 밖 (ALT_ROLES)
            g = [x for x in (jr.get("gates") or [])
                 if x.startswith(("MAGNETIC", "RADICAL", "PAIR_", "SOURCE_", "BASIN_"))]
            e = E(jn)
            if g:
                _blk("GATED_POSE", "GATED_POSE(%s: %s)" % (jn, g[0]),
                     job_keys=[jn], scope="pooled_diagnostic")
                _pool_bad.setdefault(f, []).append("%s: %s" % (jn, g[0][:40]))
                continue
            if not jr.get("ok"):
                _blk("POOL_JOB_NOT_OK",
                     "POOL_JOB_NOT_OK(%s: 게이트 목록에 없는 사유로 사용 불가 — %s)"
                     % (jn, (jr.get("gates") or ["사유 미기록"])[0][:40]),
                     job_keys=[jn], scope="pooled_diagnostic")
                _pool_bad.setdefault(f, []).append("%s: not ok" % jn)
                continue
            if e is None:
                _pool_bad.setdefault(f, []).append("%s: 에너지 없음" % jn)
                continue
            rb = (((jr.get("geom") or {}).get("magnetic") or {})
                  .get("realized_basin_id"))
            basins.setdefault(f, {}).setdefault(rb, []).append(jn)
            if emol.get(f) is None:
                continue          # ⛔ 회신 AR P0-3 — `float − None` 예외 대신 건너뛴다
                                  #   (기체 기준 부재는 위에서 이미 block 이다)
            rows.append([round(e - emol[f], 6), jn, rb])
        rows.sort()
        out["A_by_frag"][f] = {"n": len(rows),
                               "min": rows[0] if rows else None,
                               "max": rows[-1] if rows else None}
    out["realized_basins"] = {f: {str(k): v for k, v in (b or {}).items()}
                              for f, b in basins.items()}
    # ⛔ 회신 AS 해제조건 3 — 계획된 pool 이 **전건 사용가능**한지 한 곳에서 판정한다
    out["pool_completeness"] = {
        "expected": {f: len([j for j in v if _is(j, f)])
                     for f, v in _pool_expect.items()},
        "usable": {f: (out["A_by_frag"].get(f) or {}).get("n", 0) for f in frags},
        "unusable": {f: v[:4] for f, v in _pool_bad.items()},
        "ok": not _pool_bad,
        "⛔": ("계획된 자세 하나라도 결측·게이트·미해결이면 pooled 값(secondary_G · "
               "pooled min · 일반화 주장)을 **전부 비인용**으로 한다. 살아남은 "
               "부분집합으로 min 을 뽑으면 표본이 통과 쪽으로 편향된다")}
    if _pool_bad:
        _blk("POOL_INCOMPLETE",
             "POOL_INCOMPLETE(계획된 자세 중 사용 불가 %s — pooled 값을 내지 않는다)"
             % {f: len(v) for f, v in _pool_bad.items()},
             job_keys=[j.split(":")[0] for v in _pool_bad.values() for j in v],
             scope="pooled_diagnostic")

    # (2c) 🔴 동종 basin 강제 — 여러 basin 이 섞인 집합에서 min 을 뽑지 않는다
    for f, b in basins.items():
        if None in b:
            _blk("BASIN_UNRESOLVED_IN_SET",
                 "BASIN_UNRESOLVED_IN_SET(%s: %d잡이 realized basin 없음 — %s)"
                 % (f, len(b[None]), b[None][:3]),
                 job_keys=b[None], scope="pooled_diagnostic")
        real = {k: v for k, v in b.items() if k is not None}
        if len(real) > 1:
            _blk("BASIN_HETEROGENEOUS",
                 "BASIN_HETEROGENEOUS(%s: 서로 다른 realized basin %d개가 한 집합에 "
                 "있다 %s — 상태를 가로질러 min 을 뽑지 않는다. seed 이름이 아니라 "
                 "수렴 결과가 갈렸다는 뜻이다)"
                 % (f, len(real), {k: len(v) for k, v in real.items()}),
                 job_keys=[j for v in real.values() for j in v],
                 scope="pooled_diagnostic")

    # (2d) clean slab 과의 동종성 — E_ads 를 만들 때 필요하다 (회신 Z P0-4)
    _slab_rb = set()
    for jn, jr in jobs.items():
        if _cohort(jn, jr)["kind"] != "clean_ref" or not jr.get("ok"):
            continue
        rb = ((jr.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
        if rb:
            _slab_rb.add(rb)
    if _slab_rb:
        out["clean_slab_basins"] = sorted(_slab_rb)
        _cx = {k for b in basins.values() for k in b if k is not None}
        if _cx and not (_cx & _slab_rb):
            out["blocks"].append(
                "BASIN_MISMATCH_SLAB(복합체 basin %s 이 clean slab basin %s 과 "
                "겹치지 않는다 — 이 둘로 흡착에너지를 만들지 않는다)"
                % (sorted(_cx)[:2], sorted(_slab_rb)[:2]))

    # (2b) J_f — pose × magnetic-basin interaction (회신 X Q1)
    #   조각별로 자세 p 의 두 seed 차 d_p = E(p,net4) − E(p,pm1) 를 모아
    #   J_f = max_p d_p − min_p d_p. 자세마다 자기 basin 이 다르게 잡히면 커진다.
    for f in frags:
        d = {}
        for jn, jr in jobs.items():
            c = _cohort(jn, jr)
            if not _is(jn, f) or not jr.get("ok") or c["d3"] == "off":
                continue
            if not c["basin"] or not c["seed"]:
                continue                      # 구조화 필드가 없으면 짝을 못 맞춘다
            d.setdefault(c["basin"], {})[c["seed"]] = E(jn)
        dp = {k: v["afm2424_net4"] - v["afm2424_pm1"] for k, v in d.items()
              if v.get("afm2424_net4") is not None and v.get("afm2424_pm1") is not None}
        # 🔴 회신 AB P0-7 — 종전엔 짝이 **2개만 있어도** J_f 를 냈다. 네 자세 중
        #   한둘이 빠지면 range 가 자동으로 좁아져 **거짓 PASS** 가 된다(C1 과 같은
        #   편향). 기대 자세 수는 동결 manifest 에서 세고, 그 수만큼 두 seed 가
        #   **모두** 유효할 때만 낸다.
        # ⛔⛔ 회신 BB P1 (2026-09-02) — **고르는 술어와 세는 술어가 또 달랐다.**
        #   선택은 `_is(jn, f)` 로 ALT_ROLES(sensitivity·stress_sensitivity)를 빼는데
        #   기대는 잡 키를 `split("__")[1]` 로 파싱해 **대안 자세까지 셌다.** 그래서
        #   정상 2자세×2seed 에서도 `n_pose_used=1 · n_pose_required=2` 로
        #   **영구 unresolved** 였다 (BA P1 이 C1 에서 고친 것과 같은 형태의 세 번째).
        #   ⇒ 구조화 meta 로, **선택과 같은 역할 정책**으로 센다.
        _want_ids = {(_p.get("meta") or {}).get("basin_id")
                     for _p in (man.get("planned") or {}).values()
                     if ((_p.get("meta") or {}).get("kind") == "prospective_pose"
                         and (_p.get("meta") or {}).get("fragment") == f
                         and ((_p.get("meta") or {}).get("role") or "primary")
                         not in ALT_ROLES
                         and (_p.get("meta") or {}).get("vacconv") is None
                         and not (_p.get("meta") or {}).get("d3_twin_of")
                         and (_p.get("meta") or {}).get("basin_id"))}
        _want = len(_want_ids)
        # 🔴 회신 BE P1 (2026-09-03) — 조각당 primary 자세가 하나면 range 는 **구조적으로
        #   0** 이다 (대안 자세 seed 차를 500/400 meV 로 넣어도 J_f=0 — 리뷰어 재현).
        #   0 을 "range 가 작았다" 로 내면 거짓 안심이다 ⇒ **측정 불가**로 낸다.
        if 0 < _want < 2:
            out.setdefault("pose_basin_interaction", {})[f] = {
                "판정": "not_measurable", "J_f_meV": None,
                "n_pose": len(dp), "n_pose_required": _want,
                "why": ("primary 자세가 %d개라 자세 간 range 가 정의되지 않는다 — 값은 0 이 "
                        "아니라 **측정 불가**다. 대안 자세(sensitivity·stress_sensitivity)는 "
                        "역할 정책상 이 풀에 안 들어온다 (회신 BE P1)" % _want)}
            continue
        if not _want or len(dp) != _want:
            out.setdefault("pose_basin_interaction", {})[f] = {
                "판정": "unresolved", "n_pose_used": len(dp), "n_pose_required": _want,
                # ⛔ 회신 BB P1 — 수만 보면 원인을 못 찾는다. 어느 자세가 어긋났는지.
                "required_pose_ids": sorted(x for x in _want_ids if x)[:6],
                "used_pose_ids": sorted(dp)[:6],
                "누락": sorted(_want_ids - set(dp))[:4],
                "예상밖": sorted(set(dp) - _want_ids)[:4],
                "why": ("계획한 자세 전부가 두 seed 다 유효해야 한다 — 부분집합은 "
                        "range 를 좁혀 통과 쪽으로 편향된다 (회신 AB P0-7). "
                        "⚠ 기대 수는 **선택과 같은 술어**로 센다: 대안 역할"
                        "(sensitivity·stress_sensitivity)·vacconv·d3-off 제외 "
                        "(회신 BB P1)")}
            continue
        jf = max(dp.values()) - min(dp.values())
        out.setdefault("pose_basin_interaction", {})[f] = {
            "n_pose": len(dp), "n_pose_required": _want,
            "J_f_meV": round(jf * 1000, 2),
            "delta_by_pose_meV": {k: round(v * 1000, 2) for k, v in sorted(dp.items())},
            # ⚠ 회신 AB P0-7 — "seed-insensitive" 는 **과한 말**이다. 시험한 네 자세
            #   안에서 range 가 작았다는 것뿐이고, seed 에 둔감하다는 일반 진술이
            #   아니다. 허용 문구를 그대로 박는다.
            "판정": ("seed×pose interaction range 가 작았다 (시험한 %d자세 안에서)"
                     % len(dp) if jf <= 0.010 else
                     "magnetic-sensitive" if jf <= 0.040 else
                     "⛔ SELECTOR_FAIL — J_f > 40 meV")}

    # ── 닫힘 조건 C1 · C3 — **코드로** 낸다 (회신 AA P0-4 "실행 가능한 estimand")
    #   primary 가 막혀도 이 둘은 나온다. 손계산으로 넘기면 결과를 보고 식을 고를
    #   여지가 남고, 그것이 이 캠페인을 여덟 번 물린 경로다.
    try:
        out["closure_C1"] = closure_C1(man, jobs, E, emol, frags)
        out["closure_C3"] = closure_C3(man, jobs, E, frags)
        out["closure_vacconv"] = closure_vacconv(man, jobs, E, emol, frags)
        # ⛔ 2026-08-31 — `pass` 가 이제 항상 있으므로(기본 False) **applicable 을 먼저 본다.**
        #   안 그러면 진공 시험 잡이 없는 옛 번들이 "n/a" 인데 FAIL 로 막힌다.
        #   적용 불가와 실패는 다른 상태다.
        if (out["closure_vacconv"].get("applicable")
                and out["closure_vacconv"].get("pass") is False):
            out["blocks"].append("VACCONV_FAIL:" + out["closure_vacconv"]["verdict"])
        for _b in (out["closure_vacconv"].get("blocks") or []):
            out["blocks"].append("VACCONV:" + _b)
        out["potcar_identity"] = potcar_identity_gates(jobs, man)
        # ⛔ 회신 AJ — 종전엔 **기록만** 하고 blocks 에 안 합쳤다. split·pin 불일치를
        #   탐지해도 값 보고를 못 막았다. 게이트가 아니라 로그였던 것이다.
        for _b in (out["potcar_identity"].get("blocking") or []):
            out["blocks"].append("POTCAR_IDENTITY:" + _b)
        out["h1_tolerance"] = h1_tolerance(out["closure_C1"])
        out["closure_C5"] = closure_C5(man, jobs, E, emol, frags, merge_info,
                                       out["h1_tolerance"])
    except Exception as _e:                                  # noqa: BLE001
        out["blocks"].append(f"CLOSURE_COND_ERROR({_e!r})")

    # ⛔⛔ 회신 AO P0-7 (2026-08-31) — pm1 조건부 D 는 **사전 고정한 네 잡**으로
    #   정의됐는데, 앞의 집합 검사(2c)가 pm1 과 net4 를 한 조각 집합으로 묶었다.
    #   그래서 net4 가 다른 basin 에 가면 pm1 네 값이 전부 정상이어도 통째로
    #   NO_VALUE 가 됐고, 정작 요구했던 `D_net4 − D_pm1` 은 계산되지 않았다.
    #   ⇒ **그 네 잡을 언급하지 않는 집합-블록은 차단이 아니라 민감도 주석**으로 내린다.
    #     전역 블록(후보집합·기체 canary·spin control·POTCAR)은 그대로 둔다.
    #   ⚠ 이 강등은 **조기 return 앞에서** 해야 한다 — 뒤에 두면 이미 return 된 뒤다.
    # ⛔⛔ 회신 AP #11 (2026-08-31) — 기체 상자 수렴 게이트를 **조각별 10 meV 가
    #   아니라 최종 estimand 에 직접** 건다. D 에 남는 것은 두 기체의 **차이**이고,
    #   조각별로 각각 10 meV 안이어도 부호가 반대면 차에서 20 meV 가 된다.
    #       δ_gas = [E_G^SDCP(24) − E_G^SDCP(20)] − [E_G^PTFE(24) − E_G^PTFE(20)]
    #   0.01 eV 로 보고하려면 |δ_gas| ≤ 5 meV 여야 한다 (AP 가 지정한 사전 문턱).
    _sdf = next((f for f in frags if "sdcp" in f), None)
    _ctf = next((f for f in frags if f != _sdf), None)
    if _sdf and _ctf:
        # ⛔⛔ 회신 AR 해제조건 3 (2026-08-31) — **cross-job geometry/state gate.**
        #   δ_gas 가 "셀 효과" 이려면 두 상자가 (i) 같은 내부기하에서 출발하고
        #   (ii) 같은 전자상태 정책이며 (iii) **각자 독립으로 이완하지 않아야** 한다.
        #   v15 실물은 네 기체 부모가 전부 relax→static 이라 (iii) 이 깨져 있었고,
        #   δ_gas 는 셀 효과 + 독립 이완 차이를 함께 쟀다. 이제 산출물에서 직접 본다.
        _gp = (man.get("gas_geometry_policy") or {})
        _gasjr = {}
        for _f in (_sdf, _ctf):
            for _b in ("20", "24"):
                _k = "refs/mol__%s__box%s" % (_f, _b)
                _gasjr[(_f, _b)] = ((jobs.get(_k) or {}).get("meta") or {})
        _gx = []
        for _f in (_sdf, _ctf):
            _m20, _m24 = _gasjr[(_f, "20")], _gasjr[(_f, "24")]
            if not _m20 or not _m24:
                _gx.append("%s: box20/box24 잡 메타가 없다" % _f)
                continue
            for _fld, _why in (("internal_geometry_sha", "내부기하가 다르다"),
                               ("electronic_state_sha", "전자상태 정책이 다르다"),
                               ("species_order", "원소 순서가 다르다"),
                               ("counts", "원자 수가 다르다")):
                _a, _b2 = _m20.get(_fld), _m24.get(_fld)
                if _a is None or _b2 is None:
                    _gx.append("%s: %s 를 확인 못 했다 (구판 번들)" % (_f, _fld))
                elif _a != _b2:
                    _gx.append("%s: %s (%s)" % (_f, _why, _fld))
            for _b, _mm in (("20", _m20), ("24", _m24)):
                if _mm.get("fixed_geometry_static") is not True:
                    _gx.append("%s box%s: 고정기하 static 이 아니다 "
                               "(phases=%s) — 독립 이완이 δ_gas 에 섞인다"
                               % (_f, _b, _mm.get("phases")))
                # 🔴 회신 BE P0-2 — 배치·상자 크기를 **선언**에서 본다 (아래는 실물)
                if _mm.get("gas_placement") != "com_at_cell_center":
                    _gx.append("%s box%s: gas_placement=%r — COM 중심 배치가 아니면 "
                               "DIPOL 기준이 갈리고 δ_gas 가 셀 효과가 아니다"
                               % (_f, _b, _mm.get("gas_placement")))
                try:
                    _bmv = float(_mm.get("box_margin_A"))
                except (TypeError, ValueError):
                    _bmv = None
                if _bmv is None or abs(_bmv - float(_b)) > 1e-6:
                    _gx.append("%s box%s: box_margin_A=%r ≠ %s" % (_f, _b, _mm.get("box_margin_A"), _b))
            # 🔴 회신 BE P0-2 — 그리고 POSCAR **실물**에서 셀 +4 Å · 좌표 +2 Å 강체이동을 본다
            # 🔴 회신 BF P0-3 — 절대 관계(COM 중앙 · span+margin · 내부기하 재계산 · phase 집합)까지
            _gx += _gas_bytes_check(man, _f, metas={"20": _m20, "24": _m24},
                                    planned=(man.get("planned") or {}))
        if _gp.get("fixed_geometry_static") is not True:
            _gx.append("manifest.gas_geometry_policy.fixed_geometry_static 이 true 가 "
                       "아니다 (%r)" % (_gp.get("fixed_geometry_static"),))
        out["gas_pair_contract"] = {
            "ok": not _gx, "violations": _gx,
            "요구": ["box20/box24 내부기하 동일 (internal_geometry_sha)",
                     "전자상태 정책 동일 (electronic_state_sha)",
                     "둘 다 고정기하 static — 상자별 독립 이완 금지"],
            "⚠": ("이 계약이 깨지면 δ_gas 는 셀 수렴이 아니라 "
                  "'셀 + 이완 경로' 를 잰 값이라 문턱을 걸 대상이 아니다")}
        if _gx:
            _blk("GAS_PAIR_CONTRACT",
                 "GAS_PAIR_CONTRACT(δ_gas 쌍이 계약을 어겼다 — %s)" % "; ".join(_gx[:4]),
                 job_keys=["refs/mol__%s__box%s" % (f, b)
                           for f in (_sdf, _ctf) for b in ("20", "24")],
                 scope="estimand")
        _g = {}
        for _f in (_sdf, _ctf):
            _g[_f] = (E("refs/mol__%s__box24" % _f), E("refs/mol__%s__box20" % _f))
        # ⛔ 회신 AR P0-3 — 결측을 **예외가 아니라 구조화 block** 으로 처리한다
        _miss_g = [f for f, (a24, a20) in _g.items() if a24 is None or a20 is None]
        if _miss_g:
            _blk("GAS_BOX_NOT_MEASURED",
                 "GAS_BOX_NOT_MEASURED(%s: box20/box24 중 하나가 없다 — 이 묶음에서 "
                 "기체 상자 수렴을 재지 못했다. D 에는 E_G^SDCP − E_G^control 이 "
                 "남으므로 상자 오차가 소거되지 않는다)" % _miss_g,
                 job_keys=["refs/mol__%s__box%s" % (f, b)
                           for f in _miss_g for b in ("20", "24")],
                 scope="estimand")
        else:
            _d24_20 = {f: (v[0] - v[1]) for f, v in _g.items()}
            _dgas = _d24_20[_sdf] - _d24_20[_ctf]
            out["gas_box_delta"] = {
                "delta_gas_meV": round(_dgas * 1000, 3),
                "by_fragment_meV": {f: round(v * 1000, 3) for f, v in _d24_20.items()},
                "tol_meV": round(GAS_BOX_DELTA_TOL * 1000, 1),
                # ⛔ 회신 AR 해제조건 3 — 쌍 계약이 깨지면 이 값은 셀 효과가
                #   아니므로 문턱 통과로 **셀 수 없다**. 수치는 남기되 pass=False.
                "pass": bool(abs(_dgas) <= GAS_BOX_DELTA_TOL) and not _gx,
                "pair_contract_ok": not _gx,
                "식": "δ_gas = [E_G^sdcp(24)−E_G^sdcp(20)] − [E_G^ctl(24)−E_G^ctl(20)]",
                "⚠": ("조각별 값이 각각 작아도 **부호가 반대면 차에서 커진다** — "
                      "그래서 조각별이 아니라 이 차에 문턱을 건다 (회신 AP #11)")}
            if abs(_dgas) > GAS_BOX_DELTA_TOL:
                # 🔴 회신 AV P1-5 — 측정이 **유효한데 문턱을 넘은** 것은 입력 무효가
                #   아니라 해상도 문제다. 자기 문구부터 "보고 해상도를 낮춘다" 였다.
                #   D 를 막지 않고 0.01 eV 인용 자격만 잃는다 (B_num 합산이 잡는다).
                out.setdefault("advisories", []).append(
                    "GAS_BOX_DELTA(δ_gas %.2f meV > %.0f — 0.01 eV 로 보고할 수 없다. "
                    "상자를 키우거나 보고 해상도를 낮춘다 · D_raw 는 보존)"
                    % (_dgas * 1000, GAS_BOX_DELTA_TOL * 1000))

    # ⛔⛔ 회신 AS 해제조건 9 (2026-08-31) — **k 수렴을 최종 대비에 직접 건다.**
    #   0.01 eV 로 보고하려면 static k → dense k 로 갈 때 두 조각의 차가
    #   얼마나 움직이는지 알아야 한다. δ_gas 와 같은 논리다 (조각별이 아니라 차).
    _kp = (man.get("kconv_pair") or {})
    # 🔴 회신 BE P0-2 (2026-09-03) — k 수렴 쌍은 **정확히 primary 두 complex** 여야 한다.
    #   리뷰어 재현: primary 보정이 20/0 meV 로 실패하는 사례에서 `kconv_pair` 만 대안
    #   자세로 돌리자 δ_k=0 · 안정 판정. 다른 자세의 δ_k 로 primary 의 0.01 eV 를 보증할
    #   수 없다 — 쌍을 exact job key 에 결박한다.
    _ejk_k = (man.get("estimand_job_keys") or {})
    _want_k = {_ejk_k.get("E_C_sdcp"), _ejk_k.get("E_C_control")} - {None}
    if (_kp.get("jobs") and len(_kp["jobs"]) == 2 and _ejk_k
            and set(_kp["jobs"]) != _want_k):
        _blk("KCONV_PAIR_NOT_PRIMARY",
             "KCONV_PAIR_NOT_PRIMARY(k 수렴 쌍 %s 이 사전 고정 primary complex %s 와 "
             "다르다 — 다른 자세의 δ_k 로 primary 의 0.01 eV 를 보증할 수 없다 · BE P0-2)"
             % (sorted(_kp["jobs"]), sorted(_want_k)),
             job_keys=list(_kp["jobs"]), scope="estimand")
        _kp = {"status": "pair_not_primary"}
    if _kp.get("jobs") and len(_kp["jobs"]) == 2:
        _kv = {}
        for _kj in _kp["jobs"]:
            _f = ((jobs.get(_kj) or {}).get("meta") or {}).get("fragment")
            # dense 는 같은 잡의 phase 라 job record 에서 직접 읽는다
            #   (`E_dense()` 는 main() 스코프라 여기서 못 쓴다)
            _dr = ((jobs.get(_kj) or {}).get("dense") or {})
            _kv[_f] = (E(_kj), (_dr.get("E0") if _dr.get("normal_end") else None))
        _kmiss = [f for f, (c, d) in _kv.items() if c is None or d is None]
        _dk = None
        if _kmiss:
            _blk("KCONV_NOT_MEASURED",
                 "KCONV_NOT_MEASURED(%s: coarse/dense 중 하나가 없다 — "
                 "0.01 eV 보고의 k 근거가 없다)" % _kmiss,
                 job_keys=list(_kp["jobs"]), scope="estimand")
        else:
            _fs = next((f for f in _kv if "sdcp" in str(f)), None)
            _fc = next((f for f in _kv if f != _fs and f is not None), None)
            _d = {f: (v[1] - v[0]) for f, v in _kv.items()}
            if _fs is None or _fc is None:
                # ⛔ 조각을 못 가른다 — 확인 못 한 것은 통과가 아니다
                _blk("KCONV_FRAGMENT_UNRESOLVED",
                     "KCONV_FRAGMENT_UNRESOLVED(k 수렴 쌍의 조각을 못 가렸다 %s)"
                     % sorted(str(f) for f in _kv),
                     job_keys=list(_kp["jobs"]), scope="estimand")
            else:
                _dk = _d[_fs] - _d[_fc]
        if _kp.get("jobs") and len(_kp["jobs"]) == 2 and not _kmiss and _dk is not None:
            _tol = float(_kp.get("tol_eV") or 0.005)
            out["kconv_delta"] = {
                "delta_k_meV": round(_dk * 1000, 3),
                "by_fragment_meV": {f: round(v * 1000, 3) for f, v in _d.items()},
                "tol_meV": round(_tol * 1000, 1),
                "pass": bool(abs(_dk) <= _tol),
                "식": _kp.get("formula"),
                "kmesh": {"coarse": _kp.get("coarse_kmesh"),
                          "dense": _kp.get("dense_kmesh")}}
            if abs(_dk) > _tol:
                # 🔴 회신 AV P1-5 — 위 GAS_BOX_DELTA 와 같은 강등. 결측(NOT_MEASURED)
                #   은 계속 막고, **측정된 초과**는 인용 해상도만 잃는다.
                out.setdefault("advisories", []).append(
                    "KCONV_DELTA(δ_k %.2f meV > %.0f — 0.01 eV 로 보고할 수 없다. "
                    "dense 로 다시 내거나 보고 해상도를 낮춘다 · D_raw 는 보존)"
                    % (_dk * 1000, _tol * 1000))
    elif (man.get("estimand_job_keys") and
          str(_kp.get("status")) not in ("not_applicable", "not_designed")):
        _blk("KCONV_ABSENT",
             "KCONV_ABSENT(k 수렴 쌍이 봉인돼 있지 않다 — 0.01 eV 보고의 "
             "근거가 없다)", scope="estimand")
    # 🔴 렌즈2 P1-1 (2026-09-03) — `not_applicable` 은 "δ_k 를 정의할 primary 조각이 둘이
    #   아니다" 라는 **사실 주장**이다. 생성기는 조각이 2개가 아닐 때만 이 상태를 쓰지만
    #   분석기는 그 사실을 대조하지 않아, 조각이 둘인 번들에 `not_applicable` 을 적으면
    #   재개 조건도 없이 **조용히 통과**했다 (리뷰어 재현: rc 3 · KCONV 차단 0). 상태
    #   문자열이 아니라 **조각 수**가 판정한다 — 둘이면 '해당 없음' 은 거짓이다.
    elif str(_kp.get("status")) == "not_applicable" and len(_want_k) == 2:
        _blk("KCONV_STATUS_INVALID",
             "KCONV_STATUS_INVALID(kconv_pair.status=not_applicable 인데 estimand 의 primary "
             "complex 가 둘이다 %s — δ_k 는 정의된다. '해당 없음' 이 아니라 설계 제외"
             "(not_designed + 결과 보기 전 재개 조건)이거나 결측이다)" % sorted(_want_k),
             scope="estimand")
    elif str(_kp.get("status")) == "not_designed":
        # 🔴🔴 1저자 결정 2026-09-03 — **선언된 축 생략**은 차단이 아니라 주장 축소다.
        #   ⚠ 정정 (렌즈2 P0-1 · 렌즈4 P0-2 · 렌즈5 P1-1, 2026-09-03): 종전 주석은 사전등록
        #   49행("넘으면 값을 버리지 않는다")을 근거로 들었는데, 그 절은 **문턱 초과** 절이고
        #   축 **부재**의 적용 절은 50행 "축이 하나라도 없으면 NUMERIC_BUDGET_INCOMPLETE" 다.
        #   그러므로 이 경로는 50행에 대한 **비준된 예외**가 있을 때만 열린다 — 번들에 실린
        #   비준 사전등록 사본의 `3_오차예산.축_설계_제외_*` 항. 없으면 코드가 비준 문서보다
        #   관대한 것이므로 종전대로 차단한다. 있으면 MANIFEST 의 재개 조건이 그 항의 재개
        #   조건과 **같아야** 하고(생성기가 복사한다 — 드리프트 금지), 재개 조건은 문장이 아니라
        #   **기계 평가 가능한 구조**여야 한다 (렌즈2 P1-2: 어느 값에 무엇을 대는지).
        _reopen = next((v for k, v in _kp.items() if "재개_조건" in str(k)), None)
        _rp = _kconv_reopen_rule_problems(_reopen)
        _pe, _pek, _pew = _prereg_axis_exclusion(man, "δ_k")
        if _rp:
            _blk("KCONV_OMISSION_UNDECLARED",
                 "KCONV_OMISSION_UNDECLARED(k 축을 설계에서 뺐다고 하면서 **결과 보기 전에 기계 "
                 "평가 가능한 재개 조건을 선언하지 않았다** %s — 생략을 사후에 정당화할 수 없다)"
                 % _rp[:3], scope="estimand")
        elif _pe is None:
            _blk("KCONV_OMISSION_UNRATIFIED",
                 "KCONV_OMISSION_UNRATIFIED(δ_k 설계 제외가 비준 사전등록에 없다 — %s)" % _pew,
                 scope="estimand")
        elif (_pe.get("재개_조건_결과_보기_전에_선언") or {}) != dict(_reopen):
            _blk("KCONV_OMISSION_DRIFT",
                 "KCONV_OMISSION_DRIFT(MANIFEST 의 재개 조건이 비준 사전등록 %s 의 재개 조건과 "
                 "다르다 — 생성기가 사전등록에서 복사해야 하는 값이다)" % _pek, scope="estimand")
        else:
            out.setdefault("advisories", []).append(
                "KCONV_NOT_DESIGNED(k 축을 **설계에서 뺐다** — 비준 사전등록 %s 에 선언된 생략. "
                "ΔE_ads 는 보고하되 **0.01 eV 전체 안정성은 주장하지 않는다.** 재개 조건: %s)"
                % (_pek, _reopen.get("규칙")))
            # ⚠ `kconv_delta` 로 쓰면 안 된다 — 그 키가 있으면 아래 오차예산이
            #   `delta_k_meV is None` 을 보고 **missing(차단)** 으로 센다. 선언된 생략은
            #   missing 이 아니라 `axes_not_designed` 여야 하므로 **다른 키**에 남긴다.
            out["kconv_omission"] = {
                "status": "not_designed",
                "delta_k_meV": None,
                "⛔": "이 축은 재지 않았다 — 0 이 아니라 **없음**이다",
                "prereg_entry": _pek,
                "재개_조건": _reopen,
                "reopen_eval": None,          # D_raw 가 나온 뒤 기계로 채운다 (렌즈2 P1-2)
            }

    # ══ 🔴 회신 AT Q2 — 세 수치축의 **합산 오차예산** (2026-08-31) ═══════════
    #   세 축(Δ_vac · δ_gas · δ_k)은 **독립 확률오차가 아니다.** 같은 계·같은
    #   프로토콜의 체계오차라 RSS 로 합치면 안 된다. 셋이 같은 방향이면 최대
    #   15 meV 가 된다 — 각각 5 meV 를 통과해도 합이 15 meV 면 0.01 eV 보고가
    #   성립하지 않는다.  ⇒ **결과를 보기 전에** 합산 예산을 고정한다:
    #        B_num = |Δ_vac| + |δ_gas| + |δ_k| ≤ 5 meV
    #   넘으면 값을 버리는 것이 아니라 **보고 해상도를 낮추거나** 축별 민감도만
    #   보고한다 (어느 축이 얼마나 기여했는지는 아래 by_axis 가 말한다).
    # 🔴 회신 AV P1-5 — 종전엔 **결과 객체 자체가 없는 축**이 miss 에도 안 들어가
    #   한두 축만으로 B_num 이 "pass" 를 찍을 수 있었다. 축마다 상태를 강제한다:
    #     실측(bax) · 설계됐는데 결측(miss → estimand NO_VALUE) ·
    #     이 번들 설계에 없음(skip → 차단하지 않되 0.01 eV envelope 에서 그 축이
    #     빠졌음을 명시). 판정은 block_records 의 **code** 로 한다 (문자열 아님).
    _bax, _bmiss, _bskip = {}, [], []
    _bcodes = {r0.get("code") for r0 in out.get("block_records") or []}
    _vc0 = out.get("closure_vacconv") or {}
    if _vc0.get("applicable"):
        _v = _vc0.get("delta_vac_eV")
        _v = None if _v is None else float(_v) * 1000.0
        if _v is None:
            _bmiss.append("Δ_vac")
        else:
            _bax["vac"] = abs(float(_v))
    else:
        _bskip.append("Δ_vac(진공 시험이 이 번들 설계에 없음)")
    _gb0 = out.get("gas_box_delta") or {}
    if _gb0:
        _v = _gb0.get("delta_gas_meV")
        if _v is None:
            _bmiss.append("δ_gas")
        else:
            _bax["gas"] = abs(float(_v))
    elif "GAS_BOX_NOT_MEASURED" in _bcodes or "GAS_PAIR_CONTRACT" in _bcodes:
        _bmiss.append("δ_gas")
    else:
        _bskip.append("δ_gas(기체 상자 쌍이 이 번들 설계에 없음)")
    _kd0 = out.get("kconv_delta") or {}
    if _kd0:
        _v = _kd0.get("delta_k_meV")
        if _v is None:
            _bmiss.append("δ_k")
        else:
            _bax["k"] = abs(float(_v))
    elif _bcodes & {"KCONV_NOT_MEASURED", "KCONV_FRAGMENT_UNRESOLVED", "KCONV_ABSENT",
                    "KCONV_STATUS_INVALID", "KCONV_OMISSION_UNRATIFIED",
                    "KCONV_OMISSION_DRIFT", "KCONV_OMISSION_UNDECLARED"}:
        # ⚠ 선언된 생략이 **성립하지 않은** 경우(비준 항 없음·드리프트·형식 불량)는 '설계에
        #   없음' 이 아니라 **결측**이다 — 확인 못 한 것은 통과가 아니다 (사전등록 50행).
        _bmiss.append("δ_k")
    else:
        _bskip.append("δ_k(k 수렴 쌍이 이 번들 설계에 없음)")
    _BTOL = 5.0
    # 🔴 렌즈2 P1-5 · 렌즈5 P1-1 (2026-09-03) — 정의 문자열이 **세 축 고정**이었는데 값은
    #   시험한 축만 합산했다. 기계 기록이 자기 정의와 다른 양을 담으면 읽는 사람은 세 축
    #   으로 읽는다. 정의를 **실제 합산 축**으로 렌더하고 빠진 축을 같은 줄에 적는다.
    #   사전등록 원문 정의는 별도 키로 남긴다 (무엇에서 얼마나 빠졌는지 보이게).
    _axn = {"vac": "Δ_vac", "gas": "δ_gas", "k": "δ_k"}
    _ax_in = [_axn[k] for k in ("vac", "gas", "k") if k in _bax]
    _ax_out = sorted(set(_bmiss) | {s.split("(")[0] for s in _bskip})
    _prereg_out = [x for x in ("Δ_vac", "δ_gas", "δ_k") if x in _ax_out]
    _def = (("B_num = " + " + ".join("|%s|" % x for x in _ax_in) + "  (meV)")
            if _ax_in else "B_num = (합산할 실측 축이 없다)")
    if _prereg_out:
        _def += "  — 사전등록 3축 중 제외: %s (%s)" % (
            ", ".join(_prereg_out), "결측" if _bmiss else "이 번들 설계에 없음")
    out["numeric_budget"] = {
        "정의": _def,
        "정의_사전등록_원문": "B_num = |Δ_vac| + |δ_gas| + |δ_k|  (meV) — 3_오차예산",
        "tested_axes_n": len(_bax),
        # 🔴 회신 AV P1-5·Q6 — 이름을 정확히 한다. **총 오차 상한이 아니다** —
        #   ENCUT·교차축 검사가 빠져 있어 "전체 0.01 eV 수렴성" 을 말할 수 없다.
        "성격": ("**시험한 세 축의 보수적 sensitivity envelope** — 총 오차 상한이 "
                 "아니다 (ENCUT·교차축 미포함, 회신 AV Q6)"),
        "⛔_RSS_금지": ("세 축은 독립 확률오차가 아니다 — 같은 계·같은 프로토콜의 "
                        "체계오차다. RSS(제곱합근)로 합치면 상관을 0 으로 가정하는 "
                        "것이고, "
                        "셋이 같은 방향이면 실제 편차는 단순합에 가깝다 (회신 AT Q2)"),
        "by_axis_meV": {k: round(v, 3) for k, v in sorted(_bax.items())},
        "missing_axes": _bmiss,
        # ⛔ 회신 AY P1 — 설계에 **애초에 없는** 축을 실제 배열로 적는다. 종전엔
        #   측정 못 한 축(_bskip)만 담겨서, ENCUT 처럼 처음부터 설계에 없던 축이
        #   목록에 안 보였다 — 보이지 않으면 없는 것처럼 읽힌다.
        "axes_not_designed": sorted(set(_bskip) | {
            "ENCUT (평면파 컷오프 수렴 — 이 묶음에 설계 자체가 없다)",
            "축간 상호작용 (교차항 — 한 축씩만 흔들어 봤다)",
        }),
        "B_num_meV": (round(sum(_bax.values()), 3) if _bax and not _bmiss else None),
        "tol_meV": _BTOL,
        "pass": (bool(_bax) and not _bmiss and sum(_bax.values()) <= _BTOL),
        # ⛔⛔ 회신 AY P1 — 이름이 과했다. 이 불리언이 말하는 것은 **시험한 축들이**
        #   0.01 eV 안에서 안정하다는 것뿐인데, `citable_at_0.01eV` 는 값 전체가
        #   그렇다고 읽힌다. 이름을 사실에 맞추고, **전체**는 별도 키로 두되
        #   ENCUT 근거가 없으므로 None 이다 (False 가 아니라 **모른다**).
        "tested_axes_stable_at_0.01eV": (bool(_bax) and not _bmiss
                                         and sum(_bax.values()) <= _BTOL),
        # 🔴 렌즈2 P1-4 (2026-09-03) — 사전등록 3축 중 하나라도 이 결과에 없으면 전체
        #   0.01 eV 안정성은 **False** 다 (사전등록 50행 "축이 하나라도 없으면 INCOMPLETE").
        #   종전엔 언제나 None("모른다") 이어서, 문서는 "0.01 eV 주장 안 함" 이라 쓰는데
        #   기계 기록은 판단을 유보한 것처럼 읽혔다. None 은 세 축이 다 있고 ENCUT·교차항만
        #   없을 때의 값이다.
        "overall_citable_at_0.01eV": (False if _prereg_out else None),
        "overall_⚠": (("사전등록 3_오차예산 축 %s 가 이 결과에 없다 (%s) — 전체 0.01 eV "
                       "안정성은 **주장하지 않는다(False)**. 시험한 축 %s 의 envelope 만 "
                       "tested_axes_… 에 남는다 (사전등록 50행)."
                       % (_prereg_out, "결측" if _bmiss else "설계 제외", _ax_in))
                      if _prereg_out else
                      "세 축은 있으나 ENCUT·교차항 근거가 없어 None(모른다) — False 가 아니다"),
        "⚠_두_키의_차이": ("tested_axes_… 는 **시험한 축**만 말한다. overall_… 은 사전등록 "
                            "3축이 전부 있을 때 ENCUT·교차항 근거 부재로 None(모른다), "
                            "하나라도 없으면 False(주장하지 않는다). 전체 0.01 eV 를 "
                            "주장하려면 세 축 + 별도 ENCUT 설계가 필요하다 (회신 AY Q6 · "
                            "렌즈2 P1-4)."),
        "⚠_문턱_봉인": "결과를 보기 전에 정한 값이다 (회신 AT Q2 · 코드 상수)",
        "미달이면": ("값을 버리지 않는다 — **0.01 eV 안정성 주장을 하지 않고** 보고 "
                     "해상도를 낮추거나 축별 민감도만 낸다"),
    }
    if _bmiss:
        _blk("NUMERIC_BUDGET_INCOMPLETE",
             "NUMERIC_BUDGET_INCOMPLETE(축 %s 의 값이 없다 — 합산 예산을 만들 수 "
             "없으므로 0.01 eV 안정성을 주장하지 않는다)" % _bmiss,
             scope="estimand")
    elif _bax and sum(_bax.values()) > _BTOL:
        # 🔴 회신 AV P1-5 — 종전엔 이것이 estimand block 이라 **D 계산 전에**
        #   NO_VALUE 가 됐다. 문구("넘어도 raw D 는 보존, 0.01 eV 주장만 철회")와
        #   코드가 반대였다. envelope 초과는 입력이 무효라는 뜻이 아니다 —
        #   D_raw 와 축별 변화는 보존하고 **0.01 eV 인용 자격만** 없앤다.
        out["numeric_budget"]["tested_axes_stable_at_0.01eV"] = False
        out.setdefault("advisories", []).append(
            "NUMERIC_BUDGET_EXCEEDED(B_num %.2f meV > %.0f — 축별로는 통과해도 "
            "합이 넘는다 %s. D_raw 는 보존하고 0.01 eV 인용 자격만 철회한다 · "
            "회신 AV P1-5)"
            % (sum(_bax.values()), _BTOL, {k: round(v, 2) for k, v in _bax.items()}))

    _ejk0 = (man.get("estimand_job_keys") or {})
    if _ejk0:
        # ⛔⛔ 회신 AP #2 — **네 잡 자신**의 자기 상태 검사는 다른 block 유무와
        #   무관하게 **항상** 돌아야 한다. 종전엔 이것이 강등 블록 안에 있어서
        #   `blocks` 가 비면 아예 실행되지 않았다 (원래 basin 요구도 같은 자리였다).
        _tp = _estimand_topology_check(_ejk0, jobs, "pm1")
        for _m in _tp["blocks"]:
            _blk("ESTIMAND_TOPOLOGY", _m,
                 job_keys=[v for k, v in _ejk0.items() if k.startswith("E_C_")],
                 scope="estimand")
        out.setdefault("estimand_topology", {})["pm1"] = _tp
        # 🔴🔴 회신 BE P0-1 (2026-09-03) — 네 키의 **의미** 검사도 여기서, 다른 block 유무와
        #   무관하게 **항상** 돈다. 뒤쪽(exact-key 대입 직전)에만 두면 앞선 구조 블록이
        #   먼저 NO_VALUE 로 끊을 때 "왜 키가 틀렸는지" 가 산출물에 남지 않는다.
        _sem0 = _estimand_semantics_check(_ejk0, jobs, man, "pm1", "primary")
        out.setdefault("estimand_semantics", {})["pm1"] = _sem0
        for _m in _sem0["blocks"]:
            _blk("ESTIMAND_SEMANTICS", _m,
                 job_keys=[v for k, v in _ejk0.items()
                           if str(k).startswith("E_") and isinstance(v, str)],
                 scope="estimand")
        _n4k0 = (man.get("estimand_job_keys_net4") or {})
        if _n4k0:
            _tp4 = _estimand_topology_check(_n4k0, jobs, "net4")
            # net4 는 민감도라 **차단하지 않는다** — 대신 민감도 자격을 잃는다
            _tp4["usable_as_sensitivity"] = not _tp4["blocks"]
            out["estimand_topology"]["net4"] = _tp4
    if _ejk0 and out["block_records"]:
        _need0 = ("E_C_sdcp", "E_C_control", "E_G_sdcp", "E_G_control")
        _exact = {_ejk0[k] for k in _need0 if _ejk0.get(k)}
        # ⛔⛔ 회신 AP #3 — 종전엔 **문자열 매칭**으로 강등을 판단했다.
        #   `BASIN_HETEROGENEOUS` 문자열에는 job 경로가 없어서 "네 잡을 언급하지
        #   않는다" 가 **항상 참**이 되고, 그 block 이 언제나 강등됐다.
        #   ⇒ 구조화 필드(scope · job_keys)로만 판단한다. job_keys 가 비어 있으면
        #     **강등하지 않는다** (모르는 것을 안전한 쪽으로 읽지 않는다).
        # ⛔⛔ 회신 AP #3 판정 — **pooled block 을 필터링하는 방식 자체가 취약하다.**
        #   job_keys 교집합으로 걸러도, pooled 집합에는 exact key 가 거의 항상
        #   섞여 있어서 결국 D 를 죽인다(실측: BASIN_HETEROGENEOUS 의 job_keys 가
        #   그 조각의 **전 잡**이라 b00 pm1 을 포함한다).
        #   ⇒ exact-key 경로에서는 pooled 진단이 estimand 를 **막지 않는다.**
        #     그 진단의 목적은 "pooled 집합에서 min 을 뽑지 마라" 인데, 이 경로는
        #     min 을 쓰지 않고 **사전 고정한 네 잡**을 직접 대입하기 때문이다.
        #     네 잡의 안전은 따로 보장된다:
        #       · 게이트 걸린 잡 → ESTIMAND_KEY_UNUSABLE (아래 _gated)
        #       · 에너지 없음   → ESTIMAND_KEY_UNUSABLE (_none)
        #       · 자기 상태 불일치/판독불가 → _estimand_topology_check (scope=estimand)
        #   `_exact` 는 강등 판단에 쓰지 않고 기록용으로만 남긴다.
        # ⛔⛔ 회신 AR Q1/P0-2 (2026-08-31) — 종전엔 강등 시 `out["blocks"]` 를
        #   `block_records` 에서 **다시 만들었다.** 그런데 `_blk()` 를 거치지 않고
        #   `out["blocks"].append(...)` 로 직접 들어온 **구조화 안 된 전역 차단**
        #   (MOLECULAR_STATE_UNRESOLVED · CANARY_GEOM_* · POTCAR · closure 등)은
        #   record 가 없어서 **통째로 사라졌다.** 리뷰가 재현했다:
        #   MOLECULAR_STATE_UNRESOLVED + BASIN_HETEROGENEOUS → blocks 가 빈 배열.
        #   ⇒ **canonical `blocks` 는 절대 수정하지 않는다.** 강등은 별도 view 로만.
        _keep_r, _dem_r = [], []
        for _r in out["block_records"]:
            (_dem_r if _r["scope"] == "pooled_diagnostic" else _keep_r).append(_r)
        out["pooled_demote_policy"] = {
            "rule": "exact-key 경로에서는 scope=pooled_diagnostic 을 전부 강등한다",
            "why": "pooled min 을 쓰지 않으므로 그 진단이 estimand 에 적용되지 않는다",
            "estimand_keys": sorted(_exact),
            "estimand_safety": ["ESTIMAND_KEY_UNUSABLE(게이트·에너지)",
                                "ESTIMAND_TOPOLOGY_*(자기 상태 직접 비교)"]}
        # canonical 목록(blocks · block_records)은 **손대지 않는다**.
        #   primary D 판정에만 쓰는 view 를 따로 만든다.
        _dem_msgs = {r["msg"] for r in _dem_r}
        out["primary_estimand_blocks"] = [b for b in out["blocks"]
                                          if b not in _dem_msgs]
        if _dem_r:
            out["nonprimary_notes"] = [r["msg"] for r in _dem_r]
            out["nonprimary_note_records"] = _dem_r
            out["nonprimary_notes_why"] = (
                "이 블록들은 **D 에 들어가지 않는 잡**(net4·대안 자세)에 대한 것이다. "
                "pm1 조건부 D 는 사전 고정한 네 잡으로 정의되므로 지우지 않는다 "
                "(회신 AO P0-7). 강등 판정은 **job_keys 교집합**으로 하지 문자열로 "
                "하지 않는다 (회신 AP #3). 자기 분기 민감도로만 읽는다")

    # ⛔ 회신 AR Q1 — primary D 판정은 **primary view** 로 하되, pooled 진단은
    #   `secondary_G`·pooled min·일반화 주장을 **계속 차단**한다 (아래 §pooled_effect).
    _pv = out.get("primary_estimand_blocks")
    if _pv is None:
        _pv = list(out["blocks"])          # 강등이 없었으면 canonical 그대로
        out["primary_estimand_blocks"] = _pv
    # ⛔ 회신 AS 해제조건 3 — pool 완전성도 인용 조건에 넣는다
    _pool_ok = bool((out.get("pool_completeness") or {}).get("ok"))
    # 🔴🔴 회신 AT Q5 (2026-08-31) — 1저자 결정: **선택지 (a).**
    #   pooled 최솟값과 secondary_G 를 **영구 진단값(비인용)** 으로 고정한다. 추가 잡 0.
    #   이유 둘:
    #     ① dense k 검증이 primary pm1 b00 두 복합체뿐인데 pool 에는 net4 도 든다 —
    #        검증 깊이가 다른 값을 섞어 min 을 뽑는 것이다.
    #     ② net4 dense 를 +2 잡 넣어도 **basin 이 섞인 문제는 그대로다.** pm1/net4 는
    #        애초에 서로 다른 자기상태로 수렴하라고 넣은 seed 라 BASIN_HETEROGENEOUS
    #        가 사실상 상시 뜬다. 인용가능 pool 을 만들려면 basin 별로 pool 을 쪼개고
    #        "pooled min" 의 정의를 다시 짜야 한다 — 잡 두 개가 아니라 설계 변경이다.
    #   ⇒ 계산은 계속 하고 출력에도 남기되, **인용 자격은 주지 않는다.**
    _pooled_dyn = (not bool(out.get("nonprimary_notes"))) and _pool_ok
    out["pooled_effect"] = {
        "secondary_G_citable": False,
        "pooled_min_citable": False,
        "citable": "no — 영구 (회신 AT Q5 선택지 (a) · 1저자 결정 2026-08-31)",
        "would_pass_dynamic_gates": _pooled_dyn,
        "pool_complete": _pool_ok,
        "⛔_영구_비인용_사유": [
            "dense k 검증이 primary pm1 b00 두 복합체뿐 — pool 의 net4 는 미검증이다",
            "pm1/net4 는 다른 자기상태를 보려고 넣은 seed 라 basin 이 섞인다. "
            "상태를 가로질러 min 을 뽑지 않는다",
            "잡 +2 로는 ①만 닫히고 ②는 안 닫힌다 — 설계 변경이 필요한 일이다"],
        "대신_무엇을_쓰나": (
            "자세 탐색의 폭은 **MLIP 스크린**이 진다 (탐색 범위·자세 선정 규칙만, "
            "에너지는 인용 금지). DFT 는 사전등록한 한 조건의 D 하나를 낸다"),
        "why": ("pooled heterogeneity 는 primary(봉인 네 잡)에는 적용되지 않지만 "
                "pooled 최솟값·secondary_G·일반화 주장은 **계속 막는다** (회신 AR Q1)")}
    if _pv:
        out["verdict"] = "NO_VALUE — blocks 를 해소하기 전에는 단일 X 를 보고하지 않는다"
        return out

    sd = next((f for f in frags if "sdcp" in f), None)
    ct = next((f for f in frags if f != sd), None)
    a_s = out["A_by_frag"].get(sd) or {}
    a_c = out["A_by_frag"].get(ct) or {}
    if not (a_s.get("min") and a_c.get("min")):
        out["verdict"] = "NO_VALUE — 조각 한쪽에 게이트 통과 자세가 없다"
        return out

    # ⛔⛔ 2026-08-31 (회신 AN P0-1) — `estimand_job_keys` 가 있으면 **그 네 잡만** 쓴다.
    #   초판은 조각별 min 을 뺐다. 그러면 SDCP 와 PTFE 가 **서로 다른 seed** 에서
    #   뽑힐 수 있어, 사전 고정한 "pm1 조건부 D" 와 다른 양이 된다.
    #   AN §4 가 네 경로를 문서로 못박았는데 판정기는 여전히 min 을 골랐다 —
    #   문서와 코드가 갈린 채로 발송될 뻔했다.
    _ejk = (man.get("estimand_job_keys") or {})
    if _ejk:
        out["estimand_job_keys"] = dict(_ejk)
        _need = ("E_C_sdcp", "E_C_control", "E_G_sdcp", "E_G_control")
        _miss = [k for k in _need if not _ejk.get(k)]
        _ev = {k: E(_ejk[k]) for k in _need if _ejk.get(k)}
        _none = [k for k, v in _ev.items() if v is None]
        _gated = [k for k in _need if _ejk.get(k) and (jobs.get(_ejk[k]) or {}).get("gates")]
        # 🔴🔴 회신 BE P0-1 — 네 키의 **의미** 검사 (위 estimand_topology 자리에서 이미
        #   돌았고 block 도 기록됐다). 여기서는 그 결과로 **대입을 거부**한다 — 어떤 경로로
        #   와도 의미가 어긋난 키로 D 를 만들지 않는다.
        _sem = (out.get("estimand_semantics") or {}).get("pm1")
        if _sem is None:
            _sem = _estimand_semantics_check(_ejk, jobs, man, "pm1", "primary")
            out.setdefault("estimand_semantics", {})["pm1"] = _sem
            for _m in _sem["blocks"]:
                _blk("ESTIMAND_SEMANTICS", _m,
                     job_keys=[v for k, v in _ejk.items()
                               if str(k).startswith("E_") and isinstance(v, str)],
                     scope="estimand")
        if _sem["blocks"]:
            out["verdict"] = ("NO_VALUE — 사전 고정 job key 가 봉인된 의미와 다르다 "
                              "(교환·대체·다른 역할 · 회신 BE P0-1)")
            return out
        if _miss or _none or _gated:
            out["blocks"].append(
                "ESTIMAND_KEY_UNUSABLE(누락 %s · 에너지 없음 %s · 게이트됨 %s) — "
                "사전 고정한 네 잡으로만 D 를 만든다. 대체하지 않는다"
                % (_miss, _none, _gated))
            out["verdict"] = "NO_VALUE — 사전 고정 job key 를 쓸 수 없다"
            return out
        primary = ((_ev["E_C_sdcp"] - _ev["E_G_sdcp"])
                   - (_ev["E_C_control"] - _ev["E_G_control"]))
        out["estimand_mode"] = "exact_keys (사전 고정 네 잡 직접 대입)"
        secondary = a_c["min"][0] - a_s["max"][0]
        # ⛔ 회신 AO P0-7 — 요구했던 `D_net4 − D_pm1` 을 **실제로 계산한다**.
        #   net4 는 별도 직접식이다. 못 내면 그 사실을 적고, D_pm1 은 살린다.
        _n4k = (man.get("estimand_job_keys_net4") or {})
        if _n4k:
            _n4v = {k: E(_n4k[k]) for k in _need if _n4k.get(k)}
            _n4_bad = ([k for k in _need if not _n4k.get(k)]
                       + [k for k, v in _n4v.items() if v is None]
                       + [k for k in _need if _n4k.get(k)
                          and (jobs.get(_n4k[k]) or {}).get("gates")])
            # 🔴 회신 BE P0-1 — 민감도 봉인도 같은 의미 검사를 받는다 (값 대신 status 를 막는다)
            _sem4 = _estimand_semantics_check(_n4k, jobs, man, "net4", "primary")
            out.setdefault("estimand_semantics", {})["net4"] = _sem4
            _n4_bad += ["SEMANTICS:" + x for x in _sem4["blocks"]]
            # ⛔⛔ 회신 AR P1-9 · 해제조건 6 (2026-08-31) — `usable_as_sensitivity`
            #   를 **저장만 하고 읽지 않았다.** net4 두 complex 가 다른 자기 basin
            #   이어도 `D_net4` 가 계산되고 status 가 computed 로 나갔다.
            #   민감도의 요점은 "같은 계를 다른 분기에서 보면 얼마나 움직이나" 인데,
            #   상태를 가로질러 뺀 값은 그 질문에 답하지 않는다 ⇒ **값도 status 도
            #   같이 막는다.** (D_pm1 은 여전히 영향받지 않는다.)
            _tp4r = ((out.get("estimand_topology") or {}).get("net4") or {})
            _n4_topo_bad = (_tp4r.get("usable_as_sensitivity") is not True)
            if _n4_topo_bad:
                out["branch_sensitivity"] = {
                    "status": "suppressed_topology",
                    "why": ((_tp4r.get("blocks") or
                             ["net4 topology 판정이 없다 — 확인 못 한 것은 통과가 아니다"])[:2]),
                    "D_net4_eV": None,
                    "D_net4_minus_D_pm1_eV": None,
                    "⛔": ("net4 두 complex 가 같은 자기 branch 임을 확인하지 못했다. "
                           "상태를 가로질러 뺀 차는 분기 민감도가 아니므로 값을 내지 "
                           "않는다 (회신 AR P1-9). D_pm1 은 영향받지 않는다"),
                    "⚠_민감도_불완전": True}
            elif _n4_bad:
                out["branch_sensitivity"] = {
                    "status": "unavailable", "why": "net4 키 사용 불가: %s" % sorted(set(_n4_bad)),
                    "D_net4_eV": None, "D_net4_minus_D_pm1_eV": None,
                    "⚠_민감도_불완전": True,
                    "⚠": "D_pm1 은 영향받지 않는다 — net4 는 민감도다"}
            else:
                _dn4 = ((_n4v["E_C_sdcp"] - _n4v["E_G_sdcp"])
                        - (_n4v["E_C_control"] - _n4v["E_G_control"]))
                out["branch_sensitivity"] = {
                    "status": "computed",
                    "D_net4_eV": round(_dn4, 4),
                    "D_net4_minus_D_pm1_eV": round(_dn4 - primary, 4),
                    "⛔": ("민감도다 — 보고값은 pm1 조건부 D 이고 이 값을 대신 쓰거나 "
                           "둘을 평균하지 않는다")}
        else:
            out["branch_sensitivity"] = {
                "status": "not_sealed", "D_net4_eV": None,
                "⚠_민감도_불완전": True,
                "why": "manifest 에 estimand_job_keys_net4 가 없다 (net4 잡이 계획에 없음)"}
        # ⛔⛔ 회신 AR P1-10 · 해제조건 6 — **대안 자세 민감도**를 봉인식으로 낸다.
        #   종전엔 완료 여부만 보고돼 "sensitivity 를 봤다" 가 무엇을 뜻하는지
        #   결과에 없었다. net4 와 **같은 게이트**를 건다.
        _paltk = (man.get("estimand_job_keys_pose_alt") or {})
        _palt_out = {}
        for _role, _pk4 in sorted(_paltk.items()):
            if not isinstance(_pk4, dict) or not _pk4.get("E_C_sdcp"):
                continue                                  # "⛔" 주석 키는 건너뛴다
            _tpp = _estimand_topology_check(_pk4, jobs, "pose_%s" % _role)
            _pv = {k: E(_pk4[k]) for k in _need if _pk4.get(k)}
            _pbad = ([k for k in _need if not _pk4.get(k)]
                     + [k for k, v in _pv.items() if v is None]
                     + [k for k in _need if _pk4.get(k)
                        and (jobs.get(_pk4[k]) or {}).get("gates")])
            # 🔴 회신 BE P0-1 — 대안 자세 봉인: complex 는 **ALT 역할**이어야 하고
            #   (primary 를 민감도 자리에 재사용 금지) gas 는 같은 box24 여야 한다.
            _semp = _estimand_semantics_check(_pk4, jobs, man, "pose_%s" % _role, ALT_ROLES)
            out.setdefault("estimand_semantics", {})["pose_%s" % _role] = _semp
            _pbad += ["SEMANTICS:" + x for x in _semp["blocks"]]
            if _tpp["blocks"] or _tpp.get("same") is not True:
                _palt_out[_role] = {
                    "status": "suppressed_topology", "D_pose_eV": None,
                    "D_pose_minus_D_pm1_eV": None,
                    "why": (_tpp["blocks"] or ["topology 판정 없음"])[:2]}
            elif _pbad:
                _palt_out[_role] = {
                    "status": "unavailable", "D_pose_eV": None,
                    "D_pose_minus_D_pm1_eV": None,
                    "why": "자세 키 사용 불가: %s" % sorted(set(_pbad))}
            else:
                _dp = ((_pv["E_C_sdcp"] - _pv["E_G_sdcp"])
                       - (_pv["E_C_control"] - _pv["E_G_control"]))
                _palt_out[_role] = {
                    "status": "computed", "D_pose_eV": round(_dp, 4),
                    "D_pose_minus_D_pm1_eV": round(_dp - primary, 4),
                    "식": _pk4.get("formula")}
        if _paltk:
            out["pose_sensitivity"] = dict(
                _palt_out,
                **{"⛔": ("자세 민감도다 — 보고값은 primary 자세의 pm1 조건부 D 이고 "
                         "이 값들로 min 을 다시 뽑거나 평균하지 않는다")})
        elif man.get("altpose_purpose"):
            out["pose_sensitivity"] = {"status": "exploratory_only",
                                       "why": man["altpose_purpose"]}
        # ⛔ 회신 AR 해제조건 6 — "민감도 완료" 를 **한 곳에서** 판정한다.
        #   종전엔 어디에도 이 라벨이 없어서, 결과를 읽는 쪽이 D_net4 유무만 보고
        #   완료로 읽을 수 있었다.
        _bs = out["branch_sensitivity"]
        _palt_bad = sorted(r for r, v in _palt_out.items()
                           if v.get("status") != "computed")
        out["sensitivity_complete"] = bool(_bs.get("status") == "computed"
                                           and not _palt_bad)
        if _bs.get("status") != "computed":
            out.setdefault("nonprimary_notes", []).append(
                "SENSITIVITY_INCOMPLETE(자기 분기 민감도가 %s — D 를 '분기에 강건' "
                "이라고 서술하지 말 것)" % _bs.get("status"))
        if _palt_bad:
            out.setdefault("nonprimary_notes", []).append(
                "POSE_SENSITIVITY_INCOMPLETE(%s — D 를 '자세에 강건' 이라고 "
                "서술하지 말 것)" % ", ".join(
                    "%s:%s" % (r, _palt_out[r].get("status")) for r in _palt_bad))
    else:
        # 🔴🔴 회신 BE P0-1 (2026-09-03) — **fallback 을 없앤다.** 종전엔 `estimand_job_keys`
        #   가 없으면 조각별 최솟값이라는 **다른 보고량**으로 조용히 바뀌었다 (map 을
        #   지우면 자동 전환 — 리뷰어 재현). 사전 고정 네 잡이 없으면 D 는 정의되지
        #   않는다. 대체하지 않고 NO_VALUE 로 끝낸다.
        _blk("ESTIMAND_KEYS_ABSENT",
             "ESTIMAND_KEYS_ABSENT(manifest 에 estimand_job_keys 가 없다 — 조각별 "
             "최솟값으로 대체하지 않는다. 사전 고정 네 잡만이 D 다 · 회신 BE P0-1)",
             scope="estimand")
        out["estimand_mode"] = "undefined (estimand_job_keys 없음 — fallback 폐지)"
        out["verdict"] = "NO_VALUE — 사전 고정 job key 가 없다 (조각별 min 대체 금지 · BE P0-1)"
        return out
    # ⛔⛔ 회신 BA P0-2 (2026-09-02) — **범위 없는 숫자를 최상위에서 없앤다.**
    #   `primary_ddE_lowE_eV` 는 `reported_X_eV=None` · `overall_citable=None` 인데도
    #   최상위에 맨숫자로 나왔다. 읽는 사람에게 그것이 결과값으로 읽힌다 —
    #   인용 차단을 우회하는 마지막 구멍이었다.
    #   ⇒ 최상위에서 빼고 **진단 절 안**으로 옮긴다. 정본 숫자는 두 개뿐이다:
    #     `D_raw_eV`(범위 명시) · `rounded_value_under_tested_axes_eV`(시험축 조건부).
    #   ⚠ 값을 **지우지는 않는다** (회신 AT Q5 a) — 왜 못 쓰는지가 같이 사라지면
    #     재논증이 반복된다. 다만 이름과 자리로 범위를 강제한다.
    out["diagnostic_only"] = {
        "⛔": ("이 절의 수는 **인용 대상이 아니다.** 최상위 정본은 `D_raw_eV` 와 "
               "`rounded_value_under_tested_axes_eV` 둘뿐이다 (회신 BA P0-2)."),
        "primary_ddE_lowE_eV": round(primary, 4),
        "⚠_왜_최상위가_아닌가": ("범위 없는 맨숫자가 최상위에 있으면 "
                                  "`overall_citable=None` 이어도 결과값으로 읽힌다"),
    }
    # 🔴 회신 AT Q5 (a) — 값은 **계속 낸다** (내부 진단). 인용 자격만 영구히 없다.
    #   숫자를 지우면 나중에 왜 못 쓰는지도 같이 사라져 재논증이 반복된다.
    _pe = out.get("pooled_effect") or {}
    out["secondary_G_eV_diagnostic"] = (
        round(secondary, 4) if _pe.get("would_pass_dynamic_gates") else None)
    out["secondary_G_eV"] = None
    out["secondary_G_⛔"] = (
        "**영구 비인용** (회신 AT Q5 선택지 (a) · 1저자 결정 2026-08-31). "
        "secondary_G 는 pooled 최솟값/최댓값에서 나오는데, pool 은 dense k 미검증 "
        "잡과 서로 다른 자기 basin 을 함께 담는다. 진단값은 "
        "`secondary_G_eV_diagnostic` 에 남는다%s"
        % ("" if _pe.get("would_pass_dynamic_gates")
           else " (지금은 동적 게이트도 통과하지 못한다 — pooled heterogeneity 또는 "
                "pool 불완전)"))
    # 🔴 회신 AV P1-5 — **D_raw 와 인용 자격을 분리한다.**
    #   입력·상태·provenance 가 유효하면(여기 도달) D_raw 는 항상 보존한다.
    #   0.01 eV 반올림 보고는 numeric_budget 의 인용 자격이 있을 때만 낸다.
    out["D_raw_eV"] = round(primary, 6)
    # 🔴 렌즈2 P1-2 (2026-09-03) — 선언된 재개 조건을 **기계로** D_raw 에 댄다: 어느 값에
    #   대는지(D_raw_eV · 반올림 전), 충족 여부, 그때 하기로 한 행동을 결과에 남긴다 —
    #   결과를 보고 값을 고르거나(rounded vs raw) 문턱을 다시 읽을 여지를 없앤다.
    _ko = out.get("kconv_omission")
    if isinstance(_ko, dict) and isinstance(_ko.get("재개_조건"), dict):
        _ev = _kconv_reopen_eval(_ko["재개_조건"], primary)
        _ko["reopen_eval"] = _ev
        # 🔴 렌즈6′ P1-4 (2026-09-03) — 태그는 **비교 연산자가 아니라 선언된 행동**이 정한다.
        #   종전엔 `abs_lt` 일 때만 TRIGGERED 라, boundary + "dense 2잡 추가"(안 B)가 충족돼도
        #   자문 태그가 나왔다 — 재개인데 기계 기록은 자문이라고 말한다.
        _act = str((_ko.get("재개_조건") or {}).get("충족시") or "")
        _adds = any(w in _act for w in ("추가", "dense", "재개", "확장"))
        _tag = ("KCONV_REOPEN_TRIGGERED" if _ev.get("충족") and _adds
                else "KCONV_UNTESTED_AXIS_AT_THRESHOLD" if _ev.get("충족")
                else "KCONV_REOPEN_NOT_TRIGGERED")
        out.setdefault("advisories", []).append(
            "%s(|D_raw|=%.4f eV · 비교 %s · 문턱 %s eV · %s)"
            % (_tag, abs(primary), _ev.get("비교"), _ev.get("문턱_eV"), _ev.get("행동")))
    out["fragments"] = {"sdcp": sd, "control": ct}
    _nbF = out.get("numeric_budget") or {}
    _cit01 = bool(_nbF.get("tested_axes_stable_at_0.01eV"))
    out["tested_axes_stable_at_0.01eV"] = _cit01
    # 🔴 렌즈2 P1-4 — numeric_budget 이 정한 값을 그대로 쓴다: 세 축 다 있으면 None(ENCUT
    #   근거 없음 · AY P1), 사전등록 축이 하나라도 없으면 False(주장하지 않는다).
    out["overall_citable_at_0.01eV"] = _nbF.get("overall_citable_at_0.01eV")
    _vsfx = ("" if _nbF.get("overall_citable_at_0.01eV") is not False else
             " · 사전등록 축 없음(%s) — 0.01 eV 전체 안정성 미주장"
             % ",".join(str(x).split("(")[0] for x in
                        (list(_nbF.get("missing_axes") or [])
                         + [a for a in (_nbF.get("axes_not_designed") or [])
                            if any(t in str(a) for t in ("Δ_vac", "δ_gas", "δ_k"))])))
    # ⛔⛔ 회신 AZ P0-5 (2026-09-01) — **`overall=None` 을 출력 경로가 우회했다.**
    #   `overall_citable_at_0.01eV=None`("모른다")을 옳게 넣어 놓고, 바로 아래에서
    #   *시험한 축만* 통과하면 `reported_X_eV` 라는 **무조건적 이름의 숫자**를 냈다.
    #   필드명에 범위가 없으면 읽는 사람은 그것을 최종 인용값으로 읽는다.
    #   ⇒ 필드명에 범위를 박는다: `rounded_value_under_tested_axes_eV`.
    #     `reported_X_eV` 는 **overall 이 True 일 때만** 나온다 — 지금은 영영 None 이다.
    if _cit01:
        _rv = round(round(primary / PREREG_ROUND_EV) * PREREG_ROUND_EV, 2)
        out["rounded_value_under_tested_axes_eV"] = _rv
        out["rounded_value_under_tested_axes_⚠"] = (
            "**시험한 축 조건부** 값이다 (ENCUT·축간 상호작용은 안 쟀다). "
            "overall_citable_at_0.01eV 가 True 가 되기 전에는 최종 인용값이 아니다 "
            "(회신 AZ P0-5)")
    else:
        out["rounded_value_under_tested_axes_eV"] = None
        out["rounded_value_under_tested_axes_⚠"] = (
            "0.01 eV 인용 자격 없음 (B_num envelope %s · missing %s · 미설계 %s) — "
            "D_raw 와 축별 민감도만 보고한다 (회신 AV P1-5)"
            % (_nbF.get("B_num_meV"), _nbF.get("missing_axes"),
               _nbF.get("axes_not_designed")))
    # ⛔ 회신 BA Q4 — `reported_X_eV` 를 **제거한다.** overall 이 영영 None 이라
    #   그 필드는 죽어 있고, 죽은 필드는 되살아날 자리로 남는다.
    out.pop("reported_X_eV", None)
    out["reported_X_⛔"] = (
        "overall_citable_at_0.01eV=%r — ENCUT·축간 상호작용을 안 쟀으므로 무조건적 "
        "인용값을 내지 않는다. 시험한 축 조건부 값은 "
        "`rounded_value_under_tested_axes_eV` 에 있다 (회신 AZ P0-5)"
        % (out["overall_citable_at_0.01eV"],))
    # 방향 결론 — envelope 구간 [D−B, D+B] 가 0 이나 guard 를 **가로지르면** 방향을
    #   말하지 않는다 (회신 AV P1-5). B 가 없으면(축 결측) 이미 위에서 NO_VALUE 다.
    _bev = (float(_nbF["B_num_meV"]) / 1000.0
            if _nbF.get("B_num_meV") is not None else None)
    if _bev is not None:
        _lo, _hi = primary - _bev, primary + _bev
        out["D_interval_eV"] = {
            "lo": round(_lo, 4), "hi": round(_hi, 4),
            "성격": ("D_raw ± B_num — 시험한 축의 sensitivity envelope 이지 "
                     "통계 신뢰구간이 아니다")}
        if _hi <= PREREG_GUARD_EV:
            out["guard"] = ("통과 (구간 [%.4f, %.4f] 전체가 guard %.2f 이하)"
                            % (_lo, _hi, PREREG_GUARD_EV))
            # ⛔⛔ 회신 AZ P0-5 — 방향 판정도 **시험한 축 조건부**다. 무조건적
            #   "보고 가능" 은 overall 자격이 없는데도 최종 승인처럼 읽혔다.
            # 🔴 렌즈2 P1-4 — 사전등록 축이 빠졌으면 verdict 문자열에도 남긴다.
            out["verdict"] = "보고 가능 (시험한 축 조건부)" + _vsfx
        elif (_lo <= PREREG_GUARD_EV < _hi) or (_lo < 0.0 <= _hi):
            out["guard"] = ("⛔ 구간 [%.4f, %.4f] 가 guard(%.2f) 또는 0 을 "
                            "가로지른다" % (_lo, _hi, PREREG_GUARD_EV))
            out["verdict"] = ("NO_CLAIM — 방향 결론 없음 (D_raw 는 보존 · "
                              "회신 AV P1-5)")
        else:
            out["guard"] = ("⛔ 구간 [%.4f, %.4f] 전체가 guard %.2f 위 — 방향성 "
                            "주장 금지" % (_lo, _hi, PREREG_GUARD_EV))
            out["verdict"] = "NO_DIRECTIONAL_CLAIM"
    elif primary <= PREREG_GUARD_EV:
        out["guard"] = "통과 (primary %.4f <= %.2f · envelope 미상)" % (primary, PREREG_GUARD_EV)
        out["verdict"] = "보고 가능 (시험한 축 조건부)" + _vsfx
    else:
        out["guard"] = ("⛔ primary %+.4f > %.2f — guard band 미달"
                        % (primary, PREREG_GUARD_EV))
        out["verdict"] = "NO_DIRECTIONAL_CLAIM"
    out["verdict_scope"] = {
        "범위": "tested axes only (ENCUT·축간 상호작용 미측정)",
        "⛔": ("이 판정은 `overall_citable_at_0.01eV` 가 True 가 되기 전에는 "
               "최종 인용 승인이 아니다. 원고 문장에 축 조건을 병기한다 "
               "(회신 AZ P0-5)")}
    # ⛔ 회신 AO P0-6 — 기체 상자 수렴을 **이 묶음에서 검증하지 않았으면** 그 사실이
    #   D 에 라벨로 붙어야 한다. prior 를 비차단으로 내린 대가는 침묵이 아니다.
    _bx = [k for k, v in ((results or {}).get("numerical_gates") or {}).items()
           if k.startswith("box_") and v.get("verified_in_this_bundle") is False]
    if _bx:
        out.setdefault("caveats", []).append(
            "GAS_BOX_UNVERIFIED(%s: 이 묶음에 box20 이 없어 기체 상자 수렴을 "
            "검증하지 않았다. 최종 D 에는 E_G^SDCP − E_G^control 이 남으므로 상자 "
            "오차가 대수적으로 소거되지 않는다. '기체 상자 수렴 확인' 을 쓰지 말 것)"
            % sorted(_bx))
    out["⚠_후보집합"] = ("candidate_set 이 동결된 prospective_lowE 가 아니면 이 값은 "
                         "primary 가 아니라 **legacy 교정 tranche** 다 (회신 V P0-5). "
                         "'primary'·'low-energy'·'pose-insensitive'·'전역 최소' 로 쓰지 말 것")
    return out


def preflight_static_physics(man):
    """번들만으로 판정 가능한 **물리 결박**을 결과 전에 친다 → (위반, 검사한 것, 건너뛴 것).

    🔴 회신 BG P1-4 (2026-09-03) — BF 가 넣은 정적 검사(protocol exact map · 진공 c1/c2 ·
      기체 절대관계)가 **최종 분석에서만** 돌았다. 그 시점은 ≈300 h 의 계산이 끝난 뒤다.
      회신 BD P0-4 는 "비용 발생 전에 닫는다" 를 요구했는데, 전부 몇 초짜리 정적 검사라
      `--check_governance` 에서 돌면 된다. 여기가 그 자리다.
    ⚠ **봉인된 주장만** 친다 — estimand 를 봉인하지 않은 탐색용 묶음에 네 경로를 요구하면
      돌지 못한다. 대신 건너뛴 것을 **돌려주고 호출부가 화면에 적는다** (건너뛴 검사를
      통과로 읽지 않게 — 이 리포의 오래된 규율이다).
    ⛔ 못 하는 것: 에너지·수렴·k 는 못 본다 (결과가 없다). 기하와 계약만이다.
    """
    bad, done, skipped = [], [], []
    _keys = ((man.get("estimand") or {}).get("job_keys")
             or man.get("estimand_job_keys") or {})
    if not _keys:
        skipped.append("protocol exact map (estimand_job_keys 미봉인 — 탐색용 묶음)")
    else:
        _pm, _pw = _protocol_exact_map(man)
        if _pm is None:
            bad.append("protocol exact map 을 읽을 수 없다 (%s)" % _pw)
        elif {k: _keys.get(k) for k in _pm} != dict(_pm):
            # ⚠ manifest 는 branch·formula·주석도 같은 dict 에 담는다 — protocol 이 **정의한
            #   네 키만** 비교한다 (`_estimand_semantics_check` 와 같은 범위).
            bad.append("estimand_job_keys 가 비준 protocol 의 정확한 네 경로와 다르다 "
                       "(manifest %s ≠ protocol %s)"
                       % (sorted((k, _keys.get(k)) for k in _pm), sorted(_pm.items())))
        else:
            done.append("protocol exact map (네 경로가 비준 원문과 정확히 같다)")
    _vc = man.get("vacuum_convergence") or {}
    if not _vc:
        skipped.append("진공 c1/c2 (vacuum_convergence 미봉인)")
    else:
        _pvc, _pvw = _protocol_vacuum_cells(man)
        if _pvc is None:
            bad.append("진공 시험 셀을 봉인해 놓고 protocol 원문에서 못 읽는다 (%s)" % _pvw)
        else:
            _okv = True
            for _i, _k in ((0, "c1_A"), (1, "c2_A")):
                try:
                    _got = float(_vc.get(_k))
                except (TypeError, ValueError):
                    bad.append("vacuum_convergence.%s 가 수가 아니다 (%r)" % (_k, _vc.get(_k)))
                    _okv = False
                    continue
                if abs(_got - float(_pvc[_i])) > 1e-6:
                    bad.append("vacuum_convergence.%s=%s ≠ protocol %s" % (_k, _got, _pvc[_i]))
                    _okv = False
            if _okv:
                done.append("진공 c1/c2 (%s · %s — protocol 절대값과 일치)" % (_pvc[0], _pvc[1]))
    # 기체 조각은 planned 의 `refs/mol__<frag>__box<NN>` 키에서 읽는다 (분석기와 같은 출처).
    _pl = man.get("planned") or {}
    _gfr = sorted({k.split("__")[1] for k in _pl
                   if k.startswith("refs/mol__") and k.count("__") >= 2})
    _rt0 = man.get("_root") or "."
    for _f in _gfr:
        # ⚠ meta 는 `planned` 가 아니라 잡의 **job.json** 에서 읽는다 — 분석기 production
        #   경로가 보는 것이 그 파일이다 (planned 에는 phases 만 있고 지문이 없다).
        _mt = {}
        for _b in ("20", "24"):
            _jf = os.path.join(_rt0, "refs", "mol__%s__box%s" % (_f, _b), "job.json")
            try:
                with open(_jf, encoding="utf-8") as _fh:
                    _mt[_b] = json.load(_fh)
            except Exception:                                # noqa: BLE001
                _mt[_b] = {}
                bad.append("기체 %s box%s: job.json 을 읽을 수 없다 (%s)" % (_f, _b, _jf))
        # ⚠ `staged_runner` 를 뗀 사본으로 부른다 — receipt 상 집합 검사는 **실행 뒤** 것이고
        #   preflight 시점엔 반송물이 없다. 없는 것을 위반으로 세면 preflight 가 항상 막힌다.
        _man_pre = {k: v for k, v in man.items() if k != "staged_runner"}
        bad += ["기체 %s: %s" % (_f, _x) for _x in
                _gas_bytes_check(_man_pre, _f, metas=_mt, planned=_pl)]
    if _gfr:
        done.append("기체 절대관계 %s (COM 중앙 · span+margin · 내부기하 · planned phases)" % _gfr)
        if (man or {}).get("staged_runner"):
            skipped.append("기체 **실행된** 상 집합 (receipt 는 반송 뒤에 생긴다 — 최종 분석 몫)")
    else:
        skipped.append("기체 절대관계 (planned 에 refs/mol__*__box* 가 없다)")
    # 🔴 렌즈2 P1-3 (2026-09-03) — kconv 축 생략의 **정적** 조건(상태 · 재개 조건 형식 · 비준 항 ·
    #   드리프트)은 결과가 없어도 판정된다. 최종 분석에서만 걸면 ~111 h 뒤다 (BG P1-4 와 같은 유형).
    _kp0 = man.get("kconv_pair") or {}
    _ejk_p = man.get("estimand_job_keys") or {}
    _two_p = len({_ejk_p.get("E_C_sdcp"), _ejk_p.get("E_C_control")} - {None}) == 2
    if _kp0.get("jobs"):
        done.append("kconv 쌍 봉인 (jobs %d — δ_k 를 잰다)" % len(_kp0["jobs"]))
    elif not _two_p:
        skipped.append("kconv 축 (estimand primary 조각이 둘이 아니다 — δ_k 정의 안 됨)")
    elif str(_kp0.get("status")) == "not_designed":
        _rq0 = next((v for k, v in _kp0.items() if "재개_조건" in str(k)), None)
        _rpp0 = _kconv_reopen_rule_problems(_rq0)
        _pe0, _pek0, _pew0 = _prereg_axis_exclusion(man, "δ_k")
        if _rpp0:
            bad.append("kconv 설계 제외의 재개 조건이 기계 평가 불가 %s (KCONV_OMISSION_UNDECLARED)" % _rpp0[:3])
        elif _pe0 is None:
            bad.append("kconv 설계 제외가 비준 사전등록에 없다 — %s (KCONV_OMISSION_UNRATIFIED)" % _pew0)
        elif (_pe0.get("재개_조건_결과_보기_전에_선언") or {}) != dict(_rq0):
            bad.append("kconv 재개 조건이 비준 사전등록 %s 와 다르다 (KCONV_OMISSION_DRIFT)" % _pek0)
        else:
            done.append("kconv 설계 제외 (비준 사전등록 %s · 재개 조건 기계 평가 가능 · 드리프트 없음)" % _pek0)
    elif str(_kp0.get("status")) == "not_applicable":
        bad.append("kconv_pair.status=not_applicable 인데 primary 조각이 둘이다 — δ_k 는 정의된다 "
                   "(KCONV_STATUS_INVALID)")
    else:
        bad.append("kconv_pair 가 없거나 상태 미상 (%r) — 0.01 eV 의 k 근거가 없다 (KCONV_ABSENT)"
                   % (_kp0.get("status"),))
    return bad, done, skipped


def main():
    if "--selftest" in sys.argv:
        return selftest_k()
    if "--check_pin" in sys.argv:
        i = sys.argv.index("--check_pin")
        return check_pin(sys.argv[i + 1] if len(sys.argv) > i + 1 else ".")
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    delta = DELTA
    if "--delta" in sys.argv:
        delta = float(sys.argv[sys.argv.index("--delta") + 1])
    man = json.load(open(os.path.join(root, "MANIFEST.json"), encoding="utf-8"))
    # ⛔ 회신 AO Q1 — 생산 전에 봉인한 variant 별 원본 fingerprint. 러너
    #   (SEAL_POTCAR_ROOT.sh)가 **첫 VASP 실행 전에** 만든다. 없으면 없다고 적는다.
    try:
        man["_potcar_root_seal"] = json.load(
            open(os.path.join(root, "POTCAR_ROOT_SEAL.json"), encoding="utf-8"))
    except Exception:
        man["_potcar_root_seal"] = None
    man["_manifest_sha256_actual"] = hashlib.sha256(
        open(os.path.join(root, "MANIFEST.json"), "rb").read()).hexdigest()
    # 🔴 회신 AV P0-1 — planned 에 species_order 가 없으면 그 잡의 job.json 을 읽어야
    #   한다. 어디서 읽을지 알려면 루트를 실어야 한다.
    man["_root"] = root
    # ⛔ 회신 AP #12 — 공식 release 주장은 **계산 전 attestation** 이 있을 때만.
    try:
        man["_potcar_attestation"] = json.load(
            open(os.path.join(root, "POTCAR_ATTESTATION.json"), encoding="utf-8"))
    except Exception:
        man["_potcar_attestation"] = None
    # ⛔ 회신 AR P0-6 — attestation 은 **정확한 ZIP** 과도 결박돼야 한다.
    #   받은 ZIP 의 SHA256 은 번들 안에 있을 수 없으므로(자기 해시) 두 경로로 받는다:
    #     ① `--zip_sha256 <sha>`  ② 번들 루트의 ZIP_SHA256.txt (verify_zip 이 남긴다)
    #   둘 다 없으면 "결박 확인 못 함" 이고 그것은 **통과가 아니다**.
    _zsha = None
    if "--zip_sha256" in sys.argv:
        _zi = sys.argv.index("--zip_sha256")
        _zsha = sys.argv[_zi + 1] if len(sys.argv) > _zi + 1 else None
    if not _zsha:
        try:
            _zsha = open(os.path.join(root, "ZIP_SHA256.txt"),
                        encoding="utf-8").read().split()[0]
        except Exception:
            _zsha = None
    man["_zip_sha256_observed"] = (_zsha or "").strip().lower() or None

    # ⛔⛔ 회신 BB P0-6 (2026-09-02) — **증서 검증을 생산 **전**에 한 곳에서 한다.**
    #   종전 run_staged.sh 는 `made_before_production` 과 SHA map 두 가지만 봤고,
    #   schema·ZIP·manifest·allowlist·VASP·시각은 **분석 단계에 가서야** 봤다.
    #   즉 잘못된 증서로 16잡(약 300 h)을 다 돌린 뒤 거부될 수 있었다.
    #   ⇒ 러너가 이 경로를 부른다. 검사 논리는 `potcar_identity_gates` **하나**이고
    #     그 파일 SHA 는 MANIFEST 에 있다 (검사 사본을 두지 않는다 — 회신 BB P1).
    # ⛔⛔ 회신 BD P0-4 · GO 해제조건 5 (2026-09-02) — **거버넌스 검사가 비용 발생
    #   전 preflight 가 아니었다.** `--check_attestation` 은 POTCAR 만 봤고,
    #   post_hoc 경로는 거버넌스를 확인하지 않고 Stage 1 을 시작했다. 비준 판정은
    #   결과 분석 **끝에서야** exit 2 를 냈다 — manifest 의 "비용 발생 전에 닫는다"
    #   와 정면으로 어긋난다.
    #   ⇒ 별도 게이트를 만들고 러너가 SEAL **전에** 부른다. fail-closed 다.
    if "--check_governance" in sys.argv:
        _gb0 = man.get("governance_binding") or {}
        print("== 거버넌스 사전 검사 (SEAL·첫 VASP 실행 전 · 회신 BD P0-4) ==")
        if not _gb0:
            print("  ⛔ governance_binding 이 없다 — 구판 번들이다")
            return 2
        _bad_g0 = _governance_strict(_gb0)
        # 🔴 회신 BE P0-4 — preflight 도 원문 byte 재계산을 거친다 (불리언을 믿지 않는다)
        _bad_g0 += governance_bytes_check(man)
        _pv0 = man.get("provenance")
        # ⚠ selftest 픽스처는 **개발 트리에서** 만들어지므로 언제나 dirty 다.
        #   거버넌스 절은 그대로 걸고 **계보 절만** 면제한다 — 면제 사실을 화면에
        #   적고, 면제가 실물에서 열리지 않는지는 아래 음성시험이 지킨다.
        if _pv0 is None:
            _bad_g0.append("provenance 가 없다 — 어떤 코드·입력으로 만들어졌는지 "
                           "번들이 말하지 못한다")
        elif not _strict_true(_pv0.get("clean")):
            _bad_g0.append("생성 계보가 dirty 다 (%s)"
                           % ((_pv0.get("dirty") or [])[:3]))
        elif _pv0.get("dirty") or _pv0.get("unknown_git_state"):
            _bad_g0.append("clean=true 인데 dirty/미상 목록이 비어 있지 않다")
        # 🔴 회신 BF P0-4 — preflight 도 계보의 **완전성**을 본다 (요약 세 칸으로는 통과 불가)
        _bad_g0 += provenance_strict(man)
        for _i in C12_REQUIRED_DECISIONS:
            _v = (_gb0.get("decisions") or {}).get(_i) or {}
            print("  decision %-40s state=%-8s ratified=%s digest=%s"
                  % (_i, _v.get("state"), _v.get("ratified"),
                     _v.get("digest_matches")))
        for _p, _role in sorted(C12_REQUIRED_REFS.items()):
            _v = (_gb0.get("reference_files_state") or {}).get(_p) or {}
            print("  ref      %-40s role=%-13s ratified=%s"
                  % (_p.rsplit("/", 1)[-1], _v.get("role"), _v.get("ratified")))
        # 🔴 회신 BG P1-4 — 번들만으로 되는 **물리 결박**도 여기서 친다 (≈300 h 뒤가 아니라).
        _sp_bad, _sp_done, _sp_skip = preflight_static_physics(man)
        _bad_g0 += ["[정적 물리] " + _x for _x in _sp_bad]
        # 🔴🔴 2026-09-04 — **보고량이 비준 사전등록과 같은가.**
        #   구멍이었다: MANIFEST 의 `reported_quantity.이름` 을 바꿔도 어떤 게이트도
        #   안 잡았다. 실측 — clean slab 을 넣고 보고량을 "E_ads 절대값" 으로 바꿨더니
        #   preflight 가 dirty tree 만 걸고 **보고량 변경은 통과**시켰다.
        #   이 캠페인이 여덟 번 반려당한 이유가 바로 "맞는 양을 재고 있나" 인데,
        #   정작 그 양이 바뀌는 것을 기계가 안 봤다.
        _bad_g0 += reported_quantity_matches_prereg(man)
        if _bad_g0:
            print("  ⛔ **거버넌스가 서지 않는다 — 한 잡도 돌리지 않는다:**")
            for _x in _bad_g0[:12]:
                print("     · %s" % _x)
            return 2
        print("  ✔ 거버넌스 통과 — 비용을 써도 되는 상태다")
        for _x in _sp_done:
            print("  ✔ 정적 물리: %s" % _x)
        for _x in _sp_skip:
            print("  ⚠ 정적 물리 **건너뜀** (통과 아님): %s" % _x)
        print("  ⛔ 이 검사가 **못 하는 것**: POTCAR 신원은 보지 않는다 "
              "(`--check_attestation` 의 몫) · 에너지·수렴·k 는 결과가 없어 못 본다.")
        return 0
    if "--check_attestation" in sys.argv:
        # ⚠ 생산 **전**이라 잡 반송이 없다 — jobs={} 로 부른다. 그러면 잡 사이
        #   일치(cross-job) 검사는 못 하고 증서·봉인 검사만 한다. 그 한계를 화면에
        #   적는다 (잡 사이 검사는 분석 단계의 몫이다).
        _cg = potcar_identity_gates({}, man)
        _att_s = _cg.get("attestation") or {}
        _bad = list(_cg.get("blocking") or []) + list(_att_s.get("why") or [])
        _pol = ((man.get("potcar_identity_policy") or {}).get("mode") or "post_hoc")
        print("== POTCAR 증서 사전 검증 (생산 전 · 회신 BB P0-6) ==")
        print("  정책 mode = %s" % _pol)
        print("  attestation present=%s usable=%s"
              % (_att_s.get("present"), _att_s.get("usable")))
        print("  allowed_claim = %s" % _cg.get("allowed_claim"))
        _an = _cg.get("release_label_anchor_detail") or {}
        if _an:
            print("  이름 앵커: label 결박=%s · SHA map 포괄=%s%s"
                  % (_an.get("label_matches_site_report"),
                     _an.get("sha_map_covers_all_variants"),
                     (" · 미포괄 %s" % _an["uncovered_variants"][:3])
                     if _an.get("uncovered_variants") else ""))
        for _x in _bad[:12]:
            print("   ⛔ %s" % _x)
        if _pol == "require_attestation" and (_bad or not _att_s.get("usable")):
            print("  ⛔ **원고용 정책인데 증서가 쓸 수 없다** — 한 잡도 돌리지 않는다.")
            return 2
        # 🔴🔴 렌즈4 P0-1 (2026-09-03) — post_hoc 이라도 **증서가 있으면** 결함을 지금 잡는다.
        #   종전엔 post_hoc 에서 러너가 이 검사를 부르지 않아, 결함 있는 *선택* 증서가
        #   1단계를 다 돌린 **뒤에야** 최종 분석의 potcar_identity 에서 처음 드러났다. "선택" 은
        #   "없어도 된다" 이지 "틀린 것이 있어도 된다" 가 아니다 — 있으면 맞아야 하고,
        #   그것은 지금 확인할 수 있다.
        if (_pol != "require_attestation" and _att_s.get("present")
                and (_bad or not _att_s.get("usable"))):
            print("  ⛔ **선택 증서에 결함이 있다** — 이대로 두면 최종 분석에서 "
                  "potcar_identity 가 막힌다 (렌즈4 P0-1).")
            print("     POTCAR_ATTESTATION.json 을 지우고 진행하거나(없으면 러너는 "
                  "돌아간다), MAKE_POTCAR_ATTESTATION.sh 를 다시 돌리십시오.")
            return 2
        if _pol != "require_attestation" and _att_s.get("present"):
            print("  ✔ post_hoc 정책 — 선택 증서가 봉인·MANIFEST·ZIP 과 정합한다 "
                  "(dataset 신원 **기록**으로 남는다 · 원고 인용 자격은 그대로 없다).")
        elif _pol != "require_attestation":
            print("  ⚠ post_hoc 정책 — 증서 없이 진행한다. 이 묶음의 결과는 "
                  "**탐색용**이고 원고 인용 자격이 서지 않는다.")
        print("  ✔ 생산을 진행해도 되는 상태다 (정책 %s 기준)" % _pol)
        print("  ⛔ 이 검사가 **못 하는 것**: 잡 반송이 아직 없으므로 잡 사이 "
              "POTCAR/VASP 일치는 보지 않는다 — 그것은 분석 단계의 몫이다.")
        return 0

    spec = man.get("potcar_spec", {})
    planned = man.get("planned", {})

    # ══ 두 묶음 결합 (회신 AF P0-3) ═══════════════════════════════════════
    #   왜 필요한가 — 12자세는 calibration(4) + holdout(8) 이고 기체 기준계는
    #   calibration 묶음에만 있다. **어느 한쪽만으로는 조각 간 대비를 만들 수 없다.**
    #   합치되 **해시로 결속**한다: 두 MANIFEST 를 기록하고, 프로토콜이 갈리면 막는다.
    merge_roots = []
    if "--merge" in sys.argv:
        _i = sys.argv.index("--merge")
        for _v in sys.argv[_i + 1:]:
            if _v.startswith("-"):
                break
            merge_roots.append(_v)
    bundles = [(root, man)]
    for _mr in merge_roots:
        bundles.append((_mr, json.load(open(os.path.join(_mr, "MANIFEST.json"), encoding="utf-8"))))
    merge_info = merge_compat(bundles) if len(bundles) > 1 else None

    # ── 입력 무결성 (Codex P0-H) — INCAR 이 바뀌었는지부터 본다 ──────────────
    integrity = {"checked": 0, "changed": [], "missing": []}
    for rel, want in (man.get("files_sha256") or {}).items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            integrity["missing"].append(rel); continue
        integrity["checked"] += 1
        got = hashlib.sha256(open(p, "rb").read()).hexdigest()
        if got != want:
            integrity["changed"].append(rel)

    # ── 실행시 POSCAR 가 루트 POSCAR 와 같은가 (Codex 6차 §8) ─────────────────
    #   단일점 판의 주장은 "UMA 가 고른 **그 기하** 위의 DFT 에너지" 다. 외주처가
    #   다른 기하를 넣었으면 무결성 해시(배포 파일)는 통과해도 계산은 다른 계다.
    #   상 폴더의 POSCAR 는 배포물이 아니라 **러너가 만든 것**이라 files_sha256 에 없다.
    # ⛔⛔ 회신 AP #1 (2026-08-31) — 이 검사가 **정상 canary 를 반드시 막았다.**
    #   canary 는 `PARENT_GEOM` 을 따라 부모의 `relax/CONTCAR` 를 static/POSCAR 로
    #   받는데, 여기서는 relax 가 없는 잡의 static/POSCAR 를 **그 잡 자신의 루트
    #   POSCAR 와 바이트 해시로** 비교했다. 좌표가 같아도 CONTCAR 서식(Direct/scale/
    #   선택동역학 유무)만 달라도 불일치가 된다.
    #   ⇒ `PARENT_GEOM` 이 있으면 **선언된 부모의 최종 기하**를 기대값으로 삼고,
    #     바이트가 아니라 원소·순서·셀·Cartesian 좌표·고정플래그를 비교한다.
    def _expected_geom_src(jd):
        """(기대 기하 파일, 출처 라벨). PARENT_GEOM 이 있으면 부모의 최종 기하."""
        pg = os.path.join(jd, "PARENT_GEOM")
        if os.path.isfile(pg):
            tgt = os.path.normpath(os.path.join(
                jd, open(pg, encoding="utf-8").read().strip()))
            cc = os.path.join(tgt, "relax", "CONTCAR")
            if os.path.isfile(cc):
                return cc, "부모 relax/CONTCAR"
            rp2 = os.path.join(tgt, "POSCAR")
            if os.path.isfile(rp2):
                return rp2, "부모 루트 POSCAR (부모가 단일점)"
            return None, "부모 기하 없음 (%s)" % _pk(tgt, root)
        rp2 = os.path.join(jd, "POSCAR")
        return (rp2 if os.path.isfile(rp2) else None), "자기 루트 POSCAR"

    def _geom_equal(a, b, tol=1e-4):
        """원소·순서·셀·Cartesian·고정플래그 비교. → (bool, why)"""
        if a is None or b is None:
            return False, "한쪽을 못 읽었다"
        if len(a["pos"]) != len(b["pos"]):
            return False, "원자수 %d ≠ %d" % (len(a["pos"]), len(b["pos"]))
        if a.get("species") and b.get("species") and a["species"] != b["species"]:
            return False, "원소 순서 %s ≠ %s" % (a["species"], b["species"])
        if a.get("counts") != b.get("counts"):
            return False, "원소 개수 %s ≠ %s" % (a.get("counts"), b.get("counts"))
        dc = max(abs(a["cell"][i][k] - b["cell"][i][k])
                 for i in range(3) for k in range(3))
        if dc > tol:
            return False, "셀 최대차 %.3g Å" % dc
        dp = max(max(abs(x - y) for x, y in zip(p1, p2))
                 for p1, p2 in zip(a["pos"], b["pos"]))
        if dp > tol:
            return False, "Cartesian 최대차 %.3g Å" % dp
        if a.get("fixed") != b.get("fixed"):
            return False, "고정 플래그가 다르다"
        return True, "일치 (셀 %.3g · 좌표 %.3g Å)" % (dc, dp)

    integrity["runtime_poscar_mismatch"] = []
    integrity["parent_geom_checked"] = []
    for jd in sorted(glob(os.path.join(root, "*", "*", ""))):
        if os.path.isdir(os.path.join(jd, "relax")):
            continue              # 이완판은 CONTCAR 승계가 정상 — 달라야 맞다
        src, lbl = _expected_geom_src(jd)
        if src is None:
            continue
        want_g = read_poscar(src)
        for ph in ("static", "dense"):
            pp = os.path.join(jd, ph, "POSCAR")
            if not os.path.isfile(pp):
                continue
            ok, why = _geom_equal(want_g, read_poscar(pp))
            if os.path.isfile(os.path.join(jd, "PARENT_GEOM")):
                integrity["parent_geom_checked"].append(
                    "%s ← %s: %s" % (_pk(pp, root), lbl, why))
            if not ok:
                integrity["runtime_poscar_mismatch"].append(
                    "%s (기대=%s · %s)" % (_pk(pp, root), lbl, why))
    # ★ phase POSCAR 를 반송받지 못하면 위 검사는 **조용히 건너뛴다** = fail-open.
    #   OUTCAR 가 있는데 POSCAR 가 없으면 OUTCAR 좌표로 대조한다 (Codex P0-6).
    integrity["geometry_unverified"] = []
    for jd in sorted(glob(os.path.join(root, "*", "*", ""))):
        if os.path.isdir(os.path.join(jd, "relax")):
            continue
        # ⛔ 회신 AP #1 — 여기서도 기대 기하는 **PARENT_GEOM 을 따른다**
        _src2, _lbl2 = _expected_geom_src(jd)
        if _src2 is None:
            continue
        want = read_poscar(_src2)
        for ph in ("static", "dense"):
            has_oc = any(os.path.isfile(os.path.join(jd, ph, "OUTCAR" + e))
                         for e in ("", ".gz"))
            if not has_oc or os.path.isfile(os.path.join(jd, ph, "POSCAR")):
                continue
            oc = read_outcar(os.path.join(jd, ph, "OUTCAR"))
            pos = (oc or {}).get("positions")
            rel = _pk(os.path.join(jd, ph), root)
            if not pos or not want or len(pos) != len(want["pos"]):
                integrity["geometry_unverified"].append(rel)
                continue
            d = max(mic_dist(a, b, want["cell"]) for a, b in zip(pos, want["pos"]))
            if d > 0.05:
                integrity["runtime_poscar_mismatch"].append(
                    f"{rel} (OUTCAR 좌표가 루트와 최대 {d:.3f} Å 다르다)")

    jobs = {}
    results_ldau_missing = []
    _jobdirs = []
    for _ri, _mi in bundles:
        for _jd in sorted(glob(os.path.join(_ri, "*", "*", ""))):
            _jobdirs.append((_jd, _ri, _mi))
    for jd, _root_i, _man_i in _jobdirs:
        jp = os.path.join(jd, "job.json")
        if not os.path.isfile(jp):
            continue
        meta = json.load(open(jp, encoding="utf-8"))
        rel = _pk(jd, _root_i)
        _planned_i = _man_i.get("planned", {})
        _spec_i = _man_i.get("potcar_spec", {})
        if rel in jobs:                       # ⛔ 이름이 겹치면 조용히 덮지 않는다
            jobs[rel]["gates"].append(
                "MERGE_NAME_COLLISION(같은 잡 이름이 두 묶음에 있다 — 어느 쪽 값인지 "
                "알 수 없으므로 이 잡을 쓰지 않는다)")
            continue
        phases = (_planned_i.get(rel) or {}).get("phases") or meta.get("phases") or \
            ["relax", "static"]
        ocs = {ph: read_outcar(os.path.join(jd, ph, "OUTCAR")) for ph in phases}
        # ⛔ 2026-08-25 (codex E-2차 필수5) — static/dense 만 남기면 static_pin 등
        #   다른 상의 감사·세그먼트가 **RESULTS 에서 유실**된다. 모든 상을 보존한다.
        rec = {"meta": meta, "static": ocs.get("static"), "dense": ocs.get("dense"),
               "gates": []}
        for _ph in phases:
            rec[_ph] = ocs.get(_ph)
        for ph in phases:
            rec["gates"] += phase_gates(ocs[ph], ph, meta, _spec_i,
                                        want_ionic=(ph == "relax"))
        # ★ 격자가 커지는 상 사이로 NKPTS 가 안 늘면 **같은 계산을 복사한 것**이다.
        km = meta.get("kmesh") or {}
        seq = [ph for ph in phases if ocs.get(ph) and ocs[ph].get("nkpts") and km.get(ph)]
        for x, y in zip(seq, seq[1:]):
            px = py = 1
            for v in str(km[x]).split():
                px *= int(v)
            for v in str(km[y]).split():
                py *= int(v)
            if py > px and ocs[y]["nkpts"] <= ocs[x]["nkpts"]:
                rec["gates"].append(
                    f"KMESH_NOT_DENSER({y} NKPTS {ocs[y]['nkpts']} ≤ {x} {ocs[x]['nkpts']} "
                    f"인데 격자는 {km[x]}→{km[y]} — 다른 상의 산출을 복사했나)")
        rec["gates"] += potcar_provenance_gates(jd, meta, rel, _man_i)
        # 🔴 회신 AV P0-2 — receipt 는 이제 분석기가 읽는 **필수 반송물**이다
        rec["gates"] += executable_receipt_gates(
            jd, rel, _man_i, [ph for ph in phases if ocs.get(ph)])
        _ppf = os.path.join(jd, "POTCAR_PROVENANCE.json")
        if os.path.isfile(_ppf):
            try:
                rec["_prov"] = json.load(open(_ppf, encoding="utf-8"))
            except Exception:                                # noqa: BLE001
                rec["_prov"] = None
        g2, info = geometry_audit(jd, meta)
        rec["gates"] += g2
        rec["geom"] = {k: v for k, v in info.items() if not k.startswith("_")}
        rec["_contact_fp"] = info.get("_contact_fp")
        rec["_fin"] = info.get("_fin")
        rx = ocs.get("relax")
        # 힘: 블록이 없거나 원자수가 다르면 **검사 생략이 아니라 게이트**
        if rx is not None:
            if not rx.get("forces"):
                rec["gates"].append("FORCE_UNVERIFIED(TOTAL-FORCE 블록 없음)")
            elif info.get("_init_fixed") and len(rx["forces"]) != len(info["_init_fixed"]):
                rec["gates"].append(
                    f"FORCE_COUNT({len(rx['forces'])}!={len(info['_init_fixed'])})")
            elif info.get("_init_fixed"):
                fmax = max((math.sqrt(sum(c * c for c in f))
                            for f, fx in zip(rx["forces"], info["_init_fixed"]) if not fx),
                           default=0.0)
                rec["geom"]["free_fmax_eVA"] = round(fmax, 3)
                if fmax > FORCE_TOL:
                    rec["gates"].append(f"FORCE_HIGH({fmax:.3f} eV/Å)")
        # ── 단일점의 static 힘: **진단값**이지 수렴 판정이 아니다 (Codex 6차 §4) ──
        #   MLIP 기하가 DFT 최소점에서 얼마나 먼지를 보여 준다. 큰 잔류힘은
        #   "그 자세만 DFT 이완으로 넘길까" 를 결정하는 trigger 로 쓴다.
        #   ⚠ 힘 하나로 단일점 에너지 오차의 부호나 상한을 만들 수 없다 — 게이트 아님.
        st0 = ocs.get("static")
        if rx is None and st0 is not None and st0.get("forces") and \
                info.get("_init_fixed") and \
                len(st0["forces"]) == len(info["_init_fixed"]):
            fr = [math.sqrt(sum(c * c for c in f))
                  for f, fx in zip(st0["forces"], info["_init_fixed"]) if not fx]
            if fr:
                rec["geom"]["uma_geometry_residual_force"] = {
                    "fmax_eVA": round(max(fr), 3),
                    "frms_eVA": round(math.sqrt(sum(x * x for x in fr) / len(fr)), 3),
                    "meaning": ("MLIP 기하의 DFT 잔류힘 — **진단값**. 수렴 판정도, "
                                "에너지 오차 상한도 아니다. 크면 그 자세만 DFT 이완 검토."),
                    "trigger_hint_eVA": FORCE_TOL}
        # ── 자기상태 감사 (Codex P0-E · 2026-08-12 재작성) ──
        st = ocs.get("static")
        want_sign = meta.get("ni_sign_poscar_idx") or {}
        mol_sign = meta.get("mol_sign_poscar_idx") or {}
        if st is not None and want_sign:
            mom = st.get("moments")
            nions = st.get("nions")
            # ★ 완결성부터 hard gate — 표가 짧으면 파싱된 것만 검사하고 나머지를
            #   조용히 버리던 구멍이 있었다 (Ni 1개만 남겨도 통과했다).
            if not mom:
                rec["gates"].append("MAGNETIC_UNVERIFIED(LORBIT 모멘트 표 없음)")
            elif nions and len(mom) != nions:
                rec["gates"].append(
                    f"MAGNETIC_INCOMPLETE(모멘트 {len(mom)}행 ≠ NIONS {nions})")
            elif max(int(k) for k in want_sign) >= len(mom):
                rec["gates"].append(
                    f"MAGNETIC_INCOMPLETE(Ni 인덱스가 모멘트 표 {len(mom)}행 밖)")
            else:
                ni = {int(k): float(v) for k, v in want_sign.items()}
                got = {i: mom[i] for i in ni}
                # ★ 전역 반전은 시간반전이라 **같은 상태**다 — 부호를 정규화해 비교하고,
                #   진짜 문제인 **부분 반전**을 잡는다 (옛 판은 정반대였다).
                sg, flip = global_sign(got, ni)
                small = [i for i, m in got.items() if abs(m) < MOM_MIN]
                rec["geom"]["magnetic"] = {
                    "n_ni": len(ni), "global_sign": sg, "n_partial_flip": len(flip),
                    # ⛔ 2026-08-25 (codex E-4) — 개수만 남기면 "항상 같은 자리 #82"
                    #   라는 관측을 **아무도 재검증할 수 없다**. 인덱스를 기계기록.
                    "flip_indices_poscar": sorted(flip), "index_base": 0,
                    "flip_indices_poscar_1based": [i + 1 for i in sorted(flip)],
                    "flip_moments_muB": {str(i): round(got[i], 3) for i in flip},
                    "n_small": len(small), "min_abs_muB": round(min(map(abs, got.values())), 3),
                    "abs_mean_muB": round(sum(map(abs, got.values())) / len(got), 3),
                    "total_muB": st.get("mag_total")}
                # ★ 회신 Z P0-4 — realized basin 지문. seed 이름으로 짝지으면 안 된다.
                _rb, _rbd = realized_basin_id(mom, want_sign, mol_sign,
                                             incar_echo=st.get("incar_echo"))
                rec["geom"]["magnetic"]["realized_basin_id"] = _rb
                rec["geom"]["magnetic"]["realized_basin"] = _rbd
                if _rb is None:
                    rec["gates"].append(
                        f"BASIN_UNRESOLVED({_rbd.get('why')}) — realized basin 을 "
                        f"만들 수 없어 이 잡으로는 뺄셈을 하지 않는다")
                if flip:
                    rec["gates"].append(
                        f"MAGNETIC_PARTIAL_FLIP({len(flip)}/{len(ni)} Ni 가 시드 topology 와 "
                        f"다르다 — 다른 자기 basin 이다)")
                # ★★ 라디칼 상대 스핀은 **항상** 본다 (Codex 재감사 P0-2).
                #   옛 판은 Ni 가 전역 반전(sg<0)일 때만 검사해서, Ni topology 는
                #   그대로인데 라디칼 하나만 뒤집힌 경우가 **게이트 없이 통과**했다.
                #   dense 에는 넣었는데 static 에는 안 넣어서 실질적으로 열려 있었다.
                ms = {int(k): float(v) for k, v in mol_sign.items() if int(k) < len(mom)}
                if ms:
                    # Ni 전역부호 sg 로 정규화한 뒤 라디칼의 **상대** 부호를 본다.
                    bad = [i for i, v in ms.items() if mom[i] * sg * v <= 0]
                    small = [i for i in ms if abs(mom[i]) < MOM_MIN]
                    rec["geom"]["magnetic"]["radical"] = {
                        "n": len(ms), "sign_mismatch": len(bad), "collapsed": len(small),
                        "ni_global_sign": sg, "total_muB": st.get("mag_total")}
                    if bad or small:
                        rec["gates"].append(
                            f"RADICAL_BRANCH_CHANGED(부호 불일치 {len(bad)} · 소실 "
                            f"{len(small)}/{len(ms)} — Ni 부호를 정규화한 뒤에도 라디칼 "
                            f"상대 스핀이 시드와 다르다. 다른 스핀 basin 이다)")
                    elif sg < 0:
                        rec["geom"]["magnetic"]["note"] = (
                            "Ni·라디칼이 **함께** 전역 반전 — 시간반전이라 같은 상태")
                # ── LDAU occupation + total M 기록 (Codex P0-2 ③) ──
                #   판정용이 아니라 **기록용**이다 — 절대값은 PAW sphere 규약 의존.
                ld = st.get("ldau")
                if ld:
                    ups = sorted(ld.items())
                    mm = [round(v[0] - v[1], 3) for _k, v in ups]
                    rec["geom"]["magnetic"]["ldau"] = {
                        "n_atoms": len(ld),
                        "mean_n_up_dn": [round(sum(v[0] for _k, v in ups) / len(ups), 3),
                                         round(sum(v[1] for _k, v in ups) / len(ups), 3)],
                        "moment_from_occ_mean_abs": round(
                            sum(abs(x) for x in mm) / len(mm), 3),
                        "fingerprint": hashlib.sha256(
                            json.dumps(ups, sort_keys=True).encode()).hexdigest()[:12]}
                else:
                    rec["geom"]["magnetic"]["ldau"] = None
                    results_ldau_missing.append(rel)

                # ── dense 자기감사 — static 과 **같은 수준**으로 (Codex 7차 §8) ──
                #   ⚠ 옛 판은 dense 에 모멘트 표가 없으면 그냥 서명에서 빠졌다. 그러면
                #     local moment 가 없는 dense OUTCAR 도 E0 만으로 κ 에 들어간다.
                #     dense 는 **에너지를 내는 상**이므로 static 과 같은 문턱을 건다.
                dn = ocs.get("dense")
                if dn is not None:
                    dm = dn.get("moments")
                    if not dm:
                        rec["gates"].append(
                            "DENSE_MOMENTS_MISSING(dense OUTCAR 에 모멘트 표가 없다 — "
                            "자기상태를 모르고 κ 에 쓸 수 없다)")
                    elif dn.get("nions") and len(dm) != dn["nions"]:
                        rec["gates"].append(
                            f"DENSE_MOMENT_COUNT({len(dm)} != NIONS {dn['nions']})")
                    elif max(ni) >= len(dm):
                        rec["gates"].append(
                            f"DENSE_MOMENT_SHORT(Ni 인덱스 {max(ni)} 가 표 밖 — "
                            f"표 길이 {len(dm)})")
                    else:
                        miss = [i for i in ni if i >= len(dm)]
                        # ★★ dense 는 **자기 전역부호를 스스로** 구한다 (Codex 5차 P1-2).
                        #   옛 판은 static 의 sg 를 재사용해서, dense 가 완전한 시간반전
                        #   상태(Ni·라디칼·총 M 이 **함께** 뒤집힘)로 수렴하면 물리적으로
                        #   같은 상태인데도 전부 부호 불일치로 잡아 거짓 차단했다.
                        #   바로 아래 phase_sign_sig 는 전역반전을 같은 상태로 인정하는데
                        #   여기만 규칙이 달랐다 — 한 기능이 두 규칙을 쓰고 있었다.
                        sg_d, _dflip = global_sign({i: dm[i] for i in ni}, ni)
                        dq = sum(sg_d * ni[i] * dm[i] for i in ni) / len(ni)
                        dsmall = [i for i in ni if abs(dm[i]) < MOM_MIN]
                        rec["geom"]["magnetic"]["dense"] = {
                            "n_ni_found": len(ni) - len(miss),
                            "global_sign": sg_d,
                            "global_flip_vs_static": (sg_d != sg),
                            "Q_muB": round(dq, 3),
                            "f_small": round(len(dsmall) / len(ni), 3),
                            "total_muB": dn.get("mag_total")}
                        # ★ open-shell 조각(doped)의 **라디칼 상대 스핀**을 dense 에서도
                        #   본다 (Codex zip 감사 P0-5). Ni topology 는 그대로인데
                        #   라디칼만 뒤집히거나 사라지면 다른 스핀 상태를 재는 것이다.
                        if mol_sign:
                            _ms = {int(k2): float(v2) for k2, v2 in mol_sign.items()
                                   if int(k2) < len(dm)}
                            # dense 자기 부호로 정규화한 뒤 **상대** 스핀을 본다
                            _bad = [i for i, v2 in _ms.items() if dm[i] * sg_d * v2 <= 0]
                            _gone = [i for i in _ms if abs(dm[i]) < MOM_MIN]
                            rec["geom"]["magnetic"]["dense"]["radical"] = {
                                "n": len(_ms), "sign_mismatch": len(_bad),
                                "collapsed": len(_gone),
                                "total_muB": dn.get("mag_total")}
                            if _bad or _gone:
                                rec["gates"].append(
                                    f"DENSE_RADICAL_BRANCH_CHANGED(부호 불일치 {len(_bad)} · "
                                    f"소실 {len(_gone)}/{len(_ms)} — Ni 는 유지됐지만 "
                                    f"라디칼 상대 스핀이 달라졌다. κ 에 쓸 수 없다)")
                            # ⚠ 총 M 도 **절대값**으로 본다 — 전역 시간반전이면 부호가
                            #   같이 뒤집히는 게 정상이다.
                            _tm, _td = st.get("mag_total"), dn.get("mag_total")
                            if _tm is not None and _td is not None and \
                                    abs(abs(_tm) - abs(_td)) > 0.5:
                                rec["gates"].append(
                                    f"DENSE_TOTAL_M_CHANGED({_tm:+.2f} → {_td:+.2f} μB — "
                                    f"static↔dense 자기 branch 가 넘어갔다)")
                        qs = rec["geom"]["magnetic"].get("Q_muB")
                        if qs is not None and abs(qs) > 1e-9:
                            rat = dq / qs
                            rec["geom"]["magnetic"]["dense"]["Q_ratio_vs_static"] = round(rat, 3)
                            if rat < Q_RATIO_MIN:
                                rec["gates"].append(
                                    f"DENSE_MAGNETIC_COLLAPSE(Q_dense/Q_static={rat:.2f} — "
                                    f"k 를 촘촘히 했더니 자기상태가 무너졌다. κ 는 k 효과가 "
                                    f"아니라 spin-state 차를 재게 된다)")

                # ── 상별 자기 branch — k 를 바꾸며 상태가 넘어가면 'k 오차'가 아니다 ──
                sig = {}
                for ph2 in phases:
                    o2 = ocs.get(ph2)
                    if not o2 or not o2.get("moments"):
                        continue
                    mo = o2["moments"]
                    if max(ni) < len(mo):
                        sig[ph2] = "".join("+" if mo[i] > 0 else "-" for i in sorted(ni))
                rec["geom"]["magnetic"]["phase_sign_sig"] = {
                    k2: hashlib.sha256(v.encode()).hexdigest()[:8] for k2, v in sig.items()}
                uniq = {v for v in sig.values()}
                # 전역 반전끼리는 같은 상태다 — 반전본도 같이 넣어 비교한다
                if len(uniq) > 1:
                    base = sorted(sig)[0]
                    flip = sig[base].translate(str.maketrans("+-", "-+"))
                    if not all(v in (sig[base], flip) for v in sig.values()):
                        rec["gates"].append(
                            f"MAGNETIC_BRANCH_CHANGED(상별 Ni 부호 topology 가 다르다 "
                            f"{ {k2: v[:8] for k2, v in sig.items()} } — k 오차가 아니라 "
                            f"spin-state 차이를 재게 된다)")

                # ⚠ MOM_MIN 단독 문턱은 보편적이지 않다 (Codex Q7). LORBIT local moment 는
                #   PAW sphere/projector 의존 정성 지표라 표면 Ni 가 물리적으로 0.3 아래로
                #   갈 수 있다. 집단 지표 Q(부호 정규화 평균)와 f_small 을 clean 기준으로
                #   보정해 판정한다 — 절대 판정은 main() 에서 clean 분포를 알고 내린다.
                Q = sum(sg * ni[i] * got[i] for i in ni) / len(ni)
                rec["geom"]["magnetic"]["Q_muB"] = round(Q, 3)
                rec["geom"]["magnetic"]["f_small"] = round(len(small) / len(ni), 3)
                if small:
                    rec["geom"]["magnetic"]["review"] = (
                        f"{len(small)}개가 |m|<{MOM_MIN} — clean 분포와 대조 (아래 집단 판정)")
        rec["ok"] = not rec["gates"]
        jobs[rel] = rec

    # ── 자기 붕괴는 **clean seed 분포 기준**으로 판정한다 (Codex Q7) ──────────
    #   숫자(0.5·0.25)는 초기 민감도일 뿐이다. clean 두 seed 의 Q 를 기준으로 보고,
    #   기준이 없으면 판정을 보류한다(임의 문턱으로 죽이지 않는다).
    #   ★ 2026-08-12 (Codex 6차) 세 가지를 고친다:
    #     (a) `... .get("Q_muB")` 진리값 검사 → **Q=0 인 clean 을 결측으로 버린다**.
    #         Q=0 은 "완전 붕괴한 기준" 이라는 중요한 사실이다. is not None 으로 본다.
    #     (b) 두 seed 중 max 하나를 모든 pose 에 공통 적용 → seed 별 branch 차이가 섞인다.
    #         **같은 seed 의 clean** 과 비교한다.
    #     (c) clean 자체가 무자격(게이트 걸림·Q 결측)이면 조용히 통과시키지 말고
    #         MAGNETIC_REFERENCE_INVALID 로 남긴다.
    # ── rescue supersedes (wave1.5 · codex E-2차 필수1) ───────────────────────
    #   job.json 에 rescue.supersedes = "refs/clean_slab__<seed>" 가 있고 그 잡이
    #   **모든 게이트를 통과**하면, 그 seed 의 clean 참조를 rescue 잡으로 바꾼다.
    #   실패하면 원본 유지 + reference_overrides 에 거부 사유를 남긴다 (조용한 무시 금지).
    ref_alias: Dict[str, str] = {}
    ref_overrides: Dict[str, Any] = {}
    for j, r in jobs.items():
        sup = ((r.get("meta") or {}).get("rescue") or {}).get("supersedes")
        if not sup:
            continue
        _pok, _pwhy = rescue_provenance_ok(os.path.join(root, j))
        if r.get("ok") and _pok:
            ref_alias[sup] = j
            ref_overrides[sup] = {"used": j, "status": "superseded",
                                  "why": "rescue 잡이 전 게이트 + provenance 통과"}
        else:
            _reasons = [] if r.get("ok") else list((r.get("gates") or [])[:3])
            if not _pok:
                _reasons.append(f"provenance: {_pwhy}")
            ref_overrides[sup] = {"used": sup, "status": "rescue_rejected",
                                  "rejected_job": j, "why": "; ".join(_reasons)}
    # (results dict 는 아래에서 만들어진다 — 거기서 reference_overrides 로 실림)

    q_by_seed: Dict[str, Optional[float]] = {}
    ref_bad: Dict[str, str] = {}
    for sd in (man.get("seeds_full") or ["afm2424_pm1", "afm2424_net4"]):
        _canon = f"refs/clean_slab__{sd}"
        if _canon in ref_alias:
            cj = [(ref_alias[_canon], jobs[ref_alias[_canon]])]
        else:
            cj = [(j, r) for j, r in jobs.items()
                  if "clean_slab" in j and j.endswith(sd)]
        if not cj:
            ref_bad[sd] = "clean 대조군 없음"
            continue
        j, r = cj[0]
        q = ((r.get("geom") or {}).get("magnetic") or {}).get("Q_muB")
        if q is None:
            ref_bad[sd] = f"{j}: Ni moment 미완 — Q 없음"
        elif r.get("gates"):
            ref_bad[sd] = f"{j}: 기준 자체가 게이트 걸림 ({r['gates'][0][:40]})"
        else:
            q_by_seed[sd] = float(q)
    for j, r in jobs.items():
        mg = (r.get("geom") or {}).get("magnetic")
        if not mg or "Q_muB" not in mg:
            continue
        sd = r["meta"].get("seed")
        q_ref = q_by_seed.get(sd)
        mg["Q_clean_ref"] = q_ref
        mg["Q_clean_ref_seed"] = sd
        if q_ref is None:
            # ⛔⛔ 회신 AR P0-1 (2026-08-31) — **clean-free 설계에서는 이 게이트가
            #   전 complex 를 막는다.** C-12 는 clean slab 을 일부러 계산하지 않는다
            #   (D 에서 대수적으로 소거되므로). 그런데 여기서 clean Q 기준이 없다고
            #   모든 magnetic complex 를 MAGNETIC_REFERENCE_INVALID 로 막아,
            #   exact pm1/net4 가 전부 게이트돼 **primary D 가 아예 안 나왔다.**
            #   ⇒ clean 을 **선언조차 하지 않은** 판(clean-free)에서는 이 게이트를
            #     적용하지 않는다. 그 역할은 `_estimand_topology_check` 의
            #     **직접 topology 비교**가 대신한다 (회신 AP #2 로 이미 넣었다).
            #   ⚠ clean 을 선언해 놓고 결과가 없는 것은 여전히 차단이다 — 그건
            #     "계산했어야 하는데 안 온 것" 이고 clean-free 와 다르다.
            _clean_declared = bool(((man.get("refs") or {}).get("clean_slab") or [])
                                   or (man.get("magnetic_controls") or []))
            mg["verdict"] = ("clean-free 설계 — 이 판정은 직접 topology 비교가 대신한다"
                             if not _clean_declared else
                             "clean 기준 없음/무효 — 자기 붕괴 판정 보류")
            mg["clean_free"] = not _clean_declared
            if "clean_slab" not in j and _clean_declared:
                r["gates"].append(
                    f"MAGNETIC_REFERENCE_INVALID({sd}: "
                    f"{ref_bad.get(sd, '기준 없음')} — 자기 붕괴를 판정할 수 없다)")
                r["ok"] = not r["gates"]
            continue
        ratio = (mg["Q_muB"] / q_ref) if abs(q_ref) > 1e-9 else None
        mg["Q_ratio"] = None if ratio is None else round(ratio, 3)
        if ratio is None:
            # ⛔ 완전히 붕괴한 clean 은 **유효한 기준이 아니다** (Codex 7차 §9).
            #   "판정 보류" 로 pose 를 통과시키면 fail-open 이다.
            mg["verdict"] = "⛔ clean 기준 Q≈0 — 기준 자체가 무효"
            if "clean_slab" not in j:
                r["gates"].append(
                    f"MAGNETIC_REFERENCE_INVALID({sd}: clean Q≈0 — 기준이 붕괴했다. "
                    f"이 seed 의 headline 에서 제외)")
                r["ok"] = not r["gates"]
            continue
        if ratio < Q_RATIO_MIN or mg["f_small"] > F_SMALL_MAX:
            r["gates"].append(
                f"MAGNETIC_COLLAPSE(Q/Q_clean[{sd}]={ratio:.2f} · "
                f"f_small={mg['f_small']:.2f} — 같은 seed clean 대비 집단 붕괴)")
            r["ok"] = not r["gates"]

    # ── POTCAR 변형: 준중심 차이는 일관돼도 치명 (Codex P0-C) ────────────────
    subs, mixed = {}, False
    for r in jobs.values():
        st = r.get("static") or {}
        expect = [spec.get(e, e) for e in r["meta"].get("species_order", [])]
        got = [x.split()[1] if len(x.split()) > 1 else x for x in st.get("titels") or []]
        if expect and got and len(expect) == len(got):
            for e, g in zip(expect, got):
                if e != g:
                    if e in subs and subs[e] != g:
                        mixed = True
                    subs[e] = g
    potcar_warn = None
    # ⛔ 2026-08-12 — "일관되게 다르면 경고" 를 폐기한다. 고정 protocol 에서는
    #   Ni_pv → Ni_sv 도 다른 가전자·projector 라 다른 Hamiltonian 이다. 한 글자라도
    #   다르면 headline 에서 제외한다 (감도로 쓰려면 별도 protocol ID 로 분리).
    if subs:
        txt = ", ".join(f"{e}→{g}" for e, g in sorted(subs.items()))
        for r in jobs.values():
            r["gates"].append(f"POTCAR_WRONG({txt}{' · 혼재' if mixed else ''})")
            r["ok"] = False

    def E(job):
        job = ref_alias.get(job, job)          # supersedes 반영 (wave1.5)
        r = jobs.get(job)
        return r["static"]["E0"] if r and r["ok"] and r["static"] and \
            r["static"]["E0"] is not None else None

    def E_dense(job):
        """dense 도 static 과 **같은 기준**으로 건다 (옛 판은 에너지만 읽었다)."""
        r = jobs.get(job)
        if not r or not r["ok"]:
            return None
        oc = r.get("dense")
        if oc is None or not oc["normal_end"] or oc["nelm_hit"] or oc["E0"] is None:
            return None
        return oc["E0"]

    # ── --plan_dense : 조건부 dense 선택 (Codex 6차 §3) ──────────────────────
    #   왜 분석기 안인가: OUTCAR 회수·자기 게이트·유효성 판정을 **그대로 재사용**한다.
    #   별도 스크립트로 빼면 그 로직이 두 벌이 되고, 갈라지면 아무도 모른다.
    if "--plan_dense" in sys.argv:
        return plan_dense(root, man, jobs, E, E_dense)

    results = {"delta_eV": delta, "pairs": {}, "fragments": {}, "e_ads": {},
               "reference_overrides": ref_overrides,
               "numerical_gates": {}, "warnings": [], "integrity": integrity,
               # incar_audit (codex E-2) — 게이트 통과가 **무엇까지 보증하는지**의
               #   기계 기록: verified_exact / verified_equivalence_class /
               #   unverified / mismatch + 실행 세그먼트 정보. 사람용 요약(README)과
               #   어긋나면 이쪽이 정본이다.
               "jobs": {j: {"ok": r["ok"], "gates": r["gates"],
                            "E0_static": (r["static"] or {}).get("E0"),
                            "vasp_version": (r["static"] or {}).get("vasp_version"),
                            "incar_audit": {ph: (r.get(ph) or {}).get("incar_audit")
                                            for ph in (r["meta"].get("phases")
                                                       or ["static", "dense"])
                                            if (r.get(ph) or {}).get("incar_audit")},
                            "run_segments": {ph: (r.get(ph) or {}).get("run_segments")
                                             for ph in (r["meta"].get("phases")
                                                        or ["static", "dense"])
                                             if (r.get(ph) or {}).get("run_segments")},
                            "geom": r.get("geom")} for j, r in jobs.items()}}
    if potcar_warn:
        results["warnings"].append(potcar_warn)
    if results_ldau_missing:
        results["warnings"].append(
            f"LDAU occupation matrix 가 없는 잡 {len(results_ldau_missing)}개 "
            f"(LDAUPRINT=2 인데 OUTCAR 에 onsite density matrix 없음) — "
            f"자기상태를 모멘트 하나로만 보게 된다: "
            + ", ".join(results_ldau_missing[:4]))
    if integrity.get("geometry_unverified"):
        results["warnings"].append(
            f"⚠ 실행 기하를 검증 못 한 상 {len(integrity['geometry_unverified'])}개 — "
            f"phase POSCAR 도 OUTCAR 좌표도 없다: "
            + ", ".join(integrity["geometry_unverified"][:5]))
    if integrity.get("runtime_poscar_mismatch"):
        results["warnings"].append(
            f"⛔ 실행시 POSCAR 가 루트와 다른 상 "
            f"{len(integrity['runtime_poscar_mismatch'])}개 — **다른 기하를 계산했다** "
            f"(단일점 주장 무효): "
            + ", ".join(integrity["runtime_poscar_mismatch"][:6]))
    if integrity["changed"]:
        results["warnings"].append(
            f"⛔ 번들 입력 {len(integrity['changed'])}개가 바뀌었다 (INCAR/POSCAR 변조?): "
            + ", ".join(integrity["changed"][:8]))

    # ── 기체상 — 상자 게이트. **정본은 큰 상자(box24)** ──────────────────────
    #   ⚠ Wave 1(기준계 미포함)은 기준계가 **의도적으로** 없다 — 실패가 아니다.
    #     그걸 "상자 게이트 실패" 로 찍으면 정상 실행을 고장으로 읽게 된다.
    emol, mol_ok = {}, {}
    # ⛔ 2026-08-31 (회신 AN P0-2) — C-12 는 clean slab 없이 **기체 기준만** 있다.
    #   clean 유무로 has_refs 를 정하면 그 구성이 "기준계 없음(Wave 1)" 으로 오독된다.
    _refs = man.get("refs", {}) or {}
    _has_mol = any(k.startswith("mol__") for k in _refs)
    has_refs = bool(_refs.get("clean_slab")) or _has_mol
    if not has_refs:
        results["e_ads_status"] = ("NOT_APPLICABLE — Wave 1 은 기준계를 안 돌린다. "
                                  "자리 대비 ΔE 는 기준계 없이 성립하지만 절대 E_ads 는 "
                                  "만들 수 없다 (MANIFEST.claim_scope 참조).")
        results["warnings"].append(
            "Wave 1: clean/gas 기준계 없음 — **의도된 범위**다. ΔE 만 인용하고 "
            "흡착 열역학·조각 간 결합 세기·E_ads 절대값은 주장하지 말 것")
    for f in (man.get("fragments", []) if has_refs else []):
        # ⚠ job key 는 _pk() 로 POSIX 정규화돼 있다. 여기서 os.path.join 을 쓰면
        #   Windows 에서 `refs\mol__...` 가 되어 **한 건도 안 맞는다** — 그런데
        #   gas job 자체는 ok 라 required_missing 이 비고 exit 0 이 났다.
        #   "계산 완료, E_ads 만 없음" 으로 조용히 끝나는 최악의 모양이었다.
        e20 = E(f"refs/mol__{f}__box20")
        e24 = E(f"refs/mol__{f}__box24")
        # ⛔⛔ 2026-08-31 (회신 AN P0-2·P1) — `--refs_minimal` 은 box20 을 **일부러** 뺀다.
        #   초판은 "상자 2종 중 하나가 없다 → E_ads 불가" 로 막아, 그 구성에서 분석이
        #   아예 안 됐다. 그렇다고 조용히 통과시키면 안 된다 — 최종 D 에는
        #   `E_G^SDCP − E_G^PTFE` 가 남아 **기체 상자 오차가 소거되지 않기** 때문이다.
        #   ⇒ box20 이 없으면 manifest 의 **선행 근거**(`gas_box_prior`)를 요구한다.
        #     그것도 없으면 막는다. 있으면 그 값을 게이트에 그대로 싣고 출처를 남긴다.
        _prior = ((man.get("gas_box_prior") or {}).get(f) or {}) if e20 is None else {}
        if e20 is None and e24 is not None and _prior.get("dE_meV") is not None:
            # ⛔⛔ 회신 AO P0-6 (2026-08-31) — 두 가지가 틀렸다.
            #   ① `ok = d0 <= BOX_TOL` 이 **부호 있는** 값을 비교해 큰 음수도 통과했다.
            #   ② 더 근본적으로, 이 prior 는 **이번 conformer·이번 Hamiltonian 과의
            #      정합을 확인하지 못했다** (manifest 가 스스로 인정한다). 확인 못 한
            #      근거로 게이트를 통과시키는 것은 검증이 아니다.
            #   ⇒ prior 는 **비차단 참고정보**로 내린다. 통과/실패를 만들지 않는다.
            #     대신 "이 묶음에서 상자 수렴을 검증하지 않았다" 를 라벨로 남긴다.
            d0 = abs(float(_prior["dE_meV"])) / 1000.0        # ① 절대값
            results["numerical_gates"][f"box_{f}"] = {
                "dE_meV": round(d0 * 1000, 2),
                "pass": None,                                  # ② 판정하지 않는다
                "source": "prior_informational_only",
                "prior_ref": _prior.get("ref"),
                "verified_in_this_bundle": False,
                "⚠": ("이번 묶음에 box20 이 없다. 선행 대조를 **참고로만** 싣는다 — "
                      "좌표·state policy·POTCAR fingerprint 정합을 확인하지 못했으므로 "
                      "게이트로 쓰지 않는다 (회신 AO P0-6)")}
            results["warnings"].append(
                f"mol__{f}: 기체 상자 수렴을 **이 묶음에서 검증하지 않았다** — "
                f"선행값 {d0*1000:.2f} meV 는 참고정보다. D 서술에 "
                f"'기체 상자 수렴 확인' 을 쓰지 말 것")
            mol_ok[f] = None
            emol[f] = e24
            continue
        # ⛔⛔ 회신 AR P0-3 / Q2 (2026-08-31) — **옛 조각별 10 meV 게이트를 없앤다.**
        #   판정은 `δ_gas`(두 기체의 **차**) 하나로 한다. 조각별 게이트가 남아 있으면
        #   두 가지가 깨진다:
        #     ① SDCP/PTFE 가 +20/+19 meV 면 δ_gas = 1 meV 로 통과해야 하는데
        #        조각별 게이트가 두 `emol` 을 **None 으로 만들고**, 그 뒤 A(f,p)
        #        계산에서 `float − None` 으로 **예외로 죽는다** (리뷰가 재현).
        #     ② box20 누락도 GAS_BOX_NOT_MEASURED 가 아니라 예외로 끝난다.
        #   ⇒ `emol` 은 box24 를 그대로 쓰고(정본), 진단만 기록한다.
        #     결측·불일치는 `_blk(...)` 로 **구조화된 hard block** 이 된다 (아래 δ_gas).
        mol_ok[f] = True
        emol[f] = e24
        if e24 is None:
            emol[f] = None
            results["numerical_gates"][f"box_{f}"] = {
                "dE_meV": None, "pass": False,
                "why": "box24(정본)가 없다 — 이 조각의 기체 기준이 없다"}
            results["warnings"].append(f"mol__{f}: box24 없음 — 기체 기준 부재")
        else:
            _d = (abs(e20 - e24) if e20 is not None else None)
            results["numerical_gates"][f"box_{f}"] = {
                "dE_meV": (None if _d is None else round(_d * 1000, 1)),
                "pass": None,                         # ⛔ 판정하지 않는다 — 진단이다
                "role": "diagnostic_only",
                "why": ("판정은 δ_gas(두 기체의 차) 하나로 한다 (회신 AR P0-3). "
                        "조각별 값은 진단으로만 남긴다")}

    eclean = {s: E(f"refs/clean_slab__{s}")
              for s in man.get("seeds_full", ["afm2424_pm1", "afm2424_net4"])}
    eclean_dense = E_dense("refs/clean_slab__afm2424_pm1")

    for pid, pm in man.get("pairs", {}).items():
        frag = pm["fragment"]
        rec = {"fragment": frag, "dir": pm["dir"], "roll": pm["roll"],
               "uma_dE": pm.get("uma_dE"), "dE_by_seed": {}, "gates": []}
        for s in pm.get("seeds", ["afm2424_pm1"]):
            eli, eni = E(f"{pm['li_prefix']}__{s}"), E(f"{pm['ni_prefix']}__{s}")
            if eli is not None and eni is not None:
                rec["dE_by_seed"][s] = round(eni - eli, 4)
        # ── PAIR_COLLAPSED — 주기 RMSD + 접촉 지문 (Codex P0 Q5 반박 수용) ──
        s0 = pm.get("seeds", ["afm2424_pm1"])[0]
        jli, jni = jobs.get(f"{pm['li_prefix']}__{s0}"), jobs.get(f"{pm['ni_prefix']}__{s0}")
        rli = (jli or {}).get("geom", {}).get("registry")
        rni = (jni or {}).get("geom", {}).get("registry")
        if jli and jni and jli.get("_fin") and jni.get("_fin"):
            mol = jli["meta"].get("mol_poscar_idx") or []
            a, b = jli["_fin"], jni["_fin"]
            if mol and len(a["pos"]) == len(b["pos"]):
                rms = math.sqrt(sum(mic_dist(a["pos"][i], b["pos"][i], a["cell"]) ** 2
                                    for i in mol) / len(mol))
                # ⚠ 최근접 **원소명**은 판정에 넣지 않는다 — 같으면 한쪽은 이미
                #   PAIR_MIGRATED 라 완전 중복이다(Codex Q5). 접촉 지문은 원자 인덱스라
                #   "같은 자리인가" 를 직접 답한다. 경계 원자 하나로 뒤집히지 않도록
                #   완전일치 대신 Jaccard 를 쓴다.
                fa = set(jli.get("_contact_fp") or [])
                fb = set(jni.get("_contact_fp") or [])
                if not fa and not fb:
                    # ⚠ 양쪽 다 접촉이 없으면 지문은 **정보가 없다**. CONTACT_A 3.0 과
                    #   DETACH_A 4.0 사이에 미판정 shell 이 있으므로 "떠 있지 않다" 가
                    #   "지문이 검증됐다" 를 뜻하지 않는다 (Codex Q3). RMSD 는 진단으로만
                    #   남기고 이 쌍은 최종 분류에서 뺀다.
                    jac, fp_ok, why = None, False, "접촉 지문 없음 — 미검증"
                    rec["gates"].append(
                        f"BASIN_UNVERIFIED_EMPTY_CONTACT_FP(분자 RMSD {rms:.2f} Å 는 "
                        f"진단값 — 3.0~4.0 Å 미판정 shell)")
                else:
                    jac = len(fa & fb) / len(fa | fb)
                    fp_ok = jac >= FP_JACCARD
                    why = f"접촉 지문 Jaccard {jac:.2f} ≥ {FP_JACCARD}"
                rec["basin"] = {"mol_rmsd_A": round(rms, 3),
                                "contact_jaccard": None if jac is None else round(jac, 3),
                                "same_nearest_element": bool(
                                    rli and rni and rli["nearest"] == rni["nearest"]),
                                "sensitivity": {str(t): rms <= t
                                                for t in (0.50, 0.75, 1.00)}}
                if rms <= RMSD_TOL and fp_ok:
                    sp_pair = bool((jli.get("geom") or {}).get("single_point"))
                    rec["gates"].append(
                        ("SOURCE_PAIR_COLLAPSED" if sp_pair else "PAIR_COLLAPSED")
                        + f"(분자 RMSD {rms:.2f} Å ≤ {RMSD_TOL} · {why})")
        # ★★ 추정량 이름 (Codex 7차 §1) — 자세키 p=(down_dir, roll) 에 대해
        #   ΔE_match(p) = E_Ni(p) − E_Li(p)          ← 배향 혼입 없는 자리 대비
        #   D_pool      = E_Ni(p_N*) − E_Li(p_L*)    ← 짝 풀 챔피언 **대각선** 대비
        #   p_L* == p_N* 이면 둘이 같지만, 다르면 D_pool 에 자리와 자세가 섞인다.
        #   그러므로 de_main 을 무조건 "matched" 라 부르면 안 된다.
        de_main = rec["dE_by_seed"].get("afm2424_pm1")
        _pose_matched = pm.get("matched") is True
        rec["estimand"] = ("dE_match(p*)  — 같은 자세키에서 잰 자리 대비 (배향 혼입 없음)"
                           if _pose_matched else
                           "D_pool  — 짝 풀 챔피언 **대각선** 대비 (자리+자세 혼합). "
                           "matched 라 부르지 말 것")
        rec["pose_matched"] = _pose_matched
        de_alt = rec["dE_by_seed"].get("afm2424_net4")
        # ★ ΔE 만 비교하면, 두 pose 가 같은 방향으로 함께 움직이고 clean 은 안 움직인
        #   경우 ΔE 는 그대로인데 E_ads 만 달라진다 (Codex P0-2).
        ea_seed = {}
        for sd in pm.get("seeds", []):
            ec_s, em_s = eclean.get(sd), emol.get(frag)
            eli_s = E(f"{pm['li_prefix']}__{sd}")
            if ec_s is not None and em_s is not None and eli_s is not None:
                ea_seed[sd] = eli_s - ec_s - em_s
        if len(ea_seed) > 1:
            spread = max(ea_seed.values()) - min(ea_seed.values())
            rec["eads_seed_spread_meV"] = round(spread * 1000, 1)
            if spread > SEED_TOL:
                rec["gates"].append(
                    f"BLOCKED_MAGNETIC_SENSITIVITY(E_ads seed 산포 {spread * 1000:.0f} meV > 10)")
        # ★ 두 seed 끝점 에너지가 20 meV 안에서 경합하면 **어느 branch 가 바닥인지
        #   k 보정(±10)으로 뒤집힐 수 있다**. adaptive dense 가 꺼져 있으면 확인할
        #   방법이 없으므로 그 사실을 판정에 남긴다 (Codex 3차 감사).
        #   MANIFEST 는 이 규약을 적어 놓고 정작 --plan_dense 에서만 계산하고 있었다.
        for _role, _pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
            _e = {s: E(f"{_pre}__{s}") for s in pm.get("seeds", [])}
            _v = [x for x in _e.values() if x is not None]
            if len(_v) > 1 and abs(_v[0] - _v[1]) <= BRANCH_TIE_EV:
                rec.setdefault("branch_tie", {})[_role] = {
                    "gap_meV": round(abs(_v[0] - _v[1]) * 1000, 1),
                    "note": (f"두 seed 가 {BRANCH_TIE_EV*1000:.0f} meV 안에서 경합 — "
                             f"k 보정 ±{GUARD_EV*1000:.0f} 으로 순서가 뒤집힐 수 있다")}
                # ⚠ **게이트로 막지 않는다.** 우리 headline 은 branch-minimum 이 아니라
                #   같은 seed(pm1) 대비다 — 어느 branch 가 바닥인지 주장하지 않으므로
                #   경합 자체는 결함이 아니다. 실제 보호막은 seed 산포 게이트(≤10 meV)다.
                #   (Codex 3차 감사가 준 두 선택지 중 'pm1 조건부로 명시' 쪽.)
                rec["branch_tie"][_role]["claim"] = (
                    "MAGNETIC_K_UNRESOLVED_for_branch_minimum — 이 값은 "
                    "**pm1 branch 조건부**다. '자기 바닥상태에서의' 로 서술 금지")
        if de_main is not None and de_alt is not None \
                and abs(de_main - de_alt) > SEED_TOL:
            rec["gates"].append(
                f"BLOCKED_MAGNETIC_SENSITIVITY(|ΔE_pm1−ΔE_net4|="
                f"{abs(de_main - de_alt) * 1000:.0f} meV > 10)")
        elif de_main is not None and de_alt is None and len(pm.get("seeds", [])) > 1:
            rec["gates"].append("SEED_INCOMPLETE(두 seed 중 하나가 게이트/미완)")

        # ── dense-k 게이트 — **판정에 실제로 연결** (Codex P0-D) ──
        dli, dni = E_dense(f"{pm['li_prefix']}__afm2424_pm1"), \
            E_dense(f"{pm['ni_prefix']}__afm2424_pm1")
        planned_dense = any("dense" in (planned.get(f"{pm[k]}__afm2424_pm1") or {})
                            .get("phases", []) for k in ("li_prefix", "ni_prefix"))
        if planned_dense:
            if dli is None or dni is None or de_main is None:
                rec["gates"].append("NUMERICALLY_UNRESOLVED(dense 계획인데 회수 실패)")
            else:
                # ★ κ 는 **부호 있는** 양이다 (Codex 5차 taxonomy · 6차 §6).
                #   전이 게이트는 크기뿐 아니라 **보정자끼리 같은 방향인지**를 본다 —
                #   절대값만 보면 +9 와 −9 를 "둘 다 통과" 로 읽어 18 meV 를 놓친다.
                kap = (dni - dli) - de_main
                rec["kappa_eV"] = round(kap, 4)
                results.setdefault("kappa", {})
                prev = results["kappa"].get(frag)
                if prev is None or abs(kap) > abs(prev):
                    results["kappa"][frag] = round(kap, 4)   # 조각당 최악값
                dk = abs(kap)
                ok_k = dk <= K_TOL
                gate = {"dE_meV": round(dk * 1000, 1), "kappa_meV": round(kap * 1000, 1),
                        "pass": ok_k}
                # E_ads 자체의 k 수렴도 본다 (ΔE 만 보면 상쇄로 숨는다)
                if eclean_dense is not None and emol.get(frag) is not None:
                    worst = 0.0
                    for tag, pre, ed in (("Li", pm["li_prefix"], dli),
                                         ("Ni", pm["ni_prefix"], dni)):
                        es = E(f"{pre}__afm2424_pm1")
                        if es is None:
                            continue
                        d = abs((ed - eclean_dense - emol[frag])
                                - (es - eclean.get("afm2424_pm1", 0.0) - emol[frag]))
                        gate[f"dEads_{tag}_meV"] = round(d * 1000, 1)
                        worst = max(worst, d)
                    gate["dEads_meV"] = round(worst * 1000, 1)
                    ok_k = ok_k and worst <= K_TOL
                    gate["pass"] = ok_k
                results["numerical_gates"][f"k_{pid}"] = gate
                if not ok_k:
                    rec["gates"].append(f"NUMERICALLY_UNRESOLVED(dense-k {gate})")

        # ── 전역 자리 선호 vs 배향일치 대비 (2026-08-12) ────────────────────
        #   ΔE(matched) = 같은 배향에서 Li 위 vs Ni 위  — 배향 혼입 없음
        #   ΔE(global)  = 각자 최선을 다했을 때        — 문헌의 "site preference"
        #   둘의 차가 **배향 항**이다. 부호가 다르면 어느 질문인지 반드시 밝혀야 한다.
        gb = pm.get("global_best") or {}
        if gb:
            # ★ 두 seed 전부 읽는다 (Codex 7차 §5). 본 ΔE 는 seed 산포 게이트를 통과해야
            #   하는데 global 만 단일시드면 부호가 자기 branch 잡음일 수 있다.
            dg_seed = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                e2 = {}
                for role, pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
                    p2 = gb[role]["prefix"] if role in gb else pre
                    e2[role] = E(f"{p2}__{sd}")
                if e2["Li"] is not None and e2["Ni"] is not None:
                    dg_seed[sd] = round(e2["Ni"] - e2["Li"], 4)
            rec["dE_global_by_seed"] = dg_seed
            n_want = len(pm.get("seeds", []))
            if len(dg_seed) < n_want:
                rec["gates"].append(
                    f"GLOBAL_SEED_INCOMPLETE({len(dg_seed)}/{n_want}) — 전역 대비 보류")
            elif len(dg_seed) > 1:
                sp = max(dg_seed.values()) - min(dg_seed.values())
                rec["global_seed_spread_meV"] = round(sp * 1000, 1)
                if sp > SEED_TOL:
                    rec["gates"].append(
                        f"GLOBAL_MAGNETIC_SENSITIVITY(seed 산포 {sp*1000:.0f} meV > 10)")
            eg = {}
            for role, pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
                p2 = gb[role]["prefix"] if role in gb else pre
                eg[role] = E(f"{p2}__afm2424_pm1")
            if eg["Li"] is not None and eg["Ni"] is not None:
                dg = eg["Ni"] - eg["Li"]
                # ★ 이름을 정확히 (Codex 7차 §1.4) — 이건 **UMA 가 고른** 전역 챔피언
                #   대비다. DFT 재랭킹도, DFT 이완 최소점도, 흡착 자유에너지도 아니다.
                rec["dE_UMA_selected_global_champ_eV"] = round(dg, 4)
                rec["global_k_status"] = (
                    "K_DIRECTLY_CHECKED_GLOBAL" if E_dense(
                        f"{(gb.get('Ni') or {}).get('prefix', pm['ni_prefix'])}"
                        f"__afm2424_pm1") is not None
                    else "K_UNVERIFIED_GLOBAL — 전역 끝점은 coarse only")
                rec["dE_global_eV"] = round(dg, 4)      # 하위호환(폐기 예정)
                if de_main is not None:
                    rec["orientation_term_eV"] = round(dg - de_main, 4)
                    flip = (dg > 0) != (de_main > 0)
                    _gk = rec.get("global_k_status", "")
                    rec["global_vs_matched"] = (
                        f"K_UNRESOLVED_GLOBAL({_gk}) — 전역 끝점을 dense 로 검증하지 "
                        f"않았다. 부호 비교는 진단용이고 headline 아님"
                        if _gk.startswith("K_UNVERIFIED") else
                        "SIGN_DIFFERS — 배향일치 대비와 전역 자리 선호가 **반대**다. "
                        "어느 질문인지 밝히지 않고 인용 금지."
                        if flip and min(abs(dg), abs(de_main)) > GUARD_EV else
                        "SIGN_AGREES" if not flip else
                        "UNRESOLVED(한쪽이 guard band 안)")
                    if flip and min(abs(dg), abs(de_main)) > GUARD_EV \
                            and not rec.get("global_k_status", "").startswith("K_UNVERIFIED"):
                        # ⚠ 이건 계산 실패가 아니다 — 각 추정량은 유효하다.
                        #   금지되는 건 **하나의 site preference 숫자로 합치는 것**뿐이다.
                        #   그래서 gates(=값 무효화)가 아니라 해석 라벨로 남긴다.
                        rec["ESTIMAND_DEPENDENT_NO_SINGLE_SITE_PREFERENCE"] = (
                            f"D_pool {de_main:+.3f} vs UMA-selected global {dg:+.3f} eV — "
                            f"부호가 다르다. 두 값 **각각은 유효**하다. 하나의 '자리 선호' "
                            f"숫자로 합치지 말고 추정량을 밝혀 따로 보고할 것.")
            else:
                rec["dE_global_eV"] = None
                rec["global_vs_matched"] = "전역 끝점 미완/게이트 — 전역 대비 불가"
        elif pm.get("global_unmeasured"):
            rec["global_unmeasured"] = pm["global_unmeasured"]

        # ── 교차 끝점: 배향이 맞춰진 대비 (Codex 5차 결정 ②) ──────────────
        #   챔피언 ΔE 는 두 배향이 다르면 자리 효과와 배향 효과가 섞인다.
        #   같은 배향에서 잰 Δ 와 **부호가 같은지**가 배향 인공물 여부를 가른다.
        for tag, cx in (pm.get("cross") or {}).items():
            base_role = cx["role"]                      # 추가된 쪽
            other = "Li" if base_role == "Ni" else "Ni"
            opre = pm[("li" if other == "Li" else "ni") + "_prefix"]
            # ★ 두 seed 로 잰다 (Codex 6차 §5) — 옛 판은 pm1 하나만 읽었다.
            #   본 ΔE 는 seed 산포 게이트를 통과해야 하는데 교차만 단일시드면,
            #   "배향 의존" 판정이 실은 자기 branch 잡음일 수 있다.
            dm_by_seed = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                e_new, e_old = E(f"{cx['prefix']}__{sd}"), E(f"{opre}__{sd}")
                if e_new is not None and e_old is not None:
                    dm_by_seed[sd] = round(
                        (e_new - e_old) if base_role == "Ni" else (e_old - e_new), 4)
            if not dm_by_seed:
                rec.setdefault("cross", {})[tag] = {"status": "미완/게이트"}
                continue
            d_m = dm_by_seed.get("afm2424_pm1", list(dm_by_seed.values())[0])
            entry = {"orientation": cx["down_dir"], "roll": cx.get("roll_deg"),
                     "dE_matched_eV": d_m, "dE_by_seed": dm_by_seed,
                     # 교차 끝점은 dense 를 안 돌린다 — k 는 전이 해석뿐이다
                     "k_label": "K_UNVERIFIED_CROSS", "prefix": cx["prefix"]}
            rec.setdefault("cross", {})[tag] = entry
            n_seed_want = len(pm.get("seeds", []))
            if len(dm_by_seed) < n_seed_want:
                entry["verdict"] = (f"SEED_INCOMPLETE({len(dm_by_seed)}/{n_seed_want}) "
                                    f"— 배향 판정 보류")
                rec["gates"].append(
                    f"CROSS_SEED_INCOMPLETE({tag}: {len(dm_by_seed)}/{n_seed_want} seed)")
                continue
            spread = max(dm_by_seed.values()) - min(dm_by_seed.values())
            entry["seed_spread_meV"] = round(spread * 1000, 1)
            if spread > SEED_TOL:
                entry["verdict"] = (f"BLOCKED_MAGNETIC_SENSITIVITY(seed 산포 "
                                    f"{spread * 1000:.0f} meV > 10) — 배향 판정 불가")
                rec["gates"].append(
                    f"CROSS_MAGNETIC_SENSITIVITY({tag}: {spread * 1000:.0f} meV)")
                continue
            entry["quantity"] = f"dE_match({cx['down_dir']}/r{cx.get('roll_deg')})"
            entry["k_note"] = "coarse only — dense 없음"
        # ── 2×2: **두 고정자세 대비끼리** 비교한다 (Codex 7차 §1.3) ────────────
        #   ΔE_match(p_L*) = E_Ni(p_L*) − E_Li(p_L*)
        #   ΔE_match(p_N*) = E_Ni(p_N*) − E_Li(p_N*)
        #   I = ΔE_match(p_N*) − ΔE_match(p_L*) = O_N − O_L
        #   ⚠ 옛 판은 각 교차를 **대각선** de_main 과 비교했다. 그러면 I 가 안 나온다.
        #   ⚠ I 는 모집단 상호작용이 아니라 **이 두 자세에서의 유한설계 대비**다.
        cr = rec.get("cross") or {}
        mc = pm.get("cross") or {}          # ★ prefix 의 권위는 MANIFEST 쪽이다
        if not _pose_matched and len(mc) == 2:
            eL = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                # p_L* 자세: Li 는 본 끝점, Ni 는 교차(Ni_at_Li_pose)
                a1 = E(f"{pm['li_prefix']}__{sd}")
                b1 = E(f"{mc['Ni_at_Li_pose']['prefix']}__{sd}") \
                    if "Ni_at_Li_pose" in mc else None
                # p_N* 자세: Ni 는 본 끝점, Li 는 교차(Li_at_Ni_pose)
                a2 = E(f"{mc['Li_at_Ni_pose']['prefix']}__{sd}") \
                    if "Li_at_Ni_pose" in mc else None
                b2 = E(f"{pm['ni_prefix']}__{sd}")
                if None not in (a1, b1, a2, b2):
                    eL[sd] = {"dE_match_pL": round(b1 - a1, 4),
                              "dE_match_pN": round(b2 - a2, 4),
                              "I": round((b2 - a2) - (b1 - a1), 4),
                              "O_Li": round(a2 - a1, 4), "O_Ni": round(b2 - b1, 4)}
            if eL:
                rec["two_by_two"] = eL
                m = eL.get("afm2424_pm1") or list(eL.values())[0]
                dl, dn = m["dE_match_pL"], m["dE_match_pN"]
                both_big = min(abs(dl), abs(dn)) > GUARD_EV
                same = (dl > 0) == (dn > 0)
                rec["two_by_two_k_status"] = ("K_UNVERIFIED_CROSS — 교차 끝점은 "
                                              "dense 를 안 돌렸다. 아래 부호 결론은 "
                                              "coarse 값 기준이다")
                # ⚠ k 라벨은 이 루프가 끝나야 정해진다(κ 를 여기서 모은다). 잠정 판정만
                #   쓰고, 아래 후처리에서 K 게이트를 씌운다.
                rec["two_by_two_verdict"] = (
                    "UNRESOLVED(한쪽이 guard band 안 — 부호 비교 불가)" if not both_big else
                    "SIGN_AGREES_AT_BOTH_SAMPLED_POSES — **두 표본 자세에서** 부호 일치 "
                    "(모집단 배향 무관성 주장 아님)" if same else
                    "POSE_DEPENDENT_SIGN — 자세에 따라 부호가 다르다. 자세 무관 자리 선호 금지")
                if both_big and not same:
                    rec["gates"].append(
                        f"POSE_DEPENDENT_SIGN(ΔE_match(p_L*)={dl:+.3f} vs "
                        f"ΔE_match(p_N*)={dn:+.3f} eV)")
                if len(eL) > 1:
                    sp = max(x["I"] for x in eL.values()) - min(x["I"] for x in eL.values())
                    rec["two_by_two"]["I_seed_spread_meV"] = round(sp * 1000, 1)
                    if sp > SEED_TOL:
                        rec["gates"].append(
                            f"TWO_BY_TWO_MAGNETIC_SENSITIVITY(I seed 산포 {sp*1000:.0f} meV)")
        if pm.get("cross_missing"):
            rec["cross_missing"] = pm["cross_missing"]

        if de_main is not None and not rec["gates"]:
            # ★★ 직접 dense 를 돌렸으면 **그 값이 headline** 이다 (Codex zip 감사 P0-3).
            #   옛 판은 dense 로 κ 만 재고 최종 수치·판정은 coarse 를 썼다. 그러면서
            #   K_DIRECTLY_CHECKED 라는 이유로 20–40 meV guard 까지 풀어, dense 값이
            #   30 meV 바닥 반대편에 있어도 coarse 로 판정할 수 있었다.
            _dli = E_dense(f"{pm['li_prefix']}__afm2424_pm1")
            _dni = E_dense(f"{pm['ni_prefix']}__afm2424_pm1")
            if _dli is not None and _dni is not None:
                rec["dE_coarse_eV"] = de_main
                de_main = round(_dni - _dli, 4)
                rec["headline_from"] = "dense (직접 k 검증) — coarse 는 dE_coarse_eV 에"
                # ⚠ 0 은 "3×4×1 의 잔여 k 오차가 없다" 가 아니라 **전이 허용치를 안 썼다**
                #   는 뜻이다 (Codex 재감사). 이름을 그렇게 바꾼다.
                rec["k_transfer_allowance_meV"] = 0.0
                rec["k_residual_note"] = "직접 dense — 전이 허용치 미적용. 잔여 k 오차는 미추정"
            else:
                rec["headline_from"] = "coarse (dense 없음/게이트) — k 불확실성 ±10 meV"
                rec["k_transfer_allowance_meV"] = GUARD_EV * 1000
            rec["dE_Ni_minus_Li_eV"] = de_main
            # ±10 meV k guard band — 30 meV 판정바닥과 **합치지 않는다**
            a_de = abs(de_main)
            rec["k_guard"] = ("판정 유지 (>40 meV)" if a_de > delta + GUARD_EV else
                              "바닥 아래 결론 유지 (<20 meV)" if a_de < delta - GUARD_EV else
                              "⚠ 20–40 meV — k 오차로 판정이 뒤집힐 수 있다: "
                              "직접 dense 아니면 UNRESOLVED")
            if abs(de_main) <= GUARD_EV:
                rec["k_guard"] = "⛔ |ΔE| ≤ 10 meV — 부호 자체가 안 정해진다"
            ec = eclean.get("afm2424_pm1")
            if ec is not None and emol.get(frag) is not None:
                eli = E(f"{pm['li_prefix']}__afm2424_pm1")
                eni = E(f"{pm['ni_prefix']}__afm2424_pm1")
                results["e_ads"][pid] = {
                    "Li_top": round(eli - ec - emol[frag], 4),
                    "Ni_top": round(eni - ec - emol[frag], 4),
                    "mol_ref": "box24",
                    # ⚠ headline 은 **static(coarse) 값**이다. dense 는 별도 k 게이트로만
                    #   쓰고 값을 교체하지 않는다 (Codex 3차 감사 P0-4). 명시하지 않으면
                    #   "dense 로 검증된 E_ads" 로 오독된다.
                    "estimand": "E_ads(static target mesh) — dense 는 k 게이트 전용",
                    "k_check": "관측된 dense 보정이 게이트 안이면 통과. 값 교체 아님"}
        results["pairs"][pid] = rec

    # ══ 사전등록 closure estimand (회신 V P0-3 · P0-4) ══════════════════════
    #   `prereg_sdcp_neutral_contrast_2026_08_29.json` 을 코드로 옮긴 것.
    #   ⛔ 종전엔 사전등록이 **문서로만** 있었다 — 잡이 다 끝나도 판정이 재현되지 않았다.
    # ⛔⛔ 회신 AO P0-4 (2026-08-31) — nzmag canary 와 부모 기체 기준의 **static 이
    #   실제로 같은 기하였는지** 실측한다. 종전엔 부모가 relax/CONTCAR 로, canary 가
    #   루트 POSCAR 로 돌아 두 에너지 차에 구조 이완 에너지가 섞였다.
    #   ⚠ 이 검사는 **실행된 입력**(static/POSCAR)을 본다 — 선언이 아니다.
    _cg = {}
    for _mk, _cz in (man.get("molecular_spin_controls") or {}).items():
        _f = _mk.replace("mol__", "").rsplit("__box", 1)[0]
        _pp = read_poscar(os.path.join(root, "refs", _mk, "static", "POSCAR")) \
            or read_poscar(os.path.join(root, _mk, "static", "POSCAR"))
        _cp = read_poscar(os.path.join(root, str(_cz), "static", "POSCAR"))
        if _pp is None or _cp is None:
            _cg[_f] = {"same": None, "why": "static/POSCAR 를 못 읽었다 (미실행이거나 경로 불일치)"}
            continue
        if len(_pp["pos"]) != len(_cp["pos"]):
            _cg[_f] = {"same": False, "why": "원자수가 다르다 (%d vs %d)"
                       % (len(_pp["pos"]), len(_cp["pos"]))}
            continue
        _dmax = max(max(abs(a[k] - b[k]) for k in range(3))
                    for a, b in zip(_pp["pos"], _cp["pos"]))
        _cmax = max(max(abs(a[k] - b[k]) for k in range(3))
                    for a, b in zip(_pp["cell"], _cp["cell"]))
        _cg[_f] = {"same": bool(_dmax <= 1e-6 and _cmax <= 1e-6),
                   "max_cart_diff_A": _dmax, "max_cell_diff_A": _cmax,
                   "tol_A": 1e-6}
    results["gas_canary_geom"] = _cg

    _pc = _closure_estimand(man, results, E, emol, jobs, merge_info)
    if _pc:
        results["prereg_closure"] = _pc

    # ── k 전이 게이트 (Codex 5차 taxonomy · 6차 §6) ───────────────────────────
    #   MANIFEST 에 k_label_rule 을 적어 놓고 **계산은 안 하던** 구멍을 막는다.
    #   n=2 이므로 평균·표준편차·CI 를 쓰지 않는다 — deterministic max/range 다.
    cal = list(man.get("dense_calibrators") or [])
    kap_all = results.get("kappa", {})
    k_transfer, k_labels, have = k_transfer_gate(
        cal, kap_all, man.get("fragments", []))
    results["k_transfer"] = k_transfer
    results["k_labels"] = k_labels
    # ── K 미검증 quantity 의 **부호 결론을 막는다** (Codex 재감사 P0-3) ─────────
    #   교차 끝점과 전역 끝점은 dense 를 안 돌린다. 조각의 k 라벨이 UNVERIFIED 면
    #   coarse 값으로 부호를 말할 근거가 없다.
    for _pid, _r in results["pairs"].items():
        _lb = k_labels.get(_r.get("fragment"), "K_UNVERIFIED")
        if _r.get("two_by_two_verdict") and _lb == "K_UNVERIFIED":
            _r["two_by_two_verdict"] = (
                f"K_UNRESOLVED_2x2(교차는 coarse only · 조각 라벨 {_lb} — 부호 결론 "
                f"보류. I 의 전이 오차폭은 두 대비의 차라 최악 "
                f"±{2 * GUARD_EV * 1000:.0f} meV)")
            _r["gates"] = [g for g in _r.get("gates", [])
                           if not g.startswith("POSE_DEPENDENT_SIGN")]
        for _t2, _c in (_r.get("cross") or {}).items():
            _c["k_note"] = (f"coarse only · 조각 라벨 {_lb}"
                            + (" — 부호 결론 보류" if _lb == "K_UNVERIFIED" else
                               f" · 전이 허용 ±{GUARD_EV * 1000:.0f} meV"))

    for frag in man.get("fragments", []):
        dl = [r["dE_Ni_minus_Li_eV"] for r in results["pairs"].values()
              if r["fragment"] == frag and "dE_Ni_minus_Li_eV" in r]
        n_planned = sum(1 for p in man["pairs"].values() if p["fragment"] == frag)
        expect_dirs = (man.get("contract_expected_pairs") or {}).get(frag)
        # ★ 번들 **이전**에 잃은 방향까지 본다. n/n_planned 만 보면 계획 자체가 이미
        #   줄어든 경우를 영원히 못 잡는다 (계획 3/3 = 100% 인데 원래 방향은 5개).
        #   자리 스윕 방향(Li_top/Ni_top 이 애초에 없음)은 정의 밖이라 세지 않고,
        #   Li_top/Ni_top 이 **있는데 부적격**인 방향만 손실로 센다.
        aud = (man.get("pair_audit") or {}).get(frag) or {}
        ex = aud.get("excluded_dirs") or {}
        lost = {d: sorted(c) for d, c in ex.items()
                if any(s.startswith(("Li_top", "Ni_top")) and "부적격" in s for s in c)}
        nd = aud.get("n_down_dirs")
        cov = (n_planned / nd) if nd else None
        if not dl:
            results["fragments"][frag] = {"n": 0, "n_planned": n_planned,
                                          "class": "NO_DATA"}
            continue
        n = len(dl)
        med = sorted(dl)[n // 2] if n % 2 else 0.5 * (sorted(dl)[n // 2 - 1]
                                                      + sorted(dl)[n // 2])
        side = 1 if med > 0 else -1
        fs = sum(1 for x in dl if x * side > 0) / n
        fe = sum(1 for x in dl if x * side > delta) / n
        # ★ 번들 이전에 방향을 잃었으면 **무조건 검열 등급**이다. n=3·계획=3 이라
        #   coverage 100% 로 보여 ROBUST 까지 올라가던 경로를 막는다 (Codex P0-6).
        champ = [p for p in man["pairs"].values()
                 if p["fragment"] == frag and p.get("champion_pose")]
        if champ:
            # 챔피언 비교는 "Li 위 최선 vs Ni 위 최선" 이다 — 방향 통계가 아니라
            # **설계상 1쌍**이므로 n<3 로 거부하지 않는다. 대신 무엇을 비교했는지 적는다.
            # ★ 판정 기준은 방향이 아니라 **자세키**(down_dir, roll) 다 (Codex 6차 P0-4).
            cp = champ[0].get("champion_pose") or {}
            same = champ[0].get("matched") is True
            ncross = len(champ[0].get("cross") or {})
            # ⚠ 옛 판은 교차 **결과 두 개**만 있으면 "2×2 완료" 라 했다. 그런데 2×2 계산
            #   자체(two_by_two)가 실패해도 그 조건은 참이라 **가짜 완료 라벨**이 붙었다.
            #   실제로 prefix 버그로 two_by_two 가 한 번도 안 만들어지고 있었다.
            _pr = results["pairs"].get(
                f"{frag}__{champ[0]['dir']}_r{champ[0]['roll']:03d}", {})
            got = 2 if (_pr.get("two_by_two") or {}).get("afm2424_pm1") else \
                sum(1 for _t, c in (_pr.get("cross") or {}).items()
                    if "dE_matched_eV" in c) and 0
            cls = ("CHAMPION_MATCHED_POSE" if same else
                   "CHAMPION_MIXED_ORIENTATION_2x2" if ncross == 2 and got == 2 else
                   # 교차 0 = 대각선 두 모서리뿐. 자리와 배향을 **분리할 수 없다**.
                   "CHAMPION_ORIENTATION_CONFOUNDED(교차 없음 — 자리·배향 분리 불가)"
                   if ncross == 0 else
                   "THREE_CORNER_PARTIAL(교차 %d/%d 완료 — 배향 미해결)" % (got, ncross))
        elif lost:
            cls = "DIRECTION_CENSORED_%d_OF_%d" % (n_planned, nd or n_planned)
        elif expect_dirs and n_planned != expect_dirs:
            cls = "CONTRACT_SHORT(계약 %d · 계획 %d)" % (expect_dirs, n_planned)
        elif n < 3:
            cls = "NO_VERDICT_n<3"
        elif n < 0.8 * n_planned:
            cls = "CENSORED(계획 %d 중 %d — coverage<80%%)" % (n_planned, n)
        elif fs >= 0.8 and fe >= 0.8:
            cls = "ROBUST_SCREENING"
        elif fs >= 0.8 and abs(med) > delta:
            cls = "MARGINAL_TENDENCY"
        elif fs >= 0.8:
            cls = "SIGN_CONSISTENT_SMALL"
        else:
            cls = "UNRESOLVED_MIXED"
        lbl = k_labels.get(frag, "K_UNVERIFIED")
        cls = apply_k_guard(cls, med, lbl, delta)
        results["fragments"][frag] = {
            "k_label": lbl,
            "kappa_meV": (round(kap_all[frag] * 1000, 1) if frag in kap_all else None),
            "n_directions": n, "n_planned": n_planned, "dE_list": dl,
            "median_eV": round(med, 4), "class": cls,
            "n_down_dirs": nd, "direction_coverage": None if cov is None else round(cov, 2),
            "disqualified_dirs": lost,
            "read_as": ("Li 위 최선이 더 안정" if med > 0 else "Ni 위 최선이 더 안정")
            if champ else ("Li 우세 경향" if med > 0 else "Ni 우세 경향"),
            "champion_dirs": (champ[0].get("champion_dirs") if champ else None),
            "champion_pose": (champ[0].get("champion_pose") if champ else None),
            "exact_matched_pose": (champ[0].get("matched") if champ else None),
            "note": ("PBE+U(6.2)+D3-zero fixed-protocol tendency — UMA 값과 같은 표 금지. "
                     "δ=%.3f eV." % delta)}
        if lost:
            wr = aud.get("excluded_reasons") or {}
            why = "; ".join(f"{d}: {', '.join(sorted(wr.get(d, {})))}" for d in sorted(lost))
            results["fragments"][frag]["disqualified_reasons"] = \
                {d: wr.get(d, {}) for d in lost}
            results["warnings"].append(
                f"{frag}: down_dir {nd}개 중 {len(lost)}개가 **번들 이전에** 탈락했다 "
                f"— 계획 {n_planned}개는 이미 줄어든 수다. 사유: {why}. "
                f"원고에는 '{nd}방향 중 {n_planned}방향 판정'과 그 사유를 함께 쓸 것 "
                f"(CAP_ARTIFACT 는 조각 모델의 한계지 데이터 부족이 아니다)")

    # ── 필수 완결성 — static + **계획된 dense** 까지 (Codex P0-D) ────────────
    # ⛔⛔ 회신 AO P0-1 (2026-08-31) — 종전엔 **14잡 전체**의 누락을 먼저 세고
    #   exit 2 로 끝낸 뒤에야 `--gate vacconv` 분기로 들어갔다. 그래서 1단계 8잡만
    #   정상 완료한 상태도 **미실행 2단계 6잡 때문에 반드시 실패**했다.
    #   ⇒ completeness 를 **단계별로** 나눈다. 단계 분류는 run_staged.sh 와
    #     **같은 규칙**(job.json 구조화 필드)이어야 한다 — 이름 파싱 금지.
    def _stage_of(pl):
        # 계획 항목 -> "1" | "2". run_staged.sh 의 분류와 1:1 이어야 한다.
        m = (pl.get("meta") or {})
        kind, role, vac = m.get("kind"), m.get("role"), m.get("vacconv")
        if kind == "mol_ref":
            return "1"
        if kind == "prospective_pose" and role == "primary":
            return "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
        return "2"

    _gate_arg = ""
    if "--gate" in sys.argv:
        _gi = sys.argv.index("--gate")
        _gate_arg = sys.argv[_gi + 1] if len(sys.argv) > _gi + 1 else ""
    # ⚠ meta 가 없는 계획 항목은 단계를 **모른다**. 모르는 것을 1단계에서 빼면
    #   거짓 통과가 되므로 '2' 로 두지 않고 **양쪽 다 필수**로 센다.
    _no_meta = [j for j, pl in planned.items()
                if pl.get("required") and not (pl.get("meta") or {})]
    # ⛔⛔ 회신 AP #4 (2026-08-31) — 14잡이 **전부 required** 라, net4 나 대안 자세
    #   하나가 게이트되면 최종 completeness 가 exit 2 를 냈다. 그런데 우리는
    #   "net4 unavailable 은 D_pm1 에 영향 없음" 이라고 선언해 놓았다 — 모순이다.
    #   또 대안 자세 4잡은 어떤 봉인된 식에도 안 들어가면서 필수잡으로 남아 있었다.
    #   ⇒ tier 를 나눈다. estimand = 봉인된 네 잡 + 진공쌍(1단계 판정에 쓴다) +
    #     기체 기준. 나머지(net4·대안 자세)는 sensitivity 다.
    #     종료코드는 **estimand tier 만** 본다. sensitivity 결측은 상태로 보고한다.
    _ejk_all = set()
    for _kk in ("estimand_job_keys", "estimand_job_keys_net4"):
        for _k2, _v2 in (man.get(_kk) or {}).items():
            if _k2.startswith("E_") and isinstance(_v2, str):
                _ejk_all.add(_v2)
    _ejk_pm1 = {v for k, v in (man.get("estimand_job_keys") or {}).items()
                if k.startswith("E_") and isinstance(v, str)}

    def _tier_of(j, pl):
        # ⚠ tier 분리는 **exact-key 경로에서만** 뜻이 있다. 봉인된 식이 없으면
        #   어느 잡이 D 에 들어가는지 알 수 없으므로 전부 estimand 로 둔다
        #   (레거시 Li/Ni 쌍 경로에서 그 잡들이 sensitivity 로 강등되면
        #    누락이 종료코드에 안 잡히는 **회귀**가 된다 — 실측으로 잡았다).
        if not _ejk_pm1:
            return "estimand"
        m = (pl.get("meta") or {})
        if j in _ejk_pm1:
            return "estimand"
        if m.get("kind") == "mol_ref":
            return "estimand"          # 기체 기준은 D 에 직접 들어간다
        if m.get("vacconv"):
            return "estimand"          # 진공 수렴 판정이 1단계 게이트다
        return "sensitivity"
    missing, missing_sens = [], []
    for j, pl in planned.items():
        if not pl.get("required"):
            continue
        if _gate_arg == "vacconv" and (pl.get("meta") or {}) and _stage_of(pl) != "1":
            continue                      # 1단계 판정에서는 2단계 잡을 안 센다
        _bucket = missing if _tier_of(j, pl) == "estimand" else missing_sens
        if E(j) is None:
            _bucket.append(j + " [static]")
        elif "dense" in (pl.get("phases") or []) and E_dense(j) is None:
            _bucket.append(j + " [dense]")
    results["required_missing_sensitivity"] = missing_sens
    results["tier_census"] = {}
    for j, pl in planned.items():
        if pl.get("required"):
            _t = _tier_of(j, pl)
            results["tier_census"][_t] = results["tier_census"].get(_t, 0) + 1
    if missing_sens:
        results["warnings"].append(
            "sensitivity tier %d건 미완 %s — **D_pm1 에는 영향이 없다**. "
            "다만 자기 분기·자세 민감도를 보고할 수 없다 (회신 AP #4)"
            % (len(missing_sens), missing_sens[:3]))
    results["sensitivity_status"] = ("complete" if not missing_sens
                                     else "incomplete (%d건)" % len(missing_sens))
    # ⛔⛔ 회신 BB P0-1 (2026-09-02) — **두 가지가 겹친 사고다.**
    #   ① 마지막 인용 블록이 `res["citation_status"]` 를 썼는데 이 스코프에 `res` 가
    #      없다. main() 을 끝까지 타면 **반드시 NameError** 로 죽는다. 1단계는 그
    #      전에 return 하고, selftest 는 최종 main() 경로를 한 번도 안 탔다.
    #   ② `res` 를 `results` 로 고쳐도 부족하다 — RESULTS.json 을 **여기서 이미
    #      저장**하므로 인용 판정이 파일에 안 남는다. 중간 `return 2` 경로도 여럿이라
    #      그 경우에도 안 남았다.
    #   ⇒ 판정을 **저장 전에** 계산해 `results` 에 넣는다. 뒤쪽은 출력·종료코드만.
    _cl = (results.get("prereg_closure") or {})
    _vc = (results.get("closure_vacconv") or _cl.get("closure_vacconv") or {})
    _cit = citation_status(man, _cl)
    results["citation_status"] = _cit
    _cl["manuscript_citable"] = _cit["manuscript_citable"]
    _cl["⛔_인용"] = _cit["why"]

    out = os.path.join(root, "RESULTS.json")
    results["required_missing"] = missing
    for r in jobs.values():
        r.pop("_fin", None); r.pop("_contact_fp", None)
    json.dump(results, open(out, "w", encoding="utf-8"),
              indent=1, ensure_ascii=False)

    bad = {j: r for j, r in jobs.items() if not r["ok"]}
    print(f"=== 무결성 ===  검사 {integrity['checked']}개 · 변경 "
          f"{len(integrity['changed'])} · 없음 {len(integrity['missing'])}")
    print(f"=== 잡 게이트 ===  통과 {len(jobs) - len(bad)}/{len(jobs)}"
          + (f" · 문제 {len(bad)}건:" if bad else ""))
    for j, r in sorted(bad.items()):
        print(f"  ⛔ {j}: {', '.join(r['gates'])}")
    print("\n=== 자리 선호 (ΔE = E(Ni_top) − E(Li_top), 양수 = Li 우세 · seed-매칭) ===")
    for pid, r in sorted(results["pairs"].items()):
        de = r.get("dE_Ni_minus_Li_eV")
        seeds = " ".join(f"{s.split('_')[-1]}:{v:+.3f}" for s, v in r["dE_by_seed"].items())
        print(f"  {pid:34s} " + (f"{de:+.3f} eV" if de is not None else "(게이트/미완)")
              + (f"  [{seeds}]" if seeds else "")
              + (f"  ⛔{';'.join(r['gates'])}" if r["gates"] else ""))
    print("\n=== 조각별 판정 ===")
    for f, r in results["fragments"].items():
        nd = r.get("n_down_dirs")
        print(f"  {f:14s} n={r.get('n_directions', 0)}/{r.get('n_planned', '?')}"
              + (f" (원래 방향 {nd})" if nd and nd != r.get("n_planned") else "")
              + "  중앙값 "
              + (f"{r['median_eV']:+.3f} eV" if "median_eV" in r else "—")
              + f"  → {r['class']}"
              + (f"  ⚠번들이전 탈락 {len(r['disqualified_dirs'])}방향"
                 if r.get("disqualified_dirs") else ""))
    if results["e_ads"]:
        print("\n=== E_ads (pm1 seed · box24 기준계 · 음수 = 흡착 유리) ===")
        for pid, e in sorted(results["e_ads"].items()):
            print(f"  {pid:34s} Li_top {e['Li_top']:+.3f} · Ni_top {e['Ni_top']:+.3f} eV")
    for k, v in results["numerical_gates"].items():
        # ⛔ 회신 AO P0-6 — pass 가 None 이면 **판정하지 않은 것**이다. ⛔(실패)로
        #   찍으면 실패한 것처럼 보이고, ✓ 로 찍으면 검증한 것처럼 보인다.
        _mk = "✓" if v["pass"] else ("ℹ" if v["pass"] is None else "⛔")
        print(f"  {_mk} 수치게이트 {k}: {v['dE_meV']} meV"
              + (f" · E_ads {v['dEads_meV']} meV" if "dEads_meV" in v else ""))
    for w in results["warnings"]:
        print(f"  ⚠ {w}")
    print(f"\n→ {out}")
    # ⚠ 기하를 **검증하지 못한 것**도 실패다 (Codex 재감사 P0-1). 옛 판은 경고만
    #   찍고 exit 0 이라, 실제 VASP 가 무엇을 읽었는지 모르는 채 완주로 보였다.
    if integrity["changed"] or integrity["missing"] or \
            integrity.get("runtime_poscar_mismatch") or \
            integrity.get("geometry_unverified"):
        print(f"\n⛔ **입력 무결성 실패** — 변경 {len(integrity['changed'])} · "
              f"사라짐 {len(integrity['missing'])} · 실행시 기하 불일치 "
              f"{len(integrity.get('runtime_poscar_mismatch') or [])} · 기하 미검증 "
              f"{len(integrity.get('geometry_unverified') or [])} — exit 2 "
              f"(삭제도 변조이고, **검증 못 한 것도 통과가 아니다**)")
        return 2

    # ⛔⛔ 회신 AO P0-1 (2026-08-31) — stage gate 를 **다른 종료 검사보다 먼저**
    #   판정한다. 종전엔 e_ads·전체 completeness 검사 뒤에 있어서, 1단계 8잡만
    #   정상 완료한 상태가 여기까지 오지도 못하고 exit 2 로 끝났다.
    # (`_cl`·`_vc` 는 저장 전에 이미 만들었다 — 회신 BB P0-1)
    if _gate_arg:
        if _gate_arg != "vacconv":
            print(f"⛔ 모르는 --gate: {_gate_arg!r} (지원: vacconv)")
            return 2
        if missing:            # 위에서 **1단계 cohort 로 좁혀** 센 값이다
            print(f"⛔ **1단계 cohort 미완 {len(missing)}건** — exit 2:")
            for j in missing[:20]:
                print(f"   · {j}")
            return 2
        if not _vc or _vc.get("applicable") is False:
            print("⛔ 진공 수렴 판정을 낼 수 없다 (vacconv 잡이 없거나 결과가 없다)")
            return 2
        if _vc.get("blocks"):
            print("⛔ 진공 판정이 막혔다:")
            for b in _vc["blocks"][:5]:
                print(f"   · {b}")
            return 2
        print(f"■ stage gate = vacconv · {_vc.get('verdict')}")
        # ⛔⛔ 회신 AP #5 (2026-08-31) — stage gate 가 사실상 `closure_vacconv` 만 봤다.
        #   그래서 nzmag 가 부모보다 낮거나 · canary 기하가 어긋나거나 ·
        #   ROOT_SEAL 이 불일치하거나 · POTCAR source/VASP 버전이 갈려도
        #   **2단계가 열렸다.** canary 와 POTCAR 검사를 1단계에 넣은 목적과 모순이다.
        #   ⇒ stage1_prerequisites 를 따로 만들고 **전부** 통과해야 연다.
        _pi = (_cl.get("potcar_identity") or {})
        _pre = _stage1_prereqs(_cl, _vc, results)
        _pre_bad = [k for k, v in _pre.items() if not v["pass"]]
        print("■ stage-1 prerequisites:")
        for _k, _v in _pre.items():
            print(f"   {'✓' if _v['pass'] else '⛔'} {_k}: {str(_v['why'])[:70]}")
        if _pre_bad:
            print("⛔ **2단계를 열지 않는다** — 1단계 선결조건 미통과: %s" % _pre_bad)
            print("   (canary·POTCAR 검사를 1단계에 넣은 이유가 바로 이것이다)")
            return 2
        if not _vc.get("pass"):
            print("⛔ **2단계를 제출하지 않는다.** 추가 셀 탐색 없이 Figure 2e 를 제거한다.")
            return 2
        # ⛔ 회신 AO P0-3 — 통과를 **해시에 결박된 receipt** 로 남긴다.
        #   자유문구는 증거가 아니다. run_staged.sh 2 는 이 파일 없이 열리지 않고,
        #   MANIFEST 가 바뀌면 해시가 달라져 자동으로 무효가 된다.
        _s1 = sorted(j for j, pl in planned.items()
                     if pl.get("required")
                     and (not (pl.get("meta") or {}) or _stage_of(pl) == "1"))
        _rc = {
            "schema": "stage1_pass/v1",
            "gate": "vacconv",
            "verdict": _vc.get("verdict"),
            # ⛔ 회신 BA P1 — 종전엔 존재하지 않는 `delta_vac_meV` 를 읽어 **언제나
            #   null** 이었다. closure 가 만드는 키는 `delta_vac_eV` 다.
            "delta_vac_meV": (None if _vc.get("delta_vac_eV") is None
                              else round(float(_vc["delta_vac_eV"]) * 1000.0, 3)),
            "delta_vac_eV": _vc.get("delta_vac_eV"),
            "manifest_sha256": hashlib.sha256(
                open(os.path.join(root, "MANIFEST.json"), "rb").read()).hexdigest(),
            "stage1_jobs": _s1,
            "stage1_energies_eV": {j: E(j) for j in _s1},
            "integrity_checked": integrity.get("checked"),
            "n_planned_required": sum(1 for pl in planned.values() if pl.get("required")),
            "stage1_prerequisites": _pre,
            "⚠_receipt_는_증거가_아니다": ("회신 AP #4 — 이 파일이 있다는 것만으로 "
                "2단계를 열지 않는다. 러너가 2단계 **직전에** `--gate vacconv` 를 "
                "다시 실행해 현재 결과로 재판정한다"),
            "⛔": ("1단계 통과 증거. run_staged.sh 2 는 이것 없이 열리지 않는다. "
                   "MANIFEST.json 이 바뀌면 manifest_sha256 이 달라져 무효다."),
        }
        json.dump(_rc, open(os.path.join(root, "STAGE1_PASS.json"), "w",
                                    encoding="utf-8"),
                  indent=1, ensure_ascii=False)
        print(f"✅ 1단계 통과 ({len(_s1)}잡) — STAGE1_PASS.json 기록 · 2단계 제출 가능")
        return 0
    # ⚠ 기준계를 선언해 놓고 E_ads 가 하나도 안 나오면 **조용한 실패**다.
    #   경로 키가 안 맞아도 gas job 자체는 ok 라 exit 0 이 났다 (Codex 4차 P0-2).
    # ⛔ 회신 AJ — `pairs` 는 **Li/Ni 대조쌍** 경로의 산물이다. C-12 · from_basins 는
    #   basin 단위로 생성하므로 pairs 가 비어 있고, 그러면 e_ads 루프가 0회 돈다.
    #   그 상태로 이 검사를 걸면 **완주해도 무조건 exit 2** 다 (실측: C-12 v3).
    #   pairs 가 애초에 없는 판에서는 이 검사가 적용되지 않는다.
    _pairs_expected = bool(man.get("pairs"))
    if has_refs and _pairs_expected and not results["e_ads"]:
        print("\n⛔ **기준계를 선언했는데 E_ads 가 0개다** — refs 조회가 안 맞거나 "
              "상자 게이트가 전부 실패했다. exit 2")
        for k2, v2 in results["numerical_gates"].items():
            if k2.startswith("box_"):
                print(f"   {k2}: {v2}")
        return 2
    if missing:
        _scope = ("1단계 cohort" if _gate_arg == "vacconv"
                  else "estimand tier (sensitivity 결측은 종료코드에 안 넣는다)")
        print(f"\n⛔ **필수 산출 미완 {len(missing)}건** ({_scope}) — fail-closed, exit 2:")
        for j in missing[:20]:
            print(f"   · {j}")
        if _no_meta:
            print(f"   ⚠ 계획 meta 가 없어 단계를 모르는 항목 {len(_no_meta)}건은 "
                  f"**양쪽 단계 모두에서 필수**로 셌다 (모르는 것을 빼면 거짓 통과다)")
        return 2

    # ⛔⛔ 2026-08-31 (회신 AN P0-3·P0-4) — **두 가지가 종료코드에 안 걸려 있었다.**
    #   ① stage 판정: 1단계만 돌고 나면 2단계 6잡이 required_missing 이라 **무조건 exit 2**.
    #      그래서 진공 시험을 통과해도 2단계를 열 수 없었다. `--gate vacconv` 는
    #      1단계 cohort 만 보고, 그 판정으로만 끝낸다.
    #   ② 최종 판정: prereg_closure 가 NO_VALUE 여도, 진공이 실패해도 `return 0` 이
    #      될 수 있었다. **비인용 상태면 반드시 nonzero** 여야 한다.
    # ⛔⛔ 회신 BA P0-3 · 해제조건 4 — **계산 성공과 원고 인용 자격을 분리한다.**
    #   종전엔 분석기가 `manuscript_citable` 을 읽지도 않았고, post-hoc·overall=None
    #   이어도 `_final_verdict` 가 성공을 반환했다.
    #  ⚠ 계산은 저장 전에 끝났다 (회신 BB P0-1). 여기서는 **출력만** 한다 —
    #    여기서 다시 계산하면 파일에 든 값과 화면 값이 갈릴 수 있다.
    print("")
    print("── 인용 자격 ──")
    print("  manuscript_citable = %s" % _cit["manuscript_citable"])
    for b in _cit["blockers"]:
        print("   ⛔ %s" % b)
    if not _cit["manuscript_citable"]:
        print("  ⚠ 계산은 성공했을 수 있다 — 그것과 **다른 상태**다. 이 결과로 원고")
        print("     문장을 쓰지 않는다 (회신 BA P0-3).")

    _bad_final = _final_verdict(_cl, _vc)
    # ⛔⛔ 회신 BC P1 (2026-09-02) — **아무것도 안 내고 rc=0 이 나왔다.**
    #   `prereg_closure` 가 비면 `_final_verdict` 의 `bad` 가 빈 목록이라 성공으로
    #   끝났다. 보고량을 선언한 번들이 그것을 못 만들었으면 성공이 아니다.
    #   ⚠ 레거시 쌍(Li/Ni) 경로는 이 보고량을 선언하지 않는다 — 거기까지 막으면
    #     맞는 동작을 깨뜨린다. **선언한 번들에만** 건다.
    if man.get("reported_quantity") or man.get("from_basins"):
        if not (_cl or {}):
            _bad_final = list(_bad_final) + [
                "prereg_closure 가 **없다** — 보고량(ΔE_ads)을 선언한 번들이 그것을 "
                "만들지 못했다 (회신 BC P1)"]
        elif (_cl or {}).get("verdict") in (None, ""):
            _bad_final = list(_bad_final) + [
                "prereg_closure.verdict 가 **비어 있다** — 판정을 내지 못했다"]
    if _bad_final:
        print("⛔ **비인용 상태로 끝났다** — 종료코드를 0 으로 두지 않는다:")
        for b in _bad_final:
            print(f"   · {b}")
        return 2
    # 🔴 회신 BE P1 (2026-09-03) — **계산 성공과 인용 허가를 종료코드에서도 가른다.**
    #   종전(BC P1)엔 `manuscript_citable=false` 를 계산 실패와 같은 rc=2 로 냈다.
    #   manifest 가 post_hoc 정책으로 `manuscript_citable=false` 를 **선언**한 묶음은
    #   완주해도 그 코드가 나와, "탐색 성공과 인용 허가를 분리했다" 는 문서와 실행
    #   의미가 충돌했다 ⇒ rc 3 = 계산 완주 · 원고 인용 불가(탐색용). 러너는 2 와 구분한다.
    if not _cit.get("manuscript_citable"):
        print("⚠ 계산은 완주했지만 **원고 인용 자격이 없다** (탐색용) — 종료코드 3:")
        for b in (_cit.get("blockers") or [])[:6]:
            print(f"   · {b}")
        print("   (rc 2 = 판정 실패 · rc 3 = 완주했으나 인용 불가 · 회신 BE P1)")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
