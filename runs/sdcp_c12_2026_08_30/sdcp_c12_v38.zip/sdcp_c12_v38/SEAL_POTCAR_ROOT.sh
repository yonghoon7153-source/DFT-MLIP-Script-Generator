#!/usr/bin/env bash
# POTCAR 를 전 잡에 조립하고, variant 별 **원본 SHA256** 을 묶음 root 에 봉인한다.
#
# ⛔ 회신 AO Q1 / AP #7 — 봉인은 "생산 전" 이라는 **자기선언이 아니라 검사**여야 한다.
#    최초 봉인 전에 기존 VASP 산출물이 하나라도 있으면 **거부**한다. 계산 뒤에
#    만든 봉인과 구별되지 않으면 사전 승인이 아니기 때문이다.
#
# 이 스크립트가 **못 하는 것**: 봉인한 트리가 공식 배포판인지는 확인하지 못한다
#   (라이선스로 정본 SHA 를 우리가 못 싣는다). 봉인은 "이 계산들이 하나의 트리에서
#   나왔고 그 트리가 생산 전에 고정됐다" 까지만 보증한다. 공식 release 를 주장하려면
#   계산 전에 받은 attestation(POTCAR_ATTESTATION.json)이 따로 있어야 한다 (AP #12).
set -e
: "${PP:?PP=/path/to/potpaw_PBE.54 를 주세요}"
: "${POTCAR_ALLOWLIST:?POTCAR_ALLOWLIST=/abs/site_allow.txt 를 주세요}"
# ⛔ 회신 AY P0-1 — launcher 를 여기서 **절대경로로** 받아 봉인한다.
#    PATH 조회는 폐기됐다 (러너가 더 이상 command -v 를 쓰지 않는다).
: "${VASP_LAUNCHER_KIND:?VASP_LAUNCHER_KIND=mpirun|mpiexec|srun|none|wrapper 를 주세요}"
case "$VASP_LAUNCHER_KIND" in
  mpirun|mpiexec|srun)
    : "${LAUNCHER_BIN:?KIND=$VASP_LAUNCHER_KIND 면 LAUNCHER_BIN=/abs/path/to/$VASP_LAUNCHER_KIND 가 필요합니다 (PATH 에서 찾지 않습니다)}"
    case "$LAUNCHER_BIN" in /*) : ;; *) echo "⛔ LAUNCHER_BIN 은 절대경로여야 합니다: $LAUNCHER_BIN"; exit 1 ;; esac
    [ -x "$LAUNCHER_BIN" ] || { echo "⛔ LAUNCHER_BIN 이 실행파일이 아닙니다: $LAUNCHER_BIN"; exit 1; }
    LAUNCHER_SHA=$(sha256sum "$LAUNCHER_BIN" | cut -d" " -f1); export LAUNCHER_SHA LAUNCHER_BIN ;;
  none)    export LAUNCHER_BIN=""; export LAUNCHER_SHA="" ;;
  wrapper) : "${VASP_WRAPPER:?KIND=wrapper 면 VASP_WRAPPER 절대경로가 필요합니다}"
           export LAUNCHER_BIN=""; export LAUNCHER_SHA="" ;;
  *) echo "⛔ 모르는 VASP_LAUNCHER_KIND: $VASP_LAUNCHER_KIND"; exit 1 ;;
esac
export VASP_LAUNCHER_KIND

# ⛔⛔ 회신 AT P0-6 (2026-08-31) — 이 스크립트도 **번들 전역 lock** 에 참여한다.
#   종전엔 러너만 잠갔고 봉인기·attestation 생성기는 그냥 들어왔다. 같은 번들의
#   POTCAR·봉인 파일을 동시에 만지면 서로를 덮는다.
#   러너가 이미 쥐고 부르는 경우(BUNDLE_LOCK_HELD=1)는 다시 잡지 않는다 (교착 방지).
_LOCK=".lock_bundle"
_LOCK_MINE=""
if [ "${BUNDLE_LOCK_HELD:-0}" != "1" ]; then
  _RUNID="$(hostname)|$$|$(basename "$0")|$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  _T="$_LOCK.tmp.$$"
  printf '%s\n' "$_RUNID" > "$_T" || exit 3
  if ! ln "$_T" "$_LOCK" 2>/dev/null; then
    rm -f "$_T"
    echo "⛔ 이 번들에 다른 실행이 있습니다: $(cat "$_LOCK" 2>/dev/null)"
    echo "   같은 번들에서 동시에 돌리지 마세요 (POTCAR·봉인을 공유합니다)."
    exit 3
  fi
  rm -f "$_T"; _LOCK_MINE="$_RUNID"
fi
_unlock_self() { [ -n "$_LOCK_MINE" ] && [ "$(cat "$_LOCK" 2>/dev/null)" = "$_LOCK_MINE" ] \
                   && rm -f "$_LOCK"; return 0; }
# ⛔ 회신 BA P1 — unlock 을 kill 보다 **먼저** (stale lock 방지)
_bail_self() { echo ""; echo "⛔ 신호($1) — 중단합니다."; trap - EXIT INT TERM
               _unlock_self; kill -TERM 0 2>/dev/null || true; exit "$2"; }
trap '_unlock_self' EXIT
trap '_bail_self INT 130' INT
trap '_bail_self TERM 143' TERM

# ⛔ 회신 AR P0-6 — 받은 **정확한 ZIP** 과 결박한다. 번들 안에는 자기 해시를 넣을
#   수 없으므로 현장이 받은 ZIP 에서 직접 계산해 여기서 박는다:
#     BUNDLE_ZIP_SHA256=$(sha256sum sdcp_c12_vNN.zip | cut -d" " -f1)
: "${BUNDLE_ZIP_SHA256:?BUNDLE_ZIP_SHA256=\$(sha256sum <받은 zip> | cut -d' ' -f1) 를 주세요}"
case "$BUNDLE_ZIP_SHA256" in
  [0-9a-f][0-9a-f]*) [ ${#BUNDLE_ZIP_SHA256} -eq 64 ] || {
      echo "⛔ BUNDLE_ZIP_SHA256 이 64자리 hex 가 아닙니다"; exit 1; } ;;
  *) echo "⛔ BUNDLE_ZIP_SHA256 이 64자리 hex 가 아닙니다"; exit 1 ;;
esac
printf '%s\n' "$BUNDLE_ZIP_SHA256" > ZIP_SHA256.txt
SEAL=POTCAR_ROOT_SEAL.json

# ── AP #7 ① 최초 봉인 전에 **생산 산출물이 있으면 거부** ────────────────
if [ ! -f "$SEAL" ]; then
  prod=$(find . \( -name OUTCAR -o -name "OUTCAR.gz" -o -name vasprun.xml \
                   -o -name OSZICAR -o -name CONTCAR -o -name WAVECAR \
                   -o -name CHGCAR \) -print -quit 2>/dev/null || true)
  if [ -n "$prod" ]; then
    echo "생산 산출물이 이미 있습니다: $prod"
    echo "  최초 root 봉인은 **첫 VASP 실행 전에만** 만들 수 있습니다."
    echo "  계산 뒤에 만든 봉인은 사전 승인과 구별되지 않습니다 (회신 AP #7)."
    exit 1
  fi
fi

# ── AP #7 ② / 🔴🔴 회신 AT P0-3 — POTCAR 를 **매번 PP 원본에서 다시 조립**한다 ──
#    종전엔 기존 provenance 의 `allowlist_sha256` 만 맞으면 `continue` 로 건너뛰었다.
#    그래서 **가짜 POTCAR + 자기일관적인 가짜 provenance** 를 미리 놔두면 PP 원본이
#    아예 없어도 봉인이 성공했다 (리뷰어가 재현). 기존 산출물을 신뢰하는 검사는
#    검사가 아니다 — 봉인은 매번 **원본에서** 다시 만들어 대조한다.
AL_SHA=$(sha256sum "$POTCAR_ALLOWLIST" | cut -d" " -f1)
[ -d "$PP" ] || { echo "⛔ PP 트리가 없습니다: $PP — 원본 없이 봉인하지 않습니다"; exit 1; }
n_new=0; n_same=0; n_fix=0
#: 기존 봉인 — 있으면 조립본을 **덮지 않는다** (회신 BC P1)
_SEAL_FILE="POTCAR_ROOT_SEAL.json"
#: ⛔⛔ 회신 BD P0-5 (2026-09-02) — **실패가 기존 증거를 부분 변경했다.**
#:   allowlist 에 주석만 더해 SEAL 을 다시 돌리니 최종 rc=1 인데 잡별
#:   `POTCAR_PROVENANCE.json` 은 **이미 새 값으로 덮였고** 기존 root seal 은 남아
#:   트리가 반쯤 바뀐 상태가 됐다. 쓰기가 앞이고 불변량 검사가 뒤였기 때문이다.
#:   ⇒ 손대기 **전에** 원본을 백업하고, 어디서 실패하든 **전부 복원**한다.
#:     성공해야만 백업을 버린다 — 실패 시 트리는 byte-identical 이다.
#:   ⚠ 조립본을 별도 트리에 모으는 방식도 시도했으나, 봉인 스크립트가 잡 폴더를
#:     glob 하는 구조라 전부 어긋났다 (2026-09-02 실측). 백업/복원이 같은 보증을
#:     주면서 구조를 덜 흔든다.
_BK=".potcar_backup"
_backup_job() {
  mkdir -p "$1/$_BK"
  for _f in POTCAR POTCAR_PROVENANCE.json; do
    [ -f "$1/$_f" ] && cp -p "$1/$_f" "$1/$_BK/$_f"
  done
  return 0
}
_restore_all() {
  local _n=0 _b _jd _f
  for _b in */*/"$_BK"; do
    [ -d "$_b" ] || continue
    _jd=$(dirname "$_b")
    for _f in POTCAR POTCAR_PROVENANCE.json; do
      if [ -f "$_b/$_f" ]; then cp -p "$_b/$_f" "$_jd/$_f"; else rm -f "$_jd/$_f"; fi
    done
    rm -rf "$_b"; _n=$((_n+1))
  done
  [ "$_n" != 0 ] && echo "  ↩ $_n 잡을 **손대기 전 상태로** 복원했습니다 (BD P0-5)"
  return 0
}
_drop_backups() { local _b; for _b in */*/"$_BK"; do [ -d "$_b" ] && rm -rf "$_b"; done; return 0; }
trap "_restore_all 2>/dev/null || true" EXIT
for d in */*/; do
  [ -f "$d/POTCAR_ASSEMBLE.sh" ] || continue
  prev=""
  if [ -f "$d/POTCAR" ]; then prev=$(sha256sum "$d/POTCAR" | cut -d" " -f1); fi
  # ⛔⛔ 회신 BC P1 (2026-09-02) — **먼저 지우고 조립했다.** 2단계에서 다시 부르면
  #   1단계 산출물(POTCAR·provenance)이 이미 덮인 뒤에야 봉인과 대조했고, 다르면
  #   그때 죽었다 — 즉 **되돌릴 수 없는 상태로 만들어 놓고** 판정했다.
  #   ⇒ 임시 폴더에 조립 → 기존 봉인/기존 파일과 대조 → 통과할 때만 채택.
  _backup_job "$d"                      # 회신 BD P0-5 — 손대기 전에 원본을 뜬다
  _tmp="$d/.potcar_stage"; rm -rf "$_tmp"; mkdir -p "$_tmp"
  cp "$d/POTCAR_ASSEMBLE.sh" "$_tmp/"
  ( cd "$_tmp" && PP="$PP" POTCAR_ALLOWLIST="$POTCAR_ALLOWLIST" bash POTCAR_ASSEMBLE.sh ) \
    || { echo "⛔ POTCAR 조립 실패: $d (PP 원본·allowlist 를 확인하세요)"; \
         rm -rf "$_tmp"; exit 1; }
  now=$(sha256sum "$_tmp/POTCAR" | cut -d" " -f1)
  n_new=$((n_new+1))
  if [ -n "$prev" ]; then
    if [ "$prev" = "$now" ]; then n_same=$((n_same+1))
    else
      # ⛔ 기존 봉인이 있으면 **덮지 않는다** — 봉인이 그 잡의 조립본을 이미
      #   결박했으므로, 다른 조립본이 나오는 것은 환경이 바뀌었다는 뜻이다.
      if [ -f "$_SEAL_FILE" ]; then
        echo "  ⛔ $d: 재조립본이 **기존 POTCAR 와 다른데 봉인이 이미 있습니다**"
        echo "     기존 ${prev:0:16}… ≠ 재조립 ${now:0:16}…"
        echo "     1단계 산출물을 덮지 않습니다 — PP 원본·allowlist 가 바뀌었는지"
        echo "     확인하십시오 (회신 BC P1)."
        rm -rf "$_tmp"; exit 1
      fi
      n_fix=$((n_fix+1))
      echo "  🔴 $d: 있던 POTCAR 가 원본 재조립본과 **다릅니다** (봉인 전이라 채택)"
      echo "     이전 ${prev:0:16}… → 재조립 ${now:0:16}…"
    fi
  fi
  # ⛔⛔ 회신 BD P0-5 (2026-09-02) — **실패가 기존 증거를 부분 변경했다.**
  #   allowlist 에 주석만 더해 SEAL 을 다시 돌리니 최종 rc=1 인데 잡별
  #   `POTCAR_PROVENANCE.json` 은 **이미 새 값으로 덮였고** 기존 root seal 은 남아
  #   트리가 반쯤 바뀐 상태가 됐다. 쓰기가 앞이고 불변량 검사가 뒤였기 때문이다.
  #   ⇒ **전부 임시영역에 모아 두고**, 불변량 검사를 통과한 뒤 한 번에 채택한다.
  #     여기서는 아직 채택하지 않는다 (아래 `_commit_staged` 가 한다).
  # 채택 — 백업을 이미 떠 뒀으므로 어디서 실패해도 trap 이 전부 되돌린다
  mv -f "$_tmp/POTCAR" "$d/POTCAR"
  [ -f "$_tmp/POTCAR_PROVENANCE.json" ] \
    && mv -f "$_tmp/POTCAR_PROVENANCE.json" "$d/POTCAR_PROVENANCE.json"
  rm -rf "$_tmp"
  # ③ PP **원본 파일 자체**를 독립 검증한다 — provenance 를 되읽어 확인하지 않고,
  #    거기 적힌 source 경로를 PP 아래에서 직접 열어 SHA·TITEL·allowlist 를 다시 잰다.
  ( cd "$d" && PP="$PP" AL="$POTCAR_ALLOWLIST" python3 - <<'PYSRC'
# 🔴 회신 AT P0-3 — provenance 를 **되읽어 확인하지 않는다.** 거기 적힌 variant 로
#   PP 원본을 직접 열어 SHA·TITEL·allowlist 결박을 **다시 계산**한다.
import hashlib, json, os, re, sys
d = json.load(open("POTCAR_PROVENANCE.json"))
pp, al = os.environ["PP"], os.environ["AL"]
if d.get("allowlist_waived"):
    sys.exit("\u26d4 allowlist 면제 provenance 입니다 — 이 계약에서 폐지됐습니다")
vs = d.get("expected_variants") or []
src = d.get("source_sha256") or {}
if not vs:
    sys.exit("\u26d4 provenance 에 expected_variants 가 없습니다 — 원본을 대조할 수 없습니다")
alines = [ln.strip() for ln in open(al) if ln.strip() and not ln.startswith("#")]
tit = d.get("titel_lines") or []
for i, v in enumerate(vs):
    f = os.path.join(pp, v, "POTCAR")
    if not os.path.isfile(f):
        sys.exit("\u26d4 PP 원본이 없습니다: %s — 원본 없이 봉인하지 않습니다" % f)
    raw = open(f, "rb").read()
    h = hashlib.sha256(raw).hexdigest()
    if v in src and h != src[v]:
        sys.exit("\u26d4 %s 원본 SHA 불일치 (지금 %s / provenance %s)"
                 % (v, h[:16], str(src[v])[:16]))
    # allowlist 는 `sha256  <경로>/<variant>/POTCAR` 형식 — **해시와 variant 가
    # 한 줄에 묶여** 있어야 한다 (해시만 맞고 이름이 다르면 다른 PP 다)
    pat = re.compile(r"^%s\s+.*(?:^|[/\s])%s(?:[/\s]|$)" % (re.escape(h), re.escape(v)))
    if not any(pat.search(ln) for ln in alines):
        sys.exit("\u26d4 %s(%s…) 가 allowlist 에 그 해시로 묶여 있지 않습니다"
                 % (v, h[:16]))
    t = re.search(rb"TITEL\s*=\s*(.+)", raw[:4000])
    if t is None:
        sys.exit("\u26d4 %s 원본에 TITEL 이 없습니다" % v)
    tt = t.group(1).decode("utf-8", "replace").strip()
    if v not in tt.split():
        sys.exit("\u26d4 %s 원본 TITEL 에 그 variant 토큰이 없습니다: %r" % (v, tt))
    if i < len(tit) and tt not in tit[i]:
        sys.exit("\u26d4 %s TITEL 이 provenance 기록과 다릅니다 (원본 %r / 기록 %r)"
                 % (v, tt, tit[i]))
PYSRC
  ) || { echo "⛔ PP 원본 독립검증 실패: $d"; exit 1; }
done
echo "  POTCAR 재조립 $n_new 잡 (이전과 동일 $n_same · 달라서 교체 $n_fix)"
echo "  ✔ PP 원본 SHA·TITEL·allowlist 를 잡마다 **독립 재계산**했습니다 (회신 AT P0-3)"

# ── AP #7 ③ 봉인에 무엇을 담는가 ────────────────────────────────────────
VASP_BIN=$(command -v "${VASP_EXE:-vasp_std}" 2>/dev/null || true)
VASP_SHA=""; VASP_VER=""
if [ -n "$VASP_BIN" ]; then
  VASP_SHA=$(sha256sum "$VASP_BIN" | cut -d" " -f1)
  # 🔴🔴 회신 BH P0-1 (2026-09-03) — **첫 줄은 버전이 아니다.**
  #   종전: `"$VASP_BIN" --version 2>&1 | head -1`.
  #   VASP 는 argv 를 해석하지 않으므로 `--version` 은 그냥 기동이고, 실물 stdout 의
  #   첫 줄은 ` running on N total cores` 다 (버전은 대략 5번째 줄).
  #   그래서 봉인에 버전이 아닌 줄이 박히고, 1단계(최장 ~300 h)를 다 태운 뒤
  #   분석기가 OUTCAR 의 실제 버전과 대조하다 ROOT_SEAL_VASP_MISMATCH 로 전건을 닫는다.
  #   봉인·분석기는 files_sha256 에 결박돼 현장에서 고칠 수도 없다.
  #   🔴🔴 렌즈1′ P1-1 (2026-09-03) — **행 앵커가 없으면 fail-closed 가 뚫린다.** VASP 표준
  #     설치 경로가 `…/vasp.6.4.3/bin/vasp_std` 라, 기동 실패 메시지가 그 경로를 되울리면
  #     (`timeout: failed to run command '/opt/vasp.6.4.9/bin/vasp_std'` · ld.so
  #     `…/vasp_std: error while loading shared libraries`) 토큰이 잡혀 **VASP 가 한 줄도
  #     안 돌았는데 봉인이 통과**한다. 게다가 디렉터리명이 실제 빌드와 다르면 300 h 뒤
  #     ROOT_SEAL_VASP_MISMATCH — BH P0-1 이 막으려던 바로 그 사고다.
  #     ⇒ **행 시작**(Fortran list-directed 출력의 선행 공백 허용)으로 앵커한다. 경로 에코는
  #       토큰이 행 중간이라 안 걸린다.
  #   ⇒ **출력 전체**에서 행두 `vasp.<버전>` 토큰을 찾고, 못 찾으면 **봉인을 거부**한다
  #     (비용 발생 **전에** 멈춘다 — fail-closed).
  #   ⚠ 임시 디렉터리에서 기동한다: VASP 는 실행되면 그 자리에 OUTCAR 등을 남기고,
  #     번들 루트에 남으면 이후 attestation 의 `find -name OUTCAR` 가 거부한다.
  _vprobe_d=$(mktemp -d)
  # ⚠ ASE 실물 표본의 stdout 순서: `running on` → `distrk` → `distr` → **`using from now: INCAR`**
  #   → `vasp.6.1.2 …`. 즉 VASP 는 INCAR 을 연 **뒤에** 버전을 찍는다. 빈 폴더에서 띄우면
  #   INCAR 부재로 버전 전에 죽을 수 있고, 그러면 봉인이 **항상** 거부된다 (fail-closed 지만
  #   쓸 수 없는 상태). 빈 INCAR 을 놓아 그 분기를 없앤다 — POSCAR·POTCAR 부재 오류는 버전
  #   줄 **뒤**에 나므로 무관하다. (실물 VASP 로 검증하지 못한 추론 — 표본 순서에 근거.)
  : > "$_vprobe_d/INCAR"
  VASP_VER=$( (cd "$_vprobe_d" && timeout 120 "$VASP_BIN" 2>&1 || true) \
              | grep -a -m1 -oE '^[[:space:]]*vasp\.[0-9][A-Za-z0-9._-]*' \
              | tr -d '[:space:]' || true )
  rm -rf "$_vprobe_d"
  if [ -z "$VASP_VER" ]; then
    echo "⛔ VASP 버전을 관측하지 못했습니다 — 봉인하지 않습니다 (회신 BH P0-1)."
    echo "   \`$VASP_BIN\` 를 인자 없이 실행한 출력에서 'vasp.<버전>' 패턴을 못 찾았습니다."
    echo "   확인: cd \$(mktemp -d) && $VASP_BIN 2>&1 | head -20"
    echo "   그 출력을 보내 주시면 규칙을 맞춰 다시 만들어 드립니다."
    echo "   (여기서 멈추는 이유: 잘못된 배너를 봉인하면 1단계 전체(수백 h)를 태운 뒤에야"
    echo "    ROOT_SEAL_VASP_MISMATCH 로 전건이 막히고, 그때는 번들 재발급밖에 없습니다.)"
    exit 1
  fi
fi
# 🔴 회신 AV Q5 — 목록 밖 launcher 는 해시로 봉인한 wrapper 로만. 봉인 시점에
#   wrapper 를 받았으면 해시를 함께 박는다 (실행 직전 재대조는 run_staged 가 한다).
WRAP_SHA=""
if [ -n "${VASP_WRAPPER:-}" ] && [ -f "${VASP_WRAPPER:-}" ]; then
  WRAP_SHA=$(sha256sum "$VASP_WRAPPER" | cut -d" " -f1)
fi
export AL_SHA VASP_BIN VASP_SHA VASP_VER BUNDLE_ZIP_SHA256 VASP_WRAPPER WRAP_SHA
python3 - <<'PYSEAL'
import json, glob, os, re, sys, hashlib, time
seal, asm, conflict = {}, {}, []
for pp in sorted(glob.glob("*/*/POTCAR_PROVENANCE.json")):
    d = json.load(open(pp))
    for v, sha in (d.get("source_sha256") or {}).items():
        if v in seal and seal[v] != sha:
            conflict.append((v, pp))
        seal[v] = sha
    asm[os.path.dirname(pp)] = d.get("assembled_sha256")
if conflict:
    sys.exit("variant 원본 SHA 가 잡마다 다르다 — 한 트리가 아니다: %s" % conflict[:3])
if not seal:
    sys.exit("조립된 POTCAR provenance 가 하나도 없다")
rec = {
    "schema": "potcar_root_seal/v2",
    "source_sha256": seal,
    "assembled_sha256_by_job": asm,
    "allowlist_sha256": os.environ.get("AL_SHA") or None,
    "manifest_sha256": hashlib.sha256(open("MANIFEST.json", "rb").read()).hexdigest(),
    "vasp_executable": os.environ.get("VASP_BIN") or None,
    "vasp_executable_sha256": os.environ.get("VASP_SHA") or None,
    "vasp_version_banner": os.environ.get("VASP_VER") or None,
    "launcher_wrapper": os.environ.get("VASP_WRAPPER") or None,
    "launcher_wrapper_sha256": os.environ.get("WRAP_SHA") or None,
    # ⛔⛔ 2026-09-01 (회신 AY P0-1) — **named launcher 도 봉인한다.**
    #   종전엔 wrapper 만 봉인하고 mpirun/mpiexec/srun 은 러너가 PATH 에서 찾았다.
    #   PATH 앞에 가짜 mpirun 을 두면 봉인된 VASP_EXE 를 인자로 받고도 무시하고
    #   다른 실행파일을 돌릴 수 있었다 — 봉인이 반쪽이었다.
    "launcher_kind": os.environ.get("VASP_LAUNCHER_KIND") or None,
    "launcher_path": os.environ.get("LAUNCHER_BIN") or None,
    "launcher_sha256": os.environ.get("LAUNCHER_SHA") or None,
    "bundle_zip_sha256": os.environ.get("BUNDLE_ZIP_SHA256") or None,
    "sealed_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "sealed_before_production": True,
    "sealed_before_production_evidence":
        "봉인 시점에 OUTCAR/vasprun/OSZICAR/CONTCAR/WAVECAR/CHGCAR 가 하나도 없었다 "
        "(SEAL_POTCAR_ROOT.sh 가 검사하고 있으면 거부한다)",
    "note": ("v13/v14 Hamiltonian root. 전 잡의 provenance 가 이것과 같아야 한다. "
             "이전 wave 와의 수치적 동등성은 주장하지 않는다. 공식 release 여부는 "
             "이 봉인이 보증하지 않는다 — POTCAR_ATTESTATION.json 이 그 몫이다."),
}
out = "POTCAR_ROOT_SEAL.json"
if os.path.exists(out):
    old = json.load(open(out))
    diff = sorted(k for k in set(old.get("source_sha256") or {}) | set(seal)
                  if (old.get("source_sha256") or {}).get(k) != seal.get(k))
    if diff:
        sys.exit("이미 봉인된 root 와 다르다 (봉인은 바꾸지 않는다): %s" % diff)
    # ⛔⛔ 회신 AS 해제조건 4 (2026-08-31) — 종전 재대조는 **source 집합과
    #   allowlist 만** 봤다. 조립본 해시·MANIFEST·ZIP·VASP 신원이 바뀌어도
    #   "대조 통과" 가 찍혔다. 봉인의 **모든 불변량**을 다시 확인한다.
    bad = []
    # 🔴🔴 회신 AT P0-4 (2026-08-31) — 위 재대조가 **타입과 정체 필드를 안 봤다.**
    #   위조 schema · 문자열형 `sealed_before_production` ("true"/"yes" 는 파이썬에서
    #   참이다) · evidence/시각 변조가 전부 통과했다. 셋을 **정확히** 본다.
    if old.get("schema") != rec["schema"]:
        bad.append("schema: 봉인 %r ≠ 이 도구 %r (다른 스키마의 봉인을 이어쓰지 않는다)"
                   % (old.get("schema"), rec["schema"]))
    if old.get("sealed_before_production") is not True:
        bad.append("sealed_before_production 이 **불리언 True 가 아니다** (%r) — "
                   "문자열은 참으로 읽히지만 봉인이 아니다"
                   % (old.get("sealed_before_production"),))
    _ev = old.get("sealed_before_production_evidence")
    if not isinstance(_ev, str) or not _ev.strip():
        bad.append("sealed_before_production_evidence 가 비어 있거나 문자열이 아니다 (%r)"
                   % (_ev,))
    elif _ev.strip() != rec["sealed_before_production_evidence"].strip():
        bad.append("sealed_before_production_evidence 가 이 도구의 문구와 다르다 — "
                   "손으로 쓴 근거는 근거가 아니다")
    _at = old.get("sealed_at_utc")
    if not isinstance(_at, str) or not re.match(
            r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", _at or ""):
        bad.append("sealed_at_utc 가 `YYYY-MM-DDTHH:MM:SSZ` 형식이 아니다 (%r)" % (_at,))
    elif _at > rec["sealed_at_utc"]:
        bad.append("sealed_at_utc 가 **미래**다 (봉인 %s > 지금 %s)"
                   % (_at, rec["sealed_at_utc"]))
    # ⛔⛔ 회신 AZ P0-2 (2026-09-01) — **launcher 3종을 불변량 목록에 넣는다.**
    #   AY P0-1 이 launcher_kind/path/sha256 을 봉인에 **쓰기만** 하고, 재대조
    #   목록에는 안 넣었다. 그래서 봉인이 `mpirun` 인데 다음 단계에서 kind 를
    #   바꿔도 "대조 통과" 가 찍혔다 (리뷰어가 kind=none 으로 재현).
    # 🔴 회신 BH P0-1 — `vasp_version_banner` 는 **원문 정확일치로 보지 않는다.**
    #   배너 줄에 host·PID·타임스탬프가 섞이는 사이트면 2단계 SEAL 재실행에서
    #   "봉인 ≠ 지금" 으로 죽는다. 불변량은 배너 원문이 아니라 **버전 토큰**이다.
    # 🔴 렌즈1′ P1-1 (2026-09-03) — 행 앵커. 경로 에코(`…/vasp.6.4.3/bin/vasp_std`)를
    #   버전 토큰으로 읽지 않는다. 봉인 배너는 토큰 하나이거나 선행 공백 있는 배너 줄이다.
    _VT_RE = r"(?m)^[ \t]*vasp\.[0-9][A-Za-z0-9._-]*"
    _vt = lambda x: ((re.search(_VT_RE, str(x or "")) or [None]))
    _v_old = re.search(_VT_RE, str(old.get("vasp_version_banner") or ""))
    _v_new = re.search(_VT_RE, str(rec.get("vasp_version_banner") or ""))
    if (_v_old.group(0).strip() if _v_old else None) != (
            _v_new.group(0).strip() if _v_new else None):
        bad.append("VASP 버전 토큰이 다르다 (봉인 %r ≠ 지금 %r) — 다른 코드 세대다"
                   % (_v_old.group(0) if _v_old else None,
                      _v_new.group(0) if _v_new else None))
    for k in ("allowlist_sha256", "manifest_sha256", "bundle_zip_sha256",
              "vasp_executable", "vasp_executable_sha256",
              "launcher_kind", "launcher_path", "launcher_sha256"):
        # launcher_path/sha 는 kind=none|wrapper 면 비어 있는 것이 정상이다 —
        # 그때는 **양쪽 다 비어 있어야** 한다 (한쪽만 비면 아래 불일치로 잡힌다).
        if (old.get(k) or "") != (rec.get(k) or ""):
            bad.append("%s: 봉인 %r ≠ 지금 %r"
                       % (k, str(old.get(k))[:24], str(rec.get(k))[:24]))
        if not old.get(k) and k not in ("launcher_path", "launcher_sha256"):
            bad.append("%s: 기존 봉인에 없다 — 반쪽 봉인이다" % k)
    if not old.get("launcher_kind"):
        bad.append("launcher_kind: 기존 봉인에 없다 — AY P0-1 이전 판이다 "
                   "(SEAL 을 VASP_LAUNCHER_KIND·LAUNCHER_BIN 과 함께 다시 만들 것)")
    if (old.get("launcher_kind") or "") in ("mpirun", "mpiexec", "srun") \
            and not (old.get("launcher_path") and old.get("launcher_sha256")):
        bad.append("launcher_kind=%s 인데 launcher_path/sha256 이 비었다 — 반쪽 봉인이다"
                   % old.get("launcher_kind"))
    oa, na = (old.get("assembled_sha256_by_job") or {}), (rec.get("assembled_sha256_by_job") or {})
    if not oa:
        bad.append("assembled_sha256_by_job: 기존 봉인에 없다")
    else:
        adiff = sorted(k for k in set(oa) | set(na) if oa.get(k) != na.get(k))
        if adiff:
            bad.append("조립본 해시가 바뀐 잡 %d개: %s" % (len(adiff), adiff[:3]))
    if bad:
        print("⛔ 기존 봉인과 지금 상태가 다릅니다 — 봉인은 바꾸지 않습니다:")
        for b in bad:
            print("   · " + b)
        sys.exit(1)
    print("  POTCAR root 봉인 대조 통과 (%d variant · 조립본 %d잡 · allowlist·MANIFEST·"
          "ZIP·VASP 신원 전건 일치)" % (len(seal), len(na)))
else:
    json.dump(rec, open(out, "w"), indent=1, ensure_ascii=False)
    print("  POTCAR root 봉인 생성 (%d variant · allowlist %s · vasp %s)"
          % (len(seal), str(rec["allowlist_sha256"])[:12],
             str(rec["vasp_version_banner"])[:24]))
PYSEAL
_seal_rc=$?
if [ "$_seal_rc" != 0 ]; then
  echo "⛔ 봉인 단계 실패 (rc=$_seal_rc) — **트리를 손대기 전으로 되돌립니다**"
  _restore_all
  trap - EXIT
  exit "$_seal_rc"
fi
# ⛔ 회신 BD P0-5 — 불변량 검사가 전부 통과했다. 이제 백업을 버린다.
trap - EXIT
_drop_backups
echo "  ✔ 봉인 통과 — 조립본을 확정했습니다 (실패했다면 트리가 그대로 남습니다)"
