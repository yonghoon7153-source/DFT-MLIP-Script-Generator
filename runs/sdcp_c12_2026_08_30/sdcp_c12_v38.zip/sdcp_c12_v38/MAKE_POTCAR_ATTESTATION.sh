#!/usr/bin/env bash
# 회신 AP #12 — 계산 **전에** release attestation 을 만든다. POTCAR 원문은 담지 않는다.
set -e
: "${PP:?PP=/path/to/potpaw_PBE.54}"
: "${POTCAR_ALLOWLIST:?POTCAR_ALLOWLIST=/abs/site_allow.txt}"
: "${RELEASE_LABEL:?RELEASE_LABEL='potpaw_PBE.54' 처럼 배포판 이름}"
: "${SITE:?SITE='기관/담당자'}"
# ⛔ 회신 AR P0-6 — 봉인과 **같은 출처**의 ZIP 해시를 쓴다 (문자열 하나).
#   종전엔 스크립트가 근처 *.zip 을 스스로 찾아 {파일명: sha} 사전을 만들었다 —
#   무엇에 대한 attestation 인지 모호하고 분석기와 형이 달랐다.
: "${BUNDLE_ZIP_SHA256:?BUNDLE_ZIP_SHA256=\$(sha256sum <받은 zip> | cut -d' ' -f1)}"

# ⛔⛔ 회신 AT P0-6 (2026-08-31) — attestation 생성기도 **번들 전역 lock** 에
#   참여한다. 종전엔 러너만 잠갔고 이 스크립트는 그냥 들어와 같은 번들의 파일을
#   동시에 만질 수 있었다.
_LOCK=".lock_bundle"
_LOCK_MINE=""
if [ "${BUNDLE_LOCK_HELD:-0}" != "1" ]; then
  _RUNID="$(hostname)|$$|make_attestation|$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  _T="$_LOCK.tmp.$$"
  printf '%s\n' "$_RUNID" > "$_T" || exit 3
  if ! ln "$_T" "$_LOCK" 2>/dev/null; then
    rm -f "$_T"
    echo "⛔ 이 번들에 다른 실행이 있습니다: $(cat "$_LOCK" 2>/dev/null)"
    exit 3
  fi
  rm -f "$_T"; _LOCK_MINE="$_RUNID"
fi
_unlock_self() { [ -n "$_LOCK_MINE" ] && [ "$(cat "$_LOCK" 2>/dev/null)" = "$_LOCK_MINE" ] \
                   && rm -f "$_LOCK"; return 0; }
_bail_self() { echo ""; echo "⛔ 신호($1) — 중단합니다."; trap - EXIT INT TERM
               kill -TERM 0 2>/dev/null || true; _unlock_self; exit "$2"; }
trap '_unlock_self' EXIT
trap '_bail_self INT 130' INT
trap '_bail_self TERM 143' TERM

# ⛔ 회신 AR P0-6 — `made_before_production` 을 **자기선언이 아니라 산출물 부재로**
#   입증한다. 하나라도 있으면 계산 전이 아니므로 거부한다.
PROD=$(find . \( -name OUTCAR -o -name "OUTCAR.gz" -o -name vasprun.xml \
                 -o -name OSZICAR -o -name CONTCAR -o -name WAVECAR \
                 -o -name CHGCAR \) -print -quit 2>/dev/null || true)
if [ -n "$PROD" ]; then
  echo "⛔ 생산 산출물이 이미 있습니다: $PROD"
  echo "   attestation 은 **첫 VASP 실행 전에만** 만들 수 있습니다 (회신 AR P0-6)."
  exit 1
fi
# ⛔ 회신 BA 해제조건 8 (2026-09-02) — **PATH 조회 폐기.** 봉인·러너는 이미 절대경로만
#   받는데 이 스크립트만 PATH 에서 `vasp_std` 를 찾고 있었다 (같은 우회가 여기 남았다).
: "${VASP_EXE:?VASP_EXE=/abs/path/to/vasp_std 를 주세요 (PATH 에서 찾지 않습니다)}"
case "$VASP_EXE" in /*) : ;; *) echo "⛔ VASP_EXE 는 절대경로여야 합니다: $VASP_EXE"; exit 2 ;; esac
[ -x "$VASP_EXE" ] || { echo "⛔ VASP_EXE 가 실행파일이 아닙니다: $VASP_EXE"; exit 2; }
VASP_BIN="$VASP_EXE"
export VASP_BIN BUNDLE_ZIP_SHA256
python3 - <<'PYA'
import json, os, hashlib, time, subprocess
man = json.load(open("MANIFEST.json"))
spec = man.get("potcar_spec") or {}
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()
pp = os.environ["PP"]
variants = {}
for el, var in sorted(spec.items()):
    f = os.path.join(pp, var, "POTCAR")
    if not os.path.isfile(f):
        raise SystemExit("원본 POTCAR 가 없다: %s" % f)
    titel, emb = [], []
    for ln in open(f, errors="replace"):
        t = ln.strip()
        if t.startswith("TITEL"):
            titel.append(t)
        if "SHA256" in t or t.startswith("COPYR") and "hash" in t.lower():
            emb.append(t)
        if len(titel) and ln.startswith("   END of PSCTR"):
            break
    # ⛔ 회신 AR P0-6 — 분석기가 관측 TITEL 과 대조하므로 **문자열 하나**로 낸다
    variants[var] = {"element": el, "source_sha256": sha(f),
                     "titel": (titel[0] if titel else ""),
                     "titel_all": titel[:2],
                     "embedded_hash": (emb[0] if emb else ""),
                     "embedded_hash_lines": emb[:2]}
    if not titel:
        raise SystemExit("TITEL 을 못 읽었다: %s" % f)
vb = os.environ["VASP_BIN"]
# 🔴🔴 렌즈4 P0-1 (2026-09-03) — 종전엔 `vasp --version` 의 stdout **전체**를 **번들
#   루트에서** 받았다. (a) 봉인(SEAL, v34 BH P0-1)은 `vasp.<버전>` 토큰만 담으므로 여러 줄
#   원문은 토큰의 부분문자열일 수 없어 분석기가 **항상** ATTESTATION_VASP_VERSION_MISMATCH
#   를 냈다 — 선택 attestation 을 성실히 돌린 외주처가 1단계를 다 돌린 **뒤에야** potcar_identity
#   에서 막히는 함정. (b) VASP 는 argv 를 해석하지 않고 기동하므로 번들 루트에 OUTCAR 가
#   남아 SEAL 이 "생산 산출물이 이미 있다" 로 거부할 수 있었다.
#   ⇒ SEAL 과 **같은 절차**: 임시 폴더 + 빈 INCAR + 출력 전체에서 토큰 regex. 토큰이
#     없으면 attestation 을 **만들지 않는다** (fail-closed — 잘못된 증서로 111 h 뒤 막히는
#     것보다 지금 멈추는 편이 싸다). 원문 앞 8줄은 기록용으로만 따로 둔다.
# 🔴 렌즈1′ P1-2 (2026-09-03) — SEAL 과 **같은 규칙**이어야 한다:
#   ① stderr 를 stdout 에 **병합**(SEAL 의 `2>&1`) — 따로 이어붙이면 순서가 달라져 다른
#      토큰이 잡히고, 그 차이가 111 h 뒤 ATTESTATION_VASP_VERSION_MISMATCH 로 나온다.
#   ② timeout 이면 **부분 출력을 살린다**(SEAL 은 `grep -m1` 이 이미 잡은 뒤 죽는다).
#      배너를 찍고 매달리는 빌드에서 SEAL 은 봉인하는데 MAKE 만 거부하던 비대칭.
#   ③ 행 앵커 — 경로 에코(`/opt/vasp.6.4.3/bin/vasp_std`)를 버전으로 읽지 않는다.
import re, tempfile, shutil
_pd = tempfile.mkdtemp(prefix="att_vprobe_")
try:
    open(os.path.join(_pd, "INCAR"), "w").close()
    try:
        _o = subprocess.run([vb], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, timeout=120, cwd=_pd)
        _txt = _o.stdout or ""
    except subprocess.TimeoutExpired as e:
        _txt = (e.stdout.decode("utf-8", "replace")
                if isinstance(e.stdout, bytes) else (e.stdout or ""))
    except Exception as e:
        _txt = "실행 실패: %r" % e
finally:
    shutil.rmtree(_pd, ignore_errors=True)
_m = re.search(r"(?m)^[ \t]*vasp\.[0-9][A-Za-z0-9._-]*", _txt)
if not _m:
    raise SystemExit(
        "⛔ VASP 버전 토큰('vasp.<버전>')을 관측하지 못했습니다 — attestation 을 만들지 않습니다.\n"
        "   확인: cd $(mktemp -d) && : > INCAR && %s 2>&1 | head -20\n"
        "   (봉인 SEAL_POTCAR_ROOT.sh 와 같은 규칙입니다 — 렌즈4 P0-1. 그 출력을 보내 주시면 "
        "규칙을 맞춰 다시 만들어 드립니다.)\n   관측한 출력 앞부분:\n%s"
        % (vb, "\n".join("     | " + l for l in _txt.strip().splitlines()[:8])))
ver = _m.group(0).strip()
ver_head = "\n".join(_txt.strip().splitlines()[:8])
rec = {
    "schema": "potcar_attestation/v1",
    "made_before_production": True,
    "made_before_production_evidence":
        "attestation 생성 시점에 OUTCAR/OUTCAR.gz/vasprun.xml/OSZICAR/CONTCAR/"
        "WAVECAR/CHGCAR 가 하나도 없었다 (MAKE_POTCAR_ATTESTATION.sh 가 검사하고 "
        "있으면 거부한다 — 회신 AR P0-6)",
    "release_label": os.environ["RELEASE_LABEL"],
    "site": os.environ["SITE"],
    "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "manifest_sha256": sha("MANIFEST.json"),
    "bundle_zip_sha256": os.environ["BUNDLE_ZIP_SHA256"].strip().lower(),
    "allowlist_path": os.environ["POTCAR_ALLOWLIST"],
    "allowlist_sha256": sha(os.environ["POTCAR_ALLOWLIST"]),
    "pp_root": pp,
    "variants": variants,
    "vasp_executable": vb,
    "vasp_executable_sha256": sha(vb),
    # 토큰만 — 봉인 `vasp_version_banner` 와 같은 규칙 (렌즈4 P0-1). 원문은 아래 head 로.
    "vasp_version_raw": ver,
    "vasp_version_stdout_head": ver_head,
}
json.dump(rec, open("POTCAR_ATTESTATION.json", "w"), indent=1, ensure_ascii=False)
print("→ POTCAR_ATTESTATION.json (variant %d · release %s)"
      % (len(variants), rec["release_label"]))
PYA
